# Installation — Content module

## Prerequisites

- `claudephpframework-core` installed. See its INSTALL.md.
- Core `content_items` and `content_transfer_requests` tables present —
  these ship with `database/install.sql` in the core package.
- `app/Models/Group` available (comes with core).

## Steps

1. Drop into `modules/`:

   ```bash
   unzip claudephpframework-module-content.zip
   cp -r claudephpframework-module-content/content /path/to/project/modules/
   ```

2. Run migrations (none ship today, but the Migrator discovers per-module
   migrations automatically):

   ```bash
   php artisan migrate
   ```

3. Refresh module cache if enabled:

   ```bash
   php artisan module:cache
   ```

## Environment variables

None specific to this module. If you want hosted search on content,
configure `SEARCH_PROVIDER` in core's `.env` — the module picks it up
automatically via `SearchIndexer`.

## Verification

1. Log in as an authenticated user, visit `/content/create`, submit a
   published entry.
2. Visit `/content/{your-slug}` — the entry should render publicly.
3. If you've enabled a search provider, run `php artisan search:reindex content`
   then search via the site's global search form.
