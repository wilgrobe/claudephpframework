# Architecture — Content module

## Files

```
content/
├── module.php
├── routes.php                                # 10 route registrations
├── Controllers/ContentController.php         # All CRUD + transfer flows
└── Views/
    ├── form.php        # create/edit form shared
    ├── my_content.php  # "my content" list
    ├── show.php        # public detail
    └── transfer.php    # transfer-request form
```

## Tables

From core's `install.sql`:

- `content_items` — id, title, slug, body, type, status, owner_type,
  owner_user_id, owner_group_id, created_by, seo_*, published_at,
  created_at, updated_at
- `content_transfer_requests` — id, content_item_id, requester_id,
  target_type, target_user_id, target_group_id, status, approved_by,
  created_at

## Ownership model

Each content item has exactly one owner, set by `(owner_type,
owner_user_id, owner_group_id)`:

- `owner_type = 'user'` — owned by a single user (`owner_user_id` set)
- `owner_type = 'group'` — owned by a group (`owner_group_id` set)

## Transfer flows

Three flows, differentiated by (old owner type, new owner type):

1. **group → individual** — requires the receiving user to accept AND a
   group_owner/group_admin of the source group to approve.
2. **individual → individual** — requires the receiving user to accept.
3. **anything → group** — applies immediately (no approval).

All three go through `content_transfer_requests` rows. Status transitions:
`pending` → `approved` / `declined` / `cancelled`. On approval the
content_items row's owner fields get rewritten in a single UPDATE.

## Search integration

After every insert/update/delete, `ContentController` calls
`app(SearchIndexer::class)->sync('content', $id, $prefetchedRow)`. The
indexer decides index-vs-delete based on `status='published'` and enqueues
an `IndexDocumentJob` or `DeleteDocumentJob`. The `search:reindex content`
artisan command rebuilds the whole collection.

Indexed shape: `title`, `slug`, `body` (HTML-stripped), `type`,
`published_at`. If you extend the document shape, update three places:

- `SearchService::reindexContent()` — batch reindex query + row transformer
- `SearchIndexer::buildContentDoc()` — per-save document shape
- `routes/web.php` `/search` route — the view's field references

## Authorization

- Creating content: any authenticated user (`AuthMiddleware`)
- Editing / deleting: checked via `canEdit($item)` helper — user owns the
  item OR is a group admin of the owning group OR is in superadmin mode
- Approving transfers: role-gated inside `approveTransfer()` based on the
  flow type

## Dependencies

- `claudephpframework-core` — Router, Database, Auth, View, SEO,
  SearchIndexer, Queue
- `App\Models\Group` — for the group dropdown in the create form
- Tables created by core's `database/install.sql`

## Extension hooks

- Add fields to `content_items` via a migration under
  `modules/content/migrations/`. Update the form view, the controller's
  validation, and (if the field is searchable) the doc shape in the three
  places listed above.
- Add custom content types: `content_items.type` is a freeform varchar —
  ship type-specific view renderers keyed on `$item['type']`.
