# Content module

CMS-style content items with ownership (user or group), status lifecycle
(draft/published), SEO metadata, and a multi-flow ownership-transfer
workflow. Integrates with the framework's search indexer for full-text
search across title + body.

## What you get

- Authenticated users create/edit/delete their own content items
- Content can be owned by a user or a group; members of the group can
  collaborate
- Transfer workflows:
  - **Group → individual** — requires approval from a group owner/admin
  - **Individual → individual** — requires acceptance by the recipient
  - **\* → group** — auto-applied (no approval)
- Automatic slug generation + SEO canonical path tracking (301s when slugs
  change)
- Incremental search indexing on every save (via `SearchIndexer`)

## Routes

| Method | Path                              | Middleware            | Purpose                  |
|--------|-----------------------------------|-----------------------|--------------------------|
| GET    | `/content`                        | Auth                  | My content list          |
| GET    | `/content/create`                 | Auth                  | Creation form            |
| POST   | `/content/create`                 | Csrf + Auth           | Store new content        |
| GET    | `/content/{slug}`                 | —                     | Public show page         |
| GET    | `/content/{id}/edit`              | Auth                  | Edit form                |
| POST   | `/content/{id}/edit`              | Csrf + Auth           | Save changes             |
| POST   | `/content/{id}/delete`            | Csrf + Auth           | Delete                   |
| GET    | `/content/{id}/transfer`          | Auth                  | Transfer request form    |
| POST   | `/content/{id}/transfer`          | Csrf + Auth           | Submit transfer request  |
| POST   | `/content/transfer/{reqId}/{action}` | Csrf + Auth        | Approve/decline transfer |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
