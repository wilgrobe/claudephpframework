<?php
// modules/content/module.php
use Core\Module\ModuleProvider;

/**
 * Content module — the CMS-ish content_items layer. Includes the multi-flow
 * ownership transfer workflow (group → individual requires approval,
 * individual → individual requires acceptance, * → group auto-applies).
 *
 * Depends on Group model (app/Models/Group) for the user's groups dropdown.
 * If Groups later moves out of app/ entirely, update the use statement in
 * the controller.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'content'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
