<?php
// modules/content/Controllers/ContentController.php
namespace Modules\Content\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Validation\Validator;
use Core\Database\Database;
use Core\SEO\SeoManager;
use Core\Services\NotificationService;
use App\Models\Group;

/**
 * Ported from App\Controllers\ContentController. Only changes vs the
 * original: namespace moved, Response::view() calls use the 'content::'
 * prefix. Behavior is byte-for-byte identical — the full transfer workflow
 * (group→user requires approval, user→user requires acceptance, *→group
 * auto-applies) is preserved.
 */
class ContentController
{
    private Database   $db;
    private Auth       $auth;
    private SeoManager $seo;

    public function __construct()
    {
        $this->db   = Database::getInstance();
        $this->auth = Auth::getInstance();
        $this->seo  = new SeoManager();
    }

    // ── List own content ──────────────────────────────────────────────────────

    public function myContent(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $page  = max(1, (int) $request->query('page', 1));
        $type  = $request->query('type', '');

        $myGroupIdsRows = $this->db->fetchAll(
            "SELECT group_id FROM user_groups WHERE user_id = ?",
            [$this->auth->id()]
        );
        $myGroupIds = array_map(fn($r) => (int) $r['group_id'], $myGroupIdsRows);

        $whereParts = ["(ci.owner_type = 'user' AND ci.owner_user_id = ?)"];
        $bindings   = [$this->auth->id()];
        if (!empty($myGroupIds)) {
            $ph = implode(',', array_fill(0, count($myGroupIds), '?'));
            $whereParts[] = "(ci.owner_type = 'group' AND ci.owner_group_id IN ($ph))";
            foreach ($myGroupIds as $gid) $bindings[] = $gid;
        }

        $sql = "SELECT ci.*,
                       CASE ci.owner_type
                           WHEN 'group' THEN g.name
                           ELSE CONCAT(u.first_name, ' ', u.last_name)
                       END AS owner_label
                FROM content_items ci
                LEFT JOIN `groups` g ON g.id = ci.owner_group_id
                LEFT JOIN users  u ON u.id  = ci.owner_user_id
                WHERE (" . implode(' OR ', $whereParts) . ")";

        if ($type) {
            $sql .= " AND ci.type = ?";
            $bindings[] = $type;
        }

        $data = $this->db->paginate("$sql ORDER BY ci.created_at DESC", $bindings, $page, 20);

        return Response::view('content::my_content', [
            'content'    => $data,
            'type_filter'=> $type,
            'user'       => $this->auth->user(),
        ]);
    }

    // ── Create content ────────────────────────────────────────────────────────

    public function createForm(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if ($this->auth->cannot('content.create')) return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');

        $groups = (new Group())->getUserGroups($this->auth->id());
        return Response::view('content::form', [
            'content' => null,
            'groups'  => $groups,
            'user'    => $this->auth->user(),
        ]);
    }

    public function store(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if ($this->auth->cannot('content.create')) return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');

        $v = new Validator($request->post());
        $v->validate([
            'title'      => 'required|min:2|max:500',
            'slug'       => 'required|min:2|max:500',
            'type'       => 'required|max:80',
            'owner_type' => 'required|in:user,group',
        ]);

        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            Session::flash('old', $v->all());
            return Response::redirect('/content/create');
        }

        $ownerType    = $v->get('owner_type');
        $ownerGroupId = null;
        $ownerUserId  = null;

        if ($ownerType === 'group') {
            $ownerGroupId = (int) $request->post('owner_group_id', 0);
            if (!$this->auth->inGroup($this->getGroupSlug($ownerGroupId))) {
                return Response::redirect('/content/create')->withFlash('error', 'You are not a member of that group.');
            }
        } else {
            $ownerUserId = $this->auth->id();
        }

        $sanitizedBody = Validator::sanitizeHtml($request->post('body', ''));
        $status        = $request->post('status', 'draft');
        $publishedAt   = $status === 'published' ? date('Y-m-d H:i:s') : null;

        $id = $this->db->insert('content_items', [
            'title'           => $v->get('title'),
            'slug'            => $v->get('slug'),
            'body'            => $sanitizedBody,
            'type'            => $v->get('type'),
            'status'          => $status,
            'owner_type'      => $ownerType,
            'owner_user_id'   => $ownerUserId,
            'owner_group_id'  => $ownerGroupId,
            'created_by'      => $this->auth->id(),
            'seo_title'       => $v->get('seo_title'),
            'seo_description' => $v->get('seo_description'),
            'seo_keywords'    => $v->get('seo_keywords'),
            'published_at'    => $publishedAt,
        ]);

        $this->seo->register("content/{$v->get('slug')}", "/content/{$v->get('slug')}", 'content', $id);
        // Pass the prefetched shape so SearchIndexer doesn't re-fetch what
        // we just wrote.
        app(\Core\Services\SearchIndexer::class)->sync('content', $id, [
            'id'           => $id,
            'title'        => $v->get('title'),
            'slug'         => $v->get('slug'),
            'body'         => $sanitizedBody,
            'type'         => $v->get('type'),
            'status'       => $status,
            'published_at' => $publishedAt,
        ]);

        $this->auth->auditLog('content.create', 'content_items', $id, null, [
            'title'      => $v->get('title'),
            'owner_type' => $ownerType,
        ]);

        return Response::redirect("/content/{$v->get('slug')}")->withFlash('success', 'Content created.');
    }

    // ── View content ──────────────────────────────────────────────────────────

    public function show(Request $request): Response
    {
        $slug = $request->param(0);
        $item = $this->db->fetchOne(
            "SELECT ci.*,
                    CASE ci.owner_type WHEN 'group' THEN g.name ELSE CONCAT(u.first_name,' ',u.last_name) END AS owner_label
             FROM content_items ci
             LEFT JOIN `groups` g ON g.id = ci.owner_group_id
             LEFT JOIN users  u ON u.id  = ci.owner_user_id
             WHERE ci.slug = ?",
            [$slug]
        );
        if (!$item) return new Response('Content not found', 404);

        if ($item['status'] !== 'published') {
            if ($this->auth->guest()) return Response::redirect('/login');
            $canView = ($item['owner_type'] === 'user' && (int) $item['owner_user_id'] === (int) $this->auth->id())
                || ($item['owner_type'] === 'group' && $this->auth->isGroupAdmin((int) $item['owner_group_id']))
                || $this->auth->isSuperadminModeOn();
            if (!$canView) return new Response('Access denied', 403);
        }

        return Response::view('content::show', [
            'item' => $item,
            'user' => $this->auth->user(),
        ]);
    }

    // ── Edit content ──────────────────────────────────────────────────────────

    public function editForm(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id   = (int) $request->param(0);
        $item = $this->db->fetchOne("SELECT * FROM content_items WHERE id = ?", [$id]);
        if (!$item) return new Response('Not found', 404);

        if (!$this->canEdit($item)) {
            return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');
        }

        $groups = (new Group())->getUserGroups($this->auth->id());
        return Response::view('content::form', [
            'content' => $item,
            'groups'  => $groups,
            'user'    => $this->auth->user(),
        ]);
    }

    public function update(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id   = (int) $request->param(0);
        $item = $this->db->fetchOne("SELECT * FROM content_items WHERE id = ?", [$id]);
        if (!$item) return new Response('Not found', 404);

        if (!$this->canEdit($item)) {
            return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');
        }

        $v = new Validator($request->post());
        $v->validate(['title' => 'required|min:2', 'slug' => 'required|min:2']);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect("/content/$id/edit");
        }

        $oldSlug       = $item['slug'];
        $newSlug       = $v->get('slug');
        $sanitizedBody = Validator::sanitizeHtml($request->post('body', ''));
        $newStatus     = $request->post('status', $item['status']);

        $this->db->update('content_items', [
            'title'           => $v->get('title'),
            'slug'            => $newSlug,
            'body'            => $sanitizedBody,
            'status'          => $newStatus,
            'seo_title'       => $v->get('seo_title'),
            'seo_description' => $v->get('seo_description'),
            'seo_keywords'    => $v->get('seo_keywords'),
        ], 'id = ?', [$id]);

        if ($oldSlug !== $newSlug) {
            $this->seo->redirect("content/$oldSlug", "/content/$newSlug");
            $this->seo->register("content/$newSlug", "/content/$newSlug", 'content', $id);
        }

        // Prefetched-row path — skips SearchIndexer's redundant fetchOne.
        // published_at carries forward from the original row (updating
        // content doesn't change its first-publish date).
        app(\Core\Services\SearchIndexer::class)->sync('content', $id, [
            'id'           => $id,
            'title'        => $v->get('title'),
            'slug'         => $newSlug,
            'body'         => $sanitizedBody,
            'type'         => $item['type'],
            'status'       => $newStatus,
            'published_at' => $item['published_at'] ?? null,
        ]);

        $this->auth->auditLog('content.update', 'content_items', $id);
        return Response::redirect("/content/$newSlug")->withFlash('success', 'Content updated.');
    }

    // ── Delete content ────────────────────────────────────────────────────────

    public function delete(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id   = (int) $request->param(0);
        $item = $this->db->fetchOne("SELECT * FROM content_items WHERE id = ?", [$id]);
        if (!$item) return new Response('Not found', 404);

        if (!$this->canEdit($item)) {
            return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');
        }

        $this->db->delete('content_items', 'id = ?', [$id]);
        app(\Core\Services\SearchIndexer::class)->sync('content', $id);
        $this->auth->auditLog('content.delete', 'content_items', $id);
        return Response::redirect('/content')->withFlash('success', 'Content deleted.');
    }

    // ── Ownership Transfer ────────────────────────────────────────────────────
    //
    // Three flows:
    //   group → individual  requires approval by a group_owner/group_admin
    //   individual → individual  requires acceptance by the named recipient
    //   * → group           auto-applied (no approval)

    public function transferPage(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id   = (int) $request->param(0);
        $item = $this->db->fetchOne(
            "SELECT ci.*,
                    CASE ci.owner_type WHEN 'group' THEN g.name ELSE CONCAT(u.first_name,' ',u.last_name) END AS owner_label
               FROM content_items ci
               LEFT JOIN `groups` g ON g.id = ci.owner_group_id
               LEFT JOIN users    u ON u.id = ci.owner_user_id
              WHERE ci.id = ?",
            [$id]
        );
        if (!$item) return new Response('Not found', 404);

        if (!$this->canEdit($item) && !$this->auth->isSuperadminModeOn()) {
            return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');
        }

        $pending = $this->db->fetchOne(
            "SELECT tr.*,
                    CONCAT(ru.first_name,' ',ru.last_name) AS requester_name,
                    CONCAT(tu.first_name,' ',tu.last_name) AS recipient_name,
                    tg.name AS target_group_name
               FROM content_transfer_requests tr
               LEFT JOIN users    ru ON ru.id = tr.requested_by
               LEFT JOIN users    tu ON tu.id = tr.to_user_id
               LEFT JOIN `groups` tg ON tg.id = tr.to_group_id
              WHERE tr.content_id = ? AND tr.status = 'pending'
              ORDER BY tr.created_at DESC
              LIMIT 1",
            [$id]
        );

        $groups = (new Group())->getUserGroups($this->auth->id());
        return Response::view('content::transfer', [
            'item'    => $item,
            'pending' => $pending,
            'groups'  => $groups,
            'user'    => $this->auth->user(),
        ]);
    }

    public function requestTransfer(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id   = (int) $request->param(0);
        $item = $this->db->fetchOne("SELECT * FROM content_items WHERE id = ?", [$id]);
        if (!$item) return new Response('Not found', 404);

        if (!$this->canEdit($item)) {
            return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');
        }

        $existing = $this->db->fetchOne(
            "SELECT id FROM content_transfer_requests WHERE content_id = ? AND status = 'pending' LIMIT 1",
            [$id]
        );
        if ($existing) {
            return Response::redirect("/content/$id/transfer")
                ->withFlash('error', 'There is already a pending transfer request for this item. Cancel it before starting another.');
        }

        $toType    = $request->post('to_type', 'group');
        $toGroupId = $request->post('to_group_id') ? (int) $request->post('to_group_id') : null;
        $toUserId  = $request->post('to_user_id')  ? (int) $request->post('to_user_id')  : null;

        if ($toType === 'user' && !$toUserId) {
            $identifier = trim((string) $request->post('to_user_identifier', ''));
            if ($identifier === '') {
                return Response::redirect("/content/$id/transfer")
                    ->withFlash('error', 'Enter the username or email of the person who should receive this content.');
            }
            $recipient = $this->db->fetchOne(
                "SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1",
                [$identifier, $identifier]
            );
            if (!$recipient) {
                return Response::redirect("/content/$id/transfer")
                    ->withFlash('error', "No user matches \"$identifier\". Double-check the username or email.");
            }
            $toUserId = (int) $recipient['id'];
        }

        if ($toType === 'user' && $item['owner_type'] === 'user' && $toUserId === (int) $item['owner_user_id']) {
            return Response::redirect("/content/$id/transfer")
                ->withFlash('info', 'That user already owns this content.');
        }
        if ($toType === 'group' && $item['owner_type'] === 'group' && $toGroupId === (int) $item['owner_group_id']) {
            return Response::redirect("/content/$id/transfer")
                ->withFlash('info', 'That group already owns this content.');
        }

        $fromType    = $item['owner_type'];
        $flow        = null;
        if ($fromType === 'group' && $toType === 'user') {
            $flow = 'group_admin';
        } elseif ($fromType === 'user' && $toType === 'user') {
            $flow = 'recipient';
        }

        if ($flow !== null) {
            $reqId = $this->db->insert('content_transfer_requests', [
                'content_id'   => $id,
                'requested_by' => $this->auth->id(),
                'from_type'    => $fromType,
                'to_type'      => $toType,
                'to_group_id'  => $toGroupId,
                'to_user_id'   => $toUserId,
                'status'       => 'pending',
            ]);
            $this->auth->auditLog('content.transfer_requested', 'content_items', $id);

            if ($flow === 'group_admin') {
                $this->notifyGroupApprovers((int) $item['owner_group_id'], $item, (int) $reqId);
                $msg = 'Transfer request submitted. A group owner or admin must approve it.';
            } else {
                $this->notifyRecipient((int) $toUserId, $item, (int) $reqId);
                $msg = 'Transfer request submitted. The recipient must accept it before ownership moves.';
            }
            return Response::redirect("/content/$id/transfer")->withFlash('info', $msg);
        }

        $this->db->update('content_items', [
            'owner_type'     => $toType,
            'owner_user_id'  => $toType === 'user'  ? $toUserId  : null,
            'owner_group_id' => $toType === 'group' ? $toGroupId : null,
        ], 'id = ?', [$id]);

        $this->auth->auditLog('content.transferred', 'content_items', $id, ['owner_type' => $fromType], ['owner_type' => $toType]);
        return Response::redirect("/content/{$item['slug']}")->withFlash('success', 'Ownership transferred.');
    }

    public function approveTransfer(Request $request): Response
    {
        $reqId  = (int) $request->param(0);
        $action = (string) $request->param(1);
        $req    = $this->db->fetchOne("SELECT * FROM content_transfer_requests WHERE id = ?", [$reqId]);
        if (!$req || $req['status'] !== 'pending') return new Response('Not found', 404);

        $item = $this->db->fetchOne("SELECT * FROM content_items WHERE id = ?", [$req['content_id']]);
        if (!$item) return new Response('Content not found', 404);

        $authId      = (int) $this->auth->id();
        $isRequester = ((int) $req['requested_by'] === $authId);
        $isSuper     = $this->auth->isSuperadminModeOn();

        if ($action === 'cancel') {
            if (!$isRequester && !$isSuper) {
                return Response::redirect('/dashboard')->withFlash('error', 'Only the requester can cancel this transfer.');
            }
            $this->db->update('content_transfer_requests', [
                'status'      => 'rejected',
                'reviewed_by' => $authId,
                'reviewed_at' => date('Y-m-d H:i:s'),
            ], 'id = ?', [$reqId]);
            $this->auth->auditLog('content.transfer_canceled', 'content_items', $req['content_id']);
            return Response::redirect("/content/{$req['content_id']}/transfer")
                ->withFlash('info', 'Transfer request canceled.');
        }

        $fromType  = $req['from_type'];
        $toType    = $req['to_type'];
        $positive  = null;
        $verbLabel = null;

        if ($fromType === 'group' && $toType === 'user') {
            $canAct = $this->auth->isGroupAdmin((int) $item['owner_group_id']);
            if (!$canAct && !$isSuper) {
                return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');
            }
            if ($isRequester && !$isSuper) {
                return Response::redirect('/dashboard')
                    ->withFlash('error', 'You cannot approve your own transfer request. Another group owner or admin must review it.');
            }
            if (!in_array($action, ['approve', 'reject'], true)) {
                return Response::redirect('/dashboard')->withFlash('error', 'Invalid action for this request.');
            }
            $positive  = ($action === 'approve');
            $verbLabel = $positive ? 'approved' : 'rejected';

        } elseif ($fromType === 'user' && $toType === 'user') {
            $canAct = ((int) $req['to_user_id'] === $authId);
            if (!$canAct && !$isSuper) {
                return Response::redirect('/dashboard')->withFlash('error', 'Only the named recipient can act on this transfer.');
            }
            if (!in_array($action, ['accept', 'decline'], true)) {
                return Response::redirect('/dashboard')->withFlash('error', 'Invalid action for this request.');
            }
            $positive  = ($action === 'accept');
            $verbLabel = $positive ? 'accepted' : 'declined';

        } else {
            return Response::redirect('/dashboard')->withFlash('error', 'This request is in an unexpected state.');
        }

        $status = $positive ? 'approved' : 'rejected';
        $this->db->update('content_transfer_requests', [
            'status'      => $status,
            'reviewed_by' => $authId,
            'reviewed_at' => date('Y-m-d H:i:s'),
        ], 'id = ?', [$reqId]);

        if ($positive) {
            $this->db->update('content_items', [
                'owner_type'     => $toType,
                'owner_user_id'  => $toType === 'user'  ? (int) $req['to_user_id']  : null,
                'owner_group_id' => $toType === 'group' ? (int) $req['to_group_id'] : null,
            ], 'id = ?', [$req['content_id']]);
        }

        $this->auth->auditLog("content.transfer_$verbLabel", 'content_items', $req['content_id']);
        return Response::redirect('/dashboard')->withFlash('success', "Transfer $verbLabel.");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function canEdit(array $item): bool
    {
        if ($this->auth->isSuperadminModeOn()) return true;
        if ($this->auth->can('content.edit')) return true;
        if ($item['owner_type'] === 'user' && $item['owner_user_id'] === $this->auth->id()) return true;
        if ($item['owner_type'] === 'group' && $this->auth->isGroupAdmin((int) $item['owner_group_id'])) return true;
        return false;
    }

    private function notifyGroupApprovers(int $groupId, array $item, int $requestId): void
    {
        if ($groupId <= 0) return;

        $approvers = $this->db->fetchAll(
            "SELECT DISTINCT u.id
               FROM users u
               JOIN user_groups ug ON ug.user_id = u.id
               JOIN group_roles gr ON gr.id = ug.group_role_id
              WHERE ug.group_id = ?
                AND gr.base_role IN ('group_owner', 'group_admin')",
            [$groupId]
        );

        if (empty($approvers)) return;

        $notif      = new NotificationService();
        $title      = 'Content transfer needs approval';
        $itemTitle  = $item['title'] ?? 'a content item';
        $body       = "A transfer request for \"$itemTitle\" is awaiting your review.";
        $data       = [
            'request_id' => $requestId,
            'content_id' => (int) $item['id'],
            'slug'       => $item['slug'] ?? null,
            'action_url' => '/dashboard#pending-transfers',
        ];

        $requesterId = (int) $this->auth->id();
        foreach ($approvers as $row) {
            $uid = (int) $row['id'];
            if ($uid === $requesterId) continue;
            $notif->send($uid, 'content.transfer_request', $title, $body, $data, 'in_app');
        }
    }

    private function notifyRecipient(int $recipientId, array $item, int $requestId): void
    {
        if ($recipientId <= 0) return;
        $notif     = new NotificationService();
        $itemTitle = $item['title'] ?? 'a content item';
        $notif->send(
            $recipientId,
            'content.transfer_offer',
            'Content transfer offered to you',
            "Someone has offered to transfer \"$itemTitle\" to you. Accept or decline from your dashboard.",
            [
                'request_id' => $requestId,
                'content_id' => (int) $item['id'],
                'slug'       => $item['slug'] ?? null,
                'action_url' => '/dashboard#pending-transfers',
            ],
            'in_app'
        );
    }

    private function getGroupSlug(int $groupId): string
    {
        $g = $this->db->fetchOne("SELECT slug FROM `groups` WHERE id = ?", [$groupId]);
        return $g['slug'] ?? '';
    }
}
