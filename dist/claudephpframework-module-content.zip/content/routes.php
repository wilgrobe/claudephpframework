<?php
// modules/content/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;

$router->get ('/content',                             'Modules\Content\Controllers\ContentController@myContent',
    [AuthMiddleware::class]);
$router->get ('/content/create',                      'Modules\Content\Controllers\ContentController@createForm',
    [AuthMiddleware::class]);
$router->post('/content/create',                      'Modules\Content\Controllers\ContentController@store',
    [CsrfMiddleware::class, AuthMiddleware::class]);
$router->get ('/content/{slug}',                      'Modules\Content\Controllers\ContentController@show');
$router->get ('/content/{id}/edit',                   'Modules\Content\Controllers\ContentController@editForm',
    [AuthMiddleware::class]);
$router->post('/content/{id}/edit',                   'Modules\Content\Controllers\ContentController@update',
    [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/content/{id}/delete',                 'Modules\Content\Controllers\ContentController@delete',
    [CsrfMiddleware::class, AuthMiddleware::class]);
$router->get ('/content/{id}/transfer',               'Modules\Content\Controllers\ContentController@transferPage',
    [AuthMiddleware::class]);
$router->post('/content/{id}/transfer',               'Modules\Content\Controllers\ContentController@requestTransfer',
    [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/content/transfer/{reqId}/{action}',   'Modules\Content\Controllers\ContentController@approveTransfer',
    [CsrfMiddleware::class, AuthMiddleware::class]);
