<?php
// content/show.php
// Every field defaults to a safe value so a row with NULLs or a partial
// schema doesn't produce a wall of E_WARNING output. If a field really
// is blank, the user sees a tasteful em-dash instead of "undefined key".
$id            = (int)($item['id']            ?? 0);
$title         = (string)($item['title']      ?? '');
$slug          = (string)($item['slug']       ?? '');
$body          = (string)($item['body']       ?? '');
$type          = (string)($item['type']       ?? 'post');
$status        = (string)($item['status']     ?? 'draft');
$ownerType     = (string)($item['owner_type'] ?? 'user');
$ownerLabel    = (string)($item['owner_label']?? '');
$ownerUserId   = $item['owner_user_id']  ?? null;
$ownerGroupId  = (int)($item['owner_group_id'] ?? 0);
$createdBy     = $item['created_by']     ?? null;
$createdAt     = $item['created_at']     ?? null;
$seoTitleV     = $item['seo_title']       ?? '';
$seoDescV      = $item['seo_description'] ?? '';

$pageTitle       = e($title !== '' ? $title : 'Content');
$seoTitle        = $seoTitleV !== '' ? $seoTitleV : $title;
$seoDescription  = $seoDescV;
$canonical       = config('app.url') . '/content/' . $slug;
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:840px;margin:0 auto">

    <!-- Header card -->
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header">
            <div>
                <h1 style="margin:0;font-size:1.35rem;font-weight:700"><?= e($title !== '' ? $title : '(untitled)') ?></h1>
                <div style="display:flex;gap:.5rem;align-items:center;margin-top:.4rem;flex-wrap:wrap">
                    <span class="badge badge-gray"><?= e($type) ?></span>
                    <?php $sb = ['published'=>'badge-success','draft'=>'badge-gray','archived'=>'badge-warning'][$status] ?? 'badge-gray'; ?>
                    <span class="badge <?= $sb ?>"><?= e($status) ?></span>
                    <?php if ($ownerType === 'group'): ?>
                    <span style="font-size:12.5px;color:#4f46e5">👥 <?= e($ownerLabel !== '' ? $ownerLabel : 'Group') ?></span>
                    <?php else: ?>
                    <span style="font-size:12.5px;color:#6b7280">👤 <?= e($ownerLabel !== '' ? $ownerLabel : 'Individual') ?></span>
                    <?php endif; ?>
                    <?php if ($createdAt): ?>
                    <span style="font-size:12px;color:#9ca3af"><?= date('M j, Y', strtotime($createdAt)) ?></span>
                    <?php endif; ?>
                </div>
            </div>
            <?php
            $canManage = ($ownerType === 'user'  && $ownerUserId !== null && auth()->id() === (int)$ownerUserId)
                || ($ownerType === 'group' && $ownerGroupId > 0 && auth()->isGroupAdmin($ownerGroupId))
                || auth()->isSuperadminModeOn();
            ?>
            <div style="display:flex;gap:.5rem;flex-shrink:0">
                <?php if ($canManage): ?>
                <a href="/content/<?= $id ?>/edit" class="btn btn-sm btn-secondary">Edit</a>
                <a href="/content/<?= $id ?>/transfer" class="btn btn-sm btn-secondary">Transfer</a>
                <form method="POST" action="/content/<?= $id ?>/delete" data-confirm="Delete this content?">
                    <?= csrf_field() ?><button class="btn btn-sm btn-danger">Delete</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <div class="card-body" style="line-height:1.8;font-size:15px">
            <?php if (trim($body) !== ''): ?>
                <?= $body ?>
            <?php else: ?>
                <p style="color:#9ca3af;font-style:italic;margin:0">This content has no body yet. <a href="/content/<?= $id ?>/edit">Add one?</a></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Ownership transfer lives on its own page now: /content/{id}/transfer -->

</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
