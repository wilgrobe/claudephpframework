<?php $pageTitle = 'My Content'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card-header" style="background:#fff;border:1px solid #e5e7eb;border-radius:8px;padding:1rem 1.25rem;margin-bottom:1.5rem;display:flex;justify-content:space-between;align-items:center">
    <h2 style="margin:0">My Content</h2>
    <a href="/content/create" class="btn btn-primary">+ New Content</a>
</div>

<!-- Filter tabs -->
<div style="display:flex;gap:.35rem;margin-bottom:1rem">
    <a href="/content" class="btn btn-sm <?= !$type_filter ? 'btn-primary' : 'btn-secondary' ?>">All</a>
    <?php foreach (['post','page','article','resource'] as $t): ?>
    <a href="/content?type=<?= $t ?>" class="btn btn-sm <?= $type_filter === $t ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($t) ?></a>
    <?php endforeach; ?>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr><th>Title</th><th>Type</th><th>Owner</th><th>Status</th><th>Created</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php if (empty($content['items'])): ?>
            <tr><td colspan="6" style="text-align:center;color:#6b7280;padding:2rem">No content yet. <a href="/content/create">Create your first piece.</a></td></tr>
            <?php endif; ?>
            <?php foreach ($content['items'] as $item): ?>
            <tr>
                <td>
                    <a href="/content/<?= e($item['slug']) ?>" style="font-weight:500;color:#4f46e5;text-decoration:none"><?= e($item['title']) ?></a>
                </td>
                <td><span class="badge badge-gray"><?= e($item['type']) ?></span></td>
                <td style="font-size:13px">
                    <?php if ($item['owner_type'] === 'group'): ?>
                    <span style="color:#4f46e5">👥 <?= e($item['owner_label']) ?></span>
                    <?php else: ?>
                    <span>👤 <?= e($item['owner_label']) ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php $badge = ['published'=>'badge-success','draft'=>'badge-gray','archived'=>'badge-warning'][$item['status']] ?? 'badge-gray'; ?>
                    <span class="badge <?= $badge ?>"><?= e($item['status']) ?></span>
                </td>
                <td style="color:#6b7280;font-size:12px"><?= date('M j, Y', strtotime($item['created_at'])) ?></td>
                <td>
                    <div style="display:flex;gap:.35rem">
                        <a href="/content/<?= e($item['slug']) ?>" class="btn btn-xs btn-secondary">View</a>
                        <a href="/content/<?= $item['id'] ?>/edit" class="btn btn-xs btn-secondary">Edit</a>
                        <form method="POST" action="/content/<?= $item['id'] ?>/delete" data-confirm="Delete '<?= e($item['title']) ?>'?">
                            <?= csrf_field() ?><button class="btn btn-xs btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php if (!empty($content) && $content['last_page'] > 1): ?>
    <div style="padding:1rem 1.25rem">
        <?php $pagination = $content; include BASE_PATH . '/app/Views/layout/pagination.php'; ?>
    </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
