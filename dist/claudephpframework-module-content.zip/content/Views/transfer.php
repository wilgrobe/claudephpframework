<?php
// content/transfer.php — dedicated page for managing an item's ownership transfer.

$id            = (int)($item['id']            ?? 0);
$slug          = (string)($item['slug']       ?? '');
$title         = (string)($item['title']      ?? '');
$ownerType     = (string)($item['owner_type'] ?? 'user');
$ownerLabel    = (string)($item['owner_label']?? '');
$ownerUserId   = $item['owner_user_id']  ?? null;
$ownerGroupId  = (int)($item['owner_group_id'] ?? 0);

$pageTitle = 'Transfer: ' . ($title !== '' ? $title : '(untitled)');

$authId = (int) auth()->id();

$hasPending      = !empty($pending);
$pendingFromType = $hasPending ? (string)$pending['from_type'] : '';
$pendingToType   = $hasPending ? (string)$pending['to_type']   : '';
$isRequester     = $hasPending && (int)$pending['requested_by'] === $authId;
$isGroupApprover = $hasPending
    && $pendingFromType === 'group'
    && auth()->isGroupAdmin((int)$item['owner_group_id']);
$isRecipient     = $hasPending
    && $pendingFromType === 'user'
    && $pendingToType === 'user'
    && (int)$pending['to_user_id'] === $authId;
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:720px;margin:0 auto">

    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
        <div>
            <div style="font-size:12px;color:#6b7280">
                <a href="/content/<?= e($slug) ?>" style="color:#4f46e5;text-decoration:none">← <?= e($title !== '' ? $title : 'content') ?></a>
            </div>
            <h1 style="margin:.25rem 0 0;font-size:1.35rem;font-weight:700">Transfer Ownership</h1>
        </div>
        <a href="/content/<?= $id ?>/edit" class="btn btn-sm btn-secondary">Back to edit</a>
    </div>

    <div class="card" style="margin-bottom:1rem">
        <div class="card-header"><h2 style="margin:0;font-size:.95rem">Current ownership</h2></div>
        <div class="card-body" style="font-size:14px">
            <?php if ($ownerType === 'group'): ?>
                👥 Owned by group <strong><?= e($ownerLabel !== '' ? $ownerLabel : 'Group') ?></strong>.
            <?php else: ?>
                👤 Owned by <strong><?= e($ownerLabel !== '' ? $ownerLabel : 'an individual') ?></strong>.
            <?php endif; ?>
        </div>
    </div>

    <?php if ($hasPending): ?>
    <div class="card" style="margin-bottom:1rem;border-left:3px solid #f59e0b">
        <div class="card-header"><h2 style="margin:0;font-size:.95rem">⏳ Pending transfer request</h2></div>
        <div class="card-body" style="font-size:14px;line-height:1.6">
            <p style="margin:0 0 .5rem">
                <strong><?= e(trim($pending['requester_name'] ?? '') ?: 'Someone') ?></strong> requested a transfer
                <?php if ($pendingFromType === 'group' && $pendingToType === 'user'): ?>
                    from this group to
                    <strong><?= e(trim($pending['recipient_name'] ?? '') ?: 'an individual') ?></strong>.
                    A group owner or admin must approve it.
                <?php elseif ($pendingFromType === 'user' && $pendingToType === 'user'): ?>
                    to
                    <strong><?= e(trim($pending['recipient_name'] ?? '') ?: 'another user') ?></strong>.
                    The recipient must accept it before ownership moves.
                <?php elseif ($pendingToType === 'group'): ?>
                    to group <strong><?= e($pending['target_group_name'] ?? 'a group') ?></strong>.
                <?php endif; ?>
            </p>
            <div style="font-size:12px;color:#9ca3af">
                Requested <?= date('M j, Y g:i A', strtotime($pending['created_at'])) ?>
            </div>

            <div style="display:flex;gap:.5rem;margin-top:1rem;flex-wrap:wrap">
                <?php if ($isGroupApprover && !$isRequester): ?>
                    <form method="POST" action="/content/transfer/<?= (int)$pending['id'] ?>/approve" style="margin:0">
                        <?= csrf_field() ?>
                        <button class="btn btn-sm btn-primary"
                                onclick="return confirm('Approve? Ownership moves immediately.')">Approve</button>
                    </form>
                    <form method="POST" action="/content/transfer/<?= (int)$pending['id'] ?>/reject" style="margin:0">
                        <?= csrf_field() ?>
                        <button class="btn btn-sm btn-secondary" onclick="return confirm('Reject this transfer?')">Reject</button>
                    </form>
                <?php endif; ?>

                <?php if ($isRecipient): ?>
                    <form method="POST" action="/content/transfer/<?= (int)$pending['id'] ?>/accept" style="margin:0">
                        <?= csrf_field() ?>
                        <button class="btn btn-sm btn-primary"
                                onclick="return confirm('Accept ownership of this content?')">Accept</button>
                    </form>
                    <form method="POST" action="/content/transfer/<?= (int)$pending['id'] ?>/decline" style="margin:0">
                        <?= csrf_field() ?>
                        <button class="btn btn-sm btn-secondary" onclick="return confirm('Decline this transfer?')">Decline</button>
                    </form>
                <?php endif; ?>

                <?php if ($isRequester): ?>
                    <form method="POST" action="/content/transfer/<?= (int)$pending['id'] ?>/cancel" style="margin:0">
                        <?= csrf_field() ?>
                        <button class="btn btn-sm btn-secondary" onclick="return confirm('Cancel your transfer request?')">Cancel request</button>
                    </form>
                <?php endif; ?>

                <?php if (!$isRequester && !$isGroupApprover && !$isRecipient): ?>
                    <em style="font-size:12.5px;color:#6b7280">No action available for your role on this request.</em>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header"><h2 style="margin:0;font-size:.95rem">Request a transfer</h2></div>
        <div class="card-body">
            <form method="POST" action="/content/<?= $id ?>/transfer">
                <?= csrf_field() ?>

                <div class="form-group">
                    <label style="font-weight:500;font-size:13px">Transfer to</label>
                    <label style="display:flex;align-items:center;gap:.5rem;font-weight:normal;margin:.35rem 0">
                        <input type="radio" name="to_type" value="user" checked onchange="toggleTransferTarget()">
                        An individual
                    </label>
                    <label style="display:flex;align-items:center;gap:.5rem;font-weight:normal;margin:.35rem 0">
                        <input type="radio" name="to_type" value="group" onchange="toggleTransferTarget()">
                        A group
                    </label>
                </div>

                <div id="target-user" class="form-group">
                    <label style="font-weight:500;font-size:13px">Recipient (username or email)</label>
                    <input type="text" name="to_user_identifier" class="form-control"
                           placeholder="e.g. jdoe or jdoe@example.com" autocomplete="off">
                    <div style="font-size:12px;color:#6b7280;margin-top:.25rem">
                        <?php if ($ownerType === 'user'): ?>
                            The recipient will be notified and must accept the transfer before ownership moves.
                        <?php else: ?>
                            A group owner or admin must approve this before ownership moves.
                        <?php endif; ?>
                    </div>
                </div>

                <div id="target-group" class="form-group" style="display:none">
                    <label style="font-weight:500;font-size:13px">Destination group</label>
                    <select name="to_group_id" class="form-control">
                        <option value="">— Choose a group —</option>
                        <?php foreach ($groups as $g): ?>
                        <option value="<?= (int)$g['id'] ?>">
                            <?= e($g['name']) ?> (<?= e($g['role_name'] ?? $g['base_role'] ?? 'Member') ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div style="display:flex;gap:.5rem;margin-top:1rem">
                    <button type="submit" class="btn btn-primary">Request transfer</button>
                    <a href="/content/<?= e($slug) ?>" class="btn btn-secondary">Cancel</a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>

</div>

<script>
function toggleTransferTarget() {
    const t = document.querySelector('input[name="to_type"]:checked')?.value || 'user';
    document.getElementById('target-user').style.display  = t === 'user'  ? '' : 'none';
    document.getElementById('target-group').style.display = t === 'group' ? '' : 'none';
}
</script>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
