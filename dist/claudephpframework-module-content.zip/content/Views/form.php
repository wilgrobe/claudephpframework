<?php $pageTitle = $content ? 'Edit Content' : 'Create Content'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:860px;margin:0 auto">
<div class="card">
    <div class="card-header">
        <h2><?= $content ? 'Edit: '.e($content['title']) : 'Create New Content' ?></h2>
        <a href="/content" class="btn btn-secondary btn-sm">← My Content</a>
    </div>
    <div class="card-body">
        <?php $errors = \Core\Session::flash('errors') ?? []; ?>
        <form method="POST" action="<?= $content ? '/content/'.$content['id'].'/edit' : '/content/create' ?>">
            <?= csrf_field() ?>

            <div class="grid grid-2">
                <div class="form-group">
                    <label>Title *</label>
                    <input type="text" name="title" class="form-control <?= !empty($errors['title'])?'is-invalid':'' ?>"
                           value="<?= e($content['title'] ?? old('title')) ?>" required oninput="autoSlugContent(this)">
                    <?php if (!empty($errors['title'])): ?><span class="form-error"><?= e($errors['title'][0]) ?></span><?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Slug *</label>
                    <input type="text" id="content-slug" name="slug" class="form-control"
                           value="<?= e($content['slug'] ?? old('slug')) ?>" required>
                </div>
            </div>

            <?php
            // Ownership is only choosable at creation. Once content exists,
            // ownership changes have to go through the transfer workflow
            // (dedicated page, approvals where applicable) rather than a
            // silent edit — so we drop the fields from the edit form.
            $isEdit = !empty($content);
            $gridCols = $isEdit ? 'grid-2' : 'grid-3';
            ?>
            <div class="grid <?= $gridCols ?>">
                <div class="form-group">
                    <label>Content Type</label>
                    <select name="type" class="form-control">
                        <?php foreach (['post','article','page','resource','announcement','document'] as $t): ?>
                        <option value="<?= $t ?>" <?= ($content['type'] ?? 'post') === $t ? 'selected' : '' ?>><?= ucfirst($t) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="draft"     <?= ($content['status'] ?? 'draft') === 'draft'     ? 'selected' : '' ?>>Draft</option>
                        <option value="published" <?= ($content['status'] ?? '')      === 'published' ? 'selected' : '' ?>>Published</option>
                        <option value="archived"  <?= ($content['status'] ?? '')      === 'archived'  ? 'selected' : '' ?>>Archived</option>
                    </select>
                </div>
                <?php if (!$isEdit): ?>
                <div class="form-group">
                    <label>Owned By</label>
                    <select name="owner_type" class="form-control" id="owner-type" onchange="toggleOwnerGroup(this.value)">
                        <option value="user"  <?= ($content['owner_type'] ?? 'user') === 'user'  ? 'selected' : '' ?>>Me (Personal)</option>
                        <option value="group" <?= ($content['owner_type'] ?? '')     === 'group' ? 'selected' : '' ?>>A Group</option>
                    </select>
                </div>
                <?php endif; ?>
            </div>

            <?php if (!$isEdit): ?>
            <div id="owner-group-field" style="display:<?= ($content['owner_type'] ?? 'user') === 'group' ? '' : 'none' ?>;margin-bottom:1rem">
                <label class="form-group">
                    <span style="display:block;font-weight:500;font-size:13.5px;margin-bottom:.35rem">Select Group</span>
                    <select name="owner_group_id" class="form-control">
                        <option value="">— Choose a group —</option>
                        <?php foreach ($groups as $g): ?>
                        <option value="<?= $g['id'] ?>" <?= ($content['owner_group_id'] ?? 0) == $g['id'] ? 'selected' : '' ?>>
                            <?= e($g['name']) ?> (<?= e($g['role_name'] ?? $g['base_role'] ?? 'Member') ?>)
                        </option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
            <?php else: ?>
            <div style="display:flex;align-items:center;justify-content:space-between;gap:1rem;padding:.75rem 1rem;margin-bottom:1rem;background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;font-size:13.5px">
                <div style="color:#6b7280">
                    Currently owned by
                    <strong style="color:#111827">
                        <?php if (($content['owner_type'] ?? 'user') === 'group'): ?>
                            👥 group
                        <?php else: ?>
                            👤 an individual
                        <?php endif; ?>
                    </strong>.
                    Ownership changes happen on the transfer page.
                </div>
                <a href="/content/<?= (int)$content['id'] ?>/transfer" class="btn btn-sm btn-secondary">Transfer ownership →</a>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <?php
                $wy_name        = 'body';
                $wy_value       = $content['body'] ?? '';
                $wy_rows        = 18;
                $wy_scope       = 'content';
                $wy_label       = 'Content Body';
                $wy_placeholder = 'Start writing...';
                include BASE_PATH . '/app/Views/partials/wysiwyg.php';
                ?>
                <span style="font-size:12px;color:#6b7280;display:block;margin-top:.35rem">HTML is allowed. Only a safe subset (headings, lists, bold/italic/underline, links, blockquote) survives save.</span>
            </div>

            <div style="border:1px solid #e5e7eb;border-radius:8px;padding:1.25rem;margin-bottom:1rem;background:#f9fafb">
                <div style="font-weight:600;font-size:13px;margin-bottom:.75rem">SEO Settings</div>
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>SEO Title</label>
                        <input type="text" name="seo_title" class="form-control" value="<?= e($content['seo_title'] ?? '') ?>" maxlength="255">
                    </div>
                    <div class="form-group">
                        <label>Keywords</label>
                        <input type="text" name="seo_keywords" class="form-control" value="<?= e($content['seo_keywords'] ?? '') ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label>Meta Description</label>
                    <textarea name="seo_description" class="form-control" rows="2" maxlength="500"><?= e($content['seo_description'] ?? '') ?></textarea>
                </div>
            </div>

            <div style="display:flex;gap:.75rem">
                <button type="submit" class="btn btn-primary"><?= $content ? 'Save Changes' : 'Create Content' ?></button>
                <a href="/content" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</div>

<script>
function autoSlugContent(input) {
    const slug = document.getElementById('content-slug');
    if (!slug.value || slug.dataset.manual !== '1') {
        slug.value = input.value.toLowerCase().replace(/[^a-z0-9\s\-]/g,'').replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
    }
}
document.getElementById('content-slug')?.addEventListener('input', function() { this.dataset.manual = '1'; });

function toggleOwnerGroup(v) {
    const field = document.getElementById('owner-group-field');
    if (field) field.style.display = v === 'group' ? '' : 'none';
}
</script>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
