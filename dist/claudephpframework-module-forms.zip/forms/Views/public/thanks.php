<?php $pageTitle = 'Thank you — ' . ($form['name'] ?? ''); ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:640px;margin:0 auto;text-align:center;padding:3rem 1rem">
    <div style="font-size:3rem;margin-bottom:1rem">✓</div>
    <h1 style="margin-bottom:1rem"><?= e($form['name']) ?></h1>
    <p style="color:#4b5563;font-size:15px;line-height:1.6"><?= nl2br(e($message)) ?></p>
    <div style="margin-top:2rem">
        <a href="/forms/<?= e($form['slug']) ?>" class="btn btn-secondary">Submit another response</a>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
