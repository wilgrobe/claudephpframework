<?php
$pageTitle = $form['name'];
$opts = function (?string $json): array {
    if (!$json) return [];
    $d = json_decode($json, true);
    return is_array($d) ? $d : [];
};
$old = $old ?? [];
$errors = $errors ?? [];
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:640px;margin:0 auto">
    <h1 style="margin-bottom:.5rem"><?= e($form['name']) ?></h1>
    <?php if (!empty($form['description'])): ?>
    <p style="color:#6b7280;margin-bottom:1.5rem"><?= nl2br(e($form['description'])) ?></p>
    <?php endif; ?>

    <?php if (!empty($errors['_captcha'])): ?>
    <div class="alert alert-danger" style="margin-bottom:1rem"><?= e($errors['_captcha'][0]) ?></div>
    <?php endif; ?>

    <form method="POST" action="/forms/<?= e($form['slug']) ?>" enctype="multipart/form-data" class="card" style="padding:1.5rem">
        <?= csrf_field() ?>

        <?php foreach ($fields as $f): ?>
        <?php $key = (string) $f['field_key']; $value = $old[$key] ?? ''; ?>
        <div class="form-row">
            <label>
                <?= e($f['label']) ?><?php if ((int) $f['required'] === 1): ?> <span style="color:#ef4444">*</span><?php endif; ?>
            </label>

            <?php if ($f['type'] === 'textarea'): ?>
                <textarea name="<?= e($key) ?>" rows="4" <?= $f['placeholder'] ? 'placeholder="' . e($f['placeholder']) . '"' : '' ?> <?= (int) $f['required'] === 1 ? 'required' : '' ?>><?= e((string) $value) ?></textarea>

            <?php elseif ($f['type'] === 'select'): ?>
                <select name="<?= e($key) ?>" <?= (int) $f['required'] === 1 ? 'required' : '' ?>>
                    <option value="">— Select —</option>
                    <?php foreach ($opts($f['options']) as $opt): ?>
                    <option value="<?= e($opt) ?>" <?= (string) $value === (string) $opt ? 'selected' : '' ?>><?= e($opt) ?></option>
                    <?php endforeach; ?>
                </select>

            <?php elseif ($f['type'] === 'radio'): ?>
                <div>
                    <?php foreach ($opts($f['options']) as $opt): ?>
                    <label style="display:block;margin-bottom:.25rem;font-weight:normal">
                        <input type="radio" name="<?= e($key) ?>" value="<?= e($opt) ?>" <?= (string) $value === (string) $opt ? 'checked' : '' ?> <?= (int) $f['required'] === 1 ? 'required' : '' ?>>
                        <?= e($opt) ?>
                    </label>
                    <?php endforeach; ?>
                </div>

            <?php elseif ($f['type'] === 'checkbox'): ?>
                <label style="font-weight:normal">
                    <input type="checkbox" name="<?= e($key) ?>" value="1" <?= !empty($value) ? 'checked' : '' ?>>
                    Yes
                </label>

            <?php elseif ($f['type'] === 'date'): ?>
                <input type="date" name="<?= e($key) ?>" value="<?= e((string) $value) ?>" <?= (int) $f['required'] === 1 ? 'required' : '' ?>>

            <?php elseif ($f['type'] === 'number'): ?>
                <input type="number" name="<?= e($key) ?>" value="<?= e((string) $value) ?>" <?= $f['placeholder'] ? 'placeholder="' . e($f['placeholder']) . '"' : '' ?> <?= (int) $f['required'] === 1 ? 'required' : '' ?>>

            <?php elseif ($f['type'] === 'email'): ?>
                <input type="email" name="<?= e($key) ?>" value="<?= e((string) $value) ?>" <?= $f['placeholder'] ? 'placeholder="' . e($f['placeholder']) . '"' : '' ?> <?= (int) $f['required'] === 1 ? 'required' : '' ?>>

            <?php else: /* text + fallback */ ?>
                <input type="text" name="<?= e($key) ?>" value="<?= e((string) $value) ?>" <?= $f['placeholder'] ? 'placeholder="' . e($f['placeholder']) . '"' : '' ?> <?= (int) $f['required'] === 1 ? 'required' : '' ?>>
            <?php endif; ?>

            <?php if (!empty($f['help_text'])): ?>
            <small style="color:#6b7280"><?= e($f['help_text']) ?></small>
            <?php endif; ?>
            <?php if (!empty($errors[$key])): ?>
            <div class="error" style="color:#ef4444;font-size:13px;margin-top:.25rem"><?= e($errors[$key][0]) ?></div>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>

        <button class="btn btn-primary">Submit</button>
    </form>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
