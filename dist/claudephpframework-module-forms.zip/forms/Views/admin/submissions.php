<?php $pageTitle = 'Submissions: ' . $form['name']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/forms/<?= (int) $form['id'] ?>/edit" class="btn btn-sm btn-secondary">← Back to form</a>
    <h1 style="margin:0;font-size:1.5rem"><?= e($form['name']) ?> — Submissions</h1>
    <span style="color:#6b7280"><?= (int) $total ?> total</span>
    <a href="/admin/forms/<?= (int) $form['id'] ?>/submissions.csv" class="btn btn-sm btn-secondary" style="margin-left:auto">Export CSV</a>
</div>

<?php if (empty($submissions)): ?>
<div class="card">
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
        No submissions yet.
        <div style="margin-top:.5rem;font-size:13px">Public URL: <code>/forms/<?= e($form['slug']) ?></code></div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>When</th>
                    <th>Submitter</th>
                    <?php foreach (array_slice($fields, 0, 3) as $f): ?>
                    <th><?= e($f['label']) ?></th>
                    <?php endforeach; ?>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($submissions as $s): ?>
            <?php $data = json_decode((string) $s['data'], true) ?: []; ?>
            <tr>
                <td style="white-space:nowrap"><?= e(date('M j, Y H:i', strtotime((string) $s['created_at']))) ?></td>
                <td>
                    <?php if (!empty($s['submitter_username'])): ?>
                    <strong><?= e($s['submitter_username']) ?></strong>
                    <?php else: ?>
                    <span style="color:#9ca3af">guest · <?= e($s['ip_address'] ?? '—') ?></span>
                    <?php endif; ?>
                </td>
                <?php foreach (array_slice($fields, 0, 3) as $f): ?>
                    <?php $v = $data[$f['field_key']] ?? ''; if (is_bool($v)) $v = $v ? 'Yes' : 'No'; if (is_array($v)) $v = implode(', ', $v); ?>
                    <td style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e((string) $v) ?></td>
                <?php endforeach; ?>
                <td>
                    <div style="display:flex;gap:.35rem">
                        <a href="/admin/forms/<?= (int) $form['id'] ?>/submissions/<?= (int) $s['id'] ?>" class="btn btn-xs btn-secondary">View</a>
                        <form method="POST" action="/admin/forms/<?= (int) $form['id'] ?>/submissions/<?= (int) $s['id'] ?>/delete" data-confirm="Delete this submission?">
                            <?= csrf_field() ?><button class="btn btn-xs btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php
    $lastPage = max(1, (int) ceil($total / $per_page));
    if ($lastPage > 1):
    ?>
    <div class="card-body" style="display:flex;gap:.5rem;border-top:1px solid #e5e7eb">
        <?php for ($p = 1; $p <= $lastPage; $p++): ?>
        <a href="?page=<?= $p ?>" class="btn btn-xs <?= $p === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
