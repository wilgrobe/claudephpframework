<?php
$isEdit = !empty($form);
$pageTitle = $isEdit ? 'Edit Form: ' . ($form['name'] ?? '') : 'New Form';
$settings  = $isEdit && !empty($form['settings']) ? (json_decode($form['settings'], true) ?: []) : [];
$errors    = \Core\Session::get('errors', []);
$old       = \Core\Session::get('old', []);
$val       = fn(string $key, string $default = '') => e($old[$key] ?? ($form[$key] ?? $default));
$setv      = fn(string $key, string $default = '') => e($settings[$key] ?? $default);
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/forms" class="btn btn-sm btn-secondary">← Back</a>
    <h1 style="margin:0;font-size:1.5rem"><?= $isEdit ? 'Edit Form' : 'New Form' ?></h1>
</div>

<!-- ── Form metadata ─────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:1.5rem">
    <div class="card-header"><h2>Details</h2></div>
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? '/admin/forms/' . (int) $form['id'] . '/edit' : '/admin/forms/create' ?>">
            <?= csrf_field() ?>

            <div class="form-row">
                <label>Name *</label>
                <input type="text" name="name" value="<?= $val('name') ?>" required maxlength="191">
                <?php if (!empty($errors['name'])): ?><div class="error"><?= e($errors['name'][0]) ?></div><?php endif; ?>
            </div>

            <div class="form-row">
                <label>Slug *</label>
                <input type="text" name="slug" value="<?= $val('slug') ?>" required maxlength="120" pattern="[a-z0-9-]+">
                <small>Used in the public URL: <code>/forms/your-slug</code>. Lowercase letters, digits, hyphens only.</small>
                <?php if (!empty($errors['slug'])): ?><div class="error"><?= e($errors['slug'][0]) ?></div><?php endif; ?>
            </div>

            <div class="form-row">
                <label>Description</label>
                <textarea name="description" rows="2"><?= $val('description') ?></textarea>
                <small>Optional. Shown above the fields on the public page.</small>
            </div>

            <div class="form-row">
                <label><input type="checkbox" name="enabled" value="1" <?= (!$isEdit || (int) ($form['enabled'] ?? 1) === 1) ? 'checked' : '' ?>> Enabled</label>
                <small>Disabled forms return 404 publicly.</small>
            </div>

            <fieldset style="margin-top:1.5rem;padding:1rem;border:1px solid #e5e7eb;border-radius:6px">
                <legend style="font-weight:600;padding:0 .5rem">Post-submit actions</legend>

                <div class="form-row">
                    <label>Success message</label>
                    <input type="text" name="success_message" value="<?= $setv('success_message') ?>" maxlength="500">
                    <small>Shown after submission unless a redirect URL is set.</small>
                </div>

                <div class="form-row">
                    <label>Redirect URL</label>
                    <input type="url" name="redirect_url" value="<?= $setv('redirect_url') ?>" placeholder="https://example.com/thanks">
                    <small>If set, the submitter is redirected here instead of seeing the success message.</small>
                </div>

                <div class="form-row">
                    <label>Notify email</label>
                    <input type="email" name="notify_email" value="<?= $setv('notify_email') ?>" placeholder="admin@example.com">
                    <small>Send an email to this address on each submission.</small>
                </div>

                <div class="form-row">
                    <label>Webhook URL</label>
                    <input type="url" name="webhook_url" value="<?= $setv('webhook_url') ?>" placeholder="https://hooks.example.com/...">
                    <small>POST submissions as JSON to this URL. Private IPs are blocked (SSRF guard).</small>
                </div>

                <div class="form-row">
                    <label><input type="checkbox" name="require_captcha" value="1" <?= !empty($settings['require_captcha']) ? 'checked' : '' ?>> Require CAPTCHA on submit</label>
                    <small>Requires <code>CAPTCHA_PROVIDER</code> to be configured in core's <code>.env</code>.</small>
                </div>
            </fieldset>

            <div style="margin-top:1rem">
                <button class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<!-- ── Field manager ─────────────────────────────────────────────────── -->
<?php if ($isEdit): ?>
<div class="card" style="margin-bottom:1.5rem">
    <div class="card-header">
        <h2>Fields</h2>
        <span style="color:#6b7280;font-size:13px"><?= count($fields) ?> field<?= count($fields) === 1 ? '' : 's' ?></span>
    </div>

    <?php if (empty($fields)): ?>
    <div class="card-body" style="text-align:center;padding:2rem;color:#6b7280">
        No fields yet. Add one below to start collecting submissions.
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Order</th><th>Label / Key</th><th>Type</th><th>Required</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($fields as $i => $f): ?>
            <tr>
                <td style="white-space:nowrap">
                    <?php if ($i > 0): ?>
                    <form method="POST" action="/admin/forms/fields/<?= (int) $f['id'] ?>/move/up" style="display:inline"><?= csrf_field() ?><button class="btn btn-xs btn-secondary" title="Move up">↑</button></form>
                    <?php endif; ?>
                    <?php if ($i < count($fields) - 1): ?>
                    <form method="POST" action="/admin/forms/fields/<?= (int) $f['id'] ?>/move/down" style="display:inline"><?= csrf_field() ?><button class="btn btn-xs btn-secondary" title="Move down">↓</button></form>
                    <?php endif; ?>
                </td>
                <td>
                    <strong><?= e($f['label']) ?></strong>
                    <div style="font-size:12px;color:#9ca3af"><code><?= e($f['field_key']) ?></code></div>
                </td>
                <td><span class="badge badge-gray"><?= e(\Modules\Forms\Services\FormService::FIELD_TYPES[$f['type']] ?? $f['type']) ?></span></td>
                <td><?= (int) $f['required'] === 1 ? '✓' : '' ?></td>
                <td>
                    <form method="POST" action="/admin/forms/fields/<?= (int) $f['id'] ?>/delete" data-confirm="Delete field '<?= e($f['label']) ?>'?">
                        <?= csrf_field() ?><button class="btn btn-xs btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <div class="card-body" style="border-top:1px solid #e5e7eb">
        <h3 style="margin-top:0">Add a field</h3>
        <form method="POST" action="/admin/forms/<?= (int) $form['id'] ?>/fields">
            <?= csrf_field() ?>

            <div class="form-row">
                <label>Label *</label>
                <input type="text" name="label" required maxlength="191">
            </div>

            <div class="form-row">
                <label>Field key</label>
                <input type="text" name="field_key" maxlength="80" placeholder="auto-generated from label">
                <small>Lowercase identifier used in submission JSON. Leave blank to auto-derive.</small>
            </div>

            <div class="form-row">
                <label>Type *</label>
                <select name="type">
                    <?php foreach (\Modules\Forms\Services\FormService::FIELD_TYPES as $k => $label): ?>
                    <option value="<?= e($k) ?>"><?= e($label) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-row">
                <label>Placeholder</label>
                <input type="text" name="placeholder" maxlength="191">
            </div>

            <div class="form-row">
                <label>Help text</label>
                <input type="text" name="help_text" maxlength="500">
            </div>

            <div class="form-row">
                <label>Options <small>(for dropdown / radio — one per line)</small></label>
                <textarea name="options" rows="3" placeholder="Option A&#10;Option B&#10;Option C"></textarea>
            </div>

            <div style="display:flex;gap:1rem;margin-top:.5rem">
                <div class="form-row" style="flex:1">
                    <label>Min length / min value</label>
                    <input type="number" name="rule_min">
                </div>
                <div class="form-row" style="flex:1">
                    <label>Max length / max value</label>
                    <input type="number" name="rule_max">
                </div>
            </div>

            <div class="form-row">
                <label>Regex pattern</label>
                <input type="text" name="rule_pattern" placeholder="^[A-Z0-9-]+$">
                <small>Optional. No delimiters — pattern only.</small>
            </div>

            <div class="form-row">
                <label><input type="checkbox" name="required" value="1"> Required</label>
            </div>

            <button class="btn btn-primary">Add field</button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
