<?php $pageTitle = 'Submission #' . (int) $submission['id']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/forms/<?= (int) $form['id'] ?>/submissions" class="btn btn-sm btn-secondary">← Back</a>
    <h1 style="margin:0;font-size:1.5rem">Submission #<?= (int) $submission['id'] ?></h1>
</div>

<div class="card" style="margin-bottom:1.5rem">
    <div class="card-header"><h2>Meta</h2></div>
    <div class="card-body">
        <dl style="display:grid;grid-template-columns:auto 1fr;gap:.5rem 1rem;margin:0">
            <dt style="color:#6b7280">Form</dt>
            <dd style="margin:0"><a href="/admin/forms/<?= (int) $form['id'] ?>/edit"><?= e($form['name']) ?></a> (<code>/forms/<?= e($form['slug']) ?></code>)</dd>
            <dt style="color:#6b7280">Submitted</dt>
            <dd style="margin:0"><?= e($submission['created_at']) ?></dd>
            <dt style="color:#6b7280">Submitter</dt>
            <dd style="margin:0">
                <?php if (!empty($submission['submitter_username'])): ?>
                    <?= e($submission['submitter_username']) ?> &lt;<?= e((string) $submission['submitter_email']) ?>&gt;
                <?php else: ?>
                    <span style="color:#9ca3af">guest</span>
                <?php endif; ?>
            </dd>
            <dt style="color:#6b7280">IP</dt>
            <dd style="margin:0"><code><?= e((string) ($submission['ip_address'] ?? '—')) ?></code></dd>
            <dt style="color:#6b7280">User agent</dt>
            <dd style="margin:0;font-size:12px;color:#6b7280"><?= e((string) ($submission['user_agent'] ?? '—')) ?></dd>
            <dt style="color:#6b7280">Status</dt>
            <dd style="margin:0"><span class="badge badge-gray"><?= e((string) $submission['status']) ?></span></dd>
        </dl>
    </div>
</div>

<div class="card">
    <div class="card-header"><h2>Data</h2></div>
    <div class="card-body">
        <?php if (empty($fields)): ?>
        <p style="color:#6b7280">This form has no fields defined.</p>
        <?php else: ?>
        <dl style="display:grid;grid-template-columns:auto 1fr;gap:.5rem 1rem;margin:0">
            <?php foreach ($fields as $f): ?>
                <?php $v = $data[$f['field_key']] ?? null; if (is_bool($v)) $v = $v ? 'Yes' : 'No'; if (is_array($v)) $v = implode(', ', $v); ?>
                <dt style="color:#6b7280">
                    <?= e($f['label']) ?>
                    <?php if ((int) $f['required'] === 1): ?><span style="color:#ef4444">*</span><?php endif; ?>
                </dt>
                <dd style="margin:0;white-space:pre-wrap"><?= $v === null || $v === '' ? '<span style="color:#9ca3af">—</span>' : e((string) $v) ?></dd>
            <?php endforeach; ?>
        </dl>
        <?php endif; ?>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
