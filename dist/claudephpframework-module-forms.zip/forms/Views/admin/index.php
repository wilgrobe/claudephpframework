<?php $pageTitle = 'Forms'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h2>Forms</h2>
        <a href="/admin/forms/create" class="btn btn-primary btn-sm">+ New Form</a>
    </div>
    <?php if (empty($forms)): ?>
    <div class="card-body" style="text-align:center;padding:3rem 1rem">
        <p style="color:#6b7280;margin-bottom:1rem">No forms yet.</p>
        <a href="/admin/forms/create" class="btn btn-primary">Create your first form</a>
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Public URL</th>
                    <th>Status</th>
                    <th>Submissions</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($forms as $f): ?>
            <tr>
                <td><strong><?= e($f['name']) ?></strong>
                    <?php if (!empty($f['description'])): ?>
                    <div style="font-size:12px;color:#9ca3af;margin-top:.2rem"><?= e(mb_substr($f['description'], 0, 120)) ?></div>
                    <?php endif; ?>
                </td>
                <td><code style="font-size:12px;background:#f3f4f6;padding:.1rem .35rem;border-radius:4px">/forms/<?= e($f['slug']) ?></code></td>
                <td>
                    <?php if ((int) $f['enabled'] === 1): ?>
                    <span class="badge badge-success">Enabled</span>
                    <?php else: ?>
                    <span class="badge badge-gray">Disabled</span>
                    <?php endif; ?>
                </td>
                <td><?= (int) $f['submissions_count'] ?></td>
                <td>
                    <div style="display:flex;gap:.35rem">
                        <a href="/forms/<?= e($f['slug']) ?>" target="_blank" class="btn btn-xs btn-secondary">View</a>
                        <a href="/admin/forms/<?= (int) $f['id'] ?>/edit" class="btn btn-xs btn-secondary">Edit</a>
                        <a href="/admin/forms/<?= (int) $f['id'] ?>/submissions" class="btn btn-xs btn-secondary">Submissions</a>
                        <form method="POST" action="/admin/forms/<?= (int) $f['id'] ?>/delete" data-confirm="Delete form '<?= e($f['name']) ?>' and all its submissions?">
                            <?= csrf_field() ?><button class="btn btn-xs btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
