<?php
// modules/forms/Services/FormService.php
namespace Modules\Forms\Services;

use Core\Database\Database;
use Core\Services\MailService;
use Core\Services\WebhookService;

/**
 * Shared logic for the forms module: field fetch, validation against the
 * per-field rules JSON, submission dispatch (webhook + email), CSV export.
 *
 * Kept controller-agnostic so the public and admin controllers both call
 * through here rather than duplicating the logic.
 */
class FormService
{
    /** Supported field types. Drives both the admin "type" <select> and the validator. */
    public const FIELD_TYPES = [
        'text'     => 'Single-line text',
        'textarea' => 'Multi-line text',
        'email'    => 'Email address',
        'number'   => 'Number',
        'select'   => 'Dropdown',
        'radio'    => 'Radio buttons',
        'checkbox' => 'Checkbox (yes/no)',
        'date'     => 'Date',
    ];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Fetch helpers ─────────────────────────────────────────────────────

    public function findBySlug(string $slug): ?array
    {
        return $this->db->fetchOne("SELECT * FROM forms WHERE slug = ?", [$slug]);
    }

    public function findById(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM forms WHERE id = ?", [$id]);
    }

    /** @return array<int, array<string, mixed>> ordered by sort_order */
    public function fieldsFor(int $formId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM form_fields WHERE form_id = ? ORDER BY sort_order ASC, id ASC",
            [$formId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function submissionsFor(int $formId, int $limit = 50, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT s.*, u.username AS submitter_username, u.email AS submitter_email
               FROM form_submissions s
          LEFT JOIN users u ON u.id = s.user_id
              WHERE s.form_id = ?
           ORDER BY s.created_at DESC
              LIMIT ? OFFSET ?",
            [$formId, $limit, $offset]
        );
    }

    public function totalSubmissions(int $formId): int
    {
        return (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM form_submissions WHERE form_id = ?",
            [$formId]
        );
    }

    public function submissionById(int $subId, int $formId): ?array
    {
        return $this->db->fetchOne(
            "SELECT s.*, u.username AS submitter_username, u.email AS submitter_email
               FROM form_submissions s
          LEFT JOIN users u ON u.id = s.user_id
              WHERE s.id = ? AND s.form_id = ?",
            [$subId, $formId]
        );
    }

    // ── Validation ────────────────────────────────────────────────────────

    /**
     * Validate $post against the form's $fields definition.
     *
     * @param  array<int, array<string, mixed>> $fields  from fieldsFor()
     * @param  array<string, mixed>             $post    user input
     * @return array{0: array<string,mixed>, 1: array<string, string[]>}
     *                                         [sanitized values, errors]
     */
    public function validateSubmission(array $fields, array $post): array
    {
        $values = [];
        $errors = [];

        foreach ($fields as $field) {
            $key      = (string) $field['field_key'];
            $type     = (string) $field['type'];
            $required = (int) $field['required'] === 1;
            $rules    = $field['validation_rules'] ? (json_decode($field['validation_rules'], true) ?: []) : [];
            $raw      = $post[$key] ?? null;

            // Blank check first — required but empty is the most common error.
            $isBlank = $raw === null || $raw === '' || (is_array($raw) && empty($raw));
            if ($isBlank) {
                if ($required) {
                    $errors[$key][] = $field['label'] . ' is required.';
                }
                // Record blank as null so exports + the submission row are well-shaped.
                $values[$key] = null;
                continue;
            }

            // Type-specific normalization + validation.
            $clean = $this->normalizeField($type, $raw, $field, $rules, $errors);
            $values[$key] = $clean;
        }

        return [$values, $errors];
    }

    /**
     * Normalize one field's raw value and append errors to $errors if the
     * value is invalid. Pass-by-reference on $errors to keep the return
     * cleaner — call sites always care about the normalized value too.
     *
     * @return mixed normalized value (string/int/float/bool/string[]/null)
     */
    private function normalizeField(
        string $type, mixed $raw, array $field, array $rules, array &$errors
    ): mixed {
        $key   = (string) $field['field_key'];
        $label = (string) $field['label'];

        switch ($type) {
            case 'text':
            case 'textarea':
                $v = trim((string) $raw);
                if (isset($rules['min']) && mb_strlen($v) < (int) $rules['min']) {
                    $errors[$key][] = "$label must be at least {$rules['min']} characters.";
                }
                if (isset($rules['max']) && mb_strlen($v) > (int) $rules['max']) {
                    $errors[$key][] = "$label must be no more than {$rules['max']} characters.";
                }
                if (!empty($rules['pattern']) && @preg_match('/' . $rules['pattern'] . '/', $v) !== 1) {
                    $errors[$key][] = "$label is not in the expected format.";
                }
                return $v;

            case 'email':
                $v = trim((string) $raw);
                if (!filter_var($v, FILTER_VALIDATE_EMAIL)) {
                    $errors[$key][] = "$label must be a valid email address.";
                }
                return $v;

            case 'number':
                if (!is_numeric($raw)) {
                    $errors[$key][] = "$label must be a number.";
                    return null;
                }
                $v = $raw + 0; // coerces to int or float
                if (isset($rules['min']) && $v < $rules['min']) {
                    $errors[$key][] = "$label must be at least {$rules['min']}.";
                }
                if (isset($rules['max']) && $v > $rules['max']) {
                    $errors[$key][] = "$label must be no more than {$rules['max']}.";
                }
                return $v;

            case 'select':
            case 'radio':
                $v       = (string) $raw;
                $options = $field['options'] ? (json_decode($field['options'], true) ?: []) : [];
                if (!empty($options) && !in_array($v, $options, true)) {
                    $errors[$key][] = "$label must be one of the available options.";
                }
                return $v;

            case 'checkbox':
                // Single-checkbox semantic: true/false. Treat any truthy post value as checked.
                return filter_var($raw, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) ?? false;

            case 'date':
                $v = trim((string) $raw);
                $d = \DateTimeImmutable::createFromFormat('Y-m-d', $v);
                if (!$d || $d->format('Y-m-d') !== $v) {
                    $errors[$key][] = "$label must be a valid date (YYYY-MM-DD).";
                }
                return $v;

            default:
                // Unknown type → keep as string; admin shouldn't have let this happen.
                return (string) $raw;
        }
    }

    // ── Post-submit notifications ─────────────────────────────────────────

    /**
     * Fire optional webhook + email. Best-effort: failures here are logged
     * but don't roll back the submission or reveal to the submitter.
     *
     * $form contains the raw forms row.
     * $fields is the fieldsFor() list, used to render the email body.
     * $values is the validated submission payload.
     * $settings is $form['settings'] parsed.
     */
    public function dispatchNotifications(
        array $form, array $fields, array $values, int $submissionId, array $settings
    ): void {
        // Webhook — posts the submission as JSON. WebhookService writes to
        // message_log and retries via MessageRetryService if transport fails,
        // so a brief provider outage doesn't lose the event.
        if (!empty($settings['webhook_url'])) {
            try {
                (new WebhookService())->send((string) $settings['webhook_url'], [
                    'form_id'       => (int) $form['id'],
                    'form_slug'     => $form['slug'],
                    'submission_id' => $submissionId,
                    'data'          => $values,
                    'submitted_at'  => date('c'),
                ]);
            } catch (\Throwable $e) {
                error_log('[forms] webhook dispatch failed: ' . $e->getMessage());
            }
        }

        // Email notification — rendered as a plain list of label → value pairs.
        if (!empty($settings['notify_email'])) {
            try {
                $lines = ["New submission on form: {$form['name']}", str_repeat('-', 40)];
                foreach ($fields as $f) {
                    $v = $values[$f['field_key']] ?? '';
                    if (is_bool($v))   $v = $v ? 'Yes' : 'No';
                    if (is_array($v))  $v = implode(', ', $v);
                    $lines[] = $f['label'] . ': ' . $v;
                }
                $body = implode("\n", $lines);
                (new MailService())->send(
                    (string) $settings['notify_email'],
                    'New submission: ' . $form['name'],
                    nl2br(htmlspecialchars($body, ENT_QUOTES)),
                    $body
                );
            } catch (\Throwable $e) {
                error_log('[forms] notify email failed: ' . $e->getMessage());
            }
        }
    }

    // ── CSV export ────────────────────────────────────────────────────────

    /**
     * Flatten submissions into a CSV-shaped 2D array.
     *
     * Header row: ['id', 'submitted_at', 'ip_address', 'user_id', ...field labels]
     * Each data row: values in the same column order. Missing keys render as empty.
     *
     * @return array<int, array<int, string>>  header first, then rows
     */
    public function csvExport(int $formId): array
    {
        $fields      = $this->fieldsFor($formId);
        $submissions = $this->db->fetchAll(
            "SELECT * FROM form_submissions WHERE form_id = ? ORDER BY created_at ASC",
            [$formId]
        );

        $header = ['id', 'submitted_at', 'ip_address', 'user_id'];
        foreach ($fields as $f) {
            $header[] = (string) $f['label'];
        }

        $out = [$header];
        foreach ($submissions as $s) {
            $data = json_decode((string) $s['data'], true) ?: [];
            $row  = [
                (string) $s['id'],
                (string) $s['created_at'],
                (string) ($s['ip_address'] ?? ''),
                (string) ($s['user_id'] ?? ''),
            ];
            foreach ($fields as $f) {
                $v = $data[$f['field_key']] ?? '';
                if (is_bool($v))  $v = $v ? 'true' : 'false';
                if (is_array($v)) $v = implode('|', $v);
                $row[] = (string) $v;
            }
            $out[] = $row;
        }
        return $out;
    }
}
