<?php
// modules/forms/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$F = 'Modules\Forms\Controllers\FormController';
$A = 'Modules\Forms\Controllers\FormAdminController';

// ── Public render + submit ────────────────────────────────────────────────
$router->get ('/forms/{slug}', "$F@show");
$router->post('/forms/{slug}', "$F@submit", [CsrfMiddleware::class]);

// ── Admin CRUD ────────────────────────────────────────────────────────────
$router->get ('/admin/forms',             "$A@index",  [AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/forms/create',      "$A@create", [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/forms/create',      "$A@store",  [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/forms/{id}/edit',   "$A@edit",   [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/forms/{id}/edit',   "$A@update", [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/forms/{id}/delete', "$A@delete", [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);

// Field management (per-form)
$router->post('/admin/forms/{id}/fields',                 "$A@addField",      [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/forms/fields/{fieldId}/delete',     "$A@deleteField",   [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/forms/fields/{fieldId}/move/{dir}', "$A@moveField",     [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);

// Submissions
$router->get ('/admin/forms/{id}/submissions',                       "$A@submissions",       [AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/forms/{id}/submissions/{subId}',               "$A@submission",        [AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/forms/{id}/submissions.csv',                   "$A@exportCsv",         [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/forms/{id}/submissions/{subId}/delete',        "$A@deleteSubmission",  [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
