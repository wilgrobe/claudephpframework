<?php
// modules/forms/migrations/2026_04_22_150000_create_forms_tables.php
use Core\Database\Migration;

/**
 * Schema for the forms module.
 *
 * Three tables:
 *   - forms            — one row per form definition
 *   - form_fields      — many rows per form, defining the inputs
 *   - form_submissions — one row per submit, data as JSON
 *
 * JSON for submission data keeps the schema flexible: adding a new field
 * to a form doesn't require a migration, and CSV export flattens at read
 * time. The downside (no SQL-native filtering on field values) is fine for
 * submission volumes that fit this use case — if an app's forms graduate
 * to analytics-grade volume, promote the fields it cares about into typed
 * columns via a follow-up migration.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE forms (
                id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name        VARCHAR(191) NOT NULL,
                slug        VARCHAR(120) NOT NULL,
                description TEXT         NULL,
                settings    JSON         NULL,
                enabled     TINYINT(1)   NOT NULL DEFAULT 1,
                created_by  INT UNSIGNED NULL,
                created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uq_slug (slug),
                KEY idx_enabled (enabled)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE form_fields (
                id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                form_id          INT UNSIGNED NOT NULL,
                field_key        VARCHAR(80)  NOT NULL,
                type             VARCHAR(32)  NOT NULL,
                label            VARCHAR(191) NOT NULL,
                placeholder      VARCHAR(191) NULL,
                help_text        VARCHAR(500) NULL,
                required         TINYINT(1)   NOT NULL DEFAULT 0,
                options          JSON         NULL,
                validation_rules JSON         NULL,
                sort_order       INT          NOT NULL DEFAULT 0,
                created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_form_field (form_id, field_key),
                KEY idx_form_order (form_id, sort_order),
                CONSTRAINT fk_form_fields_form
                    FOREIGN KEY (form_id) REFERENCES forms (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE form_submissions (
                id         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                form_id    INT UNSIGNED NOT NULL,
                user_id    INT UNSIGNED NULL,
                data       JSON         NOT NULL,
                ip_address VARCHAR(45)  NULL,
                user_agent VARCHAR(255) NULL,
                status     ENUM('submitted','spam','processed') NOT NULL DEFAULT 'submitted',
                created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_form_created (form_id, created_at),
                KEY idx_user (user_id),
                KEY idx_status (status),
                CONSTRAINT fk_form_submissions_form
                    FOREIGN KEY (form_id) REFERENCES forms (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS form_submissions");
        $this->db->query("DROP TABLE IF EXISTS form_fields");
        $this->db->query("DROP TABLE IF EXISTS forms");
    }
};
