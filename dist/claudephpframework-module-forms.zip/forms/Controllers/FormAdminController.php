<?php
// modules/forms/Controllers/FormAdminController.php
namespace Modules\Forms\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Validation\Validator;
use Modules\Forms\Services\FormService;

/**
 * Admin CRUD for forms, their fields, and submissions. Routes are
 * protected by AuthMiddleware + RequireAdmin at registration; per-method
 * permission checks provide defense-in-depth.
 */
class FormAdminController
{
    private Database    $db;
    private Auth        $auth;
    private FormService $forms;

    public function __construct()
    {
        $this->db    = Database::getInstance();
        $this->auth  = Auth::getInstance();
        $this->forms = new FormService();
    }

    // ── Forms CRUD ────────────────────────────────────────────────────────

    public function index(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $rows = $this->db->fetchAll("
            SELECT f.*,
                   (SELECT COUNT(*) FROM form_submissions s WHERE s.form_id = f.id) AS submissions_count
              FROM forms f
             ORDER BY f.name ASC
        ");

        return Response::view('forms::admin.index', [
            'forms' => $rows,
            'user'  => $this->auth->user(),
        ]);
    }

    public function create(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();
        return Response::view('forms::admin.form', [
            'form'   => null,
            'fields' => [],
            'user'   => $this->auth->user(),
        ]);
    }

    public function store(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $v = new Validator($request->post());
        $v->validate([
            'name' => 'required|min:2|max:191',
            'slug' => 'required|min:2|max:120',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            Session::flash('old', $v->all());
            return Response::redirect('/admin/forms/create');
        }

        $slug = $this->sanitizeSlug((string) $v->get('slug'));
        if ($this->db->fetchOne("SELECT id FROM forms WHERE slug = ?", [$slug])) {
            Session::flash('errors', ['slug' => ['That slug is already in use.']]);
            Session::flash('old', $v->all());
            return Response::redirect('/admin/forms/create');
        }

        $id = $this->db->insert('forms', [
            'name'        => $v->get('name'),
            'slug'        => $slug,
            'description' => $request->post('description'),
            'settings'    => json_encode($this->buildSettings($request->post())),
            'enabled'     => (int) $request->post('enabled', 1),
            'created_by'  => $this->auth->id(),
        ]);

        $this->auth->auditLog('form.create', 'forms', $id);
        return Response::redirect("/admin/forms/$id/edit")
            ->withFlash('success', 'Form created. Now add some fields.');
    }

    public function edit(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $id   = (int) $request->param(0);
        $form = $this->forms->findById($id);
        if (!$form) return new Response('Form not found', 404);

        return Response::view('forms::admin.form', [
            'form'   => $form,
            'fields' => $this->forms->fieldsFor($id),
            'user'   => $this->auth->user(),
        ]);
    }

    public function update(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $id   = (int) $request->param(0);
        $form = $this->forms->findById($id);
        if (!$form) return new Response('Form not found', 404);

        $v = new Validator($request->post());
        $v->validate([
            'name' => 'required|min:2|max:191',
            'slug' => 'required|min:2|max:120',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect("/admin/forms/$id/edit");
        }

        $slug = $this->sanitizeSlug((string) $v->get('slug'));
        $clash = $this->db->fetchOne("SELECT id FROM forms WHERE slug = ? AND id <> ?", [$slug, $id]);
        if ($clash) {
            Session::flash('errors', ['slug' => ['That slug is already in use by another form.']]);
            return Response::redirect("/admin/forms/$id/edit");
        }

        $this->db->update('forms', [
            'name'        => $v->get('name'),
            'slug'        => $slug,
            'description' => $request->post('description'),
            'settings'    => json_encode($this->buildSettings($request->post())),
            'enabled'     => (int) $request->post('enabled', 1),
        ], 'id = ?', [$id]);

        $this->auth->auditLog('form.update', 'forms', $id);
        return Response::redirect("/admin/forms/$id/edit")
            ->withFlash('success', 'Form saved.');
    }

    public function delete(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $id = (int) $request->param(0);
        if (!$this->forms->findById($id)) return new Response('Form not found', 404);

        // Cascade deletes fields + submissions via FK ON DELETE CASCADE.
        $this->db->delete('forms', 'id = ?', [$id]);
        $this->auth->auditLog('form.delete', 'forms', $id);
        return Response::redirect('/admin/forms')
            ->withFlash('success', 'Form deleted.');
    }

    // ── Field management ──────────────────────────────────────────────────

    public function addField(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $formId = (int) $request->param(0);
        $form   = $this->forms->findById($formId);
        if (!$form) return new Response('Form not found', 404);

        $type  = (string) $request->post('type', 'text');
        if (!array_key_exists($type, FormService::FIELD_TYPES)) $type = 'text';
        $label = trim((string) $request->post('label', ''));
        $key   = $this->sanitizeFieldKey((string) ($request->post('field_key') ?: $label));

        if ($label === '' || $key === '') {
            Session::flash('errors', ['label' => ['Label and field_key are required.']]);
            return Response::redirect("/admin/forms/$formId/edit");
        }

        // Avoid key collision — append a numeric suffix until unique within the form.
        $key = $this->uniqueFieldKey($formId, $key);

        // Options for select/radio arrive as a newline-separated string.
        $options = null;
        if (in_array($type, ['select', 'radio'], true)) {
            $raw = (string) $request->post('options', '');
            $opts = array_values(array_filter(array_map('trim', explode("\n", $raw)), fn($o) => $o !== ''));
            $options = json_encode($opts);
        }

        $rules = [];
        if ($request->post('rule_min') !== null && $request->post('rule_min') !== '')   $rules['min']     = (int) $request->post('rule_min');
        if ($request->post('rule_max') !== null && $request->post('rule_max') !== '')   $rules['max']     = (int) $request->post('rule_max');
        if ($request->post('rule_pattern'))                                              $rules['pattern'] = (string) $request->post('rule_pattern');

        $nextSort = (int) $this->db->fetchColumn(
            "SELECT COALESCE(MAX(sort_order), 0) + 10 FROM form_fields WHERE form_id = ?",
            [$formId]
        );

        $this->db->insert('form_fields', [
            'form_id'          => $formId,
            'field_key'        => $key,
            'type'             => $type,
            'label'            => $label,
            'placeholder'      => $request->post('placeholder'),
            'help_text'        => $request->post('help_text'),
            'required'         => (int) $request->post('required', 0),
            'options'          => $options,
            'validation_rules' => !empty($rules) ? json_encode($rules) : null,
            'sort_order'       => $nextSort,
        ]);

        return Response::redirect("/admin/forms/$formId/edit")->withFlash('success', 'Field added.');
    }

    public function deleteField(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $fieldId = (int) $request->param(0);
        $field   = $this->db->fetchOne("SELECT form_id FROM form_fields WHERE id = ?", [$fieldId]);
        if (!$field) return new Response('Field not found', 404);

        $this->db->delete('form_fields', 'id = ?', [$fieldId]);
        return Response::redirect("/admin/forms/{$field['form_id']}/edit")
            ->withFlash('success', 'Field deleted.');
    }

    public function moveField(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $fieldId = (int) $request->param(0);
        $dir     = (string) $request->param(1);
        $field   = $this->db->fetchOne("SELECT id, form_id, sort_order FROM form_fields WHERE id = ?", [$fieldId]);
        if (!$field || !in_array($dir, ['up', 'down'], true)) return new Response('Bad request', 400);

        // Swap with the neighbor in the requested direction.
        $neighborSql = $dir === 'up'
            ? "SELECT id, sort_order FROM form_fields WHERE form_id = ? AND sort_order < ? ORDER BY sort_order DESC LIMIT 1"
            : "SELECT id, sort_order FROM form_fields WHERE form_id = ? AND sort_order > ? ORDER BY sort_order ASC  LIMIT 1";
        $neighbor = $this->db->fetchOne($neighborSql, [(int) $field['form_id'], (int) $field['sort_order']]);

        if ($neighbor) {
            $this->db->transaction(function () use ($field, $neighbor) {
                $this->db->update('form_fields', ['sort_order' => (int) $neighbor['sort_order']], 'id = ?', [(int) $field['id']]);
                $this->db->update('form_fields', ['sort_order' => (int) $field['sort_order']],    'id = ?', [(int) $neighbor['id']]);
            });
        }

        return Response::redirect("/admin/forms/{$field['form_id']}/edit");
    }

    // ── Submissions ───────────────────────────────────────────────────────

    public function submissions(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $formId = (int) $request->param(0);
        $form   = $this->forms->findById($formId);
        if (!$form) return new Response('Form not found', 404);

        $page    = max(1, (int) $request->query('page', 1));
        $perPage = 50;
        $offset  = ($page - 1) * $perPage;

        $rows  = $this->forms->submissionsFor($formId, $perPage, $offset);
        $total = $this->forms->totalSubmissions($formId);

        return Response::view('forms::admin.submissions', [
            'form'        => $form,
            'fields'      => $this->forms->fieldsFor($formId),
            'submissions' => $rows,
            'total'       => $total,
            'page'        => $page,
            'per_page'    => $perPage,
            'user'        => $this->auth->user(),
        ]);
    }

    public function submission(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $formId = (int) $request->param(0);
        $subId  = (int) $request->param(1);
        $form   = $this->forms->findById($formId);
        if (!$form) return new Response('Form not found', 404);

        $sub = $this->forms->submissionById($subId, $formId);
        if (!$sub) return new Response('Submission not found', 404);

        return Response::view('forms::admin.submission', [
            'form'       => $form,
            'fields'     => $this->forms->fieldsFor($formId),
            'submission' => $sub,
            'data'       => json_decode((string) $sub['data'], true) ?: [],
            'user'       => $this->auth->user(),
        ]);
    }

    public function exportCsv(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $formId = (int) $request->param(0);
        $form   = $this->forms->findById($formId);
        if (!$form) return new Response('Form not found', 404);

        $rows = $this->forms->csvExport($formId);

        // Build the CSV string. Using fputcsv to get proper quoting.
        $fh = fopen('php://temp', 'w+');
        foreach ($rows as $row) {
            fputcsv($fh, $row);
        }
        rewind($fh);
        $csv = stream_get_contents($fh);
        fclose($fh);

        $filename = 'form-' . preg_replace('/[^a-zA-Z0-9_-]+/', '-', (string) $form['slug']) . '-submissions.csv';
        return (new Response($csv, 200, [
            'Content-Type'        => 'text/csv; charset=UTF-8',
            'Content-Disposition' => "attachment; filename=\"$filename\"",
        ]));
    }

    public function deleteSubmission(Request $request): Response
    {
        if ($this->auth->cannot('forms.manage')) return $this->denied();

        $formId = (int) $request->param(0);
        $subId  = (int) $request->param(1);
        // Ownership check — the subId must belong to formId, otherwise 404
        // so a bad URL can't silently delete another form's submission.
        $sub = $this->forms->submissionById($subId, $formId);
        if (!$sub) return new Response('Submission not found', 404);

        $this->db->delete('form_submissions', 'id = ?', [$subId]);
        return Response::redirect("/admin/forms/$formId/submissions")
            ->withFlash('success', 'Submission deleted.');
    }

    // ── internals ─────────────────────────────────────────────────────────

    private function denied(): Response
    {
        return Response::redirect('/dashboard')->withFlash('error', 'You do not have permission to manage forms.');
    }

    private function sanitizeSlug(string $raw): string
    {
        $slug = strtolower(trim($raw));
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
        return trim((string) $slug, '-');
    }

    private function sanitizeFieldKey(string $raw): string
    {
        $key = strtolower(trim($raw));
        $key = preg_replace('/[^a-z0-9_]+/', '_', $key);
        $key = trim((string) $key, '_');
        // Field keys can't start with a digit — they're used as JSON keys
        // and some consumers read them as struct fields.
        if ($key === '' || preg_match('/^\d/', $key)) {
            $key = 'f_' . $key;
        }
        return substr($key, 0, 80);
    }

    private function uniqueFieldKey(int $formId, string $base): string
    {
        $candidate = $base;
        $i = 2;
        while ($this->db->fetchOne(
            "SELECT id FROM form_fields WHERE form_id = ? AND field_key = ?",
            [$formId, $candidate]
        )) {
            $candidate = $base . '_' . $i++;
            if ($i > 100) break; // bail sanity
        }
        return $candidate;
    }

    /**
     * Extract the per-form settings blob from the POST. Only known keys are
     * preserved; anything else is dropped so a crafted POST can't widen the
     * settings shape.
     */
    private function buildSettings(array $post): array
    {
        $out = [];
        foreach (['success_message', 'redirect_url', 'notify_email', 'webhook_url'] as $k) {
            if (!empty($post[$k])) $out[$k] = (string) $post[$k];
        }
        if (!empty($post['require_captcha'])) $out['require_captcha'] = true;
        return $out;
    }
}
