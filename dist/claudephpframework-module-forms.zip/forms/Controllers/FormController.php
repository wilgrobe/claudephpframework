<?php
// modules/forms/Controllers/FormController.php
namespace Modules\Forms\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Core\Session;
use Modules\Forms\Services\FormService;

/**
 * Public-facing form rendering + submission.
 *
 * The submit action writes a row to form_submissions, then optionally fires
 * a webhook (via WebhookService) and sends a notification email (via
 * MailService). Both are best-effort — the submitter sees success even if
 * downstream dispatch fails, because the submission itself is already saved.
 */
class FormController
{
    private Database    $db;
    private Auth        $auth;
    private FormService $forms;

    public function __construct()
    {
        $this->db    = Database::getInstance();
        $this->auth  = Auth::getInstance();
        $this->forms = new FormService();
    }

    public function show(Request $request): Response
    {
        $slug = (string) $request->param(0);
        $form = $this->forms->findBySlug($slug);

        if (!$form || (int) $form['enabled'] !== 1) {
            return new Response('Form not found', 404);
        }

        $fields = $this->forms->fieldsFor((int) $form['id']);

        return Response::view('forms::public.show', [
            'form'   => $form,
            'fields' => $fields,
            'errors' => Session::get('errors', []),
            'old'    => Session::get('old', []),
            'user'   => $this->auth->user(),
        ]);
    }

    public function submit(Request $request): Response
    {
        $slug = (string) $request->param(0);
        $form = $this->forms->findBySlug($slug);

        if (!$form || (int) $form['enabled'] !== 1) {
            return new Response('Form not found', 404);
        }

        $fields   = $this->forms->fieldsFor((int) $form['id']);
        $settings = $form['settings'] ? (json_decode($form['settings'], true) ?: []) : [];

        // Optional captcha gate — forms.settings.require_captcha triggers it.
        if (!empty($settings['require_captcha'])) {
            $token = \Core\Services\CaptchaService::tokenFromRequest($request->post());
            // Release session lock around the provider round-trip (see
            // AuthController's login for the rationale).
            $sessionActive = session_status() === PHP_SESSION_ACTIVE;
            if ($sessionActive) session_write_close();
            $captchaOk = \Core\Services\CaptchaService::verify($token, $request->ip());
            if ($sessionActive) session_start();

            if (!$captchaOk) {
                Session::flash('errors', ['_captcha' => ['Please complete the security challenge.']]);
                Session::flash('old', $request->post());
                return Response::redirect("/forms/$slug");
            }
        }

        // Validate and extract submission payload from the POST.
        [$values, $errors] = $this->forms->validateSubmission($fields, $request->post());
        if (!empty($errors)) {
            Session::flash('errors', $errors);
            Session::flash('old', $request->post());
            return Response::redirect("/forms/$slug");
        }

        // Persist.
        $submissionId = $this->db->insert('form_submissions', [
            'form_id'    => (int) $form['id'],
            'user_id'    => $this->auth->id(),
            'data'       => json_encode($values, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            'ip_address' => substr($request->ip() ?? '', 0, 45),
            'user_agent' => substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
            'status'     => 'submitted',
        ]);

        // Best-effort dispatch — never block on these.
        $this->forms->dispatchNotifications($form, $fields, $values, $submissionId, $settings);

        // Redirect to a declared URL if configured, otherwise show the thanks view.
        if (!empty($settings['redirect_url'])) {
            return Response::redirect((string) $settings['redirect_url']);
        }
        return Response::view('forms::public.thanks', [
            'form'    => $form,
            'message' => $settings['success_message'] ?? 'Thank you — your submission has been received.',
            'user'    => $this->auth->user(),
        ]);
    }
}
