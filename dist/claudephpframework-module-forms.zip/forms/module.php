<?php
// modules/forms/module.php
use Core\Module\ModuleProvider;

/**
 * Forms module — drag-drop form builder with submissions storage.
 *
 * Apps build arbitrary forms (contact, lead capture, surveys, application
 * intake) without a single form-specific controller per case. Each form has
 * a set of typed fields, public URL at /forms/{slug}, and an admin surface
 * under /admin/forms/*.
 *
 * Submissions are stored as JSON in form_submissions.data — flexible schema
 * scales to any field configuration without migrating the table per form.
 * CSV export handles the flattening when an admin exports.
 *
 * Optional per-form knobs (persisted in forms.settings JSON):
 *   - webhook_url     — POST each submission to this URL via WebhookService
 *   - notify_email    — send an email on each submission via MailService
 *   - success_message — shown after submit (default "Thank you")
 *   - redirect_url    — if set, redirect instead of showing success page
 *   - require_captcha — force CaptchaService verification on submit
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'forms'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
