# Forms module

Drag-free form builder with typed fields, per-form settings, and submission
storage. Build contact forms, lead capture, surveys, application intakes,
and internal data-collection forms without writing a controller per case.

## Features

- Admin CRUD for forms with name, slug, description, enabled flag
- Field types: text, textarea, email, number, dropdown, radio, checkbox, date
- Per-field rules: required, min/max length or value, regex pattern
- Public form at `/forms/{slug}` with CSRF + optional CAPTCHA
- Submissions stored as JSON — schema changes don't require migrations
- Admin surface for viewing submissions, paginated
- CSV export of all submissions
- Per-form post-submit hooks (all optional, persisted in `forms.settings`):
  - **success_message** — shown after submit
  - **redirect_url** — redirect instead of showing success
  - **notify_email** — send an email on each submission
  - **webhook_url** — POST submission JSON (private IPs blocked by core's SSRF guard)
  - **require_captcha** — force CaptchaService verification

## Routes

### Public

| Method | Path              | Middleware | Purpose          |
|--------|-------------------|------------|------------------|
| GET    | `/forms/{slug}`   | —          | Render form      |
| POST   | `/forms/{slug}`   | Csrf       | Submit           |

### Admin (`Auth + RequireAdmin`)

| Method | Path                                                 | Purpose                |
|--------|------------------------------------------------------|------------------------|
| GET    | `/admin/forms`                                       | List forms             |
| GET/POST | `/admin/forms/create`                              | New form               |
| GET/POST | `/admin/forms/{id}/edit`                           | Edit form + fields     |
| POST   | `/admin/forms/{id}/delete`                           | Delete form            |
| POST   | `/admin/forms/{id}/fields`                           | Add field              |
| POST   | `/admin/forms/fields/{fieldId}/delete`               | Delete field           |
| POST   | `/admin/forms/fields/{fieldId}/move/{up\|down}`      | Reorder fields         |
| GET    | `/admin/forms/{id}/submissions`                      | List submissions       |
| GET    | `/admin/forms/{id}/submissions/{subId}`              | Submission detail      |
| GET    | `/admin/forms/{id}/submissions.csv`                  | CSV export             |
| POST   | `/admin/forms/{id}/submissions/{subId}/delete`       | Delete submission      |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
