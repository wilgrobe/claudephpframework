# Installation — Forms module

## Prerequisites

- `claudephpframework-core` installed. See its INSTALL.md.
- `forms.manage` permission granted to at least one admin role. Add via
  `/admin/roles` if it doesn't exist yet (key: `forms.manage`, label:
  "Manage forms").

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-forms.zip
   cp -r claudephpframework-module-forms/forms /path/to/project/modules/
   ```

2. Run migrations — this module ships with one that creates `forms`,
   `form_fields`, and `form_submissions`:
   ```bash
   php artisan migrate
   ```

3. If you've enabled module caching in production, refresh it so the new
   module is discovered:
   ```bash
   php artisan module:cache
   ```

## Environment variables

None specific to this module. If you want per-form CAPTCHA, configure
`CAPTCHA_PROVIDER` in core's `.env` and check "Require CAPTCHA" on any
form that needs it. If you want webhook delivery, ensure
`WEBHOOK_DRIVER=http` (or `auto` in production) in core's `.env` — the
forms module uses `WebhookService` which also applies core's SSRF guard.

## Verification

1. Log in as an admin, visit `/admin/forms`.
2. Click **+ New Form**, give it a name ("Contact") and slug ("contact"),
   save.
3. On the edit page, add a few fields (e.g. a text "Name", email "Email",
   textarea "Message"). Mark Name and Email required.
4. Open `/forms/contact` in another browser tab — you should see the
   public form.
5. Submit it with test data. You should land on the thank-you page.
6. Back in admin, visit `/admin/forms/{id}/submissions` — your submission
   appears.
7. Click **Export CSV** — downloads with proper quoting and column headers.

## Troubleshooting

- **`/forms/{slug}` returns 404** — the form exists but `enabled = 0`, or
  the slug was renamed. Check `/admin/forms`.
- **Submit shows "Please complete the security challenge"** — `require_captcha`
  is set but `CAPTCHA_PROVIDER` is empty in `.env`. Either configure a
  CAPTCHA provider or uncheck the per-form toggle.
- **Webhook never fires** — check `message_log` in the superadmin message
  log. Entries with `channel='webhook'` are the attempts; failures are
  retried automatically by the scheduled `retry-messages` task. The SSRF
  guard will also block URLs that resolve to private IPs — expected
  behavior for security.
- **Notify email not received** — same debugging path via `message_log`;
  check that `MAIL_DRIVER` is configured and not `none`.
