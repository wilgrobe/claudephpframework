# Architecture — Forms module

## Files

```
forms/
├── module.php
├── routes.php                                       # 14 routes
├── Controllers/
│   ├── FormController.php                           # Public show + submit
│   └── FormAdminController.php                      # Admin CRUD + submissions
├── Services/
│   └── FormService.php                              # Shared: fetch, validate, dispatch, CSV
├── Views/
│   ├── admin/index.php                              # Forms list
│   ├── admin/form.php                               # Create/edit form + fields
│   ├── admin/submissions.php                        # Paginated submissions
│   └── admin/submission.php                         # Single submission detail
│   ├── public/show.php                              # Public form render
│   └── public/thanks.php                            # After successful submit
└── migrations/
    └── 2026_04_22_150000_create_forms_tables.php    # 3 tables
```

## Tables

**`forms`**
```
id, name, slug (unique), description, settings JSON, enabled,
created_by, created_at, updated_at
```

**`form_fields`**
```
id, form_id (FK, cascade), field_key, type, label, placeholder,
help_text, required, options JSON, validation_rules JSON, sort_order
UNIQUE (form_id, field_key)
```

**`form_submissions`**
```
id, form_id (FK, cascade), user_id (nullable), data JSON,
ip_address, user_agent, status, created_at
```

Both child tables cascade on `forms` delete — dropping a form cleans up
its fields and submissions without orphaning.

## Why JSON for submission data

The obvious alternative is one row per (submission, field, value). We
chose JSON because:

1. Submission schema changes with every field add/delete — a JSON column
   absorbs that without migrations.
2. Submission volume per form is usually low-to-moderate; SQL-native
   filtering on individual field values isn't a common need.
3. CSV export flattens at read time — simpler code than joining and
   pivoting.

If an app's form graduates to analytics-grade volume and needs SQL-native
field queries, the migration path is straightforward: write a one-off
migration that promotes the hot fields into typed columns on
`form_submissions` and backfills from the JSON. The module itself doesn't
need to change.

## Field types

Declared in `FormService::FIELD_TYPES`:

| Type       | HTML input     | Stored as        | Validation rules    |
|------------|----------------|------------------|---------------------|
| `text`     | `<input>`      | string           | min/max len, pattern |
| `textarea` | `<textarea>`   | string           | min/max len, pattern |
| `email`    | `<input email>`| string           | format               |
| `number`   | `<input number>`| int/float       | min/max value        |
| `select`   | `<select>`     | string           | must match option    |
| `radio`    | `<input radio>`| string           | must match option    |
| `checkbox` | `<input check>`| bool             | —                    |
| `date`     | `<input date>` | string YYYY-MM-DD| strict ISO format    |

Per-field `validation_rules` JSON supports: `min`, `max`, `pattern`.

Options for `select` / `radio` live in the `options` JSON column as a
flat array of strings.

## Submission pipeline

```
POST /forms/{slug}
  → FormController::submit
    → CSRF check (middleware)
    → optional CAPTCHA verify (release + restart session around HTTP)
    → FormService::validateSubmission(fields, POST)
      → per-field normalization + rule check
    → db->insert('form_submissions', ...)
    → FormService::dispatchNotifications(form, fields, values, subId, settings)
      → optional webhook via WebhookService::send (writes to message_log
        and retries on transport fail)
      → optional email via MailService::send (writes to message_log and
        retries on transport fail)
    → redirect_url OR show thanks view
```

Notifications are best-effort — a webhook or email failure doesn't roll
back the submission or leak to the submitter. MessageRetryService picks
up retries via the scheduled `retry-messages` task.

## Authorization

- Public routes (`/forms/{slug}` GET + POST) — no auth required. If
  `require_captcha` is set on the form, CAPTCHA is the bot gate.
- Admin routes — `AuthMiddleware + RequireAdmin`. Controller methods
  also check `$this->auth->cannot('forms.manage')` for defense in depth.
- IDOR guard: `submission()` and `deleteSubmission()` require the
  `{subId}` to belong to `{formId}`. A bad URL 404s rather than silently
  acting on another form's data.

## Services used (from core)

- `Core\Database\Database` — all SQL
- `Core\Auth\Auth` — actor, audit log
- `Core\Validation\Validator` — admin-side form metadata validation
- `Core\Session` — flash errors + old input across redirects
- `Core\Services\CaptchaService` — optional public-submit bot gate
- `Core\Services\MailService` — notify-email dispatch
- `Core\Services\WebhookService` — webhook dispatch (with SSRF guard)

## Extension points

- **More field types**: add to `FormService::FIELD_TYPES` and extend
  `normalizeField()` switch. The admin form and the public render view
  both iterate the constant / check the type — no hardcoded lists elsewhere.
- **Per-submission custom status workflow**: `form_submissions.status`
  enum currently has `submitted` / `spam` / `processed`. Add values via
  migration and extend the admin detail view with transition buttons.
- **Conditional logic** (show field Y only if X answered Z): not
  included. The extension path would be a `condition` JSON column on
  `form_fields` plus a JS evaluator on the public form. Deferred until
  a real use case surfaces.
- **Multi-page forms**: add a `page_number` column on `form_fields` and
  split the public view. Also deferred.

## Dependencies

- `claudephpframework-core`
- Its `users` table (via `user_id` nullable FK in `form_submissions`) —
  soft dependency, users can submit anonymously
- `forms.manage` permission in the `permissions` table

No dependencies on other modules.
