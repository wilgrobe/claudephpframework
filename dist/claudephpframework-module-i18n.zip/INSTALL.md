# Installation — i18n

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` — creates `translations` + `i18n_locales`,
   seeds locale `en` (English, default, enabled).
3. Grant `i18n.manage` to admin roles.

## Adding translations

1. `/admin/i18n` → add a locale (e.g. `fr` / "French").
2. Add translations row-by-row: locale=`en`, key=`cart.checkout_button`,
   value="Checkout"; locale=`fr`, key=`cart.checkout_button`, value="Payer".
3. Drop `<?= t('cart.checkout_button') ?>` into the relevant view.
   Defaults to `en`; users who switch via `locale_switch()` see `fr`.

## Deferred

- **URL-prefix routing** (/en/… vs /fr/…) — would require router
  changes + per-route locale injection. Today locale is a session
  concept only.
- **Import/export** — pair with the import-export module to upload/
  download translation CSVs for translators.
- **Plural forms** — today single-form only. Full Unicode CLDR
  plural rules (1, 2, few, many, other) would need a parser.
- **RTL support** — doesn't affect this module directly, but the
  app's layouts would want a `<html dir="rtl">` switch keyed on
  `current_locale()`.
- **Missing-key logging** — currently missing keys render as the
  raw key. Optional admin surface "keys not yet translated" would
  surface gaps, possibly backed by a `t()` miss-counter.
