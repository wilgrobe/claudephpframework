# i18n module

Admin translation UI + runtime `t()` helper. Translations stored in
the DB per `(locale, key)`. Locale resolved per request from session
→ Accept-Language → the seeded default (`en`). No URL-prefix routing
— current routes stay single-locale.

## Features

- **Admin UI** at `/admin/i18n` — manage locales (code + name + enabled +
  default) and translations (locale × key × value × admin note).
- **Global helpers**
  - `t('cart.checkout_button')` — look up + fall back to default
    locale + fall back to the raw key if nothing's translated.
  - `t('hello', ['name' => 'Alice'])` — `{name}`-style placeholder
    substitution; missing params stay literal so translators spot them.
  - `current_locale()` — the resolved locale for this request.
  - `locale_switch()` — renders a `<select>` that posts to `/locale`
    and refreshes. Empty output when only one locale is enabled.
- **In-request cache** — loaded-once-per-request map per locale.
  Invalidated on any admin translation write so the same request can
  see its own edits.
- **Guest support** — guests get locale from Accept-Language if no
  session value is set.

## Routes

| Method | Path                                       | Purpose |
|--------|--------------------------------------------|---------|
| POST   | `/locale`                                  | Session locale switch |
| GET    | `/admin/i18n`                              | Admin overview |
| POST   | `/admin/i18n/translations`                 | Upsert translation |
| POST   | `/admin/i18n/translations/{id}/delete`     | Delete |
| POST   | `/admin/i18n/locales`                      | Upsert locale |
| POST   | `/admin/i18n/locales/{code}/delete`        | Delete locale + its translations |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
