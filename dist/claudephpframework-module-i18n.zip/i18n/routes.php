<?php
// modules/i18n/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$L = 'Modules\I18n\Controllers\LocaleController';
$A = 'Modules\I18n\Controllers\I18nAdminController';

// Public (for guests + logged-in)
$router->post('/locale', "$L@set", [CsrfMiddleware::class]);

// Admin
$admin     = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];
$router->get ('/admin/i18n',                                  "$A@index",             $admin);
$router->post('/admin/i18n/translations',                     "$A@upsertTranslation", $adminCsrf);
$router->post('/admin/i18n/translations/{id}/delete',         "$A@deleteTranslation", $adminCsrf);
$router->post('/admin/i18n/locales',                          "$A@upsertLocale",      $adminCsrf);
$router->post('/admin/i18n/locales/{code}/delete',            "$A@deleteLocale",      $adminCsrf);
