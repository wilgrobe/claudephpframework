<?php
// modules/i18n/Helpers/helpers.php
/**
 * Global helpers for i18n.
 *
 *   <?= t('cart.checkout_button') ?>
 *   <?= t('hello', ['name' => $user['username']]) ?>          // "Hello {name}!" → "Hello alice!"
 *   <?= t('cart.total', ['amount' => '$24.99'], 'fr') ?>       // force a locale
 *   <?= current_locale() ?>
 *   <?= e(current_locale()) ?>
 */

if (!function_exists('t')) {
    function t(string $key, array $params = [], ?string $locale = null): string
    {
        return (new \Modules\I18n\Services\I18nService())->t($key, $params, $locale);
    }
}

if (!function_exists('current_locale')) {
    function current_locale(): string
    {
        return (new \Modules\I18n\Services\I18nService())->currentLocale();
    }
}

if (!function_exists('locale_switch')) {
    /**
     * Render a locale-picker dropdown. Submits to POST /locale with a
     * hidden return_url. Non-enabled locales are excluded.
     */
    function locale_switch(string $returnUrl = ''): string
    {
        $svc = new \Modules\I18n\Services\I18nService();
        $locales = $svc->enabledLocales();
        if (count($locales) < 2) return ''; // nothing to pick from
        $current = $svc->currentLocale();
        $returnUrl = $returnUrl ?: ($_SERVER['REQUEST_URI'] ?? '/');

        ob_start();
        ?>
        <form method="post" action="/locale" style="display:inline-block">
            <?= csrf_field() ?>
            <input type="hidden" name="return_url" value="<?= e($returnUrl) ?>">
            <select name="locale" onchange="this.form.submit()" style="padding:.25rem;font-size:12px">
                <?php foreach ($locales as $l): ?>
                <option value="<?= e((string) $l['code']) ?>" <?= (string) $l['code'] === $current ? 'selected' : '' ?>><?= e((string) $l['name']) ?></option>
                <?php endforeach; ?>
            </select>
        </form>
        <?php
        return (string) ob_get_clean();
    }
}
