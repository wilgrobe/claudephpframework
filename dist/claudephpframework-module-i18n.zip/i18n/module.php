<?php
// modules/i18n/module.php
use Core\Container\Container;
use Core\Module\ModuleProvider;

/**
 * i18n module — admin translation UI + runtime t() helper.
 *
 * No URL-prefix routing (no /en/… vs /fr/… — deferred). Locale
 * resolution: session → Accept-Language → config default. A single
 * POST /locale endpoint flips the session value; locale_switch()
 * renders a dropdown that posts to it.
 *
 * In-request cache keeps per-locale string maps in memory so repeated
 * t() calls don't hit the DB once the page's strings are loaded.
 * Invalidated on any admin write.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'i18n'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }

    public function register(Container $container): void
    {
        require_once __DIR__ . '/Helpers/helpers.php';
    }
};
