<?php
// modules/i18n/Controllers/I18nAdminController.php
namespace Modules\I18n\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\I18n\Services\I18nService;

/**
 *   GET  /admin/i18n                         — overview (locales + translations filtered)
 *   POST /admin/i18n/translations            — upsert a translation
 *   POST /admin/i18n/translations/{id}/delete — delete a translation
 *   POST /admin/i18n/locales                 — upsert a locale
 *   POST /admin/i18n/locales/{code}/delete   — delete a locale
 */
class I18nAdminController
{
    private Auth        $auth;
    private I18nService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new I18nService();
    }

    private function gate(): ?Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->auth->can('i18n.manage') && !$this->auth->can('admin.access')) {
            return new Response('Forbidden', 403);
        }
        return null;
    }

    public function index(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $locale = (string) $request->query('locale') ?: null;
        return Response::view('i18n::admin.index', [
            'locales'      => $this->svc->allLocales(),
            'filterLocale' => $locale,
            'translations' => $this->svc->allTranslations($locale),
        ]);
    }

    public function upsertTranslation(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        try {
            $this->svc->upsertTranslation(
                (string) $request->post('locale'),
                (string) $request->post('key'),
                (string) $request->post('value'),
                (string) $request->post('note') ?: null,
                (int) $this->auth->id()
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect('/admin/i18n')->withFlash('error', $e->getMessage());
        }
        return Response::redirect('/admin/i18n?locale=' . urlencode((string) $request->post('locale')));
    }

    public function deleteTranslation(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $this->svc->deleteTranslation((int) $request->param(0));
        return Response::redirect('/admin/i18n');
    }

    public function upsertLocale(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        try {
            $this->svc->upsertLocale(
                (string) $request->post('code'),
                (string) $request->post('name'),
                (bool) $request->post('enabled'),
                (bool) $request->post('is_default')
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect('/admin/i18n')->withFlash('error', $e->getMessage());
        }
        return Response::redirect('/admin/i18n');
    }

    public function deleteLocale(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $this->svc->deleteLocale((string) $request->param(0));
        return Response::redirect('/admin/i18n');
    }
}
