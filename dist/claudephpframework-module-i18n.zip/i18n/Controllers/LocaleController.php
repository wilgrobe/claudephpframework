<?php
// modules/i18n/Controllers/LocaleController.php
namespace Modules\I18n\Controllers;

use Core\Request;
use Core\Response;
use Modules\I18n\Services\I18nService;

/**
 * Minimal public endpoint: switch active locale.
 *   POST /locale     — body: locale, return_url
 */
class LocaleController
{
    public function set(Request $request): Response
    {
        $locale = (string) $request->post('locale');
        $return = (string) $request->post('return_url', '/');
        (new I18nService())->setCurrentLocale($locale);
        return Response::redirect($return);
    }
}
