<?php
// modules/i18n/Services/I18nService.php
namespace Modules\I18n\Services;

use Core\Database\Database;
use Core\Session;

/**
 * Translation lookup + locale resolution.
 *
 * Locale resolution order for a request:
 *   1. Explicit call to `t($key, $params, $locale)` with a locale.
 *   2. $_SESSION['locale'] set by a user action.
 *   3. Accept-Language header (first enabled match).
 *   4. Default locale (i18n_locales.is_default = 1) — 'en' by seed.
 *
 * Translation lookup for a key:
 *   1. translations WHERE locale = $locale AND key = $key
 *   2. translations WHERE locale = default AND key = $key  (fallback)
 *   3. Return the key unchanged (so missing strings are visible in the
 *      UI instead of silently blank).
 *
 * Placeholder substitution: values can contain {name}-style braces
 * that are replaced from the $params array. Missing params are left
 * as literal {name} — again, visible rather than silently empty.
 *
 * In-request cache: translations loaded by locale into a static
 * array, so repeated t() calls don't hit the DB once the page's
 * strings are in memory.
 */
class I18nService
{
    /** @var array<string, array<string, string>>  locale => key => value */
    private static array $cache = [];
    private static ?string $defaultLocale = null;

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Locale resolution ────────────────────────────────────────────────

    public function defaultLocale(): string
    {
        if (self::$defaultLocale !== null) return self::$defaultLocale;
        $row = $this->db->fetchOne(
            "SELECT code FROM i18n_locales WHERE is_default = 1 AND enabled = 1 LIMIT 1"
        );
        self::$defaultLocale = $row ? (string) $row['code'] : 'en';
        return self::$defaultLocale;
    }

    /** Locales actively selectable in the UI (enabled = 1). */
    public function enabledLocales(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM i18n_locales WHERE enabled = 1 ORDER BY is_default DESC, code ASC"
        );
    }

    /** All locales (for admin). */
    public function allLocales(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM i18n_locales ORDER BY is_default DESC, code ASC"
        );
    }

    /**
     * Resolve the active locale for the current request. Walks the
     * priority chain until something enabled comes back.
     */
    public function currentLocale(): string
    {
        Session::start();
        $enabled = array_map(static fn($r) => (string) $r['code'], $this->enabledLocales());
        if (empty($enabled)) return 'en';

        // 1. Session.
        $s = (string) ($_SESSION['locale'] ?? '');
        if ($s !== '' && in_array($s, $enabled, true)) return $s;

        // 2. Accept-Language — first enabled match.
        $accept = (string) ($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? '');
        if ($accept !== '') {
            foreach (explode(',', $accept) as $part) {
                $lang = strtolower(trim(preg_replace('~;.*~', '', $part) ?? ''));
                if ($lang === '') continue;
                // Match 'en-US' or 'en' against enabled 'en'.
                $short = explode('-', $lang)[0];
                if (in_array($lang, $enabled, true)) return $lang;
                if (in_array($short, $enabled, true)) return $short;
            }
        }

        // 3. Default.
        return $this->defaultLocale();
    }

    public function setCurrentLocale(string $locale): void
    {
        Session::start();
        $enabled = array_map(static fn($r) => (string) $r['code'], $this->enabledLocales());
        if (in_array($locale, $enabled, true)) {
            $_SESSION['locale'] = $locale;
        }
    }

    // ── Translation lookup ──────────────────────────────────────────────

    /**
     * Translate a key. $params are substituted into {placeholder}
     * tokens. Missing translations fall back to the default locale,
     * then to the raw key.
     */
    public function t(string $key, array $params = [], ?string $locale = null): string
    {
        $locale = $locale ?: $this->currentLocale();
        $value  = $this->lookup($locale, $key);
        if ($value === null) {
            $default = $this->defaultLocale();
            if ($default !== $locale) {
                $value = $this->lookup($default, $key);
            }
        }
        if ($value === null) $value = $key;
        return self::substitute($value, $params);
    }

    private function lookup(string $locale, string $key): ?string
    {
        if (!isset(self::$cache[$locale])) {
            $rows = $this->db->fetchAll(
                "SELECT `key`, value FROM translations WHERE locale = ?",
                [$locale]
            );
            $map = [];
            foreach ($rows as $r) $map[(string) $r['key']] = (string) $r['value'];
            self::$cache[$locale] = $map;
        }
        return self::$cache[$locale][$key] ?? null;
    }

    /**
     * Substitute {name} placeholders with values from $params. Missing
     * keys are left as-is so translators spot them.
     */
    public static function substitute(string $value, array $params): string
    {
        if (empty($params) || !str_contains($value, '{')) return $value;
        return preg_replace_callback('~\{([a-zA-Z0-9_]+)\}~', static function ($m) use ($params) {
            return array_key_exists($m[1], $params) ? (string) $params[$m[1]] : $m[0];
        }, $value) ?? $value;
    }

    public static function clearCache(): void
    {
        self::$cache         = [];
        self::$defaultLocale = null;
    }

    // ── Admin CRUD ──────────────────────────────────────────────────────

    /**
     * @return array<int, array<string, mixed>>  rows keyed by (locale, key)
     */
    public function allTranslations(?string $locale = null): array
    {
        $where = ''; $bind = [];
        if ($locale !== null) { $where = 'WHERE locale = ?'; $bind[] = $locale; }
        return $this->db->fetchAll(
            "SELECT * FROM translations $where ORDER BY locale ASC, `key` ASC",
            $bind
        );
    }

    public function upsertTranslation(string $locale, string $key, string $value, ?string $note, ?int $userId): void
    {
        $key = trim($key);
        if ($key === '' || $locale === '') {
            throw new \InvalidArgumentException('Locale and key required.');
        }
        $existing = $this->db->fetchOne(
            "SELECT id FROM translations WHERE locale = ? AND `key` = ?",
            [$locale, $key]
        );
        if ($existing) {
            $this->db->update('translations', [
                'value'      => $value,
                'note'       => $note !== null ? substr($note, 0, 500) : null,
                'updated_by' => $userId,
            ], 'id = ?', [(int) $existing['id']]);
        } else {
            $this->db->insert('translations', [
                'locale'     => $locale,
                'key'        => substr($key, 0, 191),
                'value'      => $value,
                'note'       => $note !== null ? substr($note, 0, 500) : null,
                'updated_by' => $userId,
            ]);
        }
        self::clearCache();
    }

    public function deleteTranslation(int $id): void
    {
        $this->db->delete('translations', 'id = ?', [$id]);
        self::clearCache();
    }

    public function upsertLocale(string $code, string $name, bool $enabled, bool $isDefault): void
    {
        $code = trim($code);
        if ($code === '' || $name === '') {
            throw new \InvalidArgumentException('Code and name required.');
        }
        if ($isDefault) {
            // Only one default at a time.
            $this->db->query("UPDATE i18n_locales SET is_default = 0");
        }
        $existing = $this->db->fetchOne("SELECT code FROM i18n_locales WHERE code = ?", [$code]);
        $row = [
            'name'       => substr($name, 0, 120),
            'enabled'    => $enabled ? 1 : 0,
            'is_default' => $isDefault ? 1 : 0,
        ];
        if ($existing) {
            $this->db->update('i18n_locales', $row, 'code = ?', [$code]);
        } else {
            $this->db->insert('i18n_locales', array_merge(['code' => substr($code, 0, 12)], $row));
        }
        self::clearCache();
    }

    public function deleteLocale(string $code): void
    {
        // Cascade-ish: drop any translations for this locale.
        $this->db->delete('translations', 'locale = ?', [$code]);
        $this->db->delete('i18n_locales', 'code = ?', [$code]);
        self::clearCache();
    }
}
