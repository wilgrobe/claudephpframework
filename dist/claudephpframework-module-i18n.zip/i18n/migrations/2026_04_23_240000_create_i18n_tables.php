<?php
// modules/i18n/migrations/2026_04_23_240000_create_i18n_tables.php
use Core\Database\Migration;

/**
 * Schema for the i18n module.
 *
 *   translations    — one row per (locale, key). `value` is the
 *                     translated string; `note` is an admin-only
 *                     context hint ("used on the cart page button").
 *                     `key` is the app-defined lookup string
 *                     (e.g. 'cart.checkout_button').
 *
 *   i18n_locales    — the set of locales the app supports, with a
 *                     `enabled` flag so a locale can be introduced
 *                     in draft without becoming selectable. Seeded
 *                     with 'en' enabled + marked default.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE i18n_locales (
                code       VARCHAR(12) NOT NULL PRIMARY KEY,
                name       VARCHAR(120) NOT NULL,
                is_default TINYINT(1) NOT NULL DEFAULT 0,
                enabled    TINYINT(1) NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_enabled (enabled)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            INSERT INTO i18n_locales (code, name, is_default, enabled)
            VALUES ('en', 'English', 1, 1)
        ");

        $this->db->query("
            CREATE TABLE translations (
                id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                locale     VARCHAR(12)  NOT NULL,
                `key`      VARCHAR(191) NOT NULL,
                value      TEXT         NOT NULL,
                note       VARCHAR(500) NULL,
                updated_by INT UNSIGNED NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_locale_key (locale, `key`),
                KEY idx_key (`key`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS translations");
        $this->db->query("DROP TABLE IF EXISTS i18n_locales");
    }
};
