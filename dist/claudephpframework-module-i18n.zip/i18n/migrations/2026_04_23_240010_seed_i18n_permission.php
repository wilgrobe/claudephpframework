<?php
// modules/i18n/migrations/2026_04_23_240010_seed_i18n_permission.php
use Core\Database\Migration;

return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage translations',
            'i18n.manage',
            'i18n',
            'Add, edit, and enable/disable translations and locales.',
        ]);
    }

    public function down(): void {}
};
