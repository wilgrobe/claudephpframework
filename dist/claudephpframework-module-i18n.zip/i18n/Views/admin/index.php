<?php $pageTitle = 'Translations'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Translations</h1>

<!-- Locales -->
<div class="card" style="margin-bottom:1rem">
    <div class="card-header"><strong>Locales</strong></div>
    <div class="card-body">
        <?php if (!empty($locales)): ?>
        <table class="table">
            <thead><tr><th>Code</th><th>Name</th><th>Default</th><th>Enabled</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($locales as $l): ?>
            <tr>
                <td><code><?= e((string) $l['code']) ?></code></td>
                <td><?= e((string) $l['name']) ?></td>
                <td><?= (int) $l['is_default'] ? '✓' : '' ?></td>
                <td><?= (int) $l['enabled'] ? '✓' : '—' ?></td>
                <td>
                    <form method="post" action="/admin/i18n/locales/<?= e((string) $l['code']) ?>/delete" onsubmit="return confirm('Delete locale + all its translations?')">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
        <form method="post" action="/admin/i18n/locales" style="display:grid;gap:.5rem;grid-template-columns:80px 2fr auto auto auto;align-items:end;margin-top:.5rem">
            <?= csrf_field() ?>
            <label>Code <input name="code" required maxlength="12" placeholder="fr"></label>
            <label>Name <input name="name" required placeholder="French"></label>
            <label><input type="checkbox" name="enabled" value="1" checked> Enabled</label>
            <label><input type="checkbox" name="is_default" value="1"> Default</label>
            <button type="submit" class="btn btn-sm btn-primary">Save locale</button>
        </form>
    </div>
</div>

<!-- Translations -->
<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <strong>Translations</strong>
        <form method="get">
            <select name="locale" onchange="this.form.submit()">
                <option value="">All locales</option>
                <?php foreach ($locales as $l): ?>
                <option value="<?= e((string) $l['code']) ?>" <?= ($filterLocale ?? '') === (string) $l['code'] ? 'selected' : '' ?>><?= e((string) $l['code']) ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>
    <div class="card-body">
        <?php if (!empty($translations)): ?>
        <table class="table">
            <thead><tr><th>Locale</th><th>Key</th><th>Value</th><th>Note</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($translations as $t): ?>
            <tr>
                <td><code><?= e((string) $t['locale']) ?></code></td>
                <td><code><?= e((string) $t['key']) ?></code></td>
                <td style="max-width:320px"><?= e(mb_substr((string) $t['value'], 0, 200)) ?></td>
                <td style="font-size:12px;color:#6b7280"><?= e((string) ($t['note'] ?? '')) ?></td>
                <td>
                    <form method="post" action="/admin/i18n/translations/<?= (int) $t['id'] ?>/delete" style="display:inline">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>

        <form method="post" action="/admin/i18n/translations" style="padding:.75rem;background:#f9fafb;border-radius:4px;margin-top:.5rem">
            <?= csrf_field() ?>
            <strong style="display:block;margin-bottom:.5rem">Add or update a translation</strong>
            <div style="display:grid;gap:.5rem;grid-template-columns:80px 2fr 3fr">
                <label>Locale
                    <select name="locale" required>
                        <?php foreach ($locales as $l): ?>
                        <option value="<?= e((string) $l['code']) ?>"><?= e((string) $l['code']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Key
                    <input name="key" required placeholder="cart.checkout_button">
                </label>
                <label>Value
                    <input name="value" required placeholder="Checkout">
                </label>
            </div>
            <label style="display:block;margin-top:.5rem">Note (admin-only context)
                <input name="note" placeholder="The main checkout button on the cart page">
            </label>
            <div style="text-align:right;margin-top:.5rem">
                <button type="submit" class="btn btn-sm btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
