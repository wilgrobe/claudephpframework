# Architecture — i18n

## Files

```
i18n/
├── module.php
├── routes.php
├── Controllers/{LocaleController,I18nAdminController}.php
├── Services/I18nService.php
├── Helpers/helpers.php
├── Views/admin/index.php
└── migrations/{create_tables, seed_permission}.php
```

## Data model

```
i18n_locales:
  code PK, name, is_default, enabled, timestamps
  Seed: ('en', 'English', 1, 1)

translations:
  id, locale, key, value, note NULL, updated_by NULL, timestamps
  UNIQUE (locale, key)
```

## Resolution chain

`currentLocale()` walks:
1. `$_SESSION['locale']` — user explicitly picked.
2. `Accept-Language` — parsed in order, matching enabled locales.
   Both full (`en-US`) and language-only (`en`) matches accepted.
3. `defaultLocale()` — first row with `is_default=1 AND enabled=1`,
   falling back to `'en'` when that row is missing.

## Lookup chain

`t($key, $params, $locale)`:
1. Load locale's map (cached in `self::$cache[$locale]`).
2. If present, use the value.
3. Else load default locale's map; use if present.
4. Else return the key unchanged.
5. Substitute `{placeholder}` → `$params[placeholder]`; leave
   unknown placeholders literal.

## Cache invalidation

`self::$cache` is static on the service. Any admin write calls
`self::clearCache()`. The cache is per-process anyway — a second
request after a cache-clear refills from the DB on first `t()` call.

## Why no URL-prefix routing

Adding `/en/…` vs `/fr/…` means every existing route gets prefixed.
That's a router change, not an i18n-module change. Deferred so this
module ships standalone and apps can opt in via their own router
config when they're ready.
