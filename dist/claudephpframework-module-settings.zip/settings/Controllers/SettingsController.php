<?php
// modules/settings/Controllers/SettingsController.php
namespace Modules\Settings\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Services\SettingsService;

/**
 * Ported from App\Controllers\Admin\SettingsController. Behavior unchanged.
 *
 * NOTE: the COLOR_DEFAULTS public constant is referenced by the live layout
 * as a fallback for CSS vars. The layout should be updated to reference
 * Modules\Settings\Controllers\SettingsController::COLOR_DEFAULTS when the
 * old class is removed.
 */
class SettingsController
{
    private const FOOTER_KEYS = [
        'footer_enabled'       => 'boolean',
        'footer_logo_text'     => 'string',
        'footer_tagline'       => 'string',
        'footer_copyright'     => 'string',
        'footer_powered_by'    => 'string',
        'footer_show_menu'     => 'boolean',
        'footer_menu_location' => 'string',
    ];

    private const GROUP_KEYS = [
        'single_group_only'    => 'boolean',
        'allow_group_creation' => 'boolean',
    ];

    private const APPEARANCE_KEYS = [
        'layout_orientation' => 'string',
        'color_primary'      => 'string',
        'color_primary_dark' => 'string',
        'color_secondary'    => 'string',
        'color_success'      => 'string',
        'color_danger'       => 'string',
        'color_warning'      => 'string',
        'color_info'         => 'string',
    ];

    public const COLOR_DEFAULTS = [
        'color_primary'      => '#4f46e5',
        'color_primary_dark' => '#3730a3',
        'color_secondary'    => '#0ea5e9',
        'color_success'      => '#10b981',
        'color_danger'       => '#ef4444',
        'color_warning'      => '#f59e0b',
        'color_info'         => '#3b82f6',
    ];

    private SettingsService $settings;
    private Auth            $auth;

    public function __construct()
    {
        $this->settings = new SettingsService();
        $this->auth     = Auth::getInstance();
    }

    public function index(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();

        $scope    = $request->query('scope', 'site');
        $scopeKey = $request->query('scope_key');
        $all      = $this->settings->all($scope, $scopeKey ?: null);

        return Response::view('settings::admin.index', [
            'settings' => $all,
            'scope'    => $scope,
            'scopeKey' => $scopeKey,
            'user'     => $this->auth->user(),
        ]);
    }

    public function save(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();

        $scope    = $request->post('scope', 'site');
        $scopeKey = $request->post('scope_key') ?: null;
        $items    = $request->post('settings', []);

        foreach ($items as $key => $value) {
            $type = $request->post("types[$key]", 'string');
            $this->settings->set($key, $value, $scope, $scopeKey, $type);
        }

        if ($newKey = $request->post('new_key')) {
            $this->settings->set(
                $newKey,
                $request->post('new_value', ''),
                $scope,
                $scopeKey,
                $request->post('new_type', 'string')
            );
        }

        $this->auth->auditLog('settings.save', null, null, null, ['scope' => $scope]);
        return Response::redirect("/admin/settings?scope=$scope")->withFlash('success', 'Settings saved.');
    }

    public function delete(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();
        $key      = $request->post('key');
        $scope    = $request->post('scope', 'site');
        $scopeKey = $request->post('scope_key') ?: null;
        $this->settings->delete($key, $scope, $scopeKey);
        return Response::redirect("/admin/settings?scope=$scope")->withFlash('success', 'Setting deleted.');
    }

    public function footer(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();

        $values = [];
        foreach (array_keys(self::FOOTER_KEYS) as $key) {
            $values[$key] = $this->settings->get($key, null, 'site');
        }

        $locations = Database::getInstance()->fetchAll(
            "SELECT DISTINCT location FROM menus WHERE is_active = 1 ORDER BY location"
        );

        return Response::view('settings::admin.footer', [
            'values'    => $values,
            'locations' => array_column($locations, 'location'),
            'user'      => $this->auth->user(),
        ]);
    }

    public function saveFooter(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();

        foreach (self::FOOTER_KEYS as $key => $type) {
            if ($type === 'boolean') {
                $value = $request->post($key) ? 'true' : 'false';
            } else {
                $value = (string) $request->post($key, '');
            }
            $this->settings->set($key, $value, 'site', null, $type);
        }

        $this->auth->auditLog('settings.footer.save', null, null, null, ['scope' => 'site']);
        return Response::redirect('/admin/settings/footer')->withFlash('success', 'Footer settings saved.');
    }

    public function groups(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();

        $values = [];
        foreach (array_keys(self::GROUP_KEYS) as $key) {
            $values[$key] = $this->settings->get($key, null, 'site');
        }

        return Response::view('settings::admin.groups', [
            'values' => $values,
            'user'   => $this->auth->user(),
        ]);
    }

    public function saveGroups(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();

        foreach (self::GROUP_KEYS as $key => $type) {
            if ($type === 'boolean') {
                $value = $request->post($key) ? 'true' : 'false';
            } else {
                $value = (string) $request->post($key, '');
            }
            $this->settings->set($key, $value, 'site', null, $type);
        }

        $this->auth->auditLog('settings.groups.save', null, null, null, ['scope' => 'site']);
        return Response::redirect('/admin/settings/groups')->withFlash('success', 'Group policy settings saved.');
    }

    public function appearance(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();

        $values = [];
        foreach (array_keys(self::APPEARANCE_KEYS) as $key) {
            $values[$key] = $this->settings->get($key, null, 'site');
        }

        return Response::view('settings::admin.appearance', [
            'values'        => $values,
            'colorDefaults' => self::COLOR_DEFAULTS,
            'user'          => $this->auth->user(),
        ]);
    }

    public function saveAppearance(Request $request): Response
    {
        if (!$this->auth->isSuperAdmin()) return $this->denied();

        $orientation = (string) $request->post('layout_orientation', 'sidebar');
        if (!in_array($orientation, ['sidebar', 'topbar'], true)) {
            $orientation = 'sidebar';
        }
        $this->settings->set('layout_orientation', $orientation, 'site', null, 'string');

        foreach (array_keys(self::COLOR_DEFAULTS) as $key) {
            $value = trim((string) $request->post($key, ''));
            if ($value !== '' && !preg_match('/^([#a-zA-Z0-9(),.\s%\-]+)$/', $value)) {
                $value = '';
            }
            $this->settings->set($key, $value, 'site', null, 'string');
        }

        $this->auth->auditLog('settings.appearance.save', null, null, null, ['scope' => 'site']);
        return Response::redirect('/admin/settings/appearance')->withFlash('success', 'Appearance settings saved.');
    }

    private function denied(): Response
    {
        return Response::redirect('/admin')->withFlash('error', 'Superadmin access required.');
    }
}
