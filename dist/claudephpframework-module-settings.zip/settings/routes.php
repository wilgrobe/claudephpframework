<?php
// modules/settings/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireSuperadmin;

$router->get ('/admin/settings',            'Modules\Settings\Controllers\SettingsController@index',
    [AuthMiddleware::class, RequireSuperadmin::class]);
$router->post('/admin/settings',            'Modules\Settings\Controllers\SettingsController@save',
    [CsrfMiddleware::class, AuthMiddleware::class, RequireSuperadmin::class]);
$router->post('/admin/settings/delete',     'Modules\Settings\Controllers\SettingsController@delete',
    [CsrfMiddleware::class, AuthMiddleware::class, RequireSuperadmin::class]);
$router->get ('/admin/settings/footer',     'Modules\Settings\Controllers\SettingsController@footer',
    [AuthMiddleware::class, RequireSuperadmin::class]);
$router->post('/admin/settings/footer',     'Modules\Settings\Controllers\SettingsController@saveFooter',
    [CsrfMiddleware::class, AuthMiddleware::class, RequireSuperadmin::class]);
$router->get ('/admin/settings/groups',     'Modules\Settings\Controllers\SettingsController@groups',
    [AuthMiddleware::class, RequireSuperadmin::class]);
$router->post('/admin/settings/groups',     'Modules\Settings\Controllers\SettingsController@saveGroups',
    [CsrfMiddleware::class, AuthMiddleware::class, RequireSuperadmin::class]);
$router->get ('/admin/settings/appearance', 'Modules\Settings\Controllers\SettingsController@appearance',
    [AuthMiddleware::class, RequireSuperadmin::class]);
$router->post('/admin/settings/appearance', 'Modules\Settings\Controllers\SettingsController@saveAppearance',
    [CsrfMiddleware::class, AuthMiddleware::class, RequireSuperadmin::class]);
