<?php $pageTitle = 'Footer Settings'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:720px;margin:0 auto">

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
    <div>
        <div style="font-size:12px;color:#6b7280">
            <a href="/admin/settings" style="color:#4f46e5;text-decoration:none">← All settings</a>
        </div>
        <h1 style="margin:.25rem 0 0;font-size:1.3rem;font-weight:700">Footer</h1>
    </div>
</div>

<div class="card">
    <div class="card-header"><h2 style="margin:0;font-size:1rem">Site Footer Configuration</h2></div>
    <div class="card-body">
        <form method="POST" action="/admin/settings/footer">
            <?= csrf_field() ?>

            <!-- Master toggle -->
            <div class="form-group" style="padding:.85rem 1rem;background:#eef2ff;border:1px solid #c7d2fe;border-radius:6px;margin-bottom:1.25rem">
                <label style="display:flex;align-items:center;gap:.6rem;cursor:pointer;font-weight:500;margin:0">
                    <input type="checkbox" name="footer_enabled" value="1" <?= !empty($values['footer_enabled']) ? 'checked' : '' ?>>
                    Show footer across the site
                </label>
                <div style="font-size:12.5px;color:#4338ca;margin-top:.35rem;line-height:1.5">
                    When off, no footer is rendered on any page. The individual fields below stay saved
                    — uncheck this to hide the footer temporarily without clearing its contents.
                </div>
            </div>

            <!-- Branding: logo + tagline -->
            <div style="border:1px solid #e5e7eb;border-radius:8px;padding:1rem 1.25rem;margin-bottom:1rem;background:#fff">
                <div style="font-weight:600;font-size:13px;margin-bottom:.75rem;color:#374151">Branding</div>
                <div class="form-group">
                    <label>Logo text</label>
                    <input type="text" name="footer_logo_text" class="form-control"
                           value="<?= e($values['footer_logo_text'] ?? '') ?>"
                           placeholder="🚀 My Application" maxlength="255">
                    <div style="font-size:12px;color:#6b7280;margin-top:.25rem">
                        Plain text and emoji are fine — no HTML. Leave blank to omit the logo.
                    </div>
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label>Tagline</label>
                    <input type="text" name="footer_tagline" class="form-control"
                           value="<?= e($values['footer_tagline'] ?? '') ?>"
                           placeholder="One-line blurb shown under the logo" maxlength="255">
                </div>
            </div>

            <!-- Menu -->
            <div style="border:1px solid #e5e7eb;border-radius:8px;padding:1rem 1.25rem;margin-bottom:1rem;background:#fff">
                <div style="font-weight:600;font-size:13px;margin-bottom:.75rem;color:#374151">Navigation menu</div>
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-weight:400">
                        <input type="checkbox" name="footer_show_menu" value="1" <?= !empty($values['footer_show_menu']) ? 'checked' : '' ?>>
                        Show menu links in the footer
                    </label>
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label>Menu location</label>
                    <?php
                    $current = $values['footer_menu_location'] ?? 'footer';
                    // Always make sure the current value is selectable even if
                    // it isn't in the active-menus list (e.g. a typo, or a
                    // disabled menu) — don't silently drop it on save.
                    $options = array_unique(array_merge($locations, [$current]));
                    sort($options);
                    ?>
                    <select name="footer_menu_location" class="form-control">
                        <?php foreach ($options as $loc): ?>
                        <option value="<?= e($loc) ?>" <?= $loc === $current ? 'selected' : '' ?>><?= e($loc) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div style="font-size:12px;color:#6b7280;margin-top:.25rem">
                        Which menu's items to render. Manage the items themselves under
                        <a href="/admin/menus" style="color:#4f46e5">Menus</a>.
                    </div>
                </div>
            </div>

            <!-- Legal / attribution -->
            <div style="border:1px solid #e5e7eb;border-radius:8px;padding:1rem 1.25rem;margin-bottom:1rem;background:#fff">
                <div style="font-weight:600;font-size:13px;margin-bottom:.75rem;color:#374151">Legal &amp; attribution</div>
                <div class="form-group">
                    <label>Copyright</label>
                    <input type="text" name="footer_copyright" class="form-control"
                           value="<?= e($values['footer_copyright'] ?? '') ?>"
                           placeholder="© {{year}} My Company" maxlength="500">
                    <div style="font-size:12px;color:#6b7280;margin-top:.25rem">
                        Use <code>{{year}}</code> to insert the current year at render time so this
                        never goes stale.
                    </div>
                </div>
                <div class="form-group" style="margin-bottom:0">
                    <label>Powered by</label>
                    <input type="text" name="footer_powered_by" class="form-control"
                           value="<?= e($values['footer_powered_by'] ?? '') ?>"
                           placeholder="Powered by …" maxlength="500">
                </div>
            </div>

            <div style="display:flex;gap:.75rem">
                <button type="submit" class="btn btn-primary">Save Footer Settings</button>
                <a href="/admin/settings" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
