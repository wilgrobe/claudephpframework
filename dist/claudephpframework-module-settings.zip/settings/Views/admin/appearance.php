<?php $pageTitle = 'Appearance Settings'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:720px;margin:0 auto">

<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem">
    <div>
        <div style="font-size:12px;color:#6b7280">
            <a href="/admin/settings" style="color:#4f46e5;text-decoration:none">← All settings</a>
        </div>
        <h1 style="margin:.25rem 0 0;font-size:1.3rem;font-weight:700">Appearance</h1>
    </div>
</div>

<div class="card">
    <div class="card-header"><h2 style="margin:0;font-size:1rem">Layout &amp; Colors</h2></div>
    <div class="card-body">
        <form method="POST" action="/admin/settings/appearance">
            <?= csrf_field() ?>

            <!-- Layout orientation -->
            <div class="form-group" style="margin-bottom:1.25rem">
                <label style="font-weight:500;font-size:13px">Navigation layout</label>
                <?php $orientation = $values['layout_orientation'] ?? 'sidebar'; ?>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:.75rem;margin-top:.5rem">
                    <label style="display:block;padding:1rem;border:2px solid <?= $orientation === 'sidebar' ? '#4f46e5' : '#e5e7eb' ?>;border-radius:8px;cursor:pointer;background:#fff">
                        <div style="display:flex;align-items:center;gap:.5rem">
                            <input type="radio" name="layout_orientation" value="sidebar" <?= $orientation === 'sidebar' ? 'checked' : '' ?>>
                            <strong>Sidebar (default)</strong>
                        </div>
                        <div style="font-size:12.5px;color:#6b7280;margin-top:.4rem;line-height:1.5">
                            Navigation runs down the left side of every page. The main content
                            sits to the right of a persistent sidebar.
                        </div>
                    </label>
                    <label style="display:block;padding:1rem;border:2px solid <?= $orientation === 'topbar' ? '#4f46e5' : '#e5e7eb' ?>;border-radius:8px;cursor:pointer;background:#fff">
                        <div style="display:flex;align-items:center;gap:.5rem">
                            <input type="radio" name="layout_orientation" value="topbar" <?= $orientation === 'topbar' ? 'checked' : '' ?>>
                            <strong>Top bar</strong>
                        </div>
                        <div style="font-size:12.5px;color:#6b7280;margin-top:.4rem;line-height:1.5">
                            Navigation runs horizontally across the top. The sidebar is hidden
                            and main content takes the full page width. Better for
                            content-heavy layouts.
                        </div>
                    </label>
                </div>
            </div>

            <!-- Colors -->
            <div style="border:1px solid #e5e7eb;border-radius:8px;padding:1rem 1.25rem;margin-bottom:1rem;background:#fff">
                <div style="font-weight:600;font-size:13px;margin-bottom:.75rem;color:#374151">Brand colors</div>
                <div style="font-size:12.5px;color:#6b7280;margin-bottom:1rem;line-height:1.5">
                    Override the CSS brand palette. Hex works best, but any valid CSS color
                    (rgb, hsl, named) is accepted. Leave a field blank to use the built-in
                    default shown next to its label.
                </div>

                <?php
                // One row per color. The HTML color input only accepts hex
                // and won't show the current value if it's empty — so we
                // mirror it to a plain text input that admins can blank to
                // reset, or type any other CSS color into.
                $fields = [
                    'color_primary'      => 'Primary',
                    'color_primary_dark' => 'Primary (dark variant)',
                    'color_secondary'    => 'Secondary',
                    'color_success'      => 'Success',
                    'color_danger'       => 'Danger',
                    'color_warning'      => 'Warning',
                    'color_info'         => 'Info',
                ];
                foreach ($fields as $key => $label):
                    $v       = (string) ($values[$key] ?? '');
                    $default = $colorDefaults[$key] ?? '';
                    // The HTML color input needs a valid hex; fall back to
                    // the default when the saved value is empty or not a
                    // hex, so the swatch always shows something.
                    $swatch  = preg_match('/^#[0-9a-f]{3,8}$/i', $v) ? $v : $default;
                ?>
                <div style="display:grid;grid-template-columns:180px 60px 1fr 110px;gap:.5rem;align-items:center;margin-bottom:.5rem">
                    <label style="font-size:13px;font-weight:500"><?= e($label) ?></label>
                    <input type="color"
                           value="<?= e($swatch) ?>"
                           oninput="document.getElementById('in-<?= e($key) ?>').value = this.value"
                           style="width:100%;height:34px;padding:0;border:1px solid #d1d5db;border-radius:4px;cursor:pointer">
                    <input type="text"
                           id="in-<?= e($key) ?>"
                           name="<?= e($key) ?>"
                           value="<?= e($v) ?>"
                           placeholder="<?= e($default) ?>"
                           class="form-control"
                           style="font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:13px">
                    <span style="font-size:11.5px;color:#9ca3af">default: <code><?= e($default) ?></code></span>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="display:flex;gap:.75rem">
                <button type="submit" class="btn btn-primary">Save Appearance</button>
                <a href="/admin/settings" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>

</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
