<?php $pageTitle = 'Settings'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<!-- Dedicated settings pages — purpose-built forms for grouped options that
     are easier to configure here than as loose key/value rows below. -->
<div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:1rem">
    <a href="/admin/settings/appearance" class="btn btn-sm btn-secondary" style="background:#eef2ff;border-color:#c7d2fe;color:#4338ca">
        🎨 Appearance &rarr;
    </a>
    <a href="/admin/settings/footer" class="btn btn-sm btn-secondary" style="background:#eef2ff;border-color:#c7d2fe;color:#4338ca">
        📐 Footer &rarr;
    </a>
    <a href="/admin/settings/groups" class="btn btn-sm btn-secondary" style="background:#eef2ff;border-color:#c7d2fe;color:#4338ca">
        👥 Group Policy &rarr;
    </a>
</div>

<!-- Scope tabs -->
<div style="display:flex;gap:.35rem;margin-bottom:1rem">
    <?php foreach (['site','page','function','group'] as $s): ?>
    <a href="/admin/settings?scope=<?= $s ?>"
       class="btn btn-sm <?= $scope === $s ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($s) ?></a>
    <?php endforeach; ?>
</div>

<div class="grid grid-2" style="align-items:flex-start">

    <!-- Current settings -->
    <div class="card">
        <div class="card-header"><h2><?= ucfirst($scope) ?> Settings</h2></div>
        <?php if (empty($settings)): ?>
        <div class="card-body"><p style="color:#6b7280;margin:0">No settings yet for this scope.</p></div>
        <?php else: ?>
        <form method="POST" action="/admin/settings">
            <?= csrf_field() ?>
            <input type="hidden" name="scope" value="<?= e($scope) ?>">
            <div class="table-responsive">
                <table class="table">
                    <thead><tr><th>Key</th><th>Value</th><th>Type</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($settings as $key => $val): ?>
                    <tr>
                        <td><code style="font-size:12px"><?= e($key) ?></code>
                            <input type="hidden" name="types[<?= e($key) ?>]" value="string">
                        </td>
                        <td>
                            <input type="text" name="settings[<?= e($key) ?>]"
                                   value="<?= e(is_array($val) ? json_encode($val) : $val) ?>"
                                   class="form-control" style="font-size:13px">
                        </td>
                        <td><span class="badge badge-gray">string</span></td>
                        <td>
                            <form method="POST" action="/admin/settings/delete" style="display:inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="key" value="<?= e($key) ?>">
                                <input type="hidden" name="scope" value="<?= e($scope) ?>">
                                <button class="btn btn-xs btn-danger" onclick="return confirm('Delete setting?')">×</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div style="padding:1rem 1.25rem">
                <button type="submit" class="btn btn-primary btn-sm">Save All</button>
            </div>
        </form>
        <?php endif; ?>
    </div>

    <!-- Add setting -->
    <div class="card">
        <div class="card-header"><h2>Add Setting</h2></div>
        <div class="card-body">
            <form method="POST" action="/admin/settings">
                <?= csrf_field() ?>
                <input type="hidden" name="scope" value="<?= e($scope) ?>">
                <?php if ($scope !== 'site'): ?>
                <div class="form-group">
                    <label>Scope Key <span style="font-weight:400;color:#6b7280">(page slug, function name, group id…)</span></label>
                    <input type="text" name="scope_key" class="form-control" value="<?= e($scopeKey ?? '') ?>">
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <label>Key *</label>
                    <input type="text" name="new_key" class="form-control" required placeholder="my_setting_key">
                </div>
                <div class="form-group">
                    <label>Value</label>
                    <input type="text" name="new_value" class="form-control">
                </div>
                <div class="form-group">
                    <label>Type</label>
                    <select name="new_type" class="form-control">
                        <option value="string">String</option>
                        <option value="integer">Integer</option>
                        <option value="boolean">Boolean</option>
                        <option value="json">JSON</option>
                        <option value="text">Text (long)</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Add Setting</button>
            </form>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
