# Settings module

Superadmin-only admin surface for reading and writing application settings.
Ships both a generic key/value editor and purpose-built forms for common
use cases (footer content, appearance / colors, group policy).

## Features

- Generic settings editor — add, edit, delete arbitrary key/value pairs
  scoped to `site` / `user` / custom scope keys
- **Footer** form — structured editor for footer columns, links, copyright
  text
- **Appearance** form — color scheme, brand colors; writes values consumed
  by the base CSS via CSS variables
- **Group policy** form — group-wide defaults (default role on invite,
  membership visibility, etc.)

Setting values are persisted via `SettingsService` which owns the schema
and scope model.

## Routes

All `/admin/settings*` routes require `AuthMiddleware + RequireSuperadmin`.

| Method | Path                         | Purpose                          |
|--------|------------------------------|----------------------------------|
| GET    | `/admin/settings`            | Generic editor                   |
| POST   | `/admin/settings`            | Save one setting                 |
| POST   | `/admin/settings/delete`     | Delete a setting                 |
| GET    | `/admin/settings/footer`     | Footer form                      |
| POST   | `/admin/settings/footer`     | Save footer settings             |
| GET    | `/admin/settings/groups`     | Group-policy form                |
| POST   | `/admin/settings/groups`     | Save group-policy settings       |
| GET    | `/admin/settings/appearance` | Appearance (colors) form         |
| POST   | `/admin/settings/appearance` | Save appearance settings         |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
