# Architecture — Settings module

## Files

```
settings/
├── module.php
├── routes.php                                     # 9 routes
├── Controllers/SettingsController.php             # All 4 editors
└── Views/admin/
    ├── settings.php                               # Generic editor
    ├── footer.php                                 # Footer form
    ├── appearance.php                             # Colors / branding
    └── groups.php                                 # Group policy
```

## Tables

- `settings` — id, key, value, scope, scope_key, type, updated_at. From
  core's `install.sql`.

## Scope model

Settings are three-way scoped:

- `scope = 'site'` — global defaults
- `scope = 'user'`, `scope_key = $user_id` — per-user preferences
- `scope = <arbitrary>`, `scope_key = <id>` — e.g. per-group settings

This module mostly writes `scope = 'site'`. Per-user settings are read by
the relevant modules (e.g. profile preferences) but typically written
elsewhere.

## The four editors

1. **Generic editor** — lists every setting, lets you add/edit/delete
   arbitrary keys. Useful for one-off values that don't warrant a
   purpose-built form.
2. **Footer** — persists structured footer data (columns of link lists,
   copyright text) under well-known keys. Read by the footer layout partial.
3. **Appearance** — persists color values under `brand_primary`,
   `brand_secondary`, etc. Layout reads these and injects CSS variables so
   the design changes without code deploys.
4. **Group policy** — persists defaults consumed by the groups module on
   new-group creation.

## COLOR_DEFAULTS constant

`SettingsController::COLOR_DEFAULTS` is a constant referenced by the base
layout for fallback color values when an appearance setting is missing.
The fully-qualified name is
`\Modules\Settings\Controllers\SettingsController::COLOR_DEFAULTS` — if
you rename or move this module's controller, update the layout's import
or the fallback will silently break.

## Authorization

All routes: `AuthMiddleware + RequireSuperadmin`. The superadmin
middleware checks both the DB flag AND the session-level superadmin mode
toggle — standard admin-surface pattern.

Internally, every mutation method also re-asserts
`$this->auth->isSuperAdmin()` (DB flag only, NOT mode toggle) — defense
in depth, so a logic bug in the middleware doesn't grant write access.

## Dependencies

- `claudephpframework-core` — SettingsService, Auth, View, Database
- Core's `settings` table
- Base layout expects `COLOR_DEFAULTS` to be reachable (adjust or remove
  this coupling if you change the module namespace)

## Extension points

Adding a new dedicated editor:

1. Write a new GET + POST route pair in `routes.php`.
2. Add the GET/POST methods to `SettingsController`.
3. Create the form view under `Views/admin/{name}.php`.
4. Use `SettingsService::get()` / `set()` — it handles serialization.
