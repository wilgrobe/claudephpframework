# Installation — Settings module

## Prerequisites

- `claudephpframework-core` installed (includes `SettingsService` and the
  `settings` table).
- At least one superadmin account with `is_superadmin = 1` in `users`.

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-settings.zip
   cp -r claudephpframework-module-settings/settings /path/to/project/modules/
   ```

2. Run migrations (none ship):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if using production caching:
   ```bash
   php artisan module:cache
   ```

## Environment variables

None — this module is a UI wrapper over `SettingsService`, which
persists values to the `settings` table. No credentials or provider
config here (those live in `.env` and the Integrations module).

## Important: superadmin mode

All `/admin/settings*` routes require superadmin **mode**, not just the
`is_superadmin` flag. Toggle mode on from the session — typically via
a superadmin-only menu item that POSTs to `/superadmin/toggle` (provided
by core). Without mode enabled, these routes 403.

## Verification

1. Log in as a superadmin, enable superadmin mode.
2. Visit `/admin/settings` — the generic editor lists all keys.
3. Visit `/admin/settings/appearance` — change a brand color, save. The
   site should pick up the new color via the CSS variables on the next
   render (refresh — CSS is inlined from settings, not cached separately
   on disk).
