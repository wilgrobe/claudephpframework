# Comments + Reactions module

Polymorphic comments and emoji reactions that any other module can opt into
with a single line in a view. Attach threaded discussion to content items,
pages, FAQ entries, products — anything with a logical type string and an id.

## Features

- **Polymorphic attachment** — `commentable_type` + `commentable_id`. Type
  strings are app-chosen labels (`'content'`, `'page'`, `'faq'`), never PHP
  class names.
- **Threaded replies** — `parent_id` nests comments arbitrarily deep; UI
  renders with a configurable visual cap (default 5 levels).
- **Four-scope moderation** — new comments land `pending` when ANY of:
  site-wide setting is on, the *commenter* is individually flagged, the
  target is owned by a group with moderation on, or the target is owned
  by a user who pre-moderates their own threads. Status values:
  `pending`, `published`, `spam`, `deleted`.
- **Moderator role + author self-moderation** — a system `Moderator`
  role ships with the `comments.moderate` permission. Assign it to
  site-level moderators who aren't full admins. Group admins/owners
  get moderation authority over their group's content automatically
  via the base-role hierarchy. Post authors moderate comments on
  their own content automatically — no role assignment needed.
- **Pluggable entity ownership** — other modules teach the comments
  module about their entity types via
  `CommentService::registerOwnershipResolver($type, $fn)`. Each
  comment's `owner_user_id` + `owner_group_id` is denormalized at
  INSERT time, making the moderation queue filter type-agnostic.
  Built-in: `'content'` (content_items). Plug-in: `'social_post'`
  (social module), and any future type that registers a resolver.
- **Aggregated notifications** — a scheduled task checks every 15 min
  and sends a single digest in-app notification per moderator per hour
  (configurable) when there are pending comments, so busy sites don't
  overwhelm moderators.
- **Unified moderation panel** — `/admin/comments` is accessible to
  anyone with moderation authority (global OR group admin). Each
  moderator sees only the queue they can act on.
- **Edit window** — authors can edit their own comments for 15 minutes
  (configurable via `comments_edit_window_seconds`). Admins bypass the
  window.
- **Reactions** — idempotent emoji toggle (`like`, `love`, `laugh`, `wow`,
  `sad`). One reaction per (target, user, type). Attaches to comments or
  to parent entities.
- **View helpers** — `comments($type, $id)` and `reactions($type, $id)`
  return HTML blocks. Drop them into any module's views to enable.

## Routes

### Public

| Method | Path                                            | Middleware      | Purpose             |
|--------|-------------------------------------------------|-----------------|---------------------|
| POST   | `/comments/{type}/{id}`                         | Csrf + Auth     | Create comment      |
| POST   | `/comments/{id}/edit`                           | Csrf + Auth     | Edit own (in window)|
| POST   | `/comments/{id}/delete`                         | Csrf + Auth     | Soft-delete own     |
| POST   | `/reactions/{type}/{id}/{reactionType}`         | Csrf + Auth     | Toggle reaction (JSON) |

### Moderation panel (any moderator — global perm OR group admin)

| Method | Path                                       | Purpose                              |
|--------|--------------------------------------------|--------------------------------------|
| GET    | `/admin/comments?status={status}`          | Moderation queue (filtered to actor) |
| POST   | `/admin/comments/{id}/status/{status}`     | Transition status                    |
| POST   | `/admin/comments/{id}/delete`              | Hard-delete (cascades children)      |

### Scope configuration (site-level moderators only)

| Method | Path                                       | Purpose                              |
|--------|--------------------------------------------|--------------------------------------|
| GET    | `/admin/comments/scopes`                   | View + toggle site/user/group scopes |
| POST   | `/admin/comments/scopes/site`              | Toggle site-wide moderation          |
| POST   | `/admin/comments/scopes/user/{userId}`     | Toggle per-user moderation           |
| POST   | `/admin/comments/scopes/group/{groupId}`   | Toggle per-group moderation          |

## Using it from another module

In any view that shows an entity:

```php
<?= comments('content', (int) $item['id']) ?>
<?= reactions('content', (int) $item['id']) ?>
```

No wiring needed beyond installing this module and running its migrations.

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
