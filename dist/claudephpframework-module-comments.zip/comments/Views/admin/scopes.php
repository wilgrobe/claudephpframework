<?php
$pageTitle = 'Moderation Scope';
/** @var bool                                                         $siteEnabled */
/** @var array<int, array{scope:string, scope_key:?string, required:bool}> $overrides */
// Split overrides into per-user and per-group for grouping in the UI.
$userOverrides  = array_values(array_filter($overrides, static fn(array $o): bool => $o['scope'] === 'user'));
$groupOverrides = array_values(array_filter($overrides, static fn(array $o): bool => $o['scope'] === 'group'));
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/comments" class="btn btn-sm btn-secondary">← Back to queue</a>
    <h1 style="margin:0;font-size:1.5rem">Moderation Scope</h1>
</div>

<p style="color:#6b7280;max-width:700px">
    New comments go to the moderation queue instead of publishing directly when any of these scopes is enabled.
    The rule applies to a comment if the <strong>site</strong> has moderation on,
    OR the <strong>author</strong> is flagged,
    OR the comment's target is <strong>owned by a group</strong> with moderation on.
</p>

<!-- ── Site-wide ──────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:1.5rem">
    <div class="card-header"><h2 style="font-size:1rem">Site-wide</h2></div>
    <div class="card-body" style="display:flex;gap:1rem;align-items:center">
        <span style="flex:1">
            <?= $siteEnabled
                ? '<strong style="color:#065f46">Enabled</strong> — all new comments go to moderation.'
                : '<strong style="color:#6b7280">Disabled</strong> — comments auto-publish (unless a per-user or per-group override fires).' ?>
        </span>
        <form method="POST" action="/admin/comments/scopes/site">
            <?= csrf_field() ?>
            <input type="hidden" name="required" value="<?= $siteEnabled ? '0' : '1' ?>">
            <button class="btn btn-sm <?= $siteEnabled ? 'btn-secondary' : 'btn-primary' ?>"><?= $siteEnabled ? 'Disable' : 'Enable' ?></button>
        </form>
    </div>
</div>

<!-- ── Per-user ──────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:1.5rem">
    <div class="card-header"><h2 style="font-size:1rem">Per-user overrides</h2></div>
    <?php if (empty($userOverrides)): ?>
    <div class="card-body" style="color:#9ca3af">No per-user overrides. Add one below to auto-moderate a specific user's comments.</div>
    <?php else: ?>
    <table class="table"><thead><tr><th>User ID</th><th>Required</th><th>Actions</th></tr></thead><tbody>
    <?php foreach ($userOverrides as $o): ?>
    <tr>
        <td><code>#<?= e((string) $o['scope_key']) ?></code></td>
        <td><?= $o['required'] ? '<span class="badge badge-warning">yes</span>' : '<span class="badge badge-gray">no</span>' ?></td>
        <td>
            <form method="POST" action="/admin/comments/scopes/user/<?= e((string) $o['scope_key']) ?>" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="required" value="<?= $o['required'] ? '0' : '1' ?>">
                <button class="btn btn-xs btn-secondary"><?= $o['required'] ? 'Disable' : 'Enable' ?></button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>

    <div class="card-body" style="border-top:1px solid #e5e7eb">
        <form method="POST" action="" onsubmit="this.action='/admin/comments/scopes/user/' + encodeURIComponent(this.user_id.value); return true;" style="display:flex;gap:.5rem;align-items:flex-end">
            <?= csrf_field() ?>
            <input type="hidden" name="required" value="1">
            <div class="form-row" style="flex:1;margin:0">
                <label>Add user ID</label>
                <input type="number" name="user_id" required min="1" placeholder="42">
            </div>
            <button class="btn btn-primary btn-sm">Enable moderation for this user</button>
        </form>
    </div>
</div>

<!-- ── Per-group ────────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:1.5rem">
    <div class="card-header"><h2 style="font-size:1rem">Per-group overrides</h2></div>
    <?php if (empty($groupOverrides)): ?>
    <div class="card-body" style="color:#9ca3af">No per-group overrides. Enabling this for a group holds all comments on that group's content for review.</div>
    <?php else: ?>
    <table class="table"><thead><tr><th>Group ID</th><th>Required</th><th>Actions</th></tr></thead><tbody>
    <?php foreach ($groupOverrides as $o): ?>
    <tr>
        <td><code>#<?= e((string) $o['scope_key']) ?></code></td>
        <td><?= $o['required'] ? '<span class="badge badge-warning">yes</span>' : '<span class="badge badge-gray">no</span>' ?></td>
        <td>
            <form method="POST" action="/admin/comments/scopes/group/<?= e((string) $o['scope_key']) ?>" style="display:inline">
                <?= csrf_field() ?>
                <input type="hidden" name="required" value="<?= $o['required'] ? '0' : '1' ?>">
                <button class="btn btn-xs btn-secondary"><?= $o['required'] ? 'Disable' : 'Enable' ?></button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
    </tbody></table>
    <?php endif; ?>

    <div class="card-body" style="border-top:1px solid #e5e7eb">
        <form method="POST" action="" onsubmit="this.action='/admin/comments/scopes/group/' + encodeURIComponent(this.group_id.value); return true;" style="display:flex;gap:.5rem;align-items:flex-end">
            <?= csrf_field() ?>
            <input type="hidden" name="required" value="1">
            <div class="form-row" style="flex:1;margin:0">
                <label>Add group ID</label>
                <input type="number" name="group_id" required min="1" placeholder="7">
            </div>
            <button class="btn btn-primary btn-sm">Enable moderation for this group</button>
        </form>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
