<?php $pageTitle = 'Comment Moderation'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h2>Comment Moderation</h2>
        <?php if ($isGlobal ?? false): ?>
        <div style="display:flex;gap:.35rem">
            <a href="/admin/comments/scopes" class="btn btn-sm btn-secondary">Scope settings</a>
        </div>
        <?php else: ?>
        <span style="font-size:12px;color:#6b7280">Showing comments you can moderate in your groups.</span>
        <?php endif; ?>
    </div>

    <!-- Status tabs with counts -->
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem;flex-wrap:wrap">
        <?php foreach (['pending', 'published', 'spam', 'deleted'] as $s): ?>
        <a href="?status=<?= e($s) ?>"
           class="btn btn-sm <?= $status === $s ? 'btn-primary' : 'btn-secondary' ?>">
            <?= ucfirst($s) ?>
            <span style="opacity:.7;margin-left:.25rem">(<?= (int) ($counts[$s] ?? 0) ?>)</span>
        </a>
        <?php endforeach; ?>
    </div>

    <?php if (empty($items)): ?>
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
        No comments in status <strong><?= e($status) ?></strong>.
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr>
                    <th>Comment</th>
                    <th>Author</th>
                    <th>Target</th>
                    <th>When</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($items as $c): ?>
            <tr>
                <td style="max-width:500px">
                    <div style="font-size:14px;line-height:1.5;white-space:pre-wrap"><?= nl2br(e(mb_substr((string) $c['body'], 0, 400))) ?><?= mb_strlen((string) $c['body']) > 400 ? '…' : '' ?></div>
                </td>
                <td>
                    <?php if (!empty($c['username'])): ?>
                    <strong><?= e($c['username']) ?></strong>
                    <div style="font-size:12px;color:#9ca3af"><?= e((string) $c['email']) ?></div>
                    <?php else: ?>
                    <span style="color:#9ca3af">deleted user</span>
                    <?php endif; ?>
                    <?php if (!empty($c['ip_address'])): ?>
                    <div style="font-size:11px;color:#9ca3af;margin-top:.15rem"><code><?= e($c['ip_address']) ?></code></div>
                    <?php endif; ?>
                </td>
                <td style="font-size:12px">
                    <span class="badge badge-gray"><?= e($c['commentable_type']) ?></span>
                    <div>#<?= (int) $c['commentable_id'] ?></div>
                    <?php if (!empty($c['parent_id'])): ?>
                    <div style="color:#9ca3af;margin-top:.2rem">reply to #<?= (int) $c['parent_id'] ?></div>
                    <?php endif; ?>
                </td>
                <td style="white-space:nowrap;font-size:12px;color:#6b7280">
                    <?= e(date('M j, Y H:i', strtotime((string) $c['created_at']))) ?>
                </td>
                <td>
                    <div style="display:flex;gap:.25rem;flex-wrap:wrap">
                        <?php
                        $buttons = [
                            'pending'   => ['published' => ['✓ Approve', 'btn-success'], 'spam' => ['✗ Spam', 'btn-warning']],
                            'published' => ['spam' => ['✗ Mark spam', 'btn-warning'], 'deleted' => ['Delete', 'btn-danger']],
                            'spam'      => ['published' => ['Restore', 'btn-success'], 'deleted' => ['Delete', 'btn-danger']],
                            'deleted'   => ['published' => ['Restore', 'btn-success']],
                        ];
                        $avail = $buttons[$c['status']] ?? [];
                        ?>
                        <?php foreach ($avail as $toStatus => [$label, $class]): ?>
                        <form method="POST" action="/admin/comments/<?= (int) $c['id'] ?>/status/<?= e($toStatus) ?>">
                            <?= csrf_field() ?><button class="btn btn-xs <?= $class ?>"><?= e($label) ?></button>
                        </form>
                        <?php endforeach; ?>
                        <form method="POST" action="/admin/comments/<?= (int) $c['id'] ?>/delete"
                              data-confirm="Hard-delete this comment and all its replies?">
                            <?= csrf_field() ?><button class="btn btn-xs btn-danger" title="Hard delete">🗑</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>

    <?php
    $lastPage = max(1, (int) ceil($total / $per_page));
    if ($lastPage > 1):
    ?>
    <div class="card-body" style="border-top:1px solid #e5e7eb;display:flex;gap:.35rem;flex-wrap:wrap">
        <?php for ($p = 1; $p <= $lastPage; $p++): ?>
        <a href="?status=<?= e($status) ?>&page=<?= $p ?>"
           class="btn btn-xs <?= $p === $page ? 'btn-primary' : 'btn-secondary' ?>"><?= $p ?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
