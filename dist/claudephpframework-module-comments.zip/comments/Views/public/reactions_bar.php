<?php
/**
 * @var \Core\Auth\Auth $auth
 * @var string          $reactable_type
 * @var int             $reactable_id
 * @var array           $counts  [type => int]
 * @var array           $mine    string[] types the current user has reacted with
 * @var array           $types   [type => emoji]
 */
?>
<div class="reactions-bar" style="display:flex;gap:.5rem;flex-wrap:wrap;margin:.75rem 0">
<?php foreach ($types as $key => $emoji): ?>
    <?php $count = (int) ($counts[$key] ?? 0); $isMine = in_array($key, $mine, true); ?>
    <button type="button"
            class="reaction-btn"
            data-target-type="<?= e($reactable_type) ?>"
            data-target-id="<?= (int) $reactable_id ?>"
            data-reaction-type="<?= e($key) ?>"
            <?= $auth->guest() ? 'disabled title="Log in to react"' : '' ?>
            style="cursor:<?= $auth->guest() ? 'not-allowed' : 'pointer' ?>;padding:.35rem .7rem;border:1px solid <?= $isMine ? '#6366f1' : '#e5e7eb' ?>;background:<?= $isMine ? '#eef2ff' : '#fff' ?>;border-radius:999px;font-size:14px;display:inline-flex;align-items:center;gap:.35rem">
        <span><?= $emoji ?></span>
        <span style="font-size:12px;color:#4b5563"><?= $count ?></span>
    </button>
<?php endforeach; ?>
</div>

<?php if (!$auth->guest()): ?>
<script>
(function() {
    // Idempotent init — attach click handler once per page load.
    if (window.__reactionsInit) return;
    window.__reactionsInit = true;
    document.addEventListener('click', async (e) => {
        const btn = e.target.closest('.reaction-btn');
        if (!btn || btn.disabled) return;
        const type = btn.dataset.targetType;
        const id = btn.dataset.targetId;
        const rt = btn.dataset.reactionType;
        try {
            const res = await fetch(`/reactions/${encodeURIComponent(type)}/${id}/${encodeURIComponent(rt)}`, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRF-Token': document.querySelector('meta[name="csrf-token"]')?.content || '',
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'csrf_token=' + encodeURIComponent(document.querySelector('meta[name="csrf-token"]')?.content || ''),
            });
            if (!res.ok) return;
            const data = await res.json();
            // Update ALL buttons for this target with the fresh counts.
            document.querySelectorAll('.reaction-btn[data-target-type="' + CSS.escape(type) + '"][data-target-id="' + CSS.escape(id) + '"]').forEach(b => {
                const k = b.dataset.reactionType;
                b.querySelectorAll('span')[1].textContent = data.counts[k] || 0;
            });
            // Active styling on the clicked one:
            if (data.action === 'added') {
                btn.style.border = '1px solid #6366f1';
                btn.style.background = '#eef2ff';
            } else {
                btn.style.border = '1px solid #e5e7eb';
                btn.style.background = '#fff';
            }
        } catch (_) {}
    });
})();
</script>
<?php endif; ?>
