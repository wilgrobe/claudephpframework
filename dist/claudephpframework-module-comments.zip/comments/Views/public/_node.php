<?php
/**
 * Recursive comment renderer. Called with:
 *   $node       — current comment array (includes 'children' from the tree builder)
 *   $auth       — \Core\Auth\Auth instance
 *   $commentable_type, $commentable_id
 *   $maxDepth   — visual nesting cap
 *   $depth      — current depth (0 for top-level)
 *
 * Uses its own local scope to avoid clobbering the outer `$node` when
 * recursing — PHP include is hoisted into the calling scope, so we pass
 * state via locally-renamed variables inside a {} block.
 */
$depth ??= 0;
$authorName = trim(
    ($node['first_name'] ?? '') . ' ' . ($node['last_name'] ?? '')
) ?: ($node['username'] ?? '(deleted user)');
$avatar = !empty($node['avatar']) ? $node['avatar'] : null;
$canEdit = !$auth->guest() && (
    (int) ($node['user_id'] ?? 0) === (int) $auth->id()
    || $auth->can('comments.moderate')
);
$withinEditWindow = time() - strtotime((string) $node['created_at']) <= 900;
?>
<div class="comment" style="margin-left:<?= min((int) $depth, (int) $maxDepth) * 24 ?>px;padding:.75rem 0;border-bottom:1px solid #f3f4f6">
    <div style="display:flex;gap:.75rem;align-items:flex-start">
        <?php if ($avatar): ?>
        <img src="<?= e($avatar) ?>" alt="" style="width:32px;height:32px;border-radius:50%;flex-shrink:0">
        <?php else: ?>
        <div style="width:32px;height:32px;border-radius:50%;background:#e5e7eb;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:12px;color:#6b7280;font-weight:600">
            <?= e(mb_substr($authorName, 0, 1)) ?>
        </div>
        <?php endif; ?>
        <div style="flex:1;min-width:0">
            <div style="font-size:13px;margin-bottom:.25rem">
                <strong><?= e($authorName) ?></strong>
                <span style="color:#9ca3af">·</span>
                <span style="color:#9ca3af"><?= e(date('M j, Y H:i', strtotime((string) $node['created_at']))) ?></span>
            </div>
            <div style="font-size:14px;line-height:1.5;white-space:pre-wrap;word-break:break-word">
                <?= nl2br(e((string) $node['body'])) ?>
            </div>
            <div style="margin-top:.35rem;font-size:12px;display:flex;gap:.75rem;align-items:center">
                <?php if (!$auth->guest() && (int) $depth < (int) $maxDepth): ?>
                <a href="#" data-reply-to="<?= (int) $node['id'] ?>" data-reply-author="<?= e($authorName) ?>"
                   onclick="event.preventDefault();
                       const f=document.createElement('form');
                       f.method='POST';
                       f.action='/comments/<?= e($commentable_type) ?>/<?= (int) $commentable_id ?>';
                       f.innerHTML = `<?= csrf_field() ?>` +
                           '<input type=hidden name=parent_id value=<?= (int) $node['id'] ?>>' +
                           '<textarea name=body rows=3 required style=\"width:100%\" placeholder=\"Reply to <?= e($authorName) ?>…\"></textarea>' +
                           '<div style=\"margin-top:.35rem\"><button class=\"btn btn-primary btn-sm\">Reply</button> <button type=button class=\"btn btn-sm btn-secondary\" onclick=\"this.closest(String.fromCharCode(46)+String.fromCharCode(99)+String.fromCharCode(111)+String.fromCharCode(109)+String.fromCharCode(109)+String.fromCharCode(101)+String.fromCharCode(110)+String.fromCharCode(116)).querySelector(String.fromCharCode(46)+String.fromCharCode(114)+String.fromCharCode(101)+String.fromCharCode(112)+String.fromCharCode(108)+String.fromCharCode(121)+String.fromCharCode(45)+String.fromCharCode(102)+String.fromCharCode(111)+String.fromCharCode(114)+String.fromCharCode(109)).remove()\">Cancel</button></div>';
                       f.style.marginTop='.5rem';
                       f.className='reply-form';
                       this.parentElement.parentElement.appendChild(f);">Reply</a>
                <?php endif; ?>

                <?php if ($canEdit && ($auth->can('comments.moderate') || $withinEditWindow)): ?>
                <form method="POST" action="/comments/<?= (int) $node['id'] ?>/delete" style="display:inline"
                      data-confirm="Delete this comment?">
                    <?= csrf_field() ?>
                    <button type="submit" style="background:none;border:none;color:#ef4444;font-size:12px;cursor:pointer;padding:0">Delete</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php if (!empty($node['children'])): ?>
        <?php foreach ($node['children'] as $child): ?>
            <?php $__saved = $node; $node = $child; $depth = ($depth ?? 0) + 1; include __DIR__ . '/_node.php'; $node = $__saved; $depth = $depth - 1; ?>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
