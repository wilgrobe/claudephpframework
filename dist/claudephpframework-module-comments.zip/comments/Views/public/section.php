<?php
/**
 * @var \Core\Auth\Auth $auth
 * @var string          $commentable_type
 * @var int             $commentable_id
 * @var array           $tree          top-level comment nodes
 * @var int             $total         count of all published comments on target
 * @var int             $maxDepth
 */
?>
<section class="comments-section" style="margin-top:2rem;padding-top:1.5rem;border-top:1px solid #e5e7eb">
    <h3 style="margin:0 0 1rem 0;font-size:1.25rem">
        Comments <span style="color:#9ca3af;font-weight:normal">(<?= (int) $total ?>)</span>
    </h3>

    <?php if ($auth->guest()): ?>
    <div style="padding:1rem;background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;margin-bottom:1.25rem;font-size:14px;color:#4b5563">
        <a href="/login">Log in</a> to post a comment.
    </div>
    <?php else: ?>
    <form method="POST" action="/comments/<?= e($commentable_type) ?>/<?= (int) $commentable_id ?>"
          style="margin-bottom:1.5rem;padding:1rem;background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px">
        <?= csrf_field() ?>
        <textarea name="body" rows="3" placeholder="Add a comment…" required
                  style="width:100%;resize:vertical" maxlength="10000"></textarea>
        <div style="margin-top:.5rem;display:flex;justify-content:flex-end">
            <button class="btn btn-primary btn-sm">Post comment</button>
        </div>
    </form>
    <?php endif; ?>

    <?php if (empty($tree)): ?>
    <p style="color:#9ca3af;font-size:14px">No comments yet — be the first.</p>
    <?php else: ?>
    <div class="comments-list">
        <?php foreach ($tree as $node): ?>
            <?php include __DIR__ . '/_node.php'; ?>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</section>
