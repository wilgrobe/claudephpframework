<?php
// modules/comments/Helpers/helpers.php
/**
 * View helpers for the comments + reactions module.
 *
 * Any module can opt its content into comments by dropping these in a view:
 *
 *   <?= comments('content', (int) $item['id']) ?>
 *   <?= reactions('content', (int) $item['id']) ?>
 *
 * Both return a block of HTML — echo them where you want the UI to appear.
 *
 * Intentionally NOT wrapped in function_exists guards beyond the absolute
 * minimum: ModuleProvider::register() includes this file exactly once
 * during bootstrap, and a redefinition attempt would indicate a bug we'd
 * want to surface loudly.
 */

if (!function_exists('comments')) {
    /**
     * Render a comments section for a target.
     *
     * @param string $type  logical type string (e.g. 'content', 'page')
     * @param int    $id    target entity id
     */
    function comments(string $type, int $id): string
    {
        $service = new \Modules\Comments\Services\CommentService();
        $flat    = $service->publishedFor($type, $id);
        $tree    = $service->tree($flat);

        ob_start();
        $auth       = \Core\Auth\Auth::getInstance();
        $commentable_type = $type;
        $commentable_id   = $id;
        $total      = count($flat);
        $maxDepth   = $service->maxDepth();
        include __DIR__ . '/../Views/public/section.php';
        return (string) ob_get_clean();
    }
}

if (!function_exists('reactions')) {
    /**
     * Render a reaction bar for a target.
     *
     * @param string $type  logical type string
     * @param int    $id    target entity id
     */
    function reactions(string $type, int $id): string
    {
        $service = new \Modules\Comments\Services\ReactionService();
        $counts  = $service->counts($type, $id);
        $auth    = \Core\Auth\Auth::getInstance();
        $mine    = $auth->guest() ? [] : $service->userReactions($type, $id, (int) $auth->id());

        ob_start();
        $reactable_type = $type;
        $reactable_id   = $id;
        $types          = \Modules\Comments\Services\ReactionService::TYPES;
        include __DIR__ . '/../Views/public/reactions_bar.php';
        return (string) ob_get_clean();
    }
}
