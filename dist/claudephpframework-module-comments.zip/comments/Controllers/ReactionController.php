<?php
// modules/comments/Controllers/ReactionController.php
namespace Modules\Comments\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Comments\Services\ReactionService;

/**
 * Reactions — emoji toggles attached to any target.
 *
 * Single endpoint: POST /reactions/{type}/{id}/{reactionType}
 * Idempotent — adds if absent, removes if present. Returns JSON so a
 * client-side button can update its label + count without reloading.
 *
 * Auth required. No CSRF on JSON endpoints would be a mistake — the
 * registration includes CsrfMiddleware.
 */
class ReactionController
{
    private Auth            $auth;
    private ReactionService $reactions;

    public function __construct()
    {
        $this->auth      = Auth::getInstance();
        $this->reactions = new ReactionService();
    }

    public function toggle(Request $request): Response
    {
        if ($this->auth->guest()) {
            return Response::json(['error' => 'login_required'], 401);
        }

        $type         = (string) $request->param(0);
        $id           = (int) $request->param(1);
        $reactionType = (string) $request->param(2);

        $result = $this->reactions->toggle($type, $id, (int) $this->auth->id(), $reactionType);
        if ($result === 'unknown') {
            return Response::json(['error' => 'invalid_reaction'], 400);
        }

        return Response::json([
            'ok'     => true,
            'action' => $result,                                    // 'added' | 'removed'
            'counts' => $this->reactions->counts($type, $id),       // fresh counts for the UI
        ]);
    }
}
