<?php
// modules/comments/Controllers/CommentAdminController.php
namespace Modules\Comments\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Session;
use Modules\Comments\Services\CommentService;

/**
 * Moderation surface for comments. Gated by AuthMiddleware + RequireAdmin
 * at registration; per-method permission checks provide defense in depth.
 *
 * Admins can transition status freely:
 *   pending → published (approve)
 *   pending → spam      (reject)
 *   *       → deleted   (soft delete — thread context preserved)
 * and hard-delete rows outright when compliance requires it.
 */
class CommentAdminController
{
    private Auth           $auth;
    private CommentService $comments;

    public function __construct()
    {
        $this->auth     = Auth::getInstance();
        $this->comments = new CommentService();
    }

    public function index(Request $request): Response
    {
        // The unified moderation panel — accessible to anyone with moderation
        // authority, whether global (comments.moderate permission) or group-
        // level (group_admin/group_owner of any group with commentable
        // content). Non-moderators get redirected.
        if (!$this->isAnyModerator()) return $this->denied();

        $status = (string) $request->query('status', 'pending');
        $page   = max(1, (int) $request->query('page', 1));
        $userId = (int) $this->auth->id();

        // Filtered list scoped to what this moderator can actually act on.
        $data = $this->comments->listForModerator($userId, $status, $page);

        // Counts per status — also authority-filtered, so a group admin sees
        // their own queue sizes rather than the site-wide counts.
        $counts = [];
        foreach (CommentService::STATUSES as $s) {
            $counts[$s] = $this->comments->listForModerator($userId, $s, 1, 1)['total'];
        }

        return Response::view('comments::admin.index', [
            'items'   => $data['items'],
            'total'   => $data['total'],
            'status'  => $data['status'],
            'page'    => $data['page'],
            'per_page'=> $data['per_page'],
            'counts'  => $counts,
            'user'    => $this->auth->user(),
            'isGlobal'=> $this->auth->can('comments.moderate'),
        ]);
    }

    /** Admin surface for configuring moderation scope overrides (site/user/group). */
    public function scopes(Request $request): Response
    {
        // Only site-level moderators configure scopes — group admins shouldn't
        // be able to set moderation policies beyond their own group.
        if ($this->auth->cannot('comments.moderate')) return $this->denied();

        return Response::view('comments::admin.scopes', [
            'siteEnabled' => $this->comments->requireModeration(),
            'overrides'   => $this->comments->listModerationScopes(),
            'user'        => $this->auth->user(),
        ]);
    }

    /**
     * POST /admin/comments/scopes/{scope}/{key?}
     *
     * scope:  'site' | 'user' | 'group'
     * key:    user id / group id; ignored when scope=site
     * body:   { required: '1' | '0' }
     */
    public function toggleScope(Request $request): Response
    {
        if ($this->auth->cannot('comments.moderate')) return $this->denied();

        $scope    = (string) $request->param(0);
        $scopeKey = $request->param(1) !== null ? (string) $request->param(1) : null;
        $required = (bool) filter_var($request->post('required', '0'), FILTER_VALIDATE_BOOLEAN);

        try {
            $this->comments->setModerationScope($scope, $scopeKey, $required);
        } catch (\InvalidArgumentException $e) {
            Session::flash('error', $e->getMessage());
            return Response::redirect('/admin/comments/scopes');
        }

        $this->auth->auditLog('comment.scope.update', 'settings', null, null, [
            'scope' => $scope, 'scope_key' => $scopeKey, 'required' => $required,
        ]);
        Session::flash('success', "Moderation scope updated.");
        return Response::redirect('/admin/comments/scopes');
    }

    /** POST /admin/comments/{id}/status/{status} */
    public function setStatus(Request $request): Response
    {
        $id       = (int) $request->param(0);
        $toStatus = (string) $request->param(1);
        $comment  = $this->comments->findById($id);
        if (!$comment) return new Response('Comment not found', 404);

        // canModerate is authoritative: allows global moderators AND group
        // admins when the target is owned by a group they administer.
        if (!$this->comments->canModerate($comment, (int) $this->auth->id())) {
            return $this->denied();
        }

        try {
            $this->comments->setStatus($id, $toStatus);
        } catch (\InvalidArgumentException $e) {
            Session::flash('error', $e->getMessage());
            return Response::redirect('/admin/comments');
        }

        $this->auth->auditLog('comment.moderate', 'comments', $id, null, [
            'from' => $comment['status'],
            'to'   => $toStatus,
        ]);
        Session::flash('success', "Comment #$id moved to $toStatus.");
        return Response::redirect('/admin/comments?status=' . urlencode((string) $comment['status']));
    }

    /** POST /admin/comments/{id}/delete — hard delete (cascades children). */
    public function delete(Request $request): Response
    {
        $id = (int) $request->param(0);
        $comment = $this->comments->findById($id);
        if (!$comment) return new Response('Comment not found', 404);

        // Hard delete is potentially destructive — keep it gated to users
        // who can moderate this specific comment (group admins CAN hard
        // delete within their own content; defensible because they could
        // already set status='deleted' which cascades on Save).
        if (!$this->comments->canModerate($comment, (int) $this->auth->id())) {
            return $this->denied();
        }

        $this->comments->hardDelete($id);
        $this->auth->auditLog('comment.hard_delete', 'comments', $id);
        Session::flash('success', "Comment #$id hard-deleted.");
        return Response::redirect('/admin/comments');
    }

    // ── internals ─────────────────────────────────────────────────────────

    /**
     * Does the current user have ANY moderation authority — global perm OR
     * group admin of at least one group? Drives whether the moderation
     * panel is accessible at all; per-comment authorization goes through
     * canModerate() on each action.
     */
    private function isAnyModerator(): bool
    {
        if ($this->auth->guest()) return false;
        if ($this->auth->can('comments.moderate')) return true;
        return !empty($this->comments->groupIdsUserCanModerate((int) $this->auth->id()));
    }

    private function denied(): Response
    {
        return Response::redirect('/dashboard')
            ->withFlash('error', 'You do not have permission to moderate comments.');
    }
}
