<?php
// modules/comments/Controllers/CommentController.php
namespace Modules\Comments\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Session;
use Modules\Comments\Services\CommentService;

/**
 * Public comment actions — add, edit own, delete own. Routes are protected
 * by AuthMiddleware + CsrfMiddleware at registration; per-method ownership
 * checks live inside.
 *
 * On success we redirect back to the referring page so the user sees their
 * comment in context rather than landing on a standalone JSON response.
 */
class CommentController
{
    private Auth           $auth;
    private CommentService $comments;

    public function __construct()
    {
        $this->auth     = Auth::getInstance();
        $this->comments = new CommentService();
    }

    /**
     * POST /comments/{type}/{id}
     *
     * Create a new comment on the given target. The optional `parent_id`
     * POST field nests the new comment under an existing comment on the
     * SAME target — cross-entity parenting is rejected in the service.
     */
    public function add(Request $request): Response
    {
        $type = (string) $request->param(0);
        $id   = (int) $request->param(1);

        if ($this->auth->guest()) return $this->back($request, 'You must be logged in to comment.');

        $body     = trim((string) $request->post('body', ''));
        $parentId = $request->post('parent_id') !== null && $request->post('parent_id') !== ''
            ? (int) $request->post('parent_id')
            : null;

        if ($body === '') {
            return $this->back($request, 'Comment cannot be empty.');
        }

        try {
            $newId = $this->comments->create(
                type:      $type,
                targetId:  $id,
                userId:    (int) $this->auth->id(),
                body:      $body,
                parentId:  $parentId,
                ip:        $request->ip(),
                userAgent: (string) ($_SERVER['HTTP_USER_AGENT'] ?? ''),
            );
        } catch (\InvalidArgumentException $e) {
            return $this->back($request, $e->getMessage());
        }

        $this->auth->auditLog('comment.create', 'comments', $newId, null, [
            'commentable_type' => $type,
            'commentable_id'   => $id,
        ]);

        $msg = $this->comments->requireModeration()
            ? 'Comment submitted and is awaiting moderation.'
            : 'Comment posted.';
        return $this->back($request, $msg, 'success');
    }

    /** POST /comments/{id}/edit — author-only within the edit window. */
    public function edit(Request $request): Response
    {
        $id      = (int) $request->param(0);
        $comment = $this->comments->findById($id);
        if (!$comment) return new Response('Comment not found', 404);

        if ($this->auth->guest()) return new Response('Forbidden', 403);

        // canModerate widens "admin bypass" to include group admins on
        // group-owned content — matches the rest of the authorization model.
        $isAdmin = $this->comments->canModerate($comment, (int) $this->auth->id());
        if (!$this->comments->canEdit($comment, (int) $this->auth->id(), $isAdmin)) {
            return new Response('Forbidden', 403);
        }

        $body = trim((string) $request->post('body', ''));
        if ($body === '') return $this->back($request, 'Comment cannot be empty.');

        try {
            $this->comments->updateBody($id, $body);
        } catch (\InvalidArgumentException $e) {
            return $this->back($request, $e->getMessage());
        }

        $this->auth->auditLog('comment.update', 'comments', $id);
        return $this->back($request, 'Comment updated.', 'success');
    }

    /** POST /comments/{id}/delete — author-only (soft delete) or admin (hard). */
    public function delete(Request $request): Response
    {
        $id      = (int) $request->param(0);
        $comment = $this->comments->findById($id);
        if (!$comment) return new Response('Comment not found', 404);

        if ($this->auth->guest()) return new Response('Forbidden', 403);

        $isAdmin = $this->comments->canModerate($comment, (int) $this->auth->id());
        if (!$isAdmin && (int) ($comment['user_id'] ?? 0) !== (int) $this->auth->id()) {
            return new Response('Forbidden', 403);
        }

        // Authors get a soft delete (status → 'deleted') so threads stay
        // visible with a "[deleted]" stub; admins can hard-delete via the
        // admin controller if needed for compliance.
        $this->comments->setStatus($id, 'deleted');
        $this->auth->auditLog('comment.delete', 'comments', $id);
        return $this->back($request, 'Comment deleted.', 'success');
    }

    // ── internals ─────────────────────────────────────────────────────────

    private function back(Request $request, string $message, string $level = 'error'): Response
    {
        Session::flash($level, $message);
        $ref = (string) ($_SERVER['HTTP_REFERER'] ?? '/');
        return Response::redirect($ref);
    }
}
