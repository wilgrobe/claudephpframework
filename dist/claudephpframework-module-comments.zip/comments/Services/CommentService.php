<?php
// modules/comments/Services/CommentService.php
namespace Modules\Comments\Services;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Services\SettingsService;

/**
 * Comment domain logic. Kept controller-agnostic so the public and admin
 * controllers both call through here rather than duplicating.
 *
 * Key knobs (site-scoped settings via SettingsService):
 *   - comments_require_moderation (bool) — new comments land 'pending' if true
 *   - comments_edit_window_seconds (int, default 900) — how long an author
 *     can edit their own comment before it becomes admin-only
 *   - comments_max_depth (int, default 5) — visual nesting cap in the tree
 */
class CommentService
{
    public const STATUSES = ['published', 'pending', 'spam', 'deleted'];

    /**
     * Registered ownership resolvers, keyed by commentable_type. Modules
     * register a resolver in their `register(Container $c)` method so
     * comments on their entities get owner_user_id + owner_group_id
     * mirrored onto each comment row, making the moderation queue type-
     * agnostic.
     *
     * Resolver signature: (int $entityId) => array{user_id: ?int, group_id: ?int} | null
     * Returning null means "no ownership information" — the comment is
     * only moderatable by global moderators.
     *
     * Static so resolvers survive re-instantiation of the service across
     * requests and so the registration site (module.php::register) fires
     * once at boot rather than per service construction.
     *
     * @var array<string, callable(int): ?array>
     */
    private static array $ownershipResolvers = [];

    private Database        $db;
    private SettingsService $settings;

    public function __construct()
    {
        $this->db       = Database::getInstance();
        $this->settings = new SettingsService();
    }

    /**
     * Register an ownership resolver for a commentable type. Idempotent —
     * registering the same type twice overwrites the previous resolver
     * (last wins), which matters if two modules claim the same type by
     * accident; the second registration will surface the conflict via
     * whichever module's tests exercise it.
     *
     * @param callable(int): ?array $resolver returns ['user_id' => ?int, 'group_id' => ?int] or null
     */
    public static function registerOwnershipResolver(string $type, callable $resolver): void
    {
        self::$ownershipResolvers[$type] = $resolver;
    }

    /** For tests — wipe the registry. Callers in production shouldn't need this. */
    public static function clearOwnershipResolvers(): void
    {
        self::$ownershipResolvers = [];
    }

    // ── Knob readers ──────────────────────────────────────────────────────

    public function requireModeration(): bool
    {
        return (bool) $this->settings->get('comments_require_moderation', false, 'site');
    }

    public function editWindowSeconds(): int
    {
        return (int) $this->settings->get('comments_edit_window_seconds', 900, 'site');
    }

    public function maxDepth(): int
    {
        return max(1, (int) $this->settings->get('comments_max_depth', 5, 'site'));
    }

    /**
     * Determine the initial status for a new comment, checking moderation
     * scope overrides in order: site → commenter → group-owner → author.
     *
     * Any one match forces 'pending'; otherwise 'published'. Site admins
     * can enable moderation globally, per-user (the *commenter*, to soft-
     * ban noisy users), per-group (per the group that owns the target),
     * or per-author (per the user who owns the target — "pre-moderate my
     * wall"). The distinction between commenter-user-scope and author-
     * user-scope matters on social posts: flagging the commenter would
     * shadow-mod them everywhere, flagging the author turns their own
     * thread into a moderated space.
     */
    public function determineInitialStatus(string $type, int $targetId, int $userId): string
    {
        // 1. Site-wide
        if ($this->requireModeration()) {
            return 'pending';
        }
        // 2. Per-commenter — this author is flagged as needing moderation
        if ((bool) $this->settings->get('comments_require_moderation', false, 'user', (string) $userId)) {
            return 'pending';
        }
        // 3. Target-ownership checks — only relevant if the target resolves
        //    to an owner (user or group). Cheap short-circuit when it doesn't.
        $own = $this->ownershipOfTarget($type, $targetId);
        if ($own) {
            // 3a. Per-group — target lives in a group with moderation on
            if (!empty($own['group_id']) && (bool) $this->settings->get(
                'comments_require_moderation', false, 'group', (string) $own['group_id']
            )) {
                return 'pending';
            }
            // 3b. Per-author — target is owned by a user who pre-moderates
            //     comments on their own content.
            if (!empty($own['user_id']) && (bool) $this->settings->get(
                'comments_require_moderation', false, 'author', (string) $own['user_id']
            )) {
                return 'pending';
            }
        }
        return 'published';
    }

    /**
     * Resolve the owner of a commentable target. Consulted by
     * determineInitialStatus (for per-group / per-author moderation) and
     * canModerate (for per-group / author authority).
     *
     * Resolution order:
     *   1. Registered resolver for $type — set by
     *      CommentService::registerOwnershipResolver. Modules self-register
     *      during bootstrap (see e.g. modules/social/module.php).
     *   2. Built-in fallback for 'content' — preserved so this module
     *      keeps working even if the content module stops registering
     *      (simplifies upgrade paths).
     *
     * Either path returns null if the entity doesn't exist or has no
     * ownership info; null disables per-group and per-author moderation
     * and leaves site-level as the only gate.
     *
     * @return array{user_id: ?int, group_id: ?int}|null
     */
    public function ownershipOfTarget(string $type, int $id): ?array
    {
        $resolver = self::$ownershipResolvers[$type] ?? null;
        if ($resolver !== null) {
            $out = $resolver($id);
            if ($out === null) return null;
            return [
                'user_id'  => isset($out['user_id'])  && $out['user_id']  !== null ? (int) $out['user_id']  : null,
                'group_id' => isset($out['group_id']) && $out['group_id'] !== null ? (int) $out['group_id'] : null,
            ];
        }

        // Fallback: 'content' has always been resolved by this service;
        // keep it working without requiring the content module to register.
        if ($type === 'content') {
            $row = $this->db->fetchOne(
                "SELECT owner_type, owner_user_id, owner_group_id
                   FROM content_items WHERE id = ?",
                [$id]
            );
            if (!$row) return null;
            return [
                'user_id'  => ($row['owner_type'] ?? '') === 'user'
                    ? (int) ($row['owner_user_id'] ?? 0) ?: null
                    : null,
                'group_id' => ($row['owner_type'] ?? '') === 'group'
                    ? (int) ($row['owner_group_id'] ?? 0) ?: null
                    : null,
            ];
        }

        return null;
    }

    /**
     * Can $userId (via the current Auth session) moderate $comment?
     *
     * Three paths to yes:
     *   1. Site-level — user has the comments.moderate permission globally
     *      (usually via the Moderator system role or a broader Admin role).
     *   2. Group-level — the commentable target is owned by a group, AND
     *      the user is group_admin or group_owner of that group. Rides on
     *      the user_groups.base_role hierarchy; no per-group perm grant.
     *   3. Author-level — the commentable target is owned by $userId.
     *      Users moderate comments on their own content (their own social
     *      posts, their own pages). This is the minimum consent-based
     *      moderation right — without it, users have no agency over
     *      replies on their own surfaces.
     *
     * Owner columns can come from two places: the cached values on the
     * comment row (populated at INSERT by create()), or a live lookup via
     * ownershipOfTarget. Prefer the cached values — they're consistent
     * with what the moderation queries filter on.
     */
    public function canModerate(array $comment, int $userId): bool
    {
        $auth = Auth::getInstance();

        // 1. Site-level
        if ($auth->can('comments.moderate')) return true;

        // Owner info — cached columns win; fall back to live resolution
        // so pre-migration rows (no owner_user_id/owner_group_id) still
        // behave correctly.
        $ownerUser  = isset($comment['owner_user_id'])  && $comment['owner_user_id']  !== null
            ? (int) $comment['owner_user_id']  : null;
        $ownerGroup = isset($comment['owner_group_id']) && $comment['owner_group_id'] !== null
            ? (int) $comment['owner_group_id'] : null;

        if ($ownerUser === null && $ownerGroup === null) {
            $type = (string) ($comment['commentable_type'] ?? '');
            $id   = (int) ($comment['commentable_id'] ?? 0);
            if ($type !== '' && $id !== 0) {
                $own = $this->ownershipOfTarget($type, $id);
                if ($own) {
                    $ownerUser  = $own['user_id']  ?? null;
                    $ownerGroup = $own['group_id'] ?? null;
                }
            }
        }

        // 2. Group-level
        if ($ownerGroup !== null && $auth->isGroupAdmin($ownerGroup)) return true;

        // 3. Author-level
        if ($ownerUser !== null && $ownerUser === $userId) return true;

        return false;
    }

    // ── Moderation scope management ──────────────────────────────────────

    /**
     * Persist a moderation-scope override. Wraps SettingsService::set with
     * the right scope/type so the read-path in determineInitialStatus sees
     * it.
     *
     * $scope: 'site', 'user' (commenter), 'group', or 'author' (target owner)
     * $scopeKey: null for site; user id / group id (as string) otherwise
     *
     * 'user' = pre-moderate everything this *commenter* writes (cross-cuts
     *          all their activity — used to soft-ban noisy accounts).
     * 'author' = pre-moderate everything written *on this user's content*
     *          (scoped to the owner's surfaces — used by creators who
     *          want a reviewed comment thread).
     */
    public function setModerationScope(string $scope, ?string $scopeKey, bool $required): void
    {
        if (!in_array($scope, ['site', 'user', 'group', 'author'], true)) {
            throw new \InvalidArgumentException("Unknown moderation scope: $scope");
        }
        if ($scope === 'site') $scopeKey = null;

        $this->settings->set(
            'comments_require_moderation',
            $required ? '1' : '0',
            $scope,
            $scopeKey,
            'bool'
        );
    }

    /**
     * Return the current moderation-scope overrides as a list of rows
     * suitable for the admin UI. Each row: scope, scope_key, required (bool).
     *
     * @return array<int, array{scope: string, scope_key: ?string, required: bool}>
     */
    public function listModerationScopes(): array
    {
        $rows = $this->db->fetchAll(
            "SELECT scope, scope_key, value FROM settings
              WHERE `key` = ?
           ORDER BY scope, scope_key",
            ['comments_require_moderation']
        );
        return array_map(static fn(array $r): array => [
            'scope'     => (string) $r['scope'],
            'scope_key' => $r['scope_key'],
            'required'  => filter_var($r['value'], FILTER_VALIDATE_BOOLEAN) ?? false,
        ], $rows);
    }

    // ── Reads ─────────────────────────────────────────────────────────────

    /**
     * Flat list of published comments for a target, ordered parent-first then
     * chronologically. Callers that want a tree can pass this through tree().
     *
     * @return array<int, array<string, mixed>>
     */
    public function publishedFor(string $type, int $id): array
    {
        return $this->db->fetchAll(
            "SELECT c.*, u.username, u.first_name, u.last_name, u.avatar
               FROM comments c
          LEFT JOIN users u ON u.id = c.user_id
              WHERE c.commentable_type = ?
                AND c.commentable_id   = ?
                AND c.status = 'published'
           ORDER BY c.parent_id IS NOT NULL, c.parent_id ASC, c.created_at ASC",
            [$type, $id]
        );
    }

    /**
     * Group a flat array of comments into a parent/child tree.
     * Each returned node has a 'children' key (array of nodes).
     *
     * @param  array<int, array<string, mixed>> $flat rows from publishedFor()
     * @return array<int, array<string, mixed>>       top-level nodes
     */
    public function tree(array $flat): array
    {
        $nodes = [];
        foreach ($flat as $row) {
            $row['children']   = [];
            $nodes[(int) $row['id']] = $row;
        }

        $roots = [];
        foreach ($nodes as $id => &$node) {
            $parentId = $node['parent_id'] !== null ? (int) $node['parent_id'] : null;
            if ($parentId && isset($nodes[$parentId])) {
                $nodes[$parentId]['children'][] = &$node;
            } else {
                $roots[] = &$node;
            }
        }
        unset($node);
        return $roots;
    }

    public function findById(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM comments WHERE id = ?", [$id]);
    }

    /** Moderation queue (unfiltered) — used only by the old listForModeration path. */
    public function listForModeration(?string $status, int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        $status = in_array($status, self::STATUSES, true) ? $status : 'pending';

        $rows = $this->db->fetchAll(
            "SELECT c.*, u.username, u.email
               FROM comments c
          LEFT JOIN users u ON u.id = c.user_id
              WHERE c.status = ?
           ORDER BY c.created_at DESC
              LIMIT ? OFFSET ?",
            [$status, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM comments WHERE status = ?",
            [$status]
        );

        return ['items' => $rows, 'total' => $total, 'status' => $status, 'page' => $page, 'per_page' => $perPage];
    }

    /**
     * Moderation queue filtered to what $userId is authorized to see.
     * Mirrors canModerate's logic on the denormalized owner columns:
     *   - Global mods (comments.moderate perm) see everything
     *   - Group admins see comments where owner_group_id ∈ their groups
     *   - Authors see comments where owner_user_id = their id
     *
     * Post-migration (2026_04_22_240000), comment rows carry
     * owner_user_id + owner_group_id directly, so this filter is type-
     * agnostic — comments on 'content', 'social_post', or any future
     * type go through one query.
     */
    public function listForModerator(
        int $userId, ?string $status = 'pending', int $page = 1, int $perPage = 50
    ): array {
        $offset = max(0, ($page - 1) * $perPage);
        $status = in_array($status, self::STATUSES, true) ? $status : 'pending';

        $auth     = Auth::getInstance();
        $isGlobal = $auth->can('comments.moderate');

        // Global moderators see everything — same shape as listForModeration.
        if ($isGlobal) {
            return $this->listForModeration($status, $page, $perPage);
        }

        $groupIds = $this->groupIdsUserCanModerate($userId);

        // Author path always applies — any user with posts is an author
        // of comments on them. Combined with the group-admin path in an
        // OR so one query covers both authorities.
        $where  = ["c.status = ?"];
        $bind   = [$status];

        $orClauses = ["c.owner_user_id = ?"];
        $bind[] = $userId;
        if (!empty($groupIds)) {
            $ph = implode(',', array_fill(0, count($groupIds), '?'));
            $orClauses[] = "c.owner_group_id IN ($ph)";
            $bind = array_merge($bind, $groupIds);
        }
        $where[] = '(' . implode(' OR ', $orClauses) . ')';

        $whereSql = 'WHERE ' . implode(' AND ', $where);

        $rows = $this->db->fetchAll(
            "SELECT c.*, u.username, u.email
               FROM comments c
          LEFT JOIN users u ON u.id = c.user_id
              $whereSql
           ORDER BY c.created_at DESC
              LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM comments c $whereSql",
            $bind
        );

        return ['items' => $rows, 'total' => $total, 'status' => $status, 'page' => $page, 'per_page' => $perPage];
    }

    /**
     * Count pending comments visible to $userId — used by the notification
     * digest. Same filtering as listForModerator; returns 0 if user has no
     * authority.
     */
    public function countPendingFor(int $userId): int
    {
        $auth = Auth::getInstance();
        $isGlobal = $auth->can('comments.moderate');

        if ($isGlobal) {
            return (int) $this->db->fetchColumn(
                "SELECT COUNT(*) FROM comments WHERE status = 'pending'"
            );
        }

        $groupIds = $this->groupIdsUserCanModerate($userId);
        $or       = ["owner_user_id = ?"];
        $bind     = [$userId];
        if (!empty($groupIds)) {
            $ph = implode(',', array_fill(0, count($groupIds), '?'));
            $or[] = "owner_group_id IN ($ph)";
            $bind = array_merge($bind, $groupIds);
        }

        return (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM comments
              WHERE status = 'pending'
                AND (" . implode(' OR ', $or) . ")",
            $bind
        );
    }

    /**
     * Groups in which $userId has group_admin or group_owner base_role.
     * Used to widen the moderation queue to group-level authority.
     *
     * @return int[]
     */
    public function groupIdsUserCanModerate(int $userId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT group_id FROM user_groups
              WHERE user_id = ?
                AND base_role IN ('group_admin', 'group_owner')",
            [$userId]
        );
        return array_map(static fn(array $r): int => (int) $r['group_id'], $rows);
    }

    /**
     * All users with any moderation authority *that currently matters*.
     * Used by the notification dispatcher. One row per user with
     * (is_global, group_ids, is_author) shape.
     *
     * Included users:
     *   - Everyone with the comments.moderate permission globally.
     *   - Every group_admin / group_owner (per-group authority).
     *   - Every user with at least one pending comment on content they
     *     own (owner_user_id in comments). Restricting to users with
     *     actually-pending authored comments avoids digesting every
     *     account on every tick — empty digests waste inbox space.
     *
     * @return array<int, array{user_id:int, is_global:bool, group_ids:int[], is_author:bool}>
     */
    public function listAllModerators(): array
    {
        $global = $this->db->fetchAll("
            SELECT DISTINCT ur.user_id
              FROM user_roles ur
              JOIN role_permissions rp ON rp.role_id = ur.role_id
              JOIN permissions p       ON p.id       = rp.permission_id
             WHERE p.slug = 'comments.moderate'
        ");
        $groups = $this->db->fetchAll("
            SELECT user_id, group_id
              FROM user_groups
             WHERE base_role IN ('group_admin', 'group_owner')
        ");
        $authors = $this->db->fetchAll("
            SELECT DISTINCT owner_user_id AS user_id
              FROM comments
             WHERE status = 'pending'
               AND owner_user_id IS NOT NULL
        ");

        $byUser = [];
        foreach ($global as $r) {
            $uid = (int) $r['user_id'];
            $byUser[$uid] ??= ['user_id' => $uid, 'is_global' => false, 'group_ids' => [], 'is_author' => false];
            $byUser[$uid]['is_global'] = true;
        }
        foreach ($groups as $r) {
            $uid = (int) $r['user_id'];
            $byUser[$uid] ??= ['user_id' => $uid, 'is_global' => false, 'group_ids' => [], 'is_author' => false];
            $byUser[$uid]['group_ids'][] = (int) $r['group_id'];
        }
        foreach ($authors as $r) {
            $uid = (int) $r['user_id'];
            $byUser[$uid] ??= ['user_id' => $uid, 'is_global' => false, 'group_ids' => [], 'is_author' => false];
            $byUser[$uid]['is_author'] = true;
        }
        return array_values($byUser);
    }

    // ── Writes ────────────────────────────────────────────────────────────

    /**
     * Create a comment on behalf of $userId. Returns the new comment id.
     * Status is determined by the moderation knob: 'published' or 'pending'.
     *
     * $parentId must either be null or an existing comment on the SAME
     * (type, id) — prevents callers from parenting cross-entity comments.
     */
    public function create(
        string $type, int $targetId, int $userId, string $body,
        ?int $parentId = null, ?string $ip = null, ?string $userAgent = null
    ): int {
        $body = trim($body);
        if ($body === '') {
            throw new \InvalidArgumentException('Comment body cannot be empty.');
        }
        if (mb_strlen($body) > 10000) {
            throw new \InvalidArgumentException('Comment is too long.');
        }

        if ($parentId !== null) {
            $parent = $this->findById($parentId);
            if (!$parent
                || (string) $parent['commentable_type'] !== $type
                || (int) $parent['commentable_id']     !== $targetId
                || (string) $parent['status']          !== 'published'
            ) {
                throw new \InvalidArgumentException('Invalid parent comment.');
            }
        }

        $status = $this->determineInitialStatus($type, $targetId, $userId);

        // Denormalize ownership onto the comment row at INSERT time so the
        // moderation queue can filter uniformly across types. Null-safe —
        // types without a registered resolver just store NULLs and are
        // only moderatable by site-level moderators.
        $own = $this->ownershipOfTarget($type, $targetId);

        return $this->db->insert('comments', [
            'commentable_type' => $type,
            'commentable_id'   => $targetId,
            'parent_id'        => $parentId,
            'user_id'          => $userId,
            'owner_user_id'    => $own['user_id']  ?? null,
            'owner_group_id'   => $own['group_id'] ?? null,
            'body'             => $body,
            'status'           => $status,
            'ip_address'       => $ip ? substr($ip, 0, 45) : null,
            'user_agent'       => $userAgent ? substr($userAgent, 0, 255) : null,
        ]);
    }

    /**
     * Can $userId edit/delete $comment?
     * Returns true if:
     *   - user is the author AND within the edit window AND status is 'published', OR
     *   - $isAdmin is true (admins bypass the window)
     */
    public function canEdit(array $comment, int $userId, bool $isAdmin): bool
    {
        if ($isAdmin) return true;
        if ((int) ($comment['user_id'] ?? 0) !== $userId) return false;
        if ((string) $comment['status'] !== 'published')  return false;

        $age = time() - strtotime((string) $comment['created_at']);
        return $age <= $this->editWindowSeconds();
    }

    public function updateBody(int $commentId, string $body): void
    {
        $body = trim($body);
        if ($body === '') {
            throw new \InvalidArgumentException('Comment body cannot be empty.');
        }
        $this->db->update('comments', ['body' => $body], 'id = ?', [$commentId]);
    }

    public function setStatus(int $commentId, string $status): void
    {
        if (!in_array($status, self::STATUSES, true)) {
            throw new \InvalidArgumentException("Unknown comment status: $status");
        }
        $this->db->update('comments', ['status' => $status], 'id = ?', [$commentId]);
    }

    public function hardDelete(int $commentId): void
    {
        // ON DELETE CASCADE on parent_id removes child threads too.
        $this->db->delete('comments', 'id = ?', [$commentId]);
    }
}
