<?php
// modules/comments/Services/ReactionService.php
namespace Modules\Comments\Services;

use Core\Database\Database;

/**
 * Emoji reactions on any target (polymorphic by string type).
 *
 * One reaction per (target, user, type) — enforced by the UNIQUE index on
 * the reactions table. toggle() is idempotent: if the row exists it's
 * deleted ("un-reacted"); if it doesn't, it's created.
 */
class ReactionService
{
    /** Emoji vocabulary the public UI offers. Keep small — users pick one or two. */
    public const TYPES = [
        'like'  => '👍',
        'love'  => '❤️',
        'laugh' => '😂',
        'wow'   => '😮',
        'sad'   => '😢',
    ];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Toggle a reaction. Returns one of:
     *   'added'    — the user had not reacted with this type; now they have
     *   'removed'  — they had, now they don't
     *   'unknown'  — $type wasn't in the allowed vocabulary; no-op
     */
    public function toggle(string $type, int $targetId, int $userId, string $reactionType): string
    {
        if (!array_key_exists($reactionType, self::TYPES)) return 'unknown';

        $existing = $this->db->fetchOne(
            "SELECT id FROM reactions
              WHERE reactable_type = ? AND reactable_id = ?
                AND user_id = ? AND type = ?",
            [$type, $targetId, $userId, $reactionType]
        );

        if ($existing) {
            $this->db->delete('reactions', 'id = ?', [(int) $existing['id']]);
            return 'removed';
        }

        $this->db->insert('reactions', [
            'reactable_type' => $type,
            'reactable_id'   => $targetId,
            'user_id'        => $userId,
            'type'           => $reactionType,
        ]);
        return 'added';
    }

    /**
     * Aggregate counts per reaction type for a target.
     * Returns a map: [reactionType => count]. Missing types are 0.
     *
     * @return array<string, int>
     */
    public function counts(string $type, int $targetId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT type, COUNT(*) AS n
               FROM reactions
              WHERE reactable_type = ? AND reactable_id = ?
           GROUP BY type",
            [$type, $targetId]
        );

        $out = array_fill_keys(array_keys(self::TYPES), 0);
        foreach ($rows as $r) {
            if (isset($out[$r['type']])) $out[$r['type']] = (int) $r['n'];
        }
        return $out;
    }

    /**
     * Which reaction types has this user already applied to this target?
     * Used by the view to render the reaction-bar buttons as active/inactive.
     *
     * @return string[]  reaction type keys
     */
    public function userReactions(string $type, int $targetId, int $userId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT type FROM reactions
              WHERE reactable_type = ? AND reactable_id = ? AND user_id = ?",
            [$type, $targetId, $userId]
        );
        return array_map(static fn(array $r): string => (string) $r['type'], $rows);
    }
}
