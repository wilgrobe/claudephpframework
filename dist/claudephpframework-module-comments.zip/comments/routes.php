<?php
// modules/comments/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$C = 'Modules\Comments\Controllers\CommentController';
$A = 'Modules\Comments\Controllers\CommentAdminController';
$R = 'Modules\Comments\Controllers\ReactionController';

// ── Public comment actions ────────────────────────────────────────────────
$router->post('/comments/{type}/{id}',    "$C@add",    [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/comments/{id}/edit',      "$C@edit",   [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/comments/{id}/delete',    "$C@delete", [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Reactions toggle (JSON) ───────────────────────────────────────────────
$router->post('/reactions/{type}/{id}/{reactionType}', "$R@toggle",
    [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Unified moderation panel ──────────────────────────────────────────────
// RequireAdmin dropped intentionally — the panel is the single place for
// both site moderators (global comments.moderate permission) AND group
// admins (group_admin+/group_owner base role). Authority is enforced
// in-controller via isAnyModerator() / canModerate() so a group admin
// who lacks site-admin access can still moderate their own group's content.
$router->get ('/admin/comments',                        "$A@index",     [AuthMiddleware::class]);
$router->post('/admin/comments/{id}/status/{status}',   "$A@setStatus", [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/admin/comments/{id}/delete',            "$A@delete",    [CsrfMiddleware::class, AuthMiddleware::class]);

// Moderation scope overrides — global moderators only. Group admins can't
// set policy beyond their own group; setting-wide controls stay with site
// moderators to prevent a compromised group admin from turning off review.
$router->get ('/admin/comments/scopes',                  "$A@scopes",      [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/comments/scopes/{scope}',          "$A@toggleScope", [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/comments/scopes/{scope}/{key}',    "$A@toggleScope", [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
