<?php
// modules/comments/module.php
use Core\Container\Container;
use Core\Module\ModuleProvider;

/**
 * Comments + reactions module.
 *
 * Polymorphic: any entity in the app (content, pages, faq entries, products
 * — anything with an id) can get comments and reactions bolted onto it by
 * calling the `comments()` / `reactions()` view helpers with a type string
 * and id.
 *
 *   <?= comments('content', (int) $item['id']) ?>
 *   <?= reactions('content', (int) $item['id']) ?>
 *
 * Admin moderation lives at /admin/comments. Status workflow:
 *   pending → published (approve) | spam (reject) | deleted (soft delete)
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'comments'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }

    public function register(Container $container): void
    {
        // Make the comments() + reactions() view helpers globally available.
        // Once per request is fine — the helpers file uses function_exists
        // guards so repeated requires are harmless.
        require_once __DIR__ . '/Helpers/helpers.php';
    }
};
