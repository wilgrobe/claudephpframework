<?php
// modules/comments/Jobs/NotifyModeratorsJob.php
namespace Modules\Comments\Jobs;

use Core\Database\Database;
use Core\Queue\Job;
use Core\Services\NotificationService;
use Core\Services\SettingsService;
use Modules\Comments\Services\CommentService;

/**
 * Digest-style notifier for comment moderators.
 *
 * Runs via a scheduled_tasks row (seeded by the companion migration) every
 * 15 minutes. For each user with moderation authority, computes the count
 * of comments they can moderate and posts ONE in-app notification per
 * {comments_notify_interval_minutes} window (default 60) — regardless of
 * how many comments landed in between. This prevents notification storms
 * when a busy site has lots of pending comments.
 *
 * Per-moderator state lives in `settings` under scope='user':
 *   comments_notifier_last_at    — ISO timestamp of the last dispatch
 *   comments_notifier_last_count — count as of that dispatch (for delta logic)
 *
 * Disable the whole pipeline by setting comments_notify_moderators=0 (site).
 */
class NotifyModeratorsJob extends Job
{
    public function handle(): void
    {
        $settings = new SettingsService();
        $comments = new CommentService();
        $db       = Database::getInstance();
        $notify   = new NotificationService();

        // Master kill-switch.
        if (!(bool) $settings->get('comments_notify_moderators', true, 'site')) {
            return;
        }

        $intervalMin = max(5, (int) $settings->get('comments_notify_interval_minutes', 60, 'site'));
        $intervalSec = $intervalMin * 60;
        $now         = time();

        // Per-moderator list.
        $moderators = $comments->listAllModerators();
        if (empty($moderators)) return;

        foreach ($moderators as $m) {
            $userId = (int) $m['user_id'];

            // Count — we call the service's own counter which already
            // applies the global-vs-group filter logic.
            $count = $this->countForModerator($db, $m);
            if ($count <= 0) continue;

            // Throttle: have we notified this user recently?
            $lastAtStr = (string) $settings->get('comments_notifier_last_at', '', 'user', (string) $userId);
            $lastAt    = $lastAtStr !== '' ? strtotime($lastAtStr) : 0;
            if ($lastAt && ($now - $lastAt) < $intervalSec) continue;

            // Dispatch — matches NotificationService::send convention
            // (type-name, title, body, data, channel).
            $label = $count === 1 ? 'comment' : 'comments';
            $notify->send(
                $userId,
                'comments.pending_digest',
                'Comments pending moderation',
                "You have $count $label awaiting review.",
                [
                    'count'      => $count,
                    'action_url' => '/admin/comments?status=pending',
                ],
                'in_app'
            );

            // Record the dispatch so we don't resend within the window.
            $settings->set('comments_notifier_last_at',    date('c', $now),       'user', (string) $userId, 'string');
            $settings->set('comments_notifier_last_count', (string) $count,       'user', (string) $userId, 'int');
        }
    }

    /**
     * Inline count of pending comments visible to this moderator, without
     * instantiating a full request-scoped Auth. We can't use
     * CommentService::countPendingFor here because it relies on the
     * current Auth session — this job runs as the scheduler with no
     * authenticated user.
     *
     * Uses denormalized owner columns (owner_user_id / owner_group_id)
     * so the count is type-agnostic — picks up comments on content,
     * social posts, and any other future commentable type.
     */
    private function countForModerator(Database $db, array $m): int
    {
        if (!empty($m['is_global'])) {
            return (int) $db->fetchColumn(
                "SELECT COUNT(*) FROM comments WHERE status = 'pending'"
            );
        }
        $groupIds  = $m['group_ids'] ?? [];
        $isAuthor  = !empty($m['is_author']);
        $userId    = (int) ($m['user_id'] ?? 0);

        $or   = [];
        $bind = [];
        if ($isAuthor && $userId > 0) {
            $or[]  = "owner_user_id = ?";
            $bind[] = $userId;
        }
        if (!empty($groupIds)) {
            $ph    = implode(',', array_fill(0, count($groupIds), '?'));
            $or[]  = "owner_group_id IN ($ph)";
            $bind  = array_merge($bind, $groupIds);
        }
        if (empty($or)) return 0;

        return (int) $db->fetchColumn(
            "SELECT COUNT(*) FROM comments
              WHERE status = 'pending'
                AND (" . implode(' OR ', $or) . ")",
            $bind
        );
    }
}
