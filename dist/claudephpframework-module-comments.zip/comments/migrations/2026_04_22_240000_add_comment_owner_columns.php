<?php
// modules/comments/migrations/2026_04_22_240000_add_comment_owner_columns.php
use Core\Database\Migration;

/**
 * Add denormalized owner columns to `comments` so the moderation queue
 * can filter by ownership without needing to know which commentable_type
 * is involved. Before this migration, moderation queries hard-coded a
 * JOIN on content_items — fine for one type, untenable once social
 * posts, products, and other entities gain comment threads.
 *
 * The fix is to mirror (owner_user_id, owner_group_id) onto the comment
 * row at INSERT time. New consumers — the social module's 'social_post'
 * type, the store's 'store_product' type, etc. — register their
 * ownership resolver with CommentService, and their comments are
 * moderatable through the same queue.
 *
 * Backfill: content_items is the only existing consumer, so this
 * migration populates owner columns for those rows in one pass.
 * Forward inserts populate via CommentService::create() using the
 * resolver.
 *
 * Moderation indexes: two new indexes cover the most common filter
 * shapes (group-admin queue, post-author queue).
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            ALTER TABLE comments
              ADD COLUMN owner_user_id  INT UNSIGNED NULL AFTER user_id,
              ADD COLUMN owner_group_id INT UNSIGNED NULL AFTER owner_user_id,
              ADD KEY idx_owner_user  (owner_user_id,  status, created_at),
              ADD KEY idx_owner_group (owner_group_id, status, created_at)
        ");

        // Backfill: existing 'content' comments inherit owner columns from
        // content_items. Done as a single UPDATE JOIN so it runs fast even
        // on large datasets.
        $this->db->query("
            UPDATE comments c
              JOIN content_items ci
                ON c.commentable_type = 'content'
               AND ci.id = c.commentable_id
               SET c.owner_user_id  = CASE WHEN ci.owner_type = 'user'  THEN ci.owner_user_id  ELSE NULL END,
                   c.owner_group_id = CASE WHEN ci.owner_type = 'group' THEN ci.owner_group_id ELSE NULL END
        ");
    }

    public function down(): void
    {
        $this->db->query("
            ALTER TABLE comments
              DROP KEY idx_owner_user,
              DROP KEY idx_owner_group,
              DROP COLUMN owner_user_id,
              DROP COLUMN owner_group_id
        ");
    }
};
