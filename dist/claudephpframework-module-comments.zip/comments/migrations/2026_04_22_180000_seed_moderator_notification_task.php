<?php
// modules/comments/migrations/2026_04_22_180000_seed_moderator_notification_task.php
use Core\Database\Migration;

/**
 * Seed a scheduled_tasks row that runs the NotifyModeratorsJob digest
 * every 15 minutes. Idempotent — INSERT IGNORE on the unique `name`.
 *
 * The job itself throttles per-moderator dispatch to no more than once per
 * `comments_notify_interval_minutes` (default 60 min), so the 15-minute
 * tick frequency just means we re-check and catch newly-pending queues
 * promptly without over-notifying.
 *
 * Disable the whole pipeline without deleting this row: set
 * comments_notify_moderators=false in site settings. The job respects
 * that kill-switch on every run.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO scheduled_tasks
                (name, class, payload, schedule_expression, queue, enabled, next_run_at)
            VALUES
                (?, ?, ?, ?, ?, 1, NOW())
        ", [
            'comments-notify-moderators',
            \Modules\Comments\Jobs\NotifyModeratorsJob::class,
            json_encode([]),
            '*/15 * * * *',
            'default',
        ]);
    }

    public function down(): void
    {
        $this->db->query("DELETE FROM scheduled_tasks WHERE name = ?", ['comments-notify-moderators']);
    }
};
