<?php
// modules/comments/migrations/2026_04_22_170000_seed_comments_moderator_role.php
use Core\Database\Migration;

/**
 * Seed the `comments.moderate` permission and a system `Moderator` role
 * that carries it. Fully idempotent via INSERT IGNORE on the unique slug
 * columns — safe to re-run.
 *
 * The Moderator role is a SYSTEM role (is_system=1) so the roles admin
 * can't accidentally delete it out from under the moderation workflow.
 *
 * Permission grant model recap (why we don't need a per-group permission):
 *   - Site-level moderation: assign the Moderator role (or any role that
 *     contains comments.moderate) to a user. CommentService::canModerate
 *     recognises this via Auth::can('comments.moderate').
 *   - Group-level moderation: users with group_admin or group_owner base
 *     roles in the group that owns the commentable target can moderate
 *     comments on that content. This rides on the existing hierarchy —
 *     no extra grants needed.
 */
return new class extends Migration {
    public function up(): void
    {
        // 1. Permission
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Moderate comments',
            'comments.moderate',
            'comments',
            'Approve, reject, or delete comments. Granted to site-level ' .
            'moderators; group admins can moderate their own group\'s content ' .
            'via the normal group role hierarchy.',
        ]);

        // 2. Role
        $this->db->query("
            INSERT IGNORE INTO roles (name, slug, description, is_system)
            VALUES (?, ?, ?, 1)
        ", [
            'Moderator',
            'moderator',
            'Can moderate comments across the site. Assign to trusted users ' .
            'who aren\'t full admins but should be able to review the ' .
            'comment moderation queue.',
        ]);

        // 3. Link role → permission. Look up ids since INSERT IGNORE may
        //    have skipped (meaning the row already existed with some id).
        $permId = (int) $this->db->fetchColumn(
            "SELECT id FROM permissions WHERE slug = ?",
            ['comments.moderate']
        );
        $roleId = (int) $this->db->fetchColumn(
            "SELECT id FROM roles WHERE slug = ?",
            ['moderator']
        );

        if ($permId > 0 && $roleId > 0) {
            $this->db->query("
                INSERT IGNORE INTO role_permissions (role_id, permission_id)
                VALUES (?, ?)
            ", [$roleId, $permId]);
        }
    }

    public function down(): void
    {
        // Safe rollback: remove the link + the seeded rows, but only if no
        // other role is still using the permission (compound policy might
        // have granted it). We're conservative — a down() that nukes widely
        // used state would be a footgun.
        $permId = (int) $this->db->fetchColumn("SELECT id FROM permissions WHERE slug = ?", ['comments.moderate']);
        $roleId = (int) $this->db->fetchColumn("SELECT id FROM roles WHERE slug = ?", ['moderator']);

        if ($permId > 0 && $roleId > 0) {
            $this->db->query("DELETE FROM role_permissions WHERE role_id = ? AND permission_id = ?", [$roleId, $permId]);
        }
        if ($roleId > 0) {
            $this->db->query("DELETE FROM roles WHERE id = ? AND is_system = 1", [$roleId]);
        }
        // Don't delete the permission — other roles may have been granted it
        // in the meantime. Dangling permissions are harmless; deleting one
        // that other roles reference would cascade their grants away.
    }
};
