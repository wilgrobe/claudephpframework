<?php
// modules/comments/migrations/2026_04_22_160000_create_comments_tables.php
use Core\Database\Migration;

/**
 * Schema for the comments + reactions module.
 *
 * Two tables:
 *   - comments   — threaded discussion attached to any entity by type string
 *   - reactions  — emoji-ish reactions attached to any entity (including
 *                  comments themselves)
 *
 * Type strings are app-chosen labels (e.g. 'content', 'page', 'faq',
 * 'comment'). We do NOT store PHP class names — that would couple the
 * schema to the codebase's namespace layout AND create a code-execution
 * risk if a bad actor ever got write access.
 *
 * Indexes are tuned for the common read:
 *   "give me all published comments on content #42, threaded by parent_id"
 *   → SELECT * FROM comments
 *     WHERE commentable_type = 'content' AND commentable_id = 42
 *       AND status = 'published'
 *     ORDER BY parent_id, created_at
 *   → idx_commentable handles the WHERE; parent_id stays in the row.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE comments (
                id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                commentable_type  VARCHAR(64)  NOT NULL,
                commentable_id    BIGINT UNSIGNED NOT NULL,
                parent_id         BIGINT UNSIGNED NULL,
                user_id           INT UNSIGNED NULL,
                body              TEXT         NOT NULL,
                status            ENUM('published','pending','spam','deleted') NOT NULL DEFAULT 'published',
                ip_address        VARCHAR(45)  NULL,
                user_agent        VARCHAR(255) NULL,
                created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                KEY idx_commentable (commentable_type, commentable_id, status),
                KEY idx_parent      (parent_id),
                KEY idx_user        (user_id, created_at),
                KEY idx_moderation  (status, created_at),
                CONSTRAINT fk_comments_parent
                    FOREIGN KEY (parent_id) REFERENCES comments (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE reactions (
                id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                reactable_type VARCHAR(64)  NOT NULL,
                reactable_id   BIGINT UNSIGNED NOT NULL,
                user_id        INT UNSIGNED NOT NULL,
                type           VARCHAR(32)  NOT NULL,
                created_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

                UNIQUE KEY uq_user_reaction (reactable_type, reactable_id, user_id, type),
                KEY idx_target_type (reactable_type, reactable_id, type),
                KEY idx_user        (user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS reactions");
        $this->db->query("DROP TABLE IF EXISTS comments");
    }
};
