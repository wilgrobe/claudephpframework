# Installation — Comments + Reactions module

## Prerequisites

- `claudephpframework-core` installed.
- `comments.moderate` permission defined in the `permissions` table and
  granted to at least one admin role. If it's missing, add it via
  `/admin/roles` (key: `comments.moderate`, label: "Moderate comments").

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-comments.zip
   cp -r claudephpframework-module-comments/comments /path/to/project/modules/
   ```

2. Run the migrations (creates `comments` + `reactions` tables, seeds
   the Moderator role, sets up the notification schedule, and adds
   denormalized owner columns to `comments`):
   ```bash
   php artisan migrate
   ```
   Four migrations run in order. The last one
   (`..._add_comment_owner_columns.php`) adds `owner_user_id` +
   `owner_group_id` to `comments` and backfills rows for existing
   `commentable_type='content'` comments. New `commentable_type`s that
   register an ownership resolver (e.g. `social_post`) get their owner
   columns populated at INSERT time via `CommentService::create`.

3. Refresh module cache if using production caching:
   ```bash
   php artisan module:cache
   ```

## Configuration (optional)

### Site-level knobs (`settings.scope = 'site'`)

| Setting                              | Default | Meaning                                                          |
|--------------------------------------|---------|------------------------------------------------------------------|
| `comments_require_moderation`        | `false` | Site-wide: new comments land `pending`                           |
| `comments_edit_window_seconds`       | `900`   | How long authors can edit their own posts                        |
| `comments_max_depth`                 | `5`     | Visual cap on reply nesting                                      |
| `comments_notify_moderators`         | `true`  | Master kill-switch for moderator digest notifications            |
| `comments_notify_interval_minutes`   | `60`    | Minimum gap between digest notifications per moderator           |

### Per-user / per-group overrides

Set via `/admin/comments/scopes` (requires `comments.moderate` permission), or
directly:

```php
// soft-moderate user #42's comments
app(\Core\Services\SettingsService::class)
    ->set('comments_require_moderation', '1', 'user', '42', 'bool');

// require moderation on everything in group #7
app(\Core\Services\SettingsService::class)
    ->set('comments_require_moderation', '1', 'group', '7', 'bool');
```

A new comment lands `pending` if ANY scope flag matches (site → author → target's group).

### Moderator role + notifications

The second migration seeds:

- The `comments.moderate` permission
- A system `Moderator` role carrying that permission
- A scheduled_task `comments-notify-moderators` that runs every 15 min to
  send aggregated digest notifications

Assign the `Moderator` role to any user from `/admin/roles` → "Moderator".
Group admins and group owners automatically get moderation authority on
their group's content — no role grant needed.

Digest behavior: each moderator gets at most one in-app notification per
`comments_notify_interval_minutes` when pending count > 0. Disable the
whole pipeline by flipping `comments_notify_moderators = false`.

## Wiring comments into your existing views

The module exposes two view helpers globally once the module is loaded:

```php
<?= comments('content', (int) $item['id']) ?>
<?= reactions('content', (int) $item['id']) ?>
```

The `$type` argument is an app-chosen label — be consistent. Once you pick
`'content'` for content items, don't mix in `'content-item'` elsewhere or
the comments will attach to different logical targets.

## Verification

1. Add `<?= comments('demo', 1) ?>` somewhere accessible (e.g. a test
   dashboard route you already have). Visit the page.
2. You should see an empty "No comments yet" block with a post form (if
   logged in).
3. Post a test comment. It should appear immediately (unless moderation
   is enabled, in which case it shows in `/admin/comments?status=pending`).
4. Add `<?= reactions('demo', 1) ?>`. Click an emoji — the button should
   flip to active-colored and the count should tick up.
5. Run the test suite: `./vendor/bin/phpunit` — the 8 new CommentService
   tests should bring you to 135 green.

## Troubleshooting

- **Reaction button does nothing** — verify your layout includes a
  `<meta name="csrf-token" content="...">` tag in `<head>`. The JS sends
  the token in the X-CSRF-Token header.
- **Reply button posts to the wrong place** — check no other module has
  also registered a `/comments/*` route. The module owns the entire
  `/comments` and `/reactions` prefixes; collisions would be ambiguous.
- **Moderation queue is empty but I just posted** — `comments_require_moderation`
  is probably `false` (new comments go straight to `published`). Flip the
  setting if you want the queue to populate.
