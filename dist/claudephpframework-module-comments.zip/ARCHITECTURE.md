# Architecture — Comments + Reactions module

## Files

```
comments/
├── module.php                                        # Provider — registers helpers on boot
├── routes.php                                        # 7 routes (public + admin + reactions)
├── Controllers/
│   ├── CommentController.php                         # Public: add, edit own, delete own
│   ├── CommentAdminController.php                    # Admin: moderation queue + transitions
│   └── ReactionController.php                        # Toggle endpoint (JSON)
├── Services/
│   ├── CommentService.php                            # Tree building, moderation, auth policy
│   └── ReactionService.php                           # Idempotent toggle + aggregate counts
├── Helpers/
│   └── helpers.php                                   # Global comments() + reactions() view helpers
├── Views/
│   ├── public/
│   │   ├── section.php                               # Full comments block (form + list)
│   │   ├── _node.php                                 # Recursive single-comment renderer
│   │   └── reactions_bar.php                         # Emoji button bar + JS toggle
│   └── admin/index.php                               # Moderation queue with status tabs
└── migrations/
    └── 2026_04_22_160000_create_comments_tables.php  # 2 tables
```

## Tables

**`comments`** — polymorphic, threaded, moderatable
```
id, commentable_type, commentable_id, parent_id (nullable, FK → comments.id),
user_id, body, status ENUM(published|pending|spam|deleted),
ip_address, user_agent, created_at, updated_at

Indexes:
  (commentable_type, commentable_id, status)  — primary read path
  (parent_id)                                 — thread fetch
  (user_id, created_at)                       — user's-own-comments views
  (status, created_at)                        — moderation queue
```

`ON DELETE CASCADE` on `parent_id` removes child threads when a parent is
hard-deleted. Admin controllers use `setStatus('deleted')` for soft delete;
the cascade only fires on `hardDelete()`.

**`reactions`** — polymorphic, idempotent
```
id, reactable_type, reactable_id, user_id, type, created_at

UNIQUE (reactable_type, reactable_id, user_id, type)
Indexes:
  (reactable_type, reactable_id, type)  — aggregate counts
  (user_id)                             — user's-own-reactions lookup
```

The UNIQUE is the key correctness invariant — `toggle()` relies on
SELECT-or-INSERT semantics and never double-counts.

## Why strings (not class names) for polymorphism

`commentable_type` and `reactable_type` store app-chosen labels like
`'content'`, not `Modules\Content\Models\ContentItem`. Two reasons:

1. **Schema is decoupled from code layout.** Renaming a namespace doesn't
   require a data migration.
2. **No string → class resolution on user input.** If type were a PHP
   class name, anything that let an attacker influence the stored value
   could lead to arbitrary class instantiation. Safe strings avoid that
   entire category.

The downside — callers have to remember their own type strings — is worth
the simplicity.

## Polymorphic type strings used by core modules

| Module   | Type string |
|----------|-------------|
| content  | `content`   |
| pages    | `page`      |
| faq      | `faq`       |
| forms    | *n/a* (no comments on form submissions) |
| (future) | pick your label; be consistent across the app |

Add your own by calling `comments('myThing', $id)` in the relevant view.
Nothing in the comments module needs to change.

## Threaded rendering

`Views/public/_node.php` is a self-recursive include. Depth is passed via a
local `$depth` counter; visual indent is `min($depth, $maxDepth) * 24px`.
Beyond `maxDepth` the nodes still render, just without additional indent,
so deep threads don't run off the page.

Reply form is injected via inline JS — no extra server round-trip for
rendering the form; on submit it POSTs to the normal create endpoint with
`parent_id` set.

## Reaction toggle (HTTP shape)

```
POST /reactions/{type}/{id}/{reactionType}
  → ReactionController::toggle
    → ReactionService::toggle — SELECT-then-INSERT-or-DELETE
    → JSON: { ok: true, action: 'added'|'removed', counts: {like: n, love: n, …} }
```

Returns counts so the client can refresh every button, not just the
clicked one. The CSS update is applied client-side by matching on
`[data-target-type]` + `[data-target-id]`.

CSRF is required (JS sends `X-CSRF-Token`); the layout needs a
`<meta name="csrf-token" content="...">` tag for the JS to pick up. Most
apps already have this for the rest of the framework's AJAX patterns.

## Authorization matrix

| Action                | Who                                                                                               |
|-----------------------|---------------------------------------------------------------------------------------------------|
| Read comments         | Everyone (status=published only on public path)                                                   |
| Post comment          | Authenticated user                                                                                |
| Edit own              | Author, within `comments_edit_window_seconds`, status=published; moderator any time               |
| Delete own (soft)     | Author, any time                                                                                  |
| Moderate (any action) | Global: `comments.moderate` permission. Group: `group_admin`+ on target's owning group.           |
| Hard delete           | Same as moderate (global OR group admin of target's owning group)                                 |
| Configure scope       | Global `comments.moderate` only (site-level setting policy)                                        |
| React                 | Authenticated user                                                                                |

Authority is checked by `CommentService::canModerate($comment, $userId)` —
the single policy function that both controllers call. Defense in depth:
controllers re-check per-action rather than relying on the middleware gate.

## Moderation scope (four-tier)

A new comment's initial status is determined by checking moderation flags
in order: **site → commenter → group-owner → author-owner**. Any match
forces `pending`; otherwise `published`.

```
determineInitialStatus($type, $targetId, $userId):
  1. site setting comments_require_moderation == true          → pending
  2. commenter scope  setting on $userId                        → pending
  3. if target has an owning group AND group-scope setting on   → pending
  4. if target has an owning user AND author-scope setting on   → pending
  else → published
```

Ownership is resolved via `ownershipOfTarget($type, $id)`, which:

1. Consults the static `$ownershipResolvers` registry. Modules that
   commentable their entities register a resolver in their module
   provider's `register(Container $c)` method. Built-in module setup:
     * `social` registers `'social_post'` — returns
       `['user_id' => author, 'group_id' => post.group_id ?? null]`.
   Any other module can register its own types the same way.
2. Falls back to a hard-coded `'content'` path that reads
   `content_items.owner_type/_user_id/_group_id`. This preserves the
   pre-registry behaviour if the content module stops registering
   itself (upgrade safety).

## Denormalized owner columns (migration 2026_04_22_240000)

The `comments` table carries `owner_user_id` + `owner_group_id`
columns, populated at INSERT time by `CommentService::create` using
the resolver above. This lets the moderation queue filter uniformly
across commentable types — the query doesn't care whether the comment
is on a content row, a social post, or some future type. Two indexes
cover the common shapes:

- `idx_owner_user  (owner_user_id,  status, created_at)` — author
  self-moderation queue.
- `idx_owner_group (owner_group_id, status, created_at)` — group-admin
  queue.

Existing rows at migration time are backfilled from `content_items`.

## canModerate rules

`canModerate(array $comment, int $userId)` returns true under any of:

1. **Site-level** — `$userId` has the `comments.moderate` permission.
2. **Group-level** — comment's `owner_group_id` matches a group where
   `$userId` is `group_admin` or `group_owner` (via user_groups.base_role).
3. **Author-level** — comment's `owner_user_id === $userId`. Post
   authors can moderate their own threads without needing a role
   assignment. This is the minimum consent-based moderation right.

The controller path `/admin/comments` only requires `AuthMiddleware`;
`listForModerator` returns an empty set for users with zero authority,
and pre-filters for authors + group admins so each moderator sees only
what they can act on.

## Notification digest job

`Modules\Comments\Jobs\NotifyModeratorsJob` runs every 15 min via a
scheduled_tasks row seeded by the companion migration. Each moderator
(global OR group) gets at most one in-app notification per
`comments_notify_interval_minutes` (default 60) when their pending count
> 0.

Per-moderator throttle state lives in `settings` under scope=`user`:

- `comments_notifier_last_at` — ISO timestamp of last dispatch
- `comments_notifier_last_count` — count at that time

Kill-switch: `comments_notify_moderators = false` (site scope) disables
the job's work entirely.

Job dispatch reuses `NotificationService::send(userId, type, title, body, data, 'in_app')`
with type `comments.pending_digest` and an `action_url` in the data
payload. Integrates with the existing bell-badge in the notifications
module — no new reader UI needed.

## Moderator role

The `2026_04_22_170000_seed_comments_moderator_role` migration idempotently
creates:

- `permissions` row with slug `comments.moderate` (module=`comments`)
- `roles` row `Moderator` (slug=`moderator`, is_system=1)
- `role_permissions` linking them

System roles (`is_system=1`) can't be deleted from the roles admin — a
safety measure so the moderation workflow can't accidentally lose its
permission source. Assign the role to users at `/admin/roles`.

Group-level moderation **doesn't** need a separate per-group permission
grant. It rides on the existing `user_groups.base_role` hierarchy
(`group_admin` and `group_owner` can moderate their group's content).
This keeps the data model simple and matches how the rest of the
framework handles group authority.

## Services used (from core)

- `Core\Database\Database` — all SQL
- `Core\Auth\Auth` — actor, audit log, permission checks
- `Core\Services\SettingsService` — read moderation knobs
- `Core\Session` — flash messages on redirects

No container bindings needed — the services are `new`-constructed in
controllers.

## Known limitations / v2 ideas

- **Guest comments** — not supported in MVP. Would require CAPTCHA +
  author_name/email columns + spam throttling.
- **@-mentions** — not supported. Would touch the body render path and
  add a notification hook.
- **Attachments** — not supported. Would require wiring FileUploadService.
- **Edit history** — a single `body` column, no audit. If compliance
  demands it, add a `comment_revisions` table and write on every update.
- **Rate limiting** — not currently imposed here; core's generic
  `RateLimiter` can be wrapped around `CommentController::add` if an app
  experiences spam.

## Dependencies

- `claudephpframework-core`
- Core's `users` table (via `user_id` FK)
- Core's `settings` table (for knobs)
- `comments.moderate` permission in the `permissions` table

No dependencies on other modules.
