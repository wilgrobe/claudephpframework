# Audit-log viewer module

Read-only admin UI over the core framework's `audit_log` table. No
writes — the audit log itself is populated by `Auth::auditLog()` from
the core's security-sensitive paths (login, logout, role changes,
superadmin toggles, emulation, etc.).

## Features

- **Filter form** — actor user id, action (exact or prefix via
  `auth.*`), model + model_id, date range (YYYY-MM-DD bounds), and
  free-text search across action/model/notes.
- **Detail view** with pretty-printed old/new JSON values side by
  side — crucial for understanding what changed.
- **Emulation awareness** — shows both actor and emulated-by columns,
  plus a `superadmin` badge when that mode was active.

## Routes

| Method | Path                         | Purpose |
|--------|------------------------------|---------|
| GET    | `/admin/audit-log`           | Filterable queue |
| GET    | `/admin/audit-log/{id}`      | Detail view |

## Permission

`audit.view` (seeded). Apps that grant a "compliance auditor" role
this permission without full admin access get a read-only audit
surface. `RequireAdmin` middleware at the route layer means full
admins can also access without the explicit perm.

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
