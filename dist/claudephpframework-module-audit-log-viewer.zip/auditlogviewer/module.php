<?php
// modules/audit-log-viewer/module.php
use Core\Module\ModuleProvider;

/**
 * Audit-log viewer module — read-only admin UI over the core
 * `audit_log` table (populated by Auth::auditLog). No write path
 * here; no new tables (the base schema owns `audit_log`).
 *
 * Filter surface: actor_user_id, action (exact or prefix via 'x.*'),
 * model + model_id, date range, free-text search across
 * action/model/notes.
 */
return new class extends ModuleProvider {
    // Namespace must match View::addNamespace's /^[a-zA-Z0-9_]+$/ regex.
    public function name(): string            { return 'audit_log_viewer'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
