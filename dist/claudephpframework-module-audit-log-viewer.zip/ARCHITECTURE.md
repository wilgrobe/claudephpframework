# Architecture — Audit-log viewer

## Files

```
audit-log-viewer/
├── module.php
├── routes.php                      # 2 routes
├── Controllers/AuditLogController.php
├── Services/AuditLogService.php    # Read-only queries + filter builder
├── Views/admin/{index,show}.php
└── migrations/…_seed_audit_viewer_permission.php  # permission only
```

## Data model

None owned — reads from the core's `audit_log` (created in
`database/schema.sql`):

```
audit_log:
  id, actor_user_id, emulated_user_id, superadmin_mode,
  action, model, model_id, old_values JSON, new_values JSON,
  ip_address, user_agent, notes, created_at
```

Existing indexes on `actor_user_id`, `action`, `(model, model_id)`
cover the filter paths. The free-text `q` search does a scan —
acceptable for logs up to low millions of rows.

## Action prefix matching

The `action` filter supports a trailing `*` to prefix-match:
`auth.*` → `LIKE 'auth.%'`. Internally implemented as a tiny
string check so the common case (exact match) stays an indexed
equality.

## No writes

This module explicitly does not expose any write path on `audit_log`.
That's a policy choice: the audit log is meant to be a forensic
record; admins shouldn't be able to edit it. If deletion ever needs
to happen (e.g. GDPR right-to-be-forgotten), it should be a separate,
carefully-gated migration path — not a button on the admin surface.
