# Installation — Audit-log viewer

## Prerequisites

- `claudephpframework-core` (which creates the `audit_log` table).
- `audit.view` permission granted to auditor roles (seeded by the
  one migration).

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` (seeds the permission; no tables are created
   — this module is read-only over the core's `audit_log`).
3. Visit `/admin/audit-log` as admin.

## Deferred features

- **Export** — download filtered result set as CSV. Works well with
  the import-export module's streaming helper.
- **Saved filters** — persist common query combinations (e.g.
  "auth failures this week") per admin.
- **Retention + prune** — a scheduled task to archive or delete rows
  older than N days to keep the table bounded.
- **Diff rendering** — today we show pretty-printed old/new JSON
  side-by-side. A coloured diff would read better on large payloads.

## Verification

- Log in; log out; visit `/admin/audit-log?action=auth.*`. Two rows
  for the same actor, one `auth.login`, one `auth.logout`.
- Toggle superadmin mode on an admin account. The resulting
  `superadmin.mode_toggle` row has old_values + new_values JSON
  visible on the detail page.
