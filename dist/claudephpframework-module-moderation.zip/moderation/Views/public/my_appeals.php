<?php $pageTitle = 'Your moderation history'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Moderation history</h1>

<?php if ((int) ($state['warnings_count'] ?? 0) > 0 || !empty($state['muted_until']) || !empty($state['suspended_until']) || !empty($state['banned_at'])): ?>
<div class="card" style="margin-bottom:1rem;border-left:4px solid #f59e0b">
    <div class="card-body">
        <h3 style="margin-top:0">Your current status</h3>
        <ul style="list-style:none;padding-left:0">
            <?php if ((int) ($state['warnings_count'] ?? 0) > 0): ?>
            <li><strong>Warnings:</strong> <?= (int) $state['warnings_count'] ?></li>
            <?php endif; ?>
            <?php if (!empty($state['muted_until']) && strtotime((string) $state['muted_until']) > time()): ?>
            <li><strong>Muted until:</strong> <?= e(date('M j, Y H:i', strtotime((string) $state['muted_until']))) ?></li>
            <?php endif; ?>
            <?php if (!empty($state['suspended_until']) && strtotime((string) $state['suspended_until']) > time()): ?>
            <li><strong>Suspended until:</strong> <?= e(date('M j, Y H:i', strtotime((string) $state['suspended_until']))) ?></li>
            <?php endif; ?>
            <?php if (!empty($state['banned_at'])): ?>
            <li style="color:#b91c1c"><strong>Banned</strong> since <?= e(date('M j, Y', strtotime((string) $state['banned_at']))) ?>
                <?php if (!empty($state['ban_reason'])): ?> — <?= e((string) $state['ban_reason']) ?><?php endif; ?>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</div>
<?php endif; ?>

<h2>Your past actions</h2>
<?php if (empty($actions)): ?>
<div class="card"><div class="card-body" style="color:#9ca3af;text-align:center;padding:2rem 1rem">Nothing on your record.</div></div>
<?php else: ?>
<?php
$pendingAppeals = [];
foreach ($appeals as $a) $pendingAppeals[(int) $a['action_id']] = $a;
?>
<div class="card">
    <table class="table">
        <thead><tr><th>When</th><th>Action</th><th>Reason</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($actions as $a): $appeal = $pendingAppeals[(int) $a['id']] ?? null; ?>
        <tr>
            <td style="font-size:13px"><?= e(date('M j, Y', strtotime((string) $a['created_at']))) ?></td>
            <td><strong><?= e((string) $a['action']) ?></strong><?= !empty($a['expires_at']) ? ' · ' . e(date('M j, Y', strtotime((string) $a['expires_at']))) : '' ?></td>
            <td style="font-size:13px;color:#6b7280"><?= e((string) ($a['reason'] ?? '')) ?></td>
            <td>
                <?php if (!empty($a['reversed_at'])): ?>
                <span class="badge badge-success">reversed</span>
                <?php else: ?>
                <span class="badge">active</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if ($appeal): ?>
                <span style="font-size:12px;color:#6b7280">Appeal <?= e((string) $appeal['status']) ?></span>
                <?php elseif (empty($a['reversed_at'])): ?>
                <a href="/my/appeals/new/<?= (int) $a['id'] ?>" class="btn btn-sm btn-secondary">Request review</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php if (!empty($appeals)): ?>
<h2 style="margin-top:1.5rem">Your appeals</h2>
<div class="card">
    <table class="table">
        <thead><tr><th>Submitted</th><th>About</th><th>Status</th><th>Reviewer notes</th></tr></thead>
        <tbody>
        <?php foreach ($appeals as $a): ?>
        <tr>
            <td style="font-size:13px"><?= e(date('M j, Y', strtotime((string) $a['created_at']))) ?></td>
            <td><code><?= e((string) $a['action_kind']) ?></code></td>
            <td><span class="badge"><?= e((string) $a['status']) ?></span></td>
            <td style="font-size:13px;color:#6b7280"><?= e((string) ($a['reviewer_notes'] ?? '')) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
