<?php $pageTitle = 'Submit appeal'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:640px;margin:0 auto">
<a href="/my/appeals" style="color:#6b7280;text-decoration:none;font-size:13px">← Moderation history</a>

<div class="card" style="margin-top:.75rem">
    <div class="card-header"><h2 style="margin:0">Appeal a moderation action</h2></div>
    <div class="card-body">
        <div style="padding:.75rem;background:#f9fafb;border-radius:4px;margin-bottom:1rem">
            <div><strong>Action:</strong> <?= e((string) $action['action']) ?>
                <?php if (!empty($action['expires_at'])): ?>
                · expires <?= e(date('M j, Y', strtotime((string) $action['expires_at']))) ?>
                <?php endif; ?>
            </div>
            <?php if (!empty($action['reason'])): ?>
            <div style="margin-top:.25rem;color:#6b7280;font-size:13px"><strong>Moderator's reason:</strong> <?= e((string) $action['reason']) ?></div>
            <?php endif; ?>
        </div>

        <form method="post" action="/my/appeals/<?= (int) $action['id'] ?>">
            <?= csrf_field() ?>
            <label style="display:block">Why should this be reconsidered?
                <textarea name="appeal_text" rows="6" required style="width:100%" placeholder="Provide context or disagreement. Keep it concise — moderators see many appeals."></textarea>
            </label>
            <div style="margin-top:.75rem;text-align:right">
                <a href="/my/appeals" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-primary">Submit appeal</button>
            </div>
        </form>
    </div>
</div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
