<?php $pageTitle = 'Moderation actions'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Moderation actions log</h2>
        <div>
            <a href="/admin/moderation/reports" class="btn btn-sm btn-secondary">Reports</a>
            <a href="/admin/moderation/appeals" class="btn btn-sm btn-secondary">Appeals</a>
        </div>
    </div>
    <?php if (empty($actions)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No actions yet.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>When</th><th>Moderator</th><th>Action</th><th>Target</th><th>Reason</th><th>Expires</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($actions as $a): ?>
        <tr style="<?= $a['reversed_at'] ? 'opacity:.6' : '' ?>">
            <td style="font-size:12px;white-space:nowrap"><?= e(date('M j H:i', strtotime((string) $a['created_at']))) ?></td>
            <td>@<?= e((string) ($a['actor_username'] ?? '?')) ?></td>
            <td><strong><?= e((string) $a['action']) ?></strong></td>
            <td>
                <?php if (!empty($a['target_username'])): ?>
                @<?= e((string) $a['target_username']) ?>
                <?php elseif (!empty($a['target_type'])): ?>
                <code><?= e((string) $a['target_type']) ?> #<?= (int) $a['target_id'] ?></code>
                <?php else: ?>—<?php endif; ?>
            </td>
            <td style="font-size:13px;color:#6b7280"><?= e(mb_substr((string) ($a['reason'] ?? ''), 0, 120)) ?></td>
            <td style="font-size:12px"><?= !empty($a['expires_at']) ? e(date('M j, Y', strtotime((string) $a['expires_at']))) : '—' ?></td>
            <td>
                <?php if (!empty($a['reversed_at'])): ?>
                <span class="badge badge-gray">reversed</span>
                <?php else: ?>
                <span class="badge badge-success">active</span>
                <?php endif; ?>
            </td>
            <td>
                <?php if (empty($a['reversed_at'])): ?>
                <form method="post" action="/admin/moderation/actions/<?= (int) $a['id'] ?>/reverse" style="display:inline" onsubmit="return confirm('Reverse this action?')">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-danger">Reverse</button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
