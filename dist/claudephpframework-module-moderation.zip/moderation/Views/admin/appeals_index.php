<?php $pageTitle = 'Appeals'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Appeals</h2>
        <div>
            <a href="/admin/moderation/reports" class="btn btn-sm btn-secondary">Reports</a>
            <a href="/admin/moderation/actions" class="btn btn-sm btn-secondary">Actions</a>
        </div>
    </div>
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem">
        <?php foreach (['pending','approved','denied'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= ($status ?? 'pending') === $s ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($s) ?></a>
        <?php endforeach; ?>
    </div>
    <?php if (empty($appeals)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No appeals in this state.</div>
    <?php else: ?>
    <?php foreach ($appeals as $a): ?>
    <div style="padding:1rem 1.25rem;border-bottom:1px solid #f3f4f6">
        <div style="display:flex;justify-content:space-between;align-items:baseline">
            <div>
                <strong>@<?= e((string) ($a['user_username'] ?? '?')) ?></strong>
                appealing <code><?= e((string) $a['action_kind']) ?></code>
                <?php if (!empty($a['target_type'])): ?>
                on <code><?= e((string) $a['target_type']) ?> #<?= (int) $a['target_id'] ?></code>
                <?php endif; ?>
            </div>
            <span style="color:#9ca3af;font-size:12px"><?= e(date('M j, Y H:i', strtotime((string) $a['created_at']))) ?></span>
        </div>
        <?php if (!empty($a['action_reason'])): ?>
        <div style="margin-top:.5rem;color:#6b7280;font-size:13px">
            <strong>Original reason:</strong> <?= e((string) $a['action_reason']) ?>
        </div>
        <?php endif; ?>
        <div style="margin-top:.5rem;padding:.75rem;background:#f9fafb;border-radius:4px"><?= nl2br(e((string) $a['appeal_text'])) ?></div>

        <?php if ($a['status'] === 'pending'): ?>
        <div style="display:flex;gap:.5rem;margin-top:.5rem">
            <form method="post" action="/admin/moderation/appeals/<?= (int) $a['id'] ?>/approve" style="flex:1;display:flex;gap:.5rem">
                <?= csrf_field() ?>
                <input name="notes" placeholder="Approval note (optional)" style="flex:1;padding:.4rem">
                <button type="submit" class="btn btn-sm btn-success">Approve + reverse action</button>
            </form>
            <form method="post" action="/admin/moderation/appeals/<?= (int) $a['id'] ?>/deny" style="flex:1;display:flex;gap:.5rem">
                <?= csrf_field() ?>
                <input name="notes" placeholder="Denial reason (shown to user)" style="flex:1;padding:.4rem">
                <button type="submit" class="btn btn-sm btn-danger">Deny</button>
            </form>
        </div>
        <?php else: ?>
        <div style="margin-top:.5rem;font-size:13px;color:#6b7280">
            <strong><?= e((string) $a['status']) ?></strong> at <?= e(date('M j, Y H:i', strtotime((string) $a['reviewed_at']))) ?>
            <?php if (!empty($a['reviewer_notes'])): ?>
            — <?= e((string) $a['reviewer_notes']) ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
