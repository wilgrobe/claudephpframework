<?php $pageTitle = 'Reports'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Reports</h2>
        <div>
            <a href="/admin/moderation/actions"  class="btn btn-sm btn-secondary">Actions log</a>
            <a href="/admin/moderation/appeals"  class="btn btn-sm btn-secondary">Appeals</a>
        </div>
    </div>
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem;flex-wrap:wrap">
        <?php foreach (['pending','resolved','dismissed'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= ($status ?? 'pending') === $s ? 'btn-primary' : 'btn-secondary' ?>">
            <?= ucfirst($s) ?>
            <span style="opacity:.7;margin-left:.25rem">(<?= (int) ($counts[$s] ?? 0) ?>)</span>
        </a>
        <?php endforeach; ?>
    </div>
    <?php if (empty($reports)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No reports in this queue.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>When</th><th>Reporter</th><th>Target</th><th>Reason</th><th>Details</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($reports as $r): ?>
        <tr>
            <td style="font-size:12px;white-space:nowrap"><?= e(date('M j H:i', strtotime((string) $r['created_at']))) ?></td>
            <td><?= e((string) ($r['reporter_username'] ?? ('#' . (int) $r['reporter_user_id']))) ?></td>
            <td style="font-family:monospace;font-size:12px"><?= e((string) $r['reportable_type']) ?> #<?= (int) $r['reportable_id'] ?></td>
            <td><?= e((string) $r['reason']) ?></td>
            <td style="color:#4b5563;font-size:13px"><?= e(mb_substr((string) ($r['details'] ?? ''), 0, 200)) ?></td>
            <td><a href="/admin/moderation/reports/<?= (int) $r['id'] ?>" class="btn btn-sm btn-secondary">Review</a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
