<?php $pageTitle = 'Report #' . (int) $report['id']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<a href="/admin/moderation/reports" style="color:#6b7280;text-decoration:none;font-size:13px">← All reports</a>

<div class="card" style="margin-top:.75rem">
    <div class="card-header">
        <h2 style="margin:0">Report #<?= (int) $report['id'] ?>
            <span class="badge"><?= e((string) $report['status']) ?></span>
        </h2>
    </div>
    <div class="card-body">
        <div style="display:grid;gap:1rem;grid-template-columns:1fr 1fr">
            <div>
                <div style="color:#6b7280;font-size:13px">Target</div>
                <div style="font-family:monospace"><?= e((string) $report['reportable_type']) ?> #<?= (int) $report['reportable_id'] ?></div>
                <?php if ($targetUser): ?>
                <div style="margin-top:.25rem">Owned by <strong>@<?= e((string) $targetUser['username']) ?></strong></div>
                <?php endif; ?>
            </div>
            <div>
                <div style="color:#6b7280;font-size:13px">Reason</div>
                <div><strong><?= e((string) $report['reason']) ?></strong></div>
                <?php if (!empty($report['details'])): ?>
                <div style="margin-top:.25rem;padding:.5rem;background:#f9fafb;border-radius:4px;font-size:13px"><?= nl2br(e((string) $report['details'])) ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if ($report['status'] === 'pending'): ?>
<div class="card" style="margin-top:1rem">
    <div class="card-header"><h3 style="margin:0">Resolve</h3></div>
    <form method="post" action="/admin/moderation/reports/<?= (int) $report['id'] ?>/resolve">
        <?= csrf_field() ?>
        <input type="hidden" name="target_user_id" value="<?= (int) ($targetUserId ?? 0) ?>">
        <div class="card-body">
            <label style="display:block">Action
                <select name="action" required>
                    <option value="none">Just resolve (no action)</option>
                    <option value="remove_content">Remove reported content</option>
                    <?php if ($targetUserId): ?>
                    <option value="warn">Warn user</option>
                    <option value="mute">Mute user</option>
                    <option value="suspend">Suspend user</option>
                    <option value="ban">Ban user</option>
                    <?php endif; ?>
                </select>
            </label>
            <?php if ($targetUserId): ?>
            <label style="display:block;margin-top:.5rem">Duration (days, for mute/suspend)
                <input type="number" name="duration_days" min="1" value="7">
            </label>
            <?php endif; ?>
            <label style="display:block;margin-top:.5rem">Reason (visible to user on appeal)
                <textarea name="reason" rows="3" style="width:100%"></textarea>
            </label>
        </div>
        <div class="card-footer" style="padding:.75rem 1.25rem;background:#f9fafb;display:flex;justify-content:space-between">
            <form method="post" action="/admin/moderation/reports/<?= (int) $report['id'] ?>/dismiss" style="display:inline">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-secondary">Dismiss</button>
            </form>
            <button type="submit" class="btn btn-primary">Resolve with action</button>
        </div>
    </form>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
