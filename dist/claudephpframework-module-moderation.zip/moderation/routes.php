<?php
// modules/moderation/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$R = 'Modules\Moderation\Controllers\ReportController';
$A = 'Modules\Moderation\Controllers\AppealController';
$M = 'Modules\Moderation\Controllers\ModerationAdminController';

// ── Public ────────────────────────────────────────────────────────────────
$router->post('/reports',                            "$R@submit",       [CsrfMiddleware::class, AuthMiddleware::class]);

$router->get ('/my/appeals',                         "$A@index",        [AuthMiddleware::class]);
$router->get ('/my/appeals/new/{actionId}',          "$A@newForm",      [AuthMiddleware::class]);
$router->post('/my/appeals/{actionId}',              "$A@submit",       [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Admin (moderation.act perm is checked in the controller) ─────────────
$admin     = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];

$router->get ('/admin/moderation/reports',                 "$M@reportsIndex",  $admin);
$router->get ('/admin/moderation/reports/{id}',            "$M@reportShow",    $admin);
$router->post('/admin/moderation/reports/{id}/dismiss',    "$M@reportDismiss", $adminCsrf);
$router->post('/admin/moderation/reports/{id}/resolve',    "$M@reportResolve", $adminCsrf);

$router->get ('/admin/moderation/actions',                 "$M@actionsIndex",  $admin);
$router->post('/admin/moderation/actions/{id}/reverse',    "$M@actionReverse", $adminCsrf);

$router->get ('/admin/moderation/appeals',                 "$M@appealsIndex",  $admin);
$router->post('/admin/moderation/appeals/{id}/approve',    "$M@appealApprove", $adminCsrf);
$router->post('/admin/moderation/appeals/{id}/deny',       "$M@appealDeny",    $adminCsrf);
