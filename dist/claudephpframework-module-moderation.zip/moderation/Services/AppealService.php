<?php
// modules/moderation/Services/AppealService.php
namespace Modules\Moderation\Services;

use Core\Database\Database;

/**
 * Appeals — users contest a specific moderation_action.
 *
 * One appeal per (user, action). Lifecycle:
 *   pending → approved → action reversed
 *           → denied
 *
 * The appeal text is the user's message; reviewer_notes is the mod's
 * reply. Approvals delegate to ModerationActionService::reverse which
 * handles the side effects (clear mute, restore content, etc.)
 */
class AppealService
{
    public const STATUSES = ['pending','approved','denied'];

    private Database               $db;
    private ModerationActionService $actions;

    public function __construct()
    {
        $this->db      = Database::getInstance();
        $this->actions = new ModerationActionService();
    }

    public function submit(int $userId, int $actionId, string $text): int
    {
        $text = trim($text);
        if ($text === '') throw new \InvalidArgumentException('Appeal text is required.');
        if (mb_strlen($text) > 4000) throw new \InvalidArgumentException('Appeal is too long.');

        $action = $this->actions->find($actionId);
        if (!$action) throw new \InvalidArgumentException('Action not found.');
        // Only the target of the action can appeal.
        if ((int) ($action['target_user_id'] ?? 0) !== $userId) {
            throw new \InvalidArgumentException('You can only appeal actions against you.');
        }

        try {
            return (int) $this->db->insert('appeals', [
                'user_id'     => $userId,
                'action_id'   => $actionId,
                'appeal_text' => $text,
                'status'      => 'pending',
            ]);
        } catch (\Throwable) {
            // Duplicate (user, action) — return the existing appeal id.
            $row = $this->db->fetchOne(
                "SELECT id FROM appeals WHERE user_id = ? AND action_id = ?",
                [$userId, $actionId]
            );
            return $row ? (int) $row['id'] : 0;
        }
    }

    public function find(int $appealId): ?array
    {
        return $this->db->fetchOne("SELECT * FROM appeals WHERE id = ?", [$appealId]);
    }

    /** @return array<int, array<string, mixed>> */
    public function listForUser(int $userId): array
    {
        return $this->db->fetchAll(
            "SELECT a.*, m.action AS action_kind, m.reason AS action_reason, m.created_at AS action_at
               FROM appeals a
               JOIN moderation_actions m ON m.id = a.action_id
              WHERE a.user_id = ?
           ORDER BY a.created_at DESC",
            [$userId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function listQueue(string $status = 'pending'): array
    {
        if (!in_array($status, self::STATUSES, true)) $status = 'pending';
        return $this->db->fetchAll(
            "SELECT a.*, u.username AS user_username, m.action AS action_kind,
                    m.target_type, m.target_id, m.reason AS action_reason
               FROM appeals a
          LEFT JOIN users u ON u.id = a.user_id
          LEFT JOIN moderation_actions m ON m.id = a.action_id
              WHERE a.status = ?
           ORDER BY a.created_at DESC
              LIMIT 200",
            [$status]
        );
    }

    public function approve(int $appealId, int $reviewerId, ?string $notes = null): bool
    {
        $a = $this->find($appealId);
        if (!$a || $a['status'] !== 'pending') return false;

        // Reverse the linked action first — if that fails, don't change
        // appeal state.
        $this->actions->reverse((int) $a['action_id'], $reviewerId, $notes);

        $this->db->update('appeals',
            [
                'status'         => 'approved',
                'reviewed_by'    => $reviewerId,
                'reviewed_at'    => date('Y-m-d H:i:s'),
                'reviewer_notes' => $notes,
            ],
            'id = ?', [$appealId]
        );
        return true;
    }

    public function deny(int $appealId, int $reviewerId, ?string $notes = null): bool
    {
        $a = $this->find($appealId);
        if (!$a || $a['status'] !== 'pending') return false;

        $this->db->update('appeals',
            [
                'status'         => 'denied',
                'reviewed_by'    => $reviewerId,
                'reviewed_at'    => date('Y-m-d H:i:s'),
                'reviewer_notes' => $notes,
            ],
            'id = ?', [$appealId]
        );
        return true;
    }
}
