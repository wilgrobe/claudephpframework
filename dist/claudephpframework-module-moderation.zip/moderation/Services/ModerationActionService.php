<?php
// modules/moderation/Services/ModerationActionService.php
namespace Modules\Moderation\Services;

use Core\Database\Database;

/**
 * Moderation actions — durable log of what moderators did.
 *
 * Six action kinds, two target shapes:
 *   User-level:     warn, mute, suspend, ban        (needs target_user_id)
 *   Content-level:  remove_content, restore_content (needs target_type + target_id)
 *
 * Side effects:
 *   warn            — increments user_moderation_state.warnings_count
 *   mute $days      — user_moderation_state.muted_until = NOW + days
 *   suspend $days   — user_moderation_state.suspended_until = NOW + days
 *   ban             — user_moderation_state.banned_at = NOW; permanent
 *   remove_content  — delegates to a registered remover per target_type
 *   restore_content — delegates to a registered restorer per target_type
 *
 * The removal/restoration of content is pluggable so this module
 * doesn't learn every entity schema: callers register via
 * `registerContentHandler($type, removeFn, restoreFn)` from their own
 * module at boot. Built-in handlers cover comments (set status=deleted)
 * and social posts (soft delete via deleted_at) when those modules
 * are installed.
 */
class ModerationActionService
{
    public const ACTIONS = ['warn','mute','suspend','ban','remove_content','restore_content'];

    /** @var array<string, array{remove: callable(int): bool, restore: callable(int): bool}> */
    private static array $contentHandlers = [];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Register content remove/restore handlers for a target_type. Each
     * handler takes an int id and returns true on success.
     */
    public static function registerContentHandler(string $type, callable $remove, callable $restore): void
    {
        self::$contentHandlers[$type] = ['remove' => $remove, 'restore' => $restore];
    }

    public static function clearContentHandlers(): void
    {
        self::$contentHandlers = [];
    }

    // ── Actions ──────────────────────────────────────────────────────────

    public function warn(int $actorId, int $targetUserId, ?string $reason = null): int
    {
        $id = $this->log($actorId, 'warn', targetUserId: $targetUserId, reason: $reason);
        $this->touchUserState($targetUserId, ['warnings_count' => $this->warningsCount($targetUserId) + 1]);
        return $id;
    }

    public function mute(int $actorId, int $targetUserId, int $days, ?string $reason = null): int
    {
        $expires = date('Y-m-d H:i:s', time() + ($days * 86400));
        $id = $this->log($actorId, 'mute', targetUserId: $targetUserId, reason: $reason, durationDays: $days, expiresAt: $expires);
        $this->touchUserState($targetUserId, ['muted_until' => $expires]);
        return $id;
    }

    public function suspend(int $actorId, int $targetUserId, int $days, ?string $reason = null): int
    {
        $expires = date('Y-m-d H:i:s', time() + ($days * 86400));
        $id = $this->log($actorId, 'suspend', targetUserId: $targetUserId, reason: $reason, durationDays: $days, expiresAt: $expires);
        $this->touchUserState($targetUserId, ['suspended_until' => $expires]);
        return $id;
    }

    public function ban(int $actorId, int $targetUserId, ?string $reason = null): int
    {
        $id = $this->log($actorId, 'ban', targetUserId: $targetUserId, reason: $reason);
        $this->touchUserState($targetUserId, [
            'banned_at'  => date('Y-m-d H:i:s'),
            'ban_reason' => $reason !== null ? mb_substr($reason, 0, 500) : null,
        ]);
        return $id;
    }

    public function removeContent(int $actorId, string $type, int $targetId, ?string $reason = null): int
    {
        $h = self::$contentHandlers[$type] ?? null;
        if ($h) ($h['remove'])($targetId);
        return $this->log($actorId, 'remove_content', targetType: $type, targetId: $targetId, reason: $reason);
    }

    public function restoreContent(int $actorId, string $type, int $targetId, ?string $reason = null): int
    {
        $h = self::$contentHandlers[$type] ?? null;
        if ($h) ($h['restore'])($targetId);
        return $this->log($actorId, 'restore_content', targetType: $type, targetId: $targetId, reason: $reason);
    }

    /**
     * Reverse a prior action — used by appeal approvals. Clears the
     * user-state field that the action set, or calls the restore
     * handler for content actions. Marks the original action as
     * reversed.
     */
    public function reverse(int $actionId, int $reverserId, ?string $reason = null): bool
    {
        $a = $this->find($actionId);
        if (!$a) return false;
        if ($a['reversed_at'] !== null) return true; // already reversed — idempotent

        switch ($a['action']) {
            case 'warn':
                // Don't decrement warnings below 0
                if ($a['target_user_id']) {
                    $cur = $this->warningsCount((int) $a['target_user_id']);
                    $this->touchUserState((int) $a['target_user_id'], ['warnings_count' => max(0, $cur - 1)]);
                }
                break;
            case 'mute':
                if ($a['target_user_id']) $this->touchUserState((int) $a['target_user_id'], ['muted_until' => null]);
                break;
            case 'suspend':
                if ($a['target_user_id']) $this->touchUserState((int) $a['target_user_id'], ['suspended_until' => null]);
                break;
            case 'ban':
                if ($a['target_user_id']) $this->touchUserState((int) $a['target_user_id'], [
                    'banned_at'  => null,
                    'ban_reason' => null,
                ]);
                break;
            case 'remove_content':
                if ($a['target_type'] && $a['target_id']) {
                    $h = self::$contentHandlers[$a['target_type']] ?? null;
                    if ($h) ($h['restore'])((int) $a['target_id']);
                }
                break;
            case 'restore_content':
                // Reversing a restore means re-removing; unusual but consistent.
                if ($a['target_type'] && $a['target_id']) {
                    $h = self::$contentHandlers[$a['target_type']] ?? null;
                    if ($h) ($h['remove'])((int) $a['target_id']);
                }
                break;
        }

        $this->db->update('moderation_actions', [
            'reversed_at' => date('Y-m-d H:i:s'),
            'reversed_by' => $reverserId,
        ], 'id = ?', [$actionId]);
        return true;
    }

    // ── User-state helpers ───────────────────────────────────────────────

    public function stateFor(int $userId): array
    {
        $row = $this->db->fetchOne("SELECT * FROM user_moderation_state WHERE user_id = ?", [$userId]);
        return $row ?: [
            'user_id' => $userId, 'warnings_count' => 0,
            'muted_until' => null, 'suspended_until' => null,
            'banned_at' => null, 'ban_reason' => null,
        ];
    }

    public function isMuted(int $userId): bool
    {
        $s = $this->stateFor($userId);
        return $s['muted_until'] !== null && strtotime((string) $s['muted_until']) > time();
    }

    public function isSuspended(int $userId): bool
    {
        $s = $this->stateFor($userId);
        return $s['suspended_until'] !== null && strtotime((string) $s['suspended_until']) > time();
    }

    public function isBanned(int $userId): bool
    {
        return $this->stateFor($userId)['banned_at'] !== null;
    }

    /** Called by the hourly expiry job. Returns count of rows cleared. */
    public function expireDue(): int
    {
        $now = date('Y-m-d H:i:s');
        $n  = $this->db->update('user_moderation_state',
            ['muted_until' => null], 'muted_until IS NOT NULL AND muted_until <= ?', [$now]);
        $n2 = $this->db->update('user_moderation_state',
            ['suspended_until' => null], 'suspended_until IS NOT NULL AND suspended_until <= ?', [$now]);
        return (int) ($n ?? 0) + (int) ($n2 ?? 0);
    }

    // ── Reads ────────────────────────────────────────────────────────────

    public function find(int $actionId): ?array
    {
        return $this->db->fetchOne("SELECT * FROM moderation_actions WHERE id = ?", [$actionId]);
    }

    /** @return array<int, array<string, mixed>> */
    public function listForUser(int $userId, int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT a.*, u.username AS actor_username
               FROM moderation_actions a
          LEFT JOIN users u ON u.id = a.actor_user_id
              WHERE a.target_user_id = ?
           ORDER BY a.created_at DESC
              LIMIT ?",
            [$userId, $limit]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function listRecent(int $limit = 100): array
    {
        return $this->db->fetchAll(
            "SELECT a.*, u.username AS actor_username, tu.username AS target_username
               FROM moderation_actions a
          LEFT JOIN users u  ON u.id  = a.actor_user_id
          LEFT JOIN users tu ON tu.id = a.target_user_id
           ORDER BY a.created_at DESC
              LIMIT ?",
            [$limit]
        );
    }

    // ── Internals ────────────────────────────────────────────────────────

    private function log(
        int $actorId, string $action,
        ?int $targetUserId = null, ?string $targetType = null, ?int $targetId = null,
        ?string $reason = null, ?int $durationDays = null, ?string $expiresAt = null
    ): int {
        if (!in_array($action, self::ACTIONS, true)) {
            throw new \InvalidArgumentException("Unknown action: $action");
        }
        return (int) $this->db->insert('moderation_actions', [
            'actor_user_id'  => $actorId,
            'action'         => $action,
            'target_user_id' => $targetUserId,
            'target_type'    => $targetType,
            'target_id'      => $targetId,
            'reason'         => $reason !== null ? mb_substr($reason, 0, 500) : null,
            'duration_days'  => $durationDays,
            'expires_at'     => $expiresAt,
        ]);
    }

    private function warningsCount(int $userId): int
    {
        return (int) $this->stateFor($userId)['warnings_count'];
    }

    private function touchUserState(int $userId, array $fields): void
    {
        $existing = $this->db->fetchOne("SELECT user_id FROM user_moderation_state WHERE user_id = ?", [$userId]);
        if ($existing) {
            $this->db->update('user_moderation_state', $fields, 'user_id = ?', [$userId]);
        } else {
            $this->db->insert('user_moderation_state', array_merge(['user_id' => $userId], $fields));
        }
    }
}
