<?php
// modules/moderation/Services/ReportService.php
namespace Modules\Moderation\Services;

use Core\Database\Database;

/**
 * Report submission + queue reads + resolution.
 *
 * A "report" is a user flagging a piece of content or another user as
 * abusive. Reports land in `pending`; moderators resolve them
 * (optionally recording a moderation_action) or dismiss them.
 *
 * The report-open uniqueness constraint
 * UNIQUE (reporter_user_id, reportable_type, reportable_id, status)
 * means one user can only have one *open* report on a given target —
 * after resolve/dismiss, they can report again if the problem recurs.
 */
class ReportService
{
    public const REASONS  = ['spam','harassment','inappropriate','off_topic','other'];
    public const STATUSES = ['pending','resolved','dismissed'];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function submit(int $reporterUserId, string $type, int $targetId, string $reason, ?string $details = null): int
    {
        if (!in_array($reason, self::REASONS, true)) $reason = 'other';
        try {
            return (int) $this->db->insert('reports', [
                'reporter_user_id' => $reporterUserId,
                'reportable_type'  => $type,
                'reportable_id'    => $targetId,
                'reason'           => $reason,
                'details'          => $details !== null ? mb_substr(trim($details), 0, 4000) : null,
                'status'           => 'pending',
            ]);
        } catch (\Throwable) {
            // Most likely a duplicate-open conflict. Return the existing row id
            // so the UI can still route to "we already have your report".
            $row = $this->db->fetchOne(
                "SELECT id FROM reports
                  WHERE reporter_user_id = ? AND reportable_type = ?
                    AND reportable_id = ? AND status = 'pending'
                  LIMIT 1",
                [$reporterUserId, $type, $targetId]
            );
            return $row ? (int) $row['id'] : 0;
        }
    }

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM reports WHERE id = ?", [$id]);
    }

    /** @return array<int, array<string, mixed>> */
    public function listQueue(string $status = 'pending', int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        if (!in_array($status, self::STATUSES, true)) $status = 'pending';
        return $this->db->fetchAll(
            "SELECT r.*, u.username AS reporter_username
               FROM reports r
          LEFT JOIN users u ON u.id = r.reporter_user_id
              WHERE r.status = ?
           ORDER BY r.created_at DESC
              LIMIT ? OFFSET ?",
            [$status, $perPage, $offset]
        );
    }

    public function counts(): array
    {
        $rows = $this->db->fetchAll(
            "SELECT status, COUNT(*) AS cnt FROM reports GROUP BY status"
        );
        $out = ['pending' => 0, 'resolved' => 0, 'dismissed' => 0];
        foreach ($rows as $r) $out[$r['status']] = (int) $r['cnt'];
        return $out;
    }

    public function resolve(int $reportId, int $moderatorId, ?int $actionId): void
    {
        $this->db->update('reports',
            [
                'status'      => 'resolved',
                'resolved_by' => $moderatorId,
                'resolved_at' => date('Y-m-d H:i:s'),
                'action_id'   => $actionId,
            ],
            'id = ?', [$reportId]
        );
    }

    public function dismiss(int $reportId, int $moderatorId): void
    {
        $this->db->update('reports',
            [
                'status'      => 'dismissed',
                'resolved_by' => $moderatorId,
                'resolved_at' => date('Y-m-d H:i:s'),
            ],
            'id = ?', [$reportId]
        );
    }
}
