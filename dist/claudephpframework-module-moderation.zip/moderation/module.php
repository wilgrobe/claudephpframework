<?php
// modules/moderation/module.php
use Core\Container\Container;
use Core\Database\Database;
use Core\Module\ModuleProvider;
use Modules\Moderation\Services\ModerationActionService;

/**
 * Moderation module — user reports + moderator actions + user appeals.
 *
 * Three pillars:
 *   reports  — users flag content/users for review
 *   actions  — moderators warn/mute/suspend/ban/remove/restore
 *   appeals  — users request review of actions against them
 *
 * Content-removal is pluggable: each consumable target_type has a
 * (remove, restore) handler pair. This module registers built-in
 * handlers for the framework's shipped commentable types when those
 * modules are installed — comments, social_post, review — so the
 * "remove content" action actually removes the content.
 *
 * Global helpers registered:
 *   report_button($type, $id)  — tiny report form next to any item
 *   mod_state_for($userId), mod_muted($userId), mod_suspended($userId), mod_banned($userId)
 *
 * Scheduled: ExpireModerationActionsJob runs hourly (via scheduled_tasks
 * seed in the companion migration) and clears mute/suspend fields when
 * their windows pass. Bans don't expire — reversed via appeal only.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'moderation'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }

    public function register(Container $container): void
    {
        require_once __DIR__ . '/Helpers/helpers.php';

        // Content handlers: each sets status/deleted_at on the target
        // table so a "remove_content" action actually hides the content
        // and "restore_content" brings it back.
        if (class_exists(\Modules\Comments\Services\CommentService::class)) {
            ModerationActionService::registerContentHandler(
                'comment',
                static function (int $id): bool {
                    Database::getInstance()->update('comments', ['status' => 'deleted'], 'id = ?', [$id]);
                    return true;
                },
                static function (int $id): bool {
                    Database::getInstance()->update('comments', ['status' => 'published'], 'id = ?', [$id]);
                    return true;
                }
            );
        }

        if (class_exists(\Modules\Social\Services\PostService::class)) {
            ModerationActionService::registerContentHandler(
                'social_post',
                static function (int $id): bool {
                    Database::getInstance()->update(
                        'social_posts',
                        ['deleted_at' => date('Y-m-d H:i:s')],
                        'id = ?', [$id]
                    );
                    return true;
                },
                static function (int $id): bool {
                    Database::getInstance()->update(
                        'social_posts',
                        ['deleted_at' => null],
                        'id = ?', [$id]
                    );
                    return true;
                }
            );
        }

        if (class_exists(\Modules\Reviews\Services\ReviewService::class)) {
            ModerationActionService::registerContentHandler(
                'review',
                static function (int $id): bool {
                    Database::getInstance()->update('reviews', ['status' => 'deleted'], 'id = ?', [$id]);
                    return true;
                },
                static function (int $id): bool {
                    Database::getInstance()->update('reviews', ['status' => 'published'], 'id = ?', [$id]);
                    return true;
                }
            );
        }
    }
};
