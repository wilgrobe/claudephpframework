<?php
// modules/moderation/Helpers/helpers.php
/**
 * View helpers for the moderation module.
 *
 *   <?= report_button('social_post', (int) $post['id']) ?>
 *   <?= mod_banned($user['id']) ? 'This account is banned' : '' ?>
 */

if (!function_exists('report_button')) {
    /**
     * Render a "Report" link that toggles a tiny details block with
     * the report form. No JS required — the <details> element handles
     * the disclosure.
     *
     * Returns an empty string for guests so it doesn't prompt them to
     * report things before they've logged in.
     */
    function report_button(string $type, int $id, string $returnUrl = ''): string
    {
        $auth = \Core\Auth\Auth::getInstance();
        if ($auth->guest()) return '';

        $returnUrl = $returnUrl ?: ($_SERVER['REQUEST_URI'] ?? '/');
        ob_start(); ?>
        <details style="display:inline-block;vertical-align:middle">
            <summary style="cursor:pointer;color:#9ca3af;font-size:12px;list-style:none">Report</summary>
            <form method="post" action="/reports" style="margin-top:.5rem;padding:.5rem;border:1px solid #e5e7eb;border-radius:4px;background:#fff;min-width:240px">
                <?= csrf_field() ?>
                <input type="hidden" name="reportable_type" value="<?= e($type) ?>">
                <input type="hidden" name="reportable_id"   value="<?= (int) $id ?>">
                <input type="hidden" name="return_url"      value="<?= e($returnUrl) ?>">
                <label style="display:block;font-size:12px;color:#6b7280">Reason
                    <select name="reason" style="width:100%">
                        <option value="spam">Spam</option>
                        <option value="harassment">Harassment</option>
                        <option value="inappropriate">Inappropriate</option>
                        <option value="off_topic">Off topic</option>
                        <option value="other">Other</option>
                    </select>
                </label>
                <label style="display:block;margin-top:.25rem;font-size:12px;color:#6b7280">Details (optional)
                    <textarea name="details" rows="2" style="width:100%"></textarea>
                </label>
                <button type="submit" class="btn btn-sm btn-danger" style="margin-top:.25rem">Submit report</button>
            </form>
        </details>
        <?php
        return (string) ob_get_clean();
    }
}

if (!function_exists('mod_state_for')) {
    function mod_state_for(int $userId): array
    {
        return (new \Modules\Moderation\Services\ModerationActionService())->stateFor($userId);
    }
}

if (!function_exists('mod_muted')) {
    function mod_muted(int $userId): bool {
        return (new \Modules\Moderation\Services\ModerationActionService())->isMuted($userId);
    }
}

if (!function_exists('mod_suspended')) {
    function mod_suspended(int $userId): bool {
        return (new \Modules\Moderation\Services\ModerationActionService())->isSuspended($userId);
    }
}

if (!function_exists('mod_banned')) {
    function mod_banned(int $userId): bool {
        return (new \Modules\Moderation\Services\ModerationActionService())->isBanned($userId);
    }
}
