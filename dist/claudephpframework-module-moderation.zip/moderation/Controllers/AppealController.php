<?php
// modules/moderation/Controllers/AppealController.php
namespace Modules\Moderation\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Moderation\Services\AppealService;
use Modules\Moderation\Services\ModerationActionService;

/**
 * User-facing appeal surface.
 *   GET  /my/appeals                  — list of my appeals + past actions
 *   GET  /my/appeals/new/{actionId}   — submission form for one action
 *   POST /my/appeals/{actionId}       — submit an appeal
 */
class AppealController
{
    private Auth                    $auth;
    private AppealService           $appeals;
    private ModerationActionService $actions;

    public function __construct()
    {
        $this->auth    = Auth::getInstance();
        $this->appeals = new AppealService();
        $this->actions = new ModerationActionService();
    }

    public function index(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $uid = (int) $this->auth->id();
        return Response::view('moderation::public.my_appeals', [
            'appeals' => $this->appeals->listForUser($uid),
            'actions' => $this->actions->listForUser($uid),
            'state'   => $this->actions->stateFor($uid),
        ]);
    }

    public function newForm(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $actionId = (int) $request->param(0);
        $action   = $this->actions->find($actionId);
        if (!$action || (int) ($action['target_user_id'] ?? 0) !== (int) $this->auth->id()) {
            return new Response('Action not found', 404);
        }
        return Response::view('moderation::public.appeal_form', ['action' => $action]);
    }

    public function submit(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $actionId = (int) $request->param(0);
        try {
            $this->appeals->submit((int) $this->auth->id(), $actionId, (string) $request->post('appeal_text', ''));
        } catch (\InvalidArgumentException $e) {
            return Response::redirect('/my/appeals')->withFlash('error', $e->getMessage());
        }
        return Response::redirect('/my/appeals')->withFlash('success', 'Appeal submitted — a moderator will review.');
    }
}
