<?php
// modules/moderation/Controllers/ModerationAdminController.php
namespace Modules\Moderation\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Modules\Moderation\Services\AppealService;
use Modules\Moderation\Services\ModerationActionService;
use Modules\Moderation\Services\ReportService;

/**
 * Admin / moderator surface.
 *   GET  /admin/moderation/reports                  — report queue
 *   GET  /admin/moderation/reports/{id}             — detail view with action form
 *   POST /admin/moderation/reports/{id}/dismiss     — dismiss without action
 *   POST /admin/moderation/reports/{id}/resolve     — resolve (optionally with action)
 *
 *   GET  /admin/moderation/actions                  — recent actions log
 *   POST /admin/moderation/actions/{id}/reverse     — reverse an action
 *
 *   GET  /admin/moderation/appeals                  — appeal queue
 *   POST /admin/moderation/appeals/{id}/approve     — approve (reverses linked action)
 *   POST /admin/moderation/appeals/{id}/deny        — deny
 *
 * Authority: scoped to the moderation.act permission (checked in
 * every handler — belt + suspenders on top of RequireAdmin).
 */
class ModerationAdminController
{
    private Auth                    $auth;
    private Database                $db;
    private ReportService           $reports;
    private ModerationActionService $actions;
    private AppealService           $appeals;

    public function __construct()
    {
        $this->auth    = Auth::getInstance();
        $this->db      = Database::getInstance();
        $this->reports = new ReportService();
        $this->actions = new ModerationActionService();
        $this->appeals = new AppealService();
    }

    private function requirePerm(): ?Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->auth->can('moderation.act')) {
            return new Response('Forbidden', 403);
        }
        return null;
    }

    // ── Reports ──────────────────────────────────────────────────────────

    public function reportsIndex(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $status = (string) $request->query('status', 'pending');
        return Response::view('moderation::admin.reports_index', [
            'reports' => $this->reports->listQueue($status),
            'counts'  => $this->reports->counts(),
            'status'  => $status,
        ]);
    }

    public function reportShow(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $rpt = $this->reports->find($id);
        if (!$rpt) return new Response('Not found', 404);

        // Try to resolve target-user-id for user-action suggestions.
        // For common types we look it up here so the admin can click
        // "warn this user" without leaving the page.
        $targetUserId = $this->lookupTargetUserId((string) $rpt['reportable_type'], (int) $rpt['reportable_id']);
        $targetUser   = $targetUserId ? $this->db->fetchOne("SELECT id, username, email FROM users WHERE id = ?", [$targetUserId]) : null;

        return Response::view('moderation::admin.report_show', [
            'report'       => $rpt,
            'targetUser'   => $targetUser,
            'targetUserId' => $targetUserId,
        ]);
    }

    public function reportDismiss(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $this->reports->dismiss($id, (int) $this->auth->id());
        return Response::redirect('/admin/moderation/reports')->withFlash('success', 'Report dismissed.');
    }

    /**
     * Resolve a report with optional action. The form posts `action`
     * plus the parameters for that action. Content-level actions read
     * reportable_type + reportable_id directly from the report row.
     */
    public function reportResolve(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id  = (int) $request->param(0);
        $rpt = $this->reports->find($id);
        if (!$rpt) return new Response('Not found', 404);

        $action       = (string) $request->post('action', '');
        $reason       = (string) $request->post('reason');
        $actorId      = (int) $this->auth->id();
        $targetUserId = (int) $request->post('target_user_id', 0);
        $days         = (int) $request->post('duration_days', 0);
        $actionId     = null;

        try {
            switch ($action) {
                case 'warn':
                    if ($targetUserId) $actionId = $this->actions->warn($actorId, $targetUserId, $reason);
                    break;
                case 'mute':
                    if ($targetUserId && $days > 0) $actionId = $this->actions->mute($actorId, $targetUserId, $days, $reason);
                    break;
                case 'suspend':
                    if ($targetUserId && $days > 0) $actionId = $this->actions->suspend($actorId, $targetUserId, $days, $reason);
                    break;
                case 'ban':
                    if ($targetUserId) $actionId = $this->actions->ban($actorId, $targetUserId, $reason);
                    break;
                case 'remove_content':
                    $actionId = $this->actions->removeContent(
                        $actorId, (string) $rpt['reportable_type'], (int) $rpt['reportable_id'], $reason
                    );
                    break;
                case 'none':
                default:
                    // No action — just resolve the report.
                    break;
            }
        } catch (\Throwable $e) {
            return Response::redirect("/admin/moderation/reports/$id")->withFlash('error', $e->getMessage());
        }

        $this->reports->resolve($id, $actorId, $actionId);
        return Response::redirect('/admin/moderation/reports')->withFlash('success', 'Report resolved.');
    }

    // ── Actions log ──────────────────────────────────────────────────────

    public function actionsIndex(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        return Response::view('moderation::admin.actions_index', [
            'actions' => $this->actions->listRecent(100),
        ]);
    }

    public function actionReverse(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $this->actions->reverse($id, (int) $this->auth->id(), (string) $request->post('reason'));
        return Response::redirect('/admin/moderation/actions')->withFlash('success', 'Action reversed.');
    }

    // ── Appeals ──────────────────────────────────────────────────────────

    public function appealsIndex(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $status = (string) $request->query('status', 'pending');
        return Response::view('moderation::admin.appeals_index', [
            'appeals' => $this->appeals->listQueue($status),
            'status'  => $status,
        ]);
    }

    public function appealApprove(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $this->appeals->approve($id, (int) $this->auth->id(), (string) $request->post('notes'));
        return Response::redirect('/admin/moderation/appeals')->withFlash('success', 'Appeal approved.');
    }

    public function appealDeny(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $this->appeals->deny($id, (int) $this->auth->id(), (string) $request->post('notes'));
        return Response::redirect('/admin/moderation/appeals')->withFlash('success', 'Appeal denied.');
    }

    /**
     * Resolve target_user_id from a reportable target. Built-in mappings
     * cover the common types the framework ships; apps add more via
     * ModerationActionService::registerContentHandler combined with
     * their own target→user lookup in the handler, or by extending
     * this controller.
     */
    private function lookupTargetUserId(string $type, int $id): ?int
    {
        switch ($type) {
            case 'social_post':
                $row = $this->db->fetchOne("SELECT user_id FROM social_posts WHERE id = ?", [$id]);
                return $row ? (int) $row['user_id'] : null;
            case 'comment':
                $row = $this->db->fetchOne("SELECT user_id FROM comments WHERE id = ?", [$id]);
                return $row ? (int) $row['user_id'] : null;
            case 'review':
                $row = $this->db->fetchOne("SELECT user_id FROM reviews WHERE id = ?", [$id]);
                return $row ? (int) $row['user_id'] : null;
            case 'user':
                return $id;
        }
        return null;
    }
}
