<?php
// modules/moderation/Controllers/ReportController.php
namespace Modules\Moderation\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Moderation\Services\ReportService;

/**
 * Public report submission.
 *   POST /reports                    — body: reportable_type, reportable_id, reason, details, return_url
 *
 * The report form itself is typically rendered by the `report_button()`
 * view helper; this controller handles its POST.
 */
class ReportController
{
    private Auth          $auth;
    private ReportService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new ReportService();
    }

    public function submit(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $type     = (string) $request->post('reportable_type');
        $targetId = (int) $request->post('reportable_id');
        $reason   = (string) $request->post('reason', 'other');
        $details  = (string) $request->post('details');
        $return   = (string) $request->post('return_url', '/');

        if ($type === '' || $targetId <= 0) {
            return Response::redirect($return)->withFlash('error', 'Missing report target.');
        }
        $this->svc->submit((int) $this->auth->id(), $type, $targetId, $reason, $details ?: null);
        return Response::redirect($return)->withFlash('success', 'Thanks — a moderator will review this.');
    }
}
