<?php
// modules/moderation/migrations/2026_04_23_140010_seed_moderation_permission_and_job.php
use Core\Database\Migration;

/**
 * Seed the `moderation.act` permission and schedule the expiry job.
 * Users with this permission see the /admin/moderation surface,
 * resolve reports, take actions, and review appeals.
 *
 * Expiry job runs hourly — cheap query (indexed on expires_at) that
 * flips muted_until / suspended_until to NULL when they pass.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Act on moderation',
            'moderation.act',
            'moderation',
            'Review reports, issue warn/mute/suspend/ban actions, resolve appeals.',
        ]);

        // Hourly scheduled_tasks row. Column shape matches the base
        // scheduled_tasks migration: name (unique), class, payload JSON,
        // schedule_expression, queue, enabled, next_run_at.
        $this->db->query("
            INSERT IGNORE INTO scheduled_tasks
                (name, class, payload, schedule_expression, queue, enabled, next_run_at)
            VALUES
                (?, ?, ?, ?, ?, 1, NOW())
        ", [
            'moderation-expire',
            \Modules\Moderation\Jobs\ExpireModerationActionsJob::class,
            json_encode([]),
            '0 * * * *',
            'default',
        ]);
    }

    public function down(): void
    {
        $this->db->query("DELETE FROM scheduled_tasks WHERE name = ?", ['moderation-expire']);
    }
};
