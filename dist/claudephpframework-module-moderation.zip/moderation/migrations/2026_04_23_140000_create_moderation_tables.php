<?php
// modules/moderation/migrations/2026_04_23_140000_create_moderation_tables.php
use Core\Database\Migration;

/**
 * Schema for the moderation module.
 *
 *   reports               — user-submitted reports of content or other
 *                           users. Polymorphic (reportable_type +
 *                           reportable_id). Status lifecycle:
 *                             pending → resolved | dismissed
 *                           `action_id` links to the moderation_action
 *                           taken on resolve (null when dismissed or
 *                           still pending). One report per
 *                           (reporter, target, open) pair — a user
 *                           shouldn't double-report the same thing
 *                           while their first report is still open.
 *
 *   moderation_actions    — durable log of moderator actions. Supports
 *                           both user-level (target_user_id, for warn /
 *                           mute / suspend / ban) and content-level
 *                           (target_type + target_id, for remove /
 *                           restore) decisions. `expires_at` nullable —
 *                           the expiry job nulls mute/suspend fields on
 *                           the user row once the timestamp passes.
 *
 *   user_moderation_state — new row on the users table would be ideal,
 *                           but the framework's existing users schema
 *                           isn't managed from this module. A 1:1
 *                           sidecar table covers the same ground
 *                           without a cross-module migration:
 *                             warnings_count, muted_until, suspended_until,
 *                             banned_at, ban_reason.
 *                           Rows are lazy — a user with no moderation
 *                           history has no row. Lookups use LEFT JOIN.
 *
 *   appeals               — user-initiated requests to review a
 *                           specific moderation_action. Lifecycle:
 *                             pending → approved | denied
 *                           On approval, the linked action is reversed
 *                           (content restored; user flags cleared) by
 *                           AppealService::approve. `appeal_text` is
 *                           the user's message; `reviewer_notes` is
 *                           the moderator's reply.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE reports (
                id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                reporter_user_id  INT UNSIGNED NOT NULL,
                reportable_type   VARCHAR(64)  NOT NULL,
                reportable_id     BIGINT UNSIGNED NOT NULL,
                reason            ENUM('spam','harassment','inappropriate','off_topic','other')
                                  NOT NULL DEFAULT 'other',
                details           TEXT NULL,
                status            ENUM('pending','resolved','dismissed')
                                  NOT NULL DEFAULT 'pending',
                resolved_by       INT UNSIGNED NULL,
                resolved_at       DATETIME NULL,
                action_id         INT UNSIGNED NULL,
                created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_open_report (reporter_user_id, reportable_type, reportable_id, status),
                KEY idx_target (reportable_type, reportable_id, status),
                KEY idx_status_created (status, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE moderation_actions (
                id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                actor_user_id   INT UNSIGNED NOT NULL,
                action          ENUM('warn','mute','suspend','ban','remove_content','restore_content')
                                NOT NULL,
                target_user_id  INT UNSIGNED NULL,
                target_type     VARCHAR(64)  NULL,
                target_id       BIGINT UNSIGNED NULL,
                reason          VARCHAR(500) NULL,
                duration_days   INT UNSIGNED NULL,
                expires_at      DATETIME NULL,
                reversed_at     DATETIME NULL,
                reversed_by     INT UNSIGNED NULL,
                created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                KEY idx_target_user (target_user_id, action, created_at),
                KEY idx_target_content (target_type, target_id, action),
                KEY idx_expires (expires_at, reversed_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE user_moderation_state (
                user_id          INT UNSIGNED NOT NULL PRIMARY KEY,
                warnings_count   INT UNSIGNED NOT NULL DEFAULT 0,
                muted_until      DATETIME NULL,
                suspended_until  DATETIME NULL,
                banned_at        DATETIME NULL,
                ban_reason       VARCHAR(500) NULL,
                updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                KEY idx_muted_until     (muted_until),
                KEY idx_suspended_until (suspended_until),
                KEY idx_banned          (banned_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE appeals (
                id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id         INT UNSIGNED NOT NULL,
                action_id       INT UNSIGNED NOT NULL,
                appeal_text     TEXT NOT NULL,
                status          ENUM('pending','approved','denied') NOT NULL DEFAULT 'pending',
                reviewed_by     INT UNSIGNED NULL,
                reviewed_at     DATETIME NULL,
                reviewer_notes  TEXT NULL,
                created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_user_action (user_id, action_id),
                KEY idx_status_created (status, created_at),
                CONSTRAINT fk_appeal_action FOREIGN KEY (action_id)
                    REFERENCES moderation_actions (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS appeals");
        $this->db->query("DROP TABLE IF EXISTS user_moderation_state");
        $this->db->query("DROP TABLE IF EXISTS moderation_actions");
        $this->db->query("DROP TABLE IF EXISTS reports");
    }
};
