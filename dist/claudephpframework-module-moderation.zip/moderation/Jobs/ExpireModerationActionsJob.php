<?php
// modules/moderation/Jobs/ExpireModerationActionsJob.php
namespace Modules\Moderation\Jobs;

use Core\Queue\Job;
use Modules\Moderation\Services\ModerationActionService;

/**
 * Hourly job that clears expired mute/suspend windows on
 * user_moderation_state rows.
 *
 * Bans don't expire — they're manually lifted via appeal approval or
 * a direct admin reversal. The job's single UPDATE scales fine
 * because `muted_until` / `suspended_until` both have indexes.
 */
class ExpireModerationActionsJob extends Job
{
    public function handle(): void
    {
        $svc = new ModerationActionService();
        $n   = $svc->expireDue();
        if ($n > 0) {
            error_log("[moderation] expired $n user_moderation_state rows");
        }
    }
}
