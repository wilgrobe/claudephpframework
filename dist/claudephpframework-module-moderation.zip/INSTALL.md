# Installation — Moderation module

## Prerequisites

- `claudephpframework-core`.
- Any combination of `comments`, `social`, `reviews` — this module's
  built-in content-remove/restore handlers auto-register for them
  when installed.
- `moderation.act` permission granted to moderators (seeded by the
  second migration).

## Steps

1. Unzip into `modules/`:
   ```bash
   cp -r claudephpframework-module-moderation/moderation /path/to/project/modules/
   ```
2. Run the migrations (creates 4 tables, seeds the permission + the
   hourly expiry job):
   ```bash
   php artisan migrate
   ```
3. Drop `report_button()` next to every item you want reportable:
   ```php
   // on a social post
   <?= report_button('social_post', (int) $post['id']) ?>
   // on a comment
   <?= report_button('comment', (int) $comment['id']) ?>
   // on a review
   <?= report_button('review', (int) $review['id']) ?>
   // on a user profile
   <?= report_button('user', (int) $profile['id']) ?>
   ```

   The modules can add these themselves in their view templates — or
   your app can drop them in from a layout partial.

## First-use walkthrough

1. User A reports user B's social post. Behind the scenes a `reports`
   row lands in status=pending.
2. Mod logs in, visits `/admin/moderation/reports`, clicks into the
   report, picks "Remove reported content + warn user" and submits.
3. Two moderation_actions rows are logged; the social post row flips
   to `deleted_at=NOW`; user B's state row gets `warnings_count=1`.
4. User B visits `/my/appeals`. They see the warning and can click
   "Request review" to submit an appeal.
5. Mod reviews `/admin/moderation/appeals`, approves with a note. The
   warning is reversed (count back to 0); the appeal row is
   resolved. The social post stays removed unless the mod separately
   restored it (the "approve appeal" flow only reverses the linked
   action; the mod did two actions, only one was appealed).

## Environment variables

None specific to this module.

## Deferred features (v2)

- **Mute/suspend enforcement in publish paths** — `mod_muted` /
  `mod_suspended` are available, but the framework's own write-paths
  (post, comment, review, DM send) don't consult them yet. Either
  add `if (mod_muted(uid)) block;` in each write handler, or wrap
  those handlers in middleware.
- **Shadow-ban** — a softer sanction where the user's content exists
  but is invisible to others. Needs a flag on posts + filter in every
  list query.
- **Automated sanctions on N warnings** — e.g. 3 warnings ⇒
  auto-suspend 7 days. Wire an event on `warn` that fires if
  `warnings_count` crosses thresholds.
- **Appeal notifications** — email or in-app when an appeal is
  decided. Integrate with `NotificationService`.
- **Report de-duplication / clustering** — today each reporter can
  file one open report per target; if 50 users report the same post
  you see 50 rows. Group them in the queue for triage efficiency.
- **Report-burden throttle** — rate-limit reports per reporter so
  one bad actor can't flood the queue.
- **Target-user lookup for more types** — `ModerationAdminController::lookupTargetUserId`
  handles the four common cases (social_post, comment, review, user).
  Add branches for store_product if you want reports against
  merchants.

## Verification

- `php -l modules/moderation/**/*.php`.
- Submit a report → it lands in `/admin/moderation/reports?status=pending`.
- Resolve with `warn` → `user_moderation_state.warnings_count` for the
  target bumps to 1.
- Appeal the warn → approval sets `reversed_at` on the action and
  decrements the warning count.
- Resolve with `mute` + duration=7 → `muted_until` is set 7 days
  in the future. Manually set it to yesterday and run the expiry
  job (`php artisan schedule:run`) — it should NULL out.
