# Moderation module

Cross-cutting abuse-reporting + user-discipline surface. Users flag
content or other users as abusive; moderators review the queue and
take action; targeted users can appeal. Sits on top of, not inside,
the comments / social / reviews modules — they own their content, this
module governs it.

## Features

### Reports
- Polymorphic — any entity type with a `report_button()` call in its
  view can be reported.
- Five reasons (spam / harassment / inappropriate / off_topic / other)
  plus free-form details.
- Uniqueness constraint on (reporter, target, open) — a user can't
  double-report the same thing while their first report is still open.

### Moderator actions
- Six action kinds: `warn`, `mute`, `suspend`, `ban`, `remove_content`,
  `restore_content`.
- `mute` / `suspend` carry a duration in days and expire automatically.
- `ban` is permanent (reverse via appeal or admin action).
- Content actions use a pluggable handler registry so this module
  doesn't need to know every entity's schema. Built-in handlers cover
  `comment`, `social_post`, `review`.
- Every action is logged to `moderation_actions` with the actor, reason,
  and (when applicable) expiry.

### User-level state
- A sidecar `user_moderation_state` row per sanctioned user:
  `warnings_count`, `muted_until`, `suspended_until`, `banned_at`,
  `ban_reason`. No-history users have no row (lazy).
- Hourly `ExpireModerationActionsJob` clears expired
  `muted_until` / `suspended_until` timestamps.

### Appeals
- Users appeal specific actions. One appeal per (user, action).
- `approve` reverses the linked action (restores content, clears
  mute / suspension / ban) and marks the appeal accordingly.
- `deny` leaves the action in place, records the reviewer's note.

## Routes

| Method | Path                                             | Purpose                     |
|--------|--------------------------------------------------|-----------------------------|
| POST   | `/reports`                                       | Submit a report             |
| GET    | `/my/appeals`                                    | Current user's history      |
| GET    | `/my/appeals/new/{actionId}`                     | Start an appeal             |
| POST   | `/my/appeals/{actionId}`                         | Submit appeal               |
| GET    | `/admin/moderation/reports`                      | Report queue                |
| GET    | `/admin/moderation/reports/{id}`                 | Report detail               |
| POST   | `/admin/moderation/reports/{id}/dismiss`         | Dismiss                     |
| POST   | `/admin/moderation/reports/{id}/resolve`         | Resolve with optional action|
| GET    | `/admin/moderation/actions`                      | Actions log                 |
| POST   | `/admin/moderation/actions/{id}/reverse`         | Reverse an action           |
| GET    | `/admin/moderation/appeals`                      | Appeal queue                |
| POST   | `/admin/moderation/appeals/{id}/approve`         | Approve (reverses action)   |
| POST   | `/admin/moderation/appeals/{id}/deny`            | Deny                        |

## View helpers

```php
<?= report_button('social_post', (int) $post['id']) ?>
<?php if (mod_banned((int) $user['id'])): ?>Account suspended<?php endif; ?>
<?= mod_muted($uid) ? 'Muted' : '' ?>
```

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
