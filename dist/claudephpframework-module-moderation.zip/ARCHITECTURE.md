# Architecture — Moderation module

## Files

```
moderation/
├── module.php
├── routes.php                                              # 12 routes
├── Controllers/
│   ├── ReportController.php                                # /reports POST
│   ├── AppealController.php                                # /my/appeals...
│   └── ModerationAdminController.php                       # /admin/moderation/*
├── Services/
│   ├── ReportService.php                                   # Submit + queue + resolve
│   ├── ModerationActionService.php                         # All action kinds + state + reverse
│   └── AppealService.php                                   # Submit, approve, deny
├── Jobs/
│   └── ExpireModerationActionsJob.php                      # Hourly expiry sweep
├── Helpers/
│   └── helpers.php                                         # report_button(), mod_banned/muted/suspended()
├── Views/
│   ├── admin/
│   │   ├── reports_index.php
│   │   ├── report_show.php
│   │   ├── actions_index.php
│   │   └── appeals_index.php
│   └── public/
│       ├── my_appeals.php
│       └── appeal_form.php
└── migrations/
    ├── 2026_04_23_140000_create_moderation_tables.php      # 4 tables
    └── 2026_04_23_140010_seed_moderation_permission_and_job.php
```

## Data model

### `reports`

```
id, reporter_user_id,
reportable_type, reportable_id,
reason ENUM, details,
status ENUM('pending','resolved','dismissed'),
resolved_by NULL, resolved_at NULL, action_id NULL,
timestamps
UNIQUE (reporter_user_id, reportable_type, reportable_id, status)
```

The "open-report uniqueness" index includes `status` so a pending
report dedups per reporter, but after resolve the same reporter can
submit a fresh report if the problem recurs.

### `moderation_actions`

```
id, actor_user_id, action ENUM,
target_user_id NULL, target_type NULL, target_id NULL,
reason NULL, duration_days NULL, expires_at NULL,
reversed_at NULL, reversed_by NULL,
created_at
```

Two target shapes:
- User actions (warn / mute / suspend / ban) set `target_user_id`.
- Content actions (remove / restore) set `target_type` + `target_id`.

Reversal is soft: the row stays, `reversed_at` is stamped, side
effects rolled back. Keeps the audit trail intact.

### `user_moderation_state`

```
user_id PK,
warnings_count, muted_until NULL, suspended_until NULL,
banned_at NULL, ban_reason NULL,
updated_at
```

Sidecar — one row per sanctioned user, no row for clean users.
Lookups use `LEFT JOIN` or `stateFor()` which returns a default
shape for rows that don't exist.

### `appeals`

```
id, user_id, action_id (FK CASCADE),
appeal_text, status ENUM('pending','approved','denied'),
reviewed_by NULL, reviewed_at NULL, reviewer_notes NULL,
timestamps
UNIQUE (user_id, action_id)
```

One appeal per (user, action). CASCADE on action deletion so
orphan appeals can't pile up.

## Content handler registry

`ModerationActionService::registerContentHandler($type, $remove, $restore)`.

The module's `register()` auto-registers handlers for:
- `comment` — `UPDATE comments SET status = 'deleted' WHERE id = ?`
  (and `'published'` for restore).
- `social_post` — `UPDATE social_posts SET deleted_at = NOW()` (null
  for restore).
- `review` — `UPDATE reviews SET status = 'deleted'` (and
  `'published'` for restore).

Each guarded by `class_exists` so moderation runs without all the
content modules installed.

Apps that add new reportable entity types register their own
remove/restore pair from their module provider's `register()` method.

## Action + appeal flow

```
  report submitted ──────────────────► status=pending
                   │
                   │ moderator reviews
                   ▼
     ┌──── dismiss ─────► status=dismissed
     │
     │ resolve with action
     ▼
  moderation_action row logged
   ├─ user-side:   user_moderation_state updated
   │               (warnings_count / muted_until / …)
   │
   └─ content-side: registered handler called
                    (status → deleted / deleted_at → NOW)

   ┌─ target user appeals a specific action
   │
   ▼
  appeal row (pending)
   │
   │ moderator reviews
   ▼
   ├─ approve → ModerationActionService::reverse(action_id)
   │            (reversed_at stamped, side effect undone)
   │            appeal row → approved
   │
   └─ deny → appeal row → denied (action remains)
```

## Expiry job

`ExpireModerationActionsJob` runs hourly (via `scheduled_tasks` seed
in the companion migration). One UPDATE per column:

```sql
UPDATE user_moderation_state SET muted_until = NULL
 WHERE muted_until IS NOT NULL AND muted_until <= NOW();

UPDATE user_moderation_state SET suspended_until = NULL
 WHERE suspended_until IS NOT NULL AND suspended_until <= NOW();
```

Both columns are indexed for selectivity. Bans are explicitly not in
this set — bans don't time out.

## Enforcement gaps

The module sets the flags; consumers of `mod_muted` / `mod_suspended`
/ `mod_banned` enforce them. Today the framework's write-paths don't
consult those flags. When wiring in, three places matter most:

- `social/PostService::create` — reject if `mod_muted(userId)`.
- `comments/CommentService::create` — same.
- `messaging/MessagingService::send` — same.

Login itself should reject suspended/banned users. That lives in
the framework's Auth layer and is outside this module's direct reach,
but an `Auth::isActive($userId)` wrapper that consults
`mod_suspended` + `mod_banned` is the idiomatic hook.

## Testing notes

- `ReportService::submit` — submitting twice as the same reporter on
  the same open report returns the existing id rather than erroring.
- `ModerationActionService::warn` → `reverse` sequence leaves the
  target's `warnings_count` at the pre-warn value.
- `mute` + expire → `muted_until` is cleared.
- `ban` + appeal-approve → `banned_at` + `ban_reason` both null.
- Unknown `target_type` in `remove_content` → action logs, no handler
  called, no error.
