# Architecture — API keys

## Files

```
api-keys/
├── module.php
├── routes.php                      # 3 routes + 1 sample /api/me
├── Controllers/ApiKeyController.php
├── Services/ApiKeyService.php      # mint, authenticate, hasScopes
├── Middleware/ApiAuthMiddleware.php
├── Views/public/index.php          # manage keys
└── migrations/…_create_api_keys_tables.php
```

## Data model

```
api_keys:
  id, user_id, name, prefix, token_hash CHAR(64) UNIQUE, last_four CHAR(4),
  scopes_json, last_used_at NULL, expires_at NULL, revoked_at NULL, created_at
  Indexes: uq_token_hash, (user_id, revoked_at), prefix
```

`prefix` is redundant with the token's leading segment but useful for
the UI (so we don't have to parse the hash). `last_four` is likewise
UI-only; a user recognizes "my laptop" by seeing `…aBcD`.

## Mint

```
token  = "phpk_live_" + rtrim(b64url(random_bytes(24)))
hash   = sha256(token)
store  { user_id, name, prefix, token_hash=hash, last_four=token[-4:],
         scopes_json, expires_at }
return token  (once — never retrievable again)
```

## Authenticate

```
Given presented token:
  1. Reject if empty or wrong prefix.
  2. hash = sha256(token).
  3. SELECT * FROM api_keys WHERE token_hash = hash LIMIT 1
  4. Reject if revoked_at IS NOT NULL.
  5. Reject if expires_at < NOW.
  6. Update last_used_at (best-effort; failures swallowed).
  7. Return (user_id, key_id, scopes).
```

No timing-side channel: comparison is on the indexed hash column,
which is constant-time at the DB level.

## Middleware contract

`ApiAuthMiddleware::__invoke($request, $next)`:
- Extracts the `Authorization: Bearer` header with a regex
  (`^Bearer\s+(\S+)$` — tolerates extra whitespace).
- Calls `ApiKeyService::authenticate`.
- On failure, returns `Response::apiJson(['error'=>code,'message'=>msg], 401|403)`.
- On success, stashes `X_API_AUTH_USER_ID`, `X_API_AUTH_KEY_ID`,
  `X_API_AUTH_SCOPES` on `$_SERVER` (avoids a global, avoids
  `$_SESSION`).

## Why $_SERVER and not a container binding?

The framework's container isn't per-request in a way that's easy to
mutate from middleware. `$_SERVER` is already per-request. A more
idiomatic solution when the framework gains request-scoped DI would
be to attach to the Request object directly.
