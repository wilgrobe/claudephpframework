# Installation — API keys

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` (creates 1 table).
3. Users self-manage keys at `/account/api-keys`.

## Adding a protected /api route

In your module's `routes.php`:

```php
use Modules\ApiKeys\Middleware\ApiAuthMiddleware;
use Modules\ApiKeys\Services\ApiKeyService;

$router->get('/api/orders/{id}', function (\Core\Request $r) {
    // Scope check — endpoint requires read:store.
    $granted = $_SERVER['X_API_AUTH_SCOPES'] ?? [];
    if (!ApiKeyService::hasScopes(['read:store'], $granted)) {
        return ApiAuthMiddleware::apiError(403, 'missing_scope', 'read:store required');
    }

    $orderId = (int) $r->param(0);
    $userId  = (int) ($_SERVER['X_API_AUTH_USER_ID'] ?? 0);
    // … fetch + return as JSON
    return \Core\Response::apiJson(['order_id' => $orderId]);
}, [ApiAuthMiddleware::class]);
```

## Deferred features

- **Per-key rate limiting** — a `api_key_usage` counter table +
  middleware check would cover it.
- **OAuth client credentials** — server-to-server flow (different
  from user-issued tokens). Would be a sibling module.
- **IP allowlists** per key — column + middleware check.
- **Admin surface** — today keys are self-service only. An
  `/admin/api-keys` surface for ops to revoke any user's keys
  drops in.

## Verification

- Mint a key at `/account/api-keys`. Copy the plaintext.
- `curl -H "Authorization: Bearer phpk_live_..." https://app.example.com/api/me`
  → returns `{"user_id":...,"key_id":...,"scopes":[...]}`.
- Revoke the key. Same curl returns `401 invalid_token`.
- Mint a key with scopes `read:store`. Hit a route requiring
  `write:content` → `403 missing_scope`.
