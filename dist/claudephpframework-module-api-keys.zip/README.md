# API keys module

User-generated scoped tokens for `/api/*` routes. New
`ApiAuthMiddleware` accepts `Authorization: Bearer <token>`,
resolves the key to a user + scopes, and stashes the auth context on
`$_SERVER` for controllers to read.

## Security posture

- **Token format** — `phpk_live_{32 url-safe base64 chars}`. 192 bits
  of entropy. The prefix is recognizable in logs so ops can spot an
  accidentally-committed key.
- **Plaintext shown once** — at mint time, and only then. Users who
  lose their token regenerate a new one.
- **Storage** — SHA-256(token) is the `token_hash` column; unique
  index makes lookup a constant-time indexed equality. Also stored:
  the prefix + the last 4 chars of the token so users can identify
  their keys in the UI without seeing the secret.
- **Scopes** are free-form strings the app defines — e.g.
  `read:store`, `write:content`. Exact-string matching; no
  hierarchies. `ApiKeyService::hasScopes($required, $granted)` is
  the helper for endpoint gating.
- **No sessions on /api** — the middleware neither reads nor writes
  `$_SESSION`. No ambient credential means no implicit CSRF surface;
  clients must present the token on every request.

## Routes

### User-facing

| Method | Path                                     | Purpose |
|--------|------------------------------------------|---------|
| GET    | `/account/api-keys`                      | List keys |
| POST   | `/account/api-keys`                      | Mint (token shown once) |
| POST   | `/account/api-keys/{id}/revoke`          | Revoke |

### /api namespace

| Method | Path                      | Middleware              | Purpose |
|--------|---------------------------|-------------------------|---------|
| GET    | `/api/me`                 | ApiAuthMiddleware       | Who am I + scopes (example) |

Apps add their own `/api/*` routes the same way — add
`ApiAuthMiddleware::class` to the route's middleware array and read
`$_SERVER['X_API_AUTH_USER_ID']` / `X_API_AUTH_SCOPES` in the
controller.

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
