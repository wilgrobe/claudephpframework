<?php
// modules/reviews/Controllers/ReviewController.php
namespace Modules\Reviews\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Reviews\Services\ReviewService;

/**
 * Public review actions:
 *   POST /reviews                     — create/update a review
 *   POST /reviews/{id}/helpful        — toggle helpful vote
 *   POST /reviews/{id}/delete         — author or admin soft-delete
 *
 * The render surface (the review section on a product/content page)
 * comes from the `reviews_for()` view helper, not this controller.
 */
class ReviewController
{
    private Auth          $auth;
    private ReviewService $reviews;

    public function __construct()
    {
        $this->auth    = Auth::getInstance();
        $this->reviews = new ReviewService();
    }

    public function store(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $type     = (string) $request->post('reviewable_type');
        $targetId = (int) $request->post('reviewable_id');
        $rating   = (int) $request->post('rating');
        $title    = (string) $request->post('title');
        $body     = (string) $request->post('body');
        $return   = (string) $request->post('return_url', '/');

        if ($type === '' || $targetId <= 0) {
            return Response::redirect($return)->withFlash('error', 'Missing target.');
        }

        try {
            $this->reviews->upsert(
                $type, $targetId, (int) $this->auth->id(),
                $rating, $title ?: null, $body ?: null,
                $request->ip(), $request->userAgent()
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect($return)->withFlash('error', $e->getMessage());
        }
        return Response::redirect($return)->withFlash('success', 'Thanks for your review.');
    }

    public function toggleHelpful(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id = (int) $request->param(0);
        $this->reviews->toggleHelpful($id, (int) $this->auth->id());
        $return = (string) $request->post('return_url', '/');
        return Response::redirect($return);
    }

    public function delete(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id     = (int) $request->param(0);
        $review = $this->reviews->findById($id);
        if (!$review) return Response::redirect('/');

        $isAdmin = method_exists($this->auth, 'isAdmin') ? $this->auth->isAdmin() : false;
        if (!$this->reviews->canEdit($review, (int) $this->auth->id(), $isAdmin)
         && !$this->reviews->canModerate($review, (int) $this->auth->id())) {
            return Response::redirect('/')->withFlash('error', 'Not permitted.');
        }
        $this->reviews->setStatus($id, 'deleted');
        $return = (string) $request->post('return_url', '/');
        return Response::redirect($return)->withFlash('success', 'Review deleted.');
    }
}
