<?php
// modules/reviews/Controllers/ReviewAdminController.php
namespace Modules\Reviews\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Reviews\Services\ReviewService;

/**
 * Admin queue for reviews.
 *   GET  /admin/reviews                  — filtered queue
 *   POST /admin/reviews/{id}/status/{s}  — status transition
 *   POST /admin/reviews/{id}/delete      — hard delete (rare — prefer status=deleted)
 *
 * Authority is handled in the service (listForModerator + canModerate)
 * so this controller only needs AuthMiddleware at the route layer —
 * users with zero authority see an empty queue.
 */
class ReviewAdminController
{
    private Auth          $auth;
    private ReviewService $reviews;

    public function __construct()
    {
        $this->auth    = Auth::getInstance();
        $this->reviews = new ReviewService();
    }

    public function index(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $status = (string) $request->query('status', 'pending');
        $page   = max(1, (int) $request->query('page', 1));
        $res = $this->reviews->listForModerator((int) $this->auth->id(), $status, $page, 50);
        return Response::view('reviews::admin.index', $res);
    }

    public function setStatus(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id     = (int) $request->param(0);
        $status = (string) $request->param(1);
        $review = $this->reviews->findById($id);
        if (!$review) return Response::redirect('/admin/reviews');
        if (!$this->reviews->canModerate($review, (int) $this->auth->id())) {
            return Response::redirect('/admin/reviews')->withFlash('error', 'Not permitted.');
        }
        try {
            $this->reviews->setStatus($id, $status);
        } catch (\InvalidArgumentException $e) {
            return Response::redirect('/admin/reviews')->withFlash('error', $e->getMessage());
        }
        return Response::redirect('/admin/reviews?status=' . urlencode((string) $request->query('status', 'pending')));
    }

    public function delete(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id     = (int) $request->param(0);
        $review = $this->reviews->findById($id);
        if (!$review) return Response::redirect('/admin/reviews');
        if (!$this->reviews->canModerate($review, (int) $this->auth->id())) {
            return Response::redirect('/admin/reviews')->withFlash('error', 'Not permitted.');
        }
        $this->reviews->hardDelete($id);
        return Response::redirect('/admin/reviews')->withFlash('success', 'Review deleted.');
    }
}
