<?php
// modules/reviews/Services/ReviewService.php
namespace Modules\Reviews\Services;

use Core\Auth\Auth;
use Core\Database\Database;

/**
 * Review domain logic.
 *
 * Reviews are polymorphic — `reviewable_type` is an app-chosen string
 * (e.g. 'store_product', 'scheduling_resource'), `reviewable_id` is
 * that entity's primary key. One review per (target, user); edits
 * update the existing row.
 *
 * Ownership resolvers: to wire review moderation into the comments-
 * module's unified queue pattern (author / group / site scope), this
 * service keeps its own static registry mirrored on the comments one.
 * Modules register their reviewable_type with `registerOwnershipResolver`
 * during bootstrap — resolver returns {user_id, group_id} for the
 * target's owner. Reviews then carry denormalized owner columns at
 * INSERT time, matching the `comments` pattern.
 *
 * Verified-purchase flag: the store module registers a purchase-check
 * callback for 'store_product' via `registerPurchaseChecker` that
 * returns true if the user has a paid order containing the product.
 * Other modules can do the same for their types — otherwise the flag
 * stays 0.
 */
class ReviewService
{
    public const STATUSES = ['published', 'pending', 'spam', 'deleted'];
    public const MIN_RATING = 1;
    public const MAX_RATING = 5;

    /** @var array<string, callable(int): ?array> */
    private static array $ownershipResolvers = [];

    /** @var array<string, callable(int, int): bool> */
    private static array $purchaseCheckers = [];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * @param callable(int): ?array $resolver Returns ['user_id'=>..., 'group_id'=>...] or null.
     */
    public static function registerOwnershipResolver(string $type, callable $resolver): void
    {
        self::$ownershipResolvers[$type] = $resolver;
    }

    /**
     * @param callable(int $userId, int $entityId): bool $checker
     *   Should return true iff $userId has purchased $entityId.
     */
    public static function registerPurchaseChecker(string $type, callable $checker): void
    {
        self::$purchaseCheckers[$type] = $checker;
    }

    public static function clearRegistries(): void
    {
        self::$ownershipResolvers = [];
        self::$purchaseCheckers   = [];
    }

    // ── Reads ─────────────────────────────────────────────────────────────

    /**
     * Published reviews for a target, newest first. Used by the public
     * view helper.
     *
     * @return array<int, array<string, mixed>>
     */
    public function publishedFor(string $type, int $targetId, int $limit = 20, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT r.*, u.username
               FROM reviews r
          LEFT JOIN users u ON u.id = r.user_id
              WHERE r.reviewable_type = ?
                AND r.reviewable_id = ?
                AND r.status = 'published'
           ORDER BY r.helpful_count DESC, r.created_at DESC
              LIMIT ? OFFSET ?",
            [$type, $targetId, $limit, $offset]
        );
    }

    public function findById(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM reviews WHERE id = ?", [$id]);
    }

    /** Find this user's existing review of a target, if any. */
    public function findUserReview(string $type, int $targetId, int $userId): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM reviews
              WHERE reviewable_type = ? AND reviewable_id = ? AND user_id = ?",
            [$type, $targetId, $userId]
        );
    }

    /**
     * Aggregate stats for a target: count of published reviews + average
     * rating (null when no reviews) + distribution count per star level.
     *
     * @return array{count: int, average: ?float, distribution: array<int,int>}
     */
    public function aggregate(string $type, int $targetId): array
    {
        $row = $this->db->fetchOne(
            "SELECT COUNT(*) AS cnt, AVG(rating) AS avg_rating
               FROM reviews
              WHERE reviewable_type = ? AND reviewable_id = ? AND status = 'published'",
            [$type, $targetId]
        );
        $count = (int) ($row['cnt'] ?? 0);
        $avg   = $row && $row['avg_rating'] !== null ? round((float) $row['avg_rating'], 2) : null;

        $rows = $this->db->fetchAll(
            "SELECT rating, COUNT(*) AS cnt
               FROM reviews
              WHERE reviewable_type = ? AND reviewable_id = ? AND status = 'published'
           GROUP BY rating",
            [$type, $targetId]
        );
        $dist = [1 => 0, 2 => 0, 3 => 0, 4 => 0, 5 => 0];
        foreach ($rows as $r) {
            $k = (int) $r['rating'];
            if (isset($dist[$k])) $dist[$k] = (int) $r['cnt'];
        }

        return ['count' => $count, 'average' => $avg, 'distribution' => $dist];
    }

    /**
     * Admin / moderator queue. Filters by the caller's authority:
     *   - Global (reviews.moderate perm)  → all
     *   - Author of target owner          → owner_user_id = userId
     *   - Group admin of target owner     → owner_group_id ∈ their groups
     */
    public function listForModerator(int $userId, ?string $status = 'pending', int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        $status = in_array($status, self::STATUSES, true) ? $status : 'pending';

        $auth = Auth::getInstance();
        if ($auth->can('reviews.moderate')) {
            $items = $this->db->fetchAll(
                "SELECT r.*, u.username, u.email
                   FROM reviews r
              LEFT JOIN users u ON u.id = r.user_id
                  WHERE r.status = ?
               ORDER BY r.created_at DESC
                  LIMIT ? OFFSET ?",
                [$status, $perPage, $offset]
            );
            $total = (int) $this->db->fetchColumn(
                "SELECT COUNT(*) FROM reviews WHERE status = ?", [$status]
            );
            return ['items' => $items, 'total' => $total, 'status' => $status, 'page' => $page, 'per_page' => $perPage];
        }

        // Author + group paths. Mirrors CommentService::listForModerator.
        $groupIds = $this->groupIdsUserCanModerate($userId);
        $or       = ['r.owner_user_id = ?'];
        $bind     = [$status, $userId];
        if (!empty($groupIds)) {
            $ph = implode(',', array_fill(0, count($groupIds), '?'));
            $or[] = "r.owner_group_id IN ($ph)";
            $bind = array_merge($bind, $groupIds);
        }
        $where = 'WHERE r.status = ? AND (' . implode(' OR ', $or) . ')';

        $items = $this->db->fetchAll(
            "SELECT r.*, u.username, u.email
               FROM reviews r
          LEFT JOIN users u ON u.id = r.user_id
              $where
           ORDER BY r.created_at DESC
              LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM reviews r $where", $bind
        );
        return ['items' => $items, 'total' => $total, 'status' => $status, 'page' => $page, 'per_page' => $perPage];
    }

    /** @return int[] */
    public function groupIdsUserCanModerate(int $userId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT group_id FROM user_groups
              WHERE user_id = ?
                AND base_role IN ('group_admin', 'group_owner')",
            [$userId]
        );
        return array_map(static fn(array $r): int => (int) $r['group_id'], $rows);
    }

    public function canModerate(array $review, int $userId): bool
    {
        $auth = Auth::getInstance();
        if ($auth->can('reviews.moderate')) return true;

        $ownerUser  = isset($review['owner_user_id'])  && $review['owner_user_id']  !== null ? (int) $review['owner_user_id']  : null;
        $ownerGroup = isset($review['owner_group_id']) && $review['owner_group_id'] !== null ? (int) $review['owner_group_id'] : null;

        if ($ownerGroup !== null && $auth->isGroupAdmin($ownerGroup)) return true;
        if ($ownerUser  !== null && $ownerUser === $userId)           return true;

        // Reviews authors can delete their own reviews — that's edit, not
        // moderation. Callers should use canEdit for author deletion.
        return false;
    }

    public function canEdit(array $review, int $userId, bool $isAdmin): bool
    {
        if ($isAdmin) return true;
        return (int) ($review['user_id'] ?? 0) === $userId
            && (string) $review['status'] === 'published';
    }

    // ── Writes ────────────────────────────────────────────────────────────

    /**
     * Create a review, or update the user's existing review of this
     * target if one exists (review-upsert). Returns the review id.
     *
     * $rating must be 1..5; anything out of range throws. An empty body
     * is allowed (a star-only rating is valid); an empty title becomes
     * NULL.
     */
    public function upsert(
        string $type, int $targetId, int $userId,
        int $rating, ?string $title, ?string $body,
        ?string $ip = null, ?string $userAgent = null
    ): int {
        if ($rating < self::MIN_RATING || $rating > self::MAX_RATING) {
            throw new \InvalidArgumentException('Rating must be 1–5.');
        }
        $title = $title !== null ? trim($title) : null;
        if ($title === '') $title = null;
        $body  = $body  !== null ? trim($body)  : null;
        if ($body  === '') $body  = null;

        // Owner resolution (for moderation)
        $resolver = self::$ownershipResolvers[$type] ?? null;
        $own = $resolver ? $resolver($targetId) : null;

        // Verified-purchase snapshot (for badge + sorting)
        $verified = 0;
        $checker  = self::$purchaseCheckers[$type] ?? null;
        if ($checker && $checker($userId, $targetId)) $verified = 1;

        $existing = $this->findUserReview($type, $targetId, $userId);
        if ($existing) {
            $this->db->update('reviews',
                [
                    'rating'            => $rating,
                    'title'             => $title,
                    'body'              => $body,
                    'verified_purchase' => $verified,
                ],
                'id = ?', [(int) $existing['id']]
            );
            return (int) $existing['id'];
        }

        return (int) $this->db->insert('reviews', [
            'reviewable_type'   => $type,
            'reviewable_id'     => $targetId,
            'user_id'           => $userId,
            'owner_user_id'     => $own['user_id']  ?? null,
            'owner_group_id'    => $own['group_id'] ?? null,
            'rating'            => $rating,
            'title'             => $title,
            'body'              => $body,
            'verified_purchase' => $verified,
            'status'            => 'published',
            'ip_address'        => $ip ? substr($ip, 0, 45) : null,
            'user_agent'        => $userAgent ? substr($userAgent, 0, 255) : null,
        ]);
    }

    public function setStatus(int $reviewId, string $status): void
    {
        if (!in_array($status, self::STATUSES, true)) {
            throw new \InvalidArgumentException("Unknown review status: $status");
        }
        $this->db->update('reviews', ['status' => $status], 'id = ?', [$reviewId]);
    }

    public function hardDelete(int $reviewId): void
    {
        $this->db->delete('reviews', 'id = ?', [$reviewId]);
    }

    // ── Helpful votes ─────────────────────────────────────────────────────

    /**
     * Toggle a helpful vote. Returns the new state (true = vote present
     * after this call). Keeps helpful_count in sync — denormalized for
     * cheap listing sorts.
     */
    public function toggleHelpful(int $reviewId, int $userId): bool
    {
        $exists = $this->db->fetchOne(
            "SELECT 1 FROM review_helpful_votes WHERE review_id = ? AND user_id = ?",
            [$reviewId, $userId]
        );
        if ($exists) {
            $this->db->delete('review_helpful_votes',
                'review_id = ? AND user_id = ?', [$reviewId, $userId]);
            $this->db->query(
                "UPDATE reviews SET helpful_count = GREATEST(0, helpful_count - 1) WHERE id = ?",
                [$reviewId]
            );
            return false;
        }
        $this->db->insert('review_helpful_votes', [
            'review_id' => $reviewId, 'user_id' => $userId,
        ]);
        $this->db->query(
            "UPDATE reviews SET helpful_count = helpful_count + 1 WHERE id = ?",
            [$reviewId]
        );
        return true;
    }

    public function hasVotedHelpful(int $reviewId, int $userId): bool
    {
        return (bool) $this->db->fetchOne(
            "SELECT 1 FROM review_helpful_votes WHERE review_id = ? AND user_id = ?",
            [$reviewId, $userId]
        );
    }
}
