<?php
// modules/reviews/migrations/2026_04_23_100010_seed_reviews_permission.php
use Core\Database\Migration;

/**
 * Seed the `reviews.moderate` permission. Site moderators with this
 * perm can act on pending/published/spam reviews from the admin queue.
 * Post authors / group admins get moderation authority automatically
 * for reviews attached to content they own, via the same resolver
 * pattern the comments module uses.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Moderate reviews',
            'reviews.moderate',
            'reviews',
            'Approve, reject, or remove user reviews across all reviewable entities.',
        ]);
    }

    public function down(): void
    {
        // Keep permission rows intact — other roles may reference them.
    }
};
