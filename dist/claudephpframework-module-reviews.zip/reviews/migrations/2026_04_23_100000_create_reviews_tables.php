<?php
// modules/reviews/migrations/2026_04_23_100000_create_reviews_tables.php
use Core\Database\Migration;

/**
 * Schema for the reviews module.
 *
 *   reviews                — polymorphic (reviewable_type, reviewable_id).
 *                            One row per (reviewable, user) — a user can
 *                            edit their own review but can't post two.
 *                            `verified_purchase` is a snapshot computed
 *                            at submit time; re-computing on every read
 *                            would burn a query per row on listing pages.
 *                            Status lifecycle mirrors comments so a
 *                            unified moderation model is possible.
 *
 *   review_helpful_votes   — (review_id, user_id) PK for idempotent
 *                            toggle. One user can vote each review
 *                            helpful at most once; removing the vote
 *                            deletes the row. `helpful_count` column
 *                            on reviews is the denormalized total —
 *                            updated in the service layer at toggle
 *                            time for cheap sorts.
 *
 *   denormalized owner columns match the comments module's shape
 *   (owner_user_id / owner_group_id) so the same ownership-resolver
 *   pattern applies — a module registering its review_type can let the
 *   target author/group moderate review threads.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE reviews (
                id                BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                reviewable_type   VARCHAR(64)  NOT NULL,
                reviewable_id     BIGINT UNSIGNED NOT NULL,
                user_id           INT UNSIGNED NOT NULL,
                owner_user_id     INT UNSIGNED NULL,
                owner_group_id    INT UNSIGNED NULL,
                rating            TINYINT UNSIGNED NOT NULL,
                title             VARCHAR(191) NULL,
                body              TEXT         NULL,
                verified_purchase TINYINT(1)   NOT NULL DEFAULT 0,
                helpful_count     INT UNSIGNED NOT NULL DEFAULT 0,
                status            ENUM('published','pending','spam','deleted')
                                  NOT NULL DEFAULT 'published',
                ip_address        VARCHAR(45)  NULL,
                user_agent        VARCHAR(255) NULL,
                created_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_user_target (reviewable_type, reviewable_id, user_id),
                KEY idx_target_status (reviewable_type, reviewable_id, status, created_at),
                KEY idx_user          (user_id),
                KEY idx_owner_user    (owner_user_id,  status, created_at),
                KEY idx_owner_group   (owner_group_id, status, created_at),
                KEY idx_status        (status, created_at),
                CONSTRAINT chk_rating_range CHECK (rating BETWEEN 1 AND 5)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE review_helpful_votes (
                review_id  BIGINT UNSIGNED NOT NULL,
                user_id    INT UNSIGNED    NOT NULL,
                created_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,

                PRIMARY KEY (review_id, user_id),
                KEY idx_user (user_id),
                CONSTRAINT fk_rhv_review
                    FOREIGN KEY (review_id) REFERENCES reviews (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS review_helpful_votes");
        $this->db->query("DROP TABLE IF EXISTS reviews");
    }
};
