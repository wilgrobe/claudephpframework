<?php
// modules/reviews/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;

$R = 'Modules\Reviews\Controllers\ReviewController';
$A = 'Modules\Reviews\Controllers\ReviewAdminController';

// ── Public ────────────────────────────────────────────────────────────────
$router->post('/reviews',                    "$R@store",          [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/reviews/{id}/helpful',       "$R@toggleHelpful",  [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/reviews/{id}/delete',        "$R@delete",         [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Admin (authority check is in the controller/service) ─────────────────
$router->get ('/admin/reviews',                       "$A@index",     [AuthMiddleware::class]);
$router->post('/admin/reviews/{id}/status/{status}',  "$A@setStatus", [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/admin/reviews/{id}/delete',           "$A@delete",    [CsrfMiddleware::class, AuthMiddleware::class]);
