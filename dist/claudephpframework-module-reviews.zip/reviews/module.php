<?php
// modules/reviews/module.php
use Core\Container\Container;
use Core\Database\Database;
use Core\Module\ModuleProvider;

/**
 * Reviews module — polymorphic 1–5 star ratings with title + body +
 * helpful votes + verified-purchase badge.
 *
 * Ownership-resolver + verified-purchase registries live on
 * ReviewService so other modules wire their entity types in at boot.
 * The reviews module opportunistically registers the store's
 * `store_product` type right here (not from the store module)
 * because reviews is the consumer — it knows what it needs from the
 * store. If the store isn't installed the registrations are harmless:
 * `class_exists` gates will short-circuit, and the checker returns
 * false (no verified badge).
 *
 * Helpers registered: reviews_for(), review_stars_badge(),
 * review_aggregate().
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'reviews'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }

    public function register(Container $container): void
    {
        require_once __DIR__ . '/Helpers/helpers.php';

        // Register a verified-purchase checker for store_product.
        // Looks for ANY order in {paid, shipped, delivered} owned by the
        // user that contains the product. Cancelled/refunded orders
        // don't count — buying + refunding shouldn't unlock "verified".
        if (class_exists(\Modules\Store\Services\ProductService::class)) {
            \Modules\Reviews\Services\ReviewService::registerPurchaseChecker(
                'store_product',
                static function (int $userId, int $productId): bool {
                    $row = Database::getInstance()->fetchOne(
                        "SELECT 1
                           FROM store_orders o
                           JOIN store_order_items oi ON oi.order_id = o.id
                          WHERE o.user_id = ?
                            AND oi.product_id = ?
                            AND o.status IN ('paid','shipped','delivered')
                          LIMIT 1",
                        [$userId, $productId]
                    );
                    return (bool) $row;
                }
            );
        }
    }
};
