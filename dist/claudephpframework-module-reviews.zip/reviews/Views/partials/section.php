<?php
// modules/reviews/Views/partials/section.php
// Expects: $list, $stats, $myReview (nullable), $auth,
//          $reviewable_type, $reviewable_id, $returnUrl.
?>
<div class="reviews-section" style="margin-top:2rem">

<!-- Aggregate bar -->
<div class="card">
    <div class="card-body" style="display:flex;gap:1.5rem;align-items:center">
        <?php if ($stats['count'] === 0): ?>
        <div style="color:#9ca3af;font-size:14px">No reviews yet — be the first.</div>
        <?php else: ?>
        <div style="text-align:center;min-width:120px">
            <div style="font-size:2rem;font-weight:600"><?= number_format((float) $stats['average'], 1) ?></div>
            <div style="color:#f59e0b;letter-spacing:2px">
                <?php
                $avg  = (float) $stats['average'];
                $full = (int) floor($avg);
                $half = ($avg - $full) >= 0.5;
                echo str_repeat('★', $full) . ($half ? '½' : '') . str_repeat('☆', max(0, 5 - $full - ($half ? 1 : 0)));
                ?>
            </div>
            <div style="color:#6b7280;font-size:12px"><?= (int) $stats['count'] ?> review<?= (int) $stats['count'] === 1 ? '' : 's' ?></div>
        </div>
        <div style="flex:1">
            <?php for ($i = 5; $i >= 1; $i--): ?>
            <?php
            $count  = (int) ($stats['distribution'][$i] ?? 0);
            $pct    = $stats['count'] > 0 ? ($count / $stats['count']) * 100 : 0;
            ?>
            <div style="display:flex;align-items:center;gap:.5rem;font-size:12px;margin-bottom:.15rem">
                <span style="width:2rem;color:#6b7280"><?= $i ?>★</span>
                <div style="flex:1;background:#f3f4f6;height:6px;border-radius:3px;overflow:hidden">
                    <div style="background:#f59e0b;height:100%;width:<?= $pct ?>%"></div>
                </div>
                <span style="width:2rem;text-align:right;color:#9ca3af"><?= $count ?></span>
            </div>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Write / edit form -->
<?php if (!$auth->guest()): ?>
<div class="card" style="margin-top:1rem">
    <div class="card-header"><strong><?= $myReview ? 'Edit your review' : 'Write a review' ?></strong></div>
    <form method="post" action="/reviews">
        <?= csrf_field() ?>
        <input type="hidden" name="reviewable_type" value="<?= e($reviewable_type) ?>">
        <input type="hidden" name="reviewable_id"   value="<?= (int) $reviewable_id ?>">
        <input type="hidden" name="return_url"      value="<?= e($returnUrl) ?>">
        <div class="card-body">
            <label>Rating
                <select name="rating" required>
                    <option value="">— stars —</option>
                    <?php foreach ([5,4,3,2,1] as $r): ?>
                    <option value="<?= $r ?>" <?= $myReview && (int) $myReview['rating'] === $r ? 'selected' : '' ?>>
                        <?= str_repeat('★', $r) . str_repeat('☆', 5 - $r) ?> (<?= $r ?>)
                    </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label style="display:block;margin-top:.5rem">Title (optional)
                <input name="title" value="<?= e((string) ($myReview['title'] ?? '')) ?>" style="width:100%">
            </label>
            <label style="display:block;margin-top:.5rem">Your review (optional)
                <textarea name="body" rows="4" style="width:100%"><?= e((string) ($myReview['body'] ?? '')) ?></textarea>
            </label>
        </div>
        <div class="card-footer" style="padding:.5rem 1rem;background:#f9fafb;text-align:right">
            <button type="submit" class="btn btn-primary"><?= $myReview ? 'Update review' : 'Submit review' ?></button>
        </div>
    </form>
</div>
<?php else: ?>
<div style="margin-top:1rem;color:#9ca3af;font-size:13px">
    <a href="/login">Log in</a> to write a review.
</div>
<?php endif; ?>

<!-- Review list -->
<?php if (!empty($list)): ?>
<div style="margin-top:1rem">
    <?php foreach ($list as $r): ?>
    <div class="card" style="margin-bottom:.75rem">
        <div class="card-body">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:1rem">
                <div>
                    <div style="color:#f59e0b;font-size:14px;letter-spacing:2px">
                        <?= str_repeat('★', (int) $r['rating']) . str_repeat('☆', 5 - (int) $r['rating']) ?>
                    </div>
                    <?php if (!empty($r['title'])): ?>
                    <div style="font-weight:600;margin-top:.15rem"><?= e($r['title']) ?></div>
                    <?php endif; ?>
                </div>
                <div style="text-align:right;color:#9ca3af;font-size:12px">
                    <div>@<?= e((string) ($r['username'] ?? 'user')) ?></div>
                    <?php if ((int) $r['verified_purchase'] === 1): ?>
                    <div style="color:#16a34a;font-size:11px">✓ verified purchase</div>
                    <?php endif; ?>
                    <div><?= e(date('M j, Y', strtotime((string) $r['created_at']))) ?></div>
                </div>
            </div>
            <?php if (!empty($r['body'])): ?>
            <div style="margin-top:.5rem;color:#374151;white-space:pre-wrap;line-height:1.5"><?= nl2br(e((string) $r['body'])) ?></div>
            <?php endif; ?>
            <?php if (!$auth->guest()): ?>
            <div style="margin-top:.5rem;font-size:12px;color:#6b7280">
                <form method="post" action="/reviews/<?= (int) $r['id'] ?>/helpful" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="return_url" value="<?= e($returnUrl) ?>">
                    <button type="submit" class="btn btn-sm btn-secondary">
                        Helpful · <?= (int) $r['helpful_count'] ?>
                    </button>
                </form>
                <?php if ((int) $r['user_id'] === (int) $auth->id()): ?>
                <form method="post" action="/reviews/<?= (int) $r['id'] ?>/delete" style="display:inline;margin-left:.25rem" onsubmit="return confirm('Delete your review?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="return_url" value="<?= e($returnUrl) ?>">
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
                <?php endif; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

</div>
