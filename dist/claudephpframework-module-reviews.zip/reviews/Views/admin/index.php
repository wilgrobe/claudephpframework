<?php $pageTitle = 'Reviews moderation'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header"><h2 style="margin:0">Reviews <span style="color:#9ca3af;font-size:13px">(<?= (int) ($total ?? 0) ?>)</span></h2></div>
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem;flex-wrap:wrap">
        <?php foreach (['pending','published','spam','deleted'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= ($status ?? '') === $s ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($s) ?></a>
        <?php endforeach; ?>
    </div>
    <?php if (empty($items)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">
        Nothing in this queue.
    </div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>When</th><th>Target</th><th>Author</th><th>Rating</th><th>Review</th><th>Actions</th></tr></thead>
        <tbody>
        <?php foreach ($items as $r): ?>
        <tr>
            <td style="font-size:12px;white-space:nowrap"><?= e(date('M j H:i', strtotime((string) $r['created_at']))) ?></td>
            <td style="font-family:monospace;font-size:12px"><?= e((string) $r['reviewable_type']) ?> #<?= (int) $r['reviewable_id'] ?></td>
            <td><?= e((string) ($r['username'] ?? ('#' . (int) $r['user_id']))) ?></td>
            <td style="color:#f59e0b;letter-spacing:1px"><?= str_repeat('★', (int) $r['rating']) . str_repeat('☆', 5 - (int) $r['rating']) ?></td>
            <td>
                <?php if (!empty($r['title'])): ?><strong><?= e((string) $r['title']) ?></strong><br><?php endif; ?>
                <span style="color:#4b5563;font-size:13px"><?= e(mb_substr((string) ($r['body'] ?? ''), 0, 200)) ?><?= mb_strlen((string) ($r['body'] ?? '')) > 200 ? '…' : '' ?></span>
            </td>
            <td>
                <?php foreach (['published','pending','spam','deleted'] as $t): if ($t === $r['status']) continue; ?>
                <form method="post" action="/admin/reviews/<?= (int) $r['id'] ?>/status/<?= e($t) ?>?status=<?= e($status ?? 'pending') ?>" style="display:inline">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-secondary"><?= ucfirst($t) ?></button>
                </form>
                <?php endforeach; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
