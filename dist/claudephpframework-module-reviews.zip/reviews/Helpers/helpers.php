<?php
// modules/reviews/Helpers/helpers.php
/**
 * View helpers for the reviews module.
 *
 *   <?= reviews_for('store_product', (int) $product['id']) ?>
 *   <?= review_stars_badge('store_product', (int) $product['id']) ?>  // "★★★★☆ (27)"
 *
 * Registered once per request by the module provider (see module.php
 * register). function_exists guards make re-inclusion harmless.
 */

if (!function_exists('reviews_for')) {
    /**
     * Render the reviews section for a target: aggregate bar + reviews
     * list + write-a-review form (when logged in and not yet reviewed).
     */
    function reviews_for(string $type, int $id, string $returnUrl = ''): string
    {
        $service = new \Modules\Reviews\Services\ReviewService();
        $list    = $service->publishedFor($type, $id, 50);
        $stats   = $service->aggregate($type, $id);

        $auth     = \Core\Auth\Auth::getInstance();
        $myReview = null;
        if (!$auth->guest()) {
            $myReview = $service->findUserReview($type, $id, (int) $auth->id());
        }
        $returnUrl = $returnUrl ?: ($_SERVER['REQUEST_URI'] ?? '/');

        ob_start();
        $reviewable_type = $type;
        $reviewable_id   = $id;
        include __DIR__ . '/../Views/partials/section.php';
        return (string) ob_get_clean();
    }
}

if (!function_exists('review_stars_badge')) {
    /**
     * Inline stars badge (★★★★☆ 4.2 · 27 reviews) for listings.
     * Returns an empty string when there are zero reviews so callers
     * don't have to branch.
     */
    function review_stars_badge(string $type, int $id): string
    {
        $stats = (new \Modules\Reviews\Services\ReviewService())->aggregate($type, $id);
        if ($stats['count'] === 0) return '';

        $avg = (float) $stats['average'];
        $full = (int) floor($avg);
        $half = ($avg - $full) >= 0.5;
        $stars = str_repeat('★', $full)
               . ($half ? '½' : '')
               . str_repeat('☆', max(0, 5 - $full - ($half ? 1 : 0)));

        return '<span class="review-badge" style="color:#f59e0b">' . $stars . '</span>'
             . ' <span style="color:#6b7280;font-size:12px">'
             . number_format($avg, 1) . ' · ' . (int) $stats['count'] . ' review'
             . ((int) $stats['count'] === 1 ? '' : 's')
             . '</span>';
    }
}

if (!function_exists('review_aggregate')) {
    /** Raw aggregate data for a target — for views that render their own chrome. */
    function review_aggregate(string $type, int $id): array
    {
        return (new \Modules\Reviews\Services\ReviewService())->aggregate($type, $id);
    }
}
