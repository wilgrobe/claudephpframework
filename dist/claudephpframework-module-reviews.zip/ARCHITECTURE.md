# Architecture — Reviews module

## Files

```
reviews/
├── module.php
├── routes.php                                        # 6 routes
├── Controllers/
│   ├── ReviewController.php                          # Public: create/edit/vote/delete
│   └── ReviewAdminController.php                     # /admin/reviews queue
├── Services/
│   └── ReviewService.php                             # Upsert, aggregate, helpful, moderation queue
├── Helpers/
│   └── helpers.php                                   # reviews_for(), review_stars_badge(), review_aggregate()
├── Views/
│   ├── partials/section.php                          # The whole review section (aggregate + form + list)
│   └── admin/index.php                               # /admin/reviews
└── migrations/
    ├── 2026_04_23_100000_create_reviews_tables.php   # 2 tables
    └── 2026_04_23_100010_seed_reviews_permission.php
```

## Data model

### `reviews`

```
id BIGINT, reviewable_type, reviewable_id,
user_id, owner_user_id NULL, owner_group_id NULL,
rating TINYINT [1..5], title NULL, body NULL,
verified_purchase TINYINT, helpful_count,
status ENUM('published','pending','spam','deleted'),
ip_address, user_agent, timestamps
UNIQUE (reviewable_type, reviewable_id, user_id)
CHECK (rating BETWEEN 1 AND 5)
```

Denormalized `owner_user_id` + `owner_group_id` match the pattern
pioneered in the comments module so the same moderator-queue
filtering (site / group-admin / target-owner) works here.

### `review_helpful_votes`

```
review_id, user_id, created_at
PK (review_id, user_id)
```

One row per (review, voter). Toggle via `ReviewService::toggleHelpful`
which keeps `reviews.helpful_count` in sync.

## Registries

Two static registries on `ReviewService`:

### Ownership resolver

```php
ReviewService::registerOwnershipResolver('social_post', fn(int $id) => ...);
```

Populates `owner_user_id` + `owner_group_id` on review INSERT so the
moderation queue can filter by ownership without joining each
target table.

### Purchase checker (for the verified badge)

```php
ReviewService::registerPurchaseChecker('store_product',
    fn(int $userId, int $productId) => bool);
```

The reviews module auto-registers the store's checker — a review on
`store_product` where the user has a paid (or shipped / delivered)
order containing the product gets `verified_purchase = 1` at submit
time. The badge is a snapshot; reviews written before a purchase don't
retroactively earn the badge when the purchase happens.

## Aggregate rendering

`review_stars_badge` is the compact one-liner for product listings:

```
★★★★☆ 4.2 · 27 reviews
```

It returns an empty string when there are zero reviews so templates
can unconditionally echo it without a guard.

`reviews_for` renders the full section: aggregate card with per-star
bars, write-/edit-form for logged-in users, and the paginated list
with helpful buttons.

## Testing notes

- `ReviewService::upsert` → assert one row per (target, user) after
  multiple calls, with the latest values taking effect.
- `toggleHelpful` → assert `helpful_count` is maintained and the unique
  vote constraint dedups.
- `aggregate` → assert distribution sums to count; average respects
  zero-review case by returning null.
- Moderation queue for a non-global user → only surfaces reviews
  matching their author / group authority.
