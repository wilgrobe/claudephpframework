# Reviews module

Polymorphic star ratings + reviews for any entity type. Drop
`<?= reviews_for('store_product', $product['id']) ?>` into a view and
get the full surface: aggregate bar, per-star distribution, write-a-
review form, list with helpful votes, verified-purchase badges.

## Features

- **1–5 star ratings** with optional title + body. One review per
  `(target, user)` — resubmission edits the existing review.
- **Aggregate stats** — count, average, per-star distribution. Cheap
  to render; available as both HTML (`review_stars_badge`) and data
  (`review_aggregate`).
- **Helpful votes** — toggle per user per review. Denormalized
  `helpful_count` on the review row for cheap sort.
- **Verified-purchase badge** — pluggable via
  `ReviewService::registerPurchaseChecker($type, $fn)`. The store is
  auto-wired: a review on `store_product` checks the user's paid
  orders for the product.
- **Moderation** — mirrors comments' four-scope model. Site
  moderators with `reviews.moderate`; group admins for group-owned
  targets; target authors for author-owned targets. Pluggable via
  `ReviewService::registerOwnershipResolver($type, $fn)`.
- **Admin queue** at `/admin/reviews` with status tabs.

## Routes

| Method | Path                                 | Purpose                    |
|--------|--------------------------------------|----------------------------|
| POST   | `/reviews`                           | Create / update review     |
| POST   | `/reviews/{id}/helpful`              | Toggle helpful vote        |
| POST   | `/reviews/{id}/delete`               | Author / moderator delete  |
| GET    | `/admin/reviews`                     | Moderation queue           |
| POST   | `/admin/reviews/{id}/status/{s}`     | Change status              |
| POST   | `/admin/reviews/{id}/delete`         | Hard delete                |

## View helpers

```php
<?= reviews_for('store_product', (int) $product['id']) ?>
<?= review_stars_badge('store_product', (int) $product['id']) ?>
<?php $stats = review_aggregate('store_product', (int) $product['id']); ?>
```

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
