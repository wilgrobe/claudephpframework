# Installation — Reviews module

## Prerequisites

- `claudephpframework-core`.
- `reviews.moderate` permission granted to site moderators (seeded by
  the second migration).

## Steps

1. Unzip into `modules/`:
   ```bash
   cp -r claudephpframework-module-reviews/reviews /path/to/project/modules/
   ```
2. Run migrations (creates 2 tables + seeds the permission):
   ```bash
   php artisan migrate
   ```
3. Drop `reviews_for()` into whatever entity's detail view you want
   reviewable:
   ```php
   // modules/store/Views/public/product.php
   <?= reviews_for('store_product', (int) $product['id']) ?>
   ```

The store integration (verified-purchase check) is automatic when the
store module is installed — see `module.php`.

## Deferred features (v2)

- **Per-entity moderation-scope settings** — a "this product's
  reviews require pre-moderation" toggle would flow through
  `ReviewService::determineInitialStatus` cleanly if the settings
  scope were extended; today all reviews land as `published`.
- **Review reply** — merchant response to each review. A
  `review_replies` table (review_id, user_id, body, timestamps) slots
  in next to `reviews`.
- **Photo uploads** — add a `review_images` table paralleling
  `store_product_images`. Wire through `FileUploadService`.
- **Sort + filter** in `reviews_for` — today sorted by helpful desc,
  then newest. Expose `?sort=newest|oldest|rating_desc|...` query param.

## Verification

- `php -l modules/reviews/**/*.php`.
- As user A buy product X. Log in as A, visit product X, submit a 4-
  star review. The "verified purchase" badge should appear.
- Log in as user B who didn't buy X. Submit a 2-star review. No badge.
- Submit helpful votes on both; totals update on refresh.
