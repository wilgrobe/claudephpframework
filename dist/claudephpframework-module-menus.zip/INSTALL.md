# Installation — Menus module

## Prerequisites

- `claudephpframework-core` installed.
- Core tables `menus` and `menu_items` present (from `install.sql`).

## Steps

1. Drop into `modules/`:
   ```bash
   unzip claudephpframework-module-menus.zip
   cp -r claudephpframework-module-menus/menus /path/to/project/modules/
   ```

2. Run migrations (none ship):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if using production caching:
   ```bash
   php artisan module:cache
   ```

## Environment variables

None.

## Verification

1. Log in as admin, visit `/admin/menus`.
2. Create a menu with location `primary`.
3. Add a couple of items (e.g. Home → `/`, About → `/about`).
4. In any layout view, call `<?= menu('primary') ?>` — you should see the
   items render. (Wrap the output; the helper returns raw HTML from
   `MenuService::render()`.)
