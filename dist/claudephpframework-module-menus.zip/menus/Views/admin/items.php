<?php $pageTitle = 'Menu Items — ' . e($menu['name']); ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="margin-bottom:1rem">
    <a href="/admin/menus" class="btn btn-secondary btn-sm">← Back to Menus</a>
</div>

<div class="grid grid-2" style="align-items:flex-start">

    <!-- Current items (sortable) -->
    <div class="card">
        <div class="card-header">
            <h2>Items in "<?= e($menu['name']) ?>"</h2>
            <span style="font-size:12px;color:#6b7280">Drag to reorder</span>
        </div>
        <?php if (empty($items)): ?>
        <div class="card-body"><p style="color:#6b7280;margin:0">No items yet. Add one →</p></div>
        <?php else: ?>
        <ul id="sortable-items" style="list-style:none;margin:0;padding:.5rem">
            <?php
            // Build nested display
            $topLevel = array_filter($items, fn($i) => !$i['parent_id']);
            $children = [];
            foreach ($items as $i) {
                if ($i['parent_id']) $children[$i['parent_id']][] = $i;
            }
            foreach ($topLevel as $item): ?>
            <li data-id="<?= $item['id'] ?>" style="background:#f9fafb;border:1px solid #e5e7eb;border-radius:6px;padding:.6rem .85rem;margin-bottom:.4rem;cursor:grab;display:flex;align-items:center;justify-content:space-between;gap:.5rem">
                <div style="display:flex;align-items:center;gap:.5rem">
                    <span style="color:#9ca3af;cursor:grab">⠿</span>
                    <div>
                        <div style="font-weight:500;font-size:13.5px"><?= e($item['label']) ?></div>
                        <div style="font-size:11px;color:#9ca3af">
                            <?= $item['url'] ? e($item['url']) : '<em>no link (submenu parent)</em>' ?>
                            — <em><?= e($item['visibility']) ?><?= $item['condition_value'] ? ': '.e($item['condition_value']) : '' ?></em>
                        </div>
                    </div>
                </div>
                <form method="POST" action="/admin/menus/items/<?= $item['id'] ?>/delete" data-confirm="Delete this menu item?">
                    <?= csrf_field() ?><button class="btn btn-xs btn-danger">×</button>
                </form>
            </li>
            <?php if (!empty($children[$item['id']])): ?>
            <?php foreach ($children[$item['id']] as $child): ?>
            <li data-id="<?= $child['id'] ?>" style="background:#fff;border:1px solid #e5e7eb;border-radius:6px;padding:.5rem .85rem .5rem 2rem;margin-bottom:.3rem;margin-left:1.5rem;display:flex;align-items:center;justify-content:space-between;gap:.5rem">
                <div>
                    <span style="font-size:13px">↳ <strong><?= e($child['label']) ?></strong></span>
                    <span style="font-size:11px;color:#9ca3af;margin-left:.35rem"><?= $child['url'] ? e($child['url']) : '' ?></span>
                </div>
                <form method="POST" action="/admin/menus/items/<?= $child['id'] ?>/delete" data-confirm="Delete?">
                    <?= csrf_field() ?><button class="btn btn-xs btn-danger">×</button>
                </form>
            </li>
            <?php endforeach; ?>
            <?php endif; ?>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>
    </div>

    <!-- Add item form -->
    <div class="card">
        <div class="card-header"><h2>Add Menu Item</h2></div>
        <div class="card-body">
            <form method="POST" action="/admin/menus/<?= $menu['id'] ?>/items">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label>Label *</label>
                    <input type="text" name="label" class="form-control" required placeholder="Home, About, Dashboard…">
                </div>
                <div class="form-group">
                    <label>URL <span style="color:#6b7280;font-weight:400">(leave blank for unlinked submenu parent)</span></label>
                    <input type="text" name="url" class="form-control" placeholder="/page/about">
                </div>
                <div class="form-group">
                    <label>Parent (for submenu items)</label>
                    <select name="parent_id" class="form-control">
                        <option value="">— Top Level —</option>
                        <?php foreach (array_filter($items, fn($i) => !$i['parent_id']) as $p): ?>
                        <option value="<?= $p['id'] ?>"><?= e($p['label']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>Visibility</label>
                        <select name="visibility" class="form-control" id="vis-select" onchange="toggleCondition(this.value)">
                            <option value="always">Always</option>
                            <option value="logged_in">Logged In Only</option>
                            <option value="logged_out">Logged Out Only</option>
                            <option value="role">By Role</option>
                            <option value="permission">By Permission</option>
                            <option value="group">By Group</option>
                        </select>
                    </div>
                    <div class="form-group" id="condition-field" style="display:none">
                        <label>Condition Value</label>
                        <input type="text" name="condition_value" class="form-control" placeholder="role-slug / permission.slug / group-slug">
                    </div>
                </div>
                <div class="form-group">
                    <label>Show Only on Pages <span style="color:#6b7280;font-weight:400">(comma-separated slugs, blank=all)</span></label>
                    <input type="text" name="show_on_pages" class="form-control" placeholder="about, contact, pricing">
                </div>
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>Icon (optional)</label>
                        <input type="text" name="icon" class="form-control" placeholder="🏠 or css class">
                    </div>
                    <div class="form-group">
                        <label>Sort Order</label>
                        <input type="number" name="sort_order" class="form-control" value="0">
                    </div>
                </div>
                <div class="form-group">
                    <label>Link Target</label>
                    <select name="target" class="form-control">
                        <option value="_self">Same window</option>
                        <option value="_blank">New tab</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Add Item</button>
            </form>
        </div>
    </div>
</div>

<script>
function toggleCondition(vis) {
    document.getElementById('condition-field').style.display =
        ['role','permission','group'].includes(vis) ? '' : 'none';
}

// Simple drag-to-reorder
const list = document.getElementById('sortable-items');
if (list) {
    let dragging = null;
    list.querySelectorAll('li').forEach(li => {
        li.addEventListener('dragstart', () => { dragging = li; li.style.opacity = '.4'; });
        li.addEventListener('dragend',   () => { dragging = null; li.style.opacity = ''; });
        li.addEventListener('dragover',  e => { e.preventDefault(); const after = getDragAfter(list, e.clientY);
            after ? list.insertBefore(dragging, after) : list.appendChild(dragging); });
        li.setAttribute('draggable', true);
    });
    list.addEventListener('drop', () => {
        const order = [...list.querySelectorAll('li')].map(li => li.dataset.id);
        csrfPost('/admin/menus/items/reorder', Object.fromEntries(order.map((id,i) => [`order[${i}]`, id])));
    });
}
function getDragAfter(container, y) {
    const items = [...container.querySelectorAll('li:not(.dragging)')];
    return items.reduce((closest, child) => {
        const box = child.getBoundingClientRect();
        const offset = y - box.top - box.height / 2;
        return (offset < 0 && offset > closest.offset) ? { offset, element: child } : closest;
    }, { offset: Number.NEGATIVE_INFINITY }).element;
}
</script>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
