<?php
// modules/menus/module.php
use Core\Module\ModuleProvider;

/**
 * Menus module — admin CRUD for the MenuService-backed navigation trees.
 * The `menu('location')` helper in core/helpers.php is what views actually
 * call; this module just provides the admin UI for editing what that helper
 * returns.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'menus'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
