# Architecture — Menus module

## Files

```
menus/
├── module.php
├── routes.php                                 # 6 routes
├── Controllers/MenuController.php             # CRUD + reorder
└── Views/
    ├── index.php                              # Menus list
    └── items.php                              # Item editor per menu
```

## Tables

- `menus` — id, name, location (unique), created_at
- `menu_items` — id, menu_id, parent_id, label, url, sort_order, created_at

## Service split

- **MenuService** — lives in core (`core/Services/MenuService.php`). Reads
  the tables, builds the nested tree, renders HTML. Used by the `menu()`
  helper in views.
- **MenuController** — lives in this module. Admin-facing CRUD only. It
  writes the tables that MenuService reads.

This split is intentional — the read path ships with core so layouts work
even without the admin UI installed. The module provides the authoring
experience.

## Rendering

`menu('primary')` helper calls `MenuService::renderLocation('primary')`
which:

1. Finds the menu row with `location = 'primary'`
2. Fetches all `menu_items` ordered by `(parent_id, sort_order)`
3. Builds the nested tree via `buildTree()`
4. Renders a `<ul><li>` nest

Override the rendering by extending MenuService and rebinding in
`config/services.php`.

## Reorder UX

The items view includes drag-and-drop. On drop, JS POSTs the new ordering
as `[{id, parent_id, sort_order}, ...]` to `/admin/menus/items/reorder`.
The controller validates and bulk-updates.

## Authorization

All routes require `AuthMiddleware + RequireAdmin`. No per-user ownership
— menus are global.

## Dependencies

- `claudephpframework-core` — MenuService, Router, View, Auth
- Core's `menus` + `menu_items` tables
