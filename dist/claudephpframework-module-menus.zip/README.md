# Menus module

Admin CRUD for navigation menus. Menus are stored as a tree of items and
rendered by the core `menu('location')` helper in views.

## Features

- Create / delete menus keyed by a location string (e.g. `primary`,
  `footer`, `sidebar`)
- Add menu items with label, URL, sort order
- Drag-to-reorder items within a menu (persisted via a POST reorder endpoint)
- Items rendered live by `MenuService::tree($location)` which the `menu()`
  helper wraps

## Routes

| Method | Path                                | Middleware              | Purpose                 |
|--------|-------------------------------------|-------------------------|-------------------------|
| GET    | `/admin/menus`                      | Auth + Admin            | List menus              |
| POST   | `/admin/menus/create`               | Csrf + Auth + Admin     | Create menu             |
| GET    | `/admin/menus/{id}/items`           | Auth + Admin            | Edit items on a menu    |
| POST   | `/admin/menus/{id}/items`           | Csrf + Auth + Admin     | Add an item             |
| POST   | `/admin/menus/items/{id}/delete`    | Csrf + Auth + Admin     | Delete an item          |
| POST   | `/admin/menus/items/reorder`        | Csrf + Auth + Admin     | Reorder (AJAX)          |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
