# Pages module

Administrable static pages with SEO metadata, custom layouts, and a
"set as guest homepage" toggle. Admin CRUD surface; public rendering
(`/{slug}`) stays in core's `routes/web.php` because it's a catch-all
that interacts with SEO redirects.

## Features

- Admin CRUD for pages with title, slug, body (rich HTML), status
  (draft/published), `is_public` visibility flag
- Per-page SEO fields: title, description, keywords
- Layout selector — pick any layout under `app/Views/layout/*.php`
- "Set as guest homepage" checkbox — writes
  `guest_home_page_slug` into the site settings scope
- Slug rename → automatic 301 redirect via `SeoManager`
- Incremental search indexing on save

## Routes

| Method | Path                              | Middleware              | Purpose            |
|--------|-----------------------------------|-------------------------|--------------------|
| GET    | `/admin/pages`                    | Auth + Admin            | Admin list         |
| GET    | `/admin/pages/create`             | Auth + Admin            | Create form        |
| POST   | `/admin/pages/create`             | Csrf + Auth + Admin     | Store              |
| GET    | `/admin/pages/{id}/edit`          | Auth + Admin            | Edit form          |
| POST   | `/admin/pages/{id}/edit`          | Csrf + Auth + Admin     | Save changes       |
| POST   | `/admin/pages/{id}/delete`        | Csrf + Auth + Admin     | Delete             |
| GET    | `/page/{slug}`                    | —                       | Legacy 301         |

The public reader for `/{slug}` lives in `routes/web.php`, not here.

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
