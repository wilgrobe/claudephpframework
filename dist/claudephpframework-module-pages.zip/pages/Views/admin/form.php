<?php $pageTitle = $page ? 'Edit Page' : 'New Page'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:900px;margin:0 auto">
<div class="card">
    <div class="card-header">
        <h2><?= $page ? 'Edit: ' . e($page['title']) : 'Create Static Page' ?></h2>
        <a href="/admin/pages" class="btn btn-secondary btn-sm">← Back</a>
    </div>
    <div class="card-body">
        <?php $errors = \Core\Session::flash('errors') ?? []; ?>
        <form method="POST" action="<?= $page ? '/admin/pages/'.$page['id'].'/edit' : '/admin/pages/create' ?>">
            <?= csrf_field() ?>

            <div class="grid grid-2">
                <div class="form-group">
                    <label>Title *</label>
                    <input type="text" name="title" class="form-control <?= !empty($errors['title'])?'is-invalid':'' ?>"
                           value="<?= e($page['title'] ?? old('title')) ?>" required oninput="autoSlugPage(this)">
                    <?php if (!empty($errors['title'])): ?><span class="form-error"><?= e($errors['title'][0]) ?></span><?php endif; ?>
                </div>
                <div class="form-group">
                    <label>URL Slug *</label>
                    <input type="text" id="page-slug" name="slug" class="form-control <?= !empty($errors['slug'])?'is-invalid':'' ?>"
                           value="<?= e($page['slug'] ?? old('slug')) ?>" required>
                    <span style="font-size:12px;color:#6b7280">URL: /page/<strong id="slug-preview"><?= e($page['slug'] ?? '') ?></strong></span>
                </div>
            </div>

            <div class="form-group">
                <?php
                // WYSIWYG body editor — see app/Views/partials/wysiwyg.php.
                // The controller runs body through Validator::sanitizeHtml() on
                // save so only allow-listed tags survive.
                $wy_name        = 'body';
                $wy_value       = $page['body'] ?? '';
                $wy_rows        = 16;
                $wy_scope       = 'page';
                $wy_label       = 'Content';
                $wy_placeholder = 'Start writing the page...';
                include BASE_PATH . '/app/Views/partials/wysiwyg.php';
                ?>
                <span style="font-size:12px;color:#6b7280;display:block;margin-top:.35rem">HTML is allowed. Only a safe subset (headings, lists, bold/italic/underline, links, blockquote) survives save.</span>
            </div>

            <div style="border:1px solid #e5e7eb;border-radius:8px;padding:1.25rem;margin-bottom:1rem;background:#f9fafb">
                <div style="font-weight:600;font-size:13px;margin-bottom:.75rem">SEO Settings</div>
                <div class="grid grid-2">
                    <div class="form-group">
                        <label>SEO Title</label>
                        <input type="text" name="seo_title" class="form-control" value="<?= e($page['seo_title'] ?? '') ?>" maxlength="255" placeholder="Defaults to page title">
                    </div>
                    <div class="form-group">
                        <label>SEO Keywords</label>
                        <input type="text" name="seo_keywords" class="form-control" value="<?= e($page['seo_keywords'] ?? '') ?>" placeholder="comma, separated, keywords">
                    </div>
                </div>
                <div class="form-group">
                    <label>Meta Description</label>
                    <textarea name="seo_description" class="form-control" rows="2" maxlength="500"><?= e($page['seo_description'] ?? '') ?></textarea>
                </div>
            </div>

            <div class="grid grid-3" style="margin-bottom:1rem">
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" class="form-control">
                        <option value="draft" <?= ($page['status'] ?? '') === 'draft' ? 'selected' : '' ?>>Draft</option>
                        <option value="published" <?= ($page['status'] ?? '') === 'published' ? 'selected' : '' ?>>Published</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Layout</label>
                    <select name="layout" class="form-control">
                        <option value="default">Default</option>
                        <option value="wide">Wide</option>
                        <option value="minimal">Minimal</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Sort Order</label>
                    <input type="number" name="sort_order" class="form-control" value="<?= e($page['sort_order'] ?? 0) ?>">
                </div>
            </div>

            <div class="form-group">
                <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-weight:400">
                    <input type="checkbox" name="is_public" value="1" <?= ($page['is_public'] ?? 1) ? 'checked' : '' ?>>
                    Publicly visible (guests can view this page)
                </label>
            </div>

            <?php
            // Home-page toggle. A page can be the site's guest home page only
            // if it's both publicly visible AND published — otherwise we'd
            // serve an orphan to guests who hit "/". The checkbox stays
            // active regardless; the server simply won't honor the request
            // on save if the page state doesn't qualify.
            $currentHomeSlug = setting('guest_home_page_slug', '');
            $isCurrentHome   = !empty($page['slug']) && $page['slug'] === $currentHomeSlug;
            ?>
            <div class="form-group" style="padding:.75rem 1rem;background:#fefce8;border:1px solid #fde68a;border-radius:6px">
                <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;font-weight:500;color:#78350f">
                    <input type="checkbox" name="is_home_page" value="1" <?= $isCurrentHome ? 'checked' : '' ?>>
                    Use as guest home page
                </label>
                <div style="font-size:12.5px;color:#78350f;margin-top:.3rem;line-height:1.5">
                    When checked, this page is shown at <code>/</code> for visitors who are not signed in.
                    <?php if ($currentHomeSlug && !$isCurrentHome): ?>
                    The current home page is <strong>/<?= e($currentHomeSlug) ?></strong>; saving with this
                    box checked will replace it.
                    <?php elseif (!$currentHomeSlug): ?>
                    No page is currently set as the home page — guests see the login screen at <code>/</code>.
                    <?php endif; ?>
                    Only takes effect when the page is Published and Publicly visible.
                </div>
            </div>

            <div style="display:flex;gap:.75rem">
                <button type="submit" class="btn btn-primary"><?= $page ? 'Save Changes' : 'Create Page' ?></button>
                <a href="/admin/pages" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</div>

<script>
function autoSlugPage(input) {
    const slug = input.value.toLowerCase().replace(/[^a-z0-9\s\-]/g,'').replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
    document.getElementById('page-slug').value = slug;
    document.getElementById('slug-preview').textContent = slug;
}
document.getElementById('page-slug')?.addEventListener('input', function() {
    document.getElementById('slug-preview').textContent = this.value;
});
</script>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
