<?php
// modules/pages/Controllers/PageController.php
namespace Modules\Pages\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Validation\Validator;
use Core\Database\Database;
use Core\SEO\SeoManager;
use Core\Services\SettingsService;

/**
 * Admin CRUD for static pages. Ported from App\Controllers\Admin\PageController.
 * Behavior is byte-for-byte identical; the only changes are:
 *   - namespace moved under Modules\Pages\Controllers
 *   - Response::view() calls use the 'pages::' namespace
 *
 * Everything else (validation rules, SEO redirect registration, home-page
 * reconciliation, audit logging) is unchanged.
 */
class PageController
{
    private Database        $db;
    private Auth            $auth;
    private SeoManager      $seo;
    private SettingsService $settings;

    public function __construct()
    {
        $this->db       = Database::getInstance();
        $this->auth     = Auth::getInstance();
        $this->seo      = new SeoManager();
        $this->settings = new SettingsService();
    }

    public function index(Request $request): Response
    {
        if ($this->auth->cannot('pages.manage')) return $this->denied();
        $pages = $this->db->fetchAll("SELECT * FROM pages ORDER BY sort_order, title");
        return Response::view('pages::admin.index', ['pages' => $pages, 'user' => $this->auth->user()]);
    }

    public function create(Request $request): Response
    {
        if ($this->auth->cannot('pages.manage')) return $this->denied();
        return Response::view('pages::admin.form', ['page' => null, 'user' => $this->auth->user()]);
    }

    public function store(Request $request): Response
    {
        if ($this->auth->cannot('pages.manage')) return $this->denied();
        $v = new Validator($request->post());
        $v->validate([
            'title'  => 'required|min:2|max:500',
            'slug'   => 'required|min:2|max:500',
            'status' => 'required|in:draft,published',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect('/admin/pages/create');
        }
        $slug          = $v->get('slug');
        $sanitizedBody = Validator::sanitizeHtml($request->post('body', ''));
        $status        = $v->get('status');
        $isPublic      = (int) $request->post('is_public', 1);

        $id = $this->db->insert('pages', [
            'title'           => $v->get('title'),
            'slug'            => $slug,
            'body'            => $sanitizedBody,
            'layout'          => $request->post('layout', 'default'),
            'status'          => $status,
            'is_public'       => $isPublic,
            'seo_title'       => $v->get('seo_title'),
            'seo_description' => $v->get('seo_description'),
            'seo_keywords'    => $v->get('seo_keywords'),
            'sort_order'      => (int) $request->post('sort_order', 0),
            'created_by'      => $this->auth->id(),
            'published_at'    => $status === 'published' ? date('Y-m-d H:i:s') : null,
        ]);
        // Register the canonical path so slug changes later can leave a 301
        // breadcrumb in seo_links.
        $this->seo->register($slug, "/$slug", 'page', $id);
        app(\Core\Services\SearchIndexer::class)->sync('pages', $id, [
            'id'        => $id,
            'title'     => $v->get('title'),
            'slug'      => $slug,
            'body'      => $sanitizedBody,
            'status'    => $status,
            'is_public' => $isPublic,
        ]);

        $this->syncHomePageSetting($slug, (bool) $request->post('is_home_page', 0));

        $this->auth->auditLog('page.create', 'pages', $id);
        return Response::redirect('/admin/pages')->withFlash('success', 'Page created.');
    }

    public function edit(Request $request): Response
    {
        if ($this->auth->cannot('pages.manage')) return $this->denied();
        $id   = (int) $request->param(0);
        $page = $this->db->fetchOne("SELECT * FROM pages WHERE id = ?", [$id]);
        if (!$page) return new Response('Not found', 404);
        return Response::view('pages::admin.form', ['page' => $page, 'user' => $this->auth->user()]);
    }

    public function update(Request $request): Response
    {
        if ($this->auth->cannot('pages.manage')) return $this->denied();
        $id   = (int) $request->param(0);
        $page = $this->db->fetchOne("SELECT * FROM pages WHERE id = ?", [$id]);
        if (!$page) return new Response('Not found', 404);

        $v = new Validator($request->post());
        $v->validate([
            'title'  => 'required|min:2|max:500',
            'slug'   => 'required|min:2|max:500',
            'status' => 'required|in:draft,published',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect("/admin/pages/$id/edit");
        }

        $oldSlug       = $page['slug'];
        $newSlug       = $v->get('slug');
        $sanitizedBody = Validator::sanitizeHtml($request->post('body', ''));
        $newStatus     = $v->get('status');
        $newIsPublic   = (int) $request->post('is_public', 1);

        $this->db->update('pages', [
            'title'           => $v->get('title'),
            'slug'            => $newSlug,
            'body'            => $sanitizedBody,
            'layout'          => $request->post('layout', 'default'),
            'status'          => $newStatus,
            'is_public'       => $newIsPublic,
            'seo_title'       => $v->get('seo_title'),
            'seo_description' => $v->get('seo_description'),
            'seo_keywords'    => $v->get('seo_keywords'),
        ], 'id = ?', [$id]);

        // If slug changed, register the new canonical path and leave a 301
        // from the old slug so bookmarks / external links keep working.
        if ($oldSlug !== $newSlug) {
            $this->seo->redirect($oldSlug, "/$newSlug");
            $this->seo->register($newSlug, "/$newSlug", 'page', $id);

            // If the renamed page was the guest home page, roll the setting
            // forward to the new slug so the homepage doesn't silently break.
            if ($this->settings->get('guest_home_page_slug', '', 'site') === $oldSlug) {
                $this->settings->set('guest_home_page_slug', $newSlug, 'site');
            }
        }

        $this->syncHomePageSetting($newSlug, (bool) $request->post('is_home_page', 0));

        app(\Core\Services\SearchIndexer::class)->sync('pages', $id, [
            'id'        => $id,
            'title'     => $v->get('title'),
            'slug'      => $newSlug,
            'body'      => $sanitizedBody,
            'status'    => $newStatus,
            'is_public' => $newIsPublic,
        ]);

        $this->auth->auditLog('page.update', 'pages', $id);
        return Response::redirect('/admin/pages')->withFlash('success', 'Page updated.');
    }

    public function delete(Request $request): Response
    {
        if ($this->auth->cannot('pages.manage')) return $this->denied();
        $id   = (int) $request->param(0);
        $page = $this->db->fetchOne("SELECT slug FROM pages WHERE id = ?", [$id]);

        $this->db->delete('pages', 'id = ?', [$id]);
        app(\Core\Services\SearchIndexer::class)->sync('pages', $id);

        // If we just deleted the guest home page, clear the setting so /
        // falls back to /login instead of serving a 404-like orphan.
        if ($page && $this->settings->get('guest_home_page_slug', '', 'site') === $page['slug']) {
            $this->settings->delete('guest_home_page_slug', 'site');
        }

        $this->auth->auditLog('page.delete', 'pages', $id);
        return Response::redirect('/admin/pages')->withFlash('success', 'Page deleted.');
    }

    // Public rendering is still served by the /{slug} catch-all in
    // routes/web.php (it interacts with SEO redirects).

    /**
     * Reconcile the "is_home_page" form checkbox with the site setting.
     * See original App\Controllers\Admin\PageController for full behavior notes.
     */
    private function syncHomePageSetting(string $slug, bool $wantHome): void
    {
        $current = (string) $this->settings->get('guest_home_page_slug', '', 'site');

        if ($wantHome) {
            if ($current !== $slug) {
                $this->settings->set('guest_home_page_slug', $slug, 'site');
            }
            return;
        }
        if ($current === $slug) {
            $this->settings->delete('guest_home_page_slug', 'site');
        }
    }

    private function denied(): Response
    {
        return Response::redirect('/admin')->withFlash('error', 'Access denied.');
    }
}
