<?php
// modules/pages/module.php
use Core\Module\ModuleProvider;

/**
 * Pages module — administrable static pages with SEO metadata, custom
 * layouts, and a "set as guest home" toggle. The public renderer for /{slug}
 * stays in routes/web.php because it's a catch-all that interacts with SEO
 * redirects; the admin CRUD lives here.
 */
return new class extends ModuleProvider {
    public function name(): string { return 'pages'; }

    public function routesFile(): ?string   { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string    { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
