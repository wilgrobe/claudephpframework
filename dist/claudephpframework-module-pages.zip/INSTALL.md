# Installation — Pages module

## Prerequisites

- `claudephpframework-core` installed.
- Core tables `pages`, `seo_links`, `settings` present (from `install.sql`).
- `pages.manage` permission granted to at least one admin role.

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-pages.zip
   cp -r claudephpframework-module-pages/pages /path/to/project/modules/
   ```

2. Run migrations (none ship):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if using production caching:
   ```bash
   php artisan module:cache
   ```

## Environment variables

None.

## Guest homepage setting

The "Set as guest home page" checkbox writes the page's slug into
`settings(key='guest_home_page_slug', scope='site')`. Core's home route in
`routes/web.php` reads this and serves the page to logged-out visitors. To
revert to the default (redirect to `/login`), uncheck the box on the
current guest home page, or run:

```php
app(\Core\Services\SettingsService::class)->delete('guest_home_page_slug', 'site');
```

## Verification

1. Visit `/admin/pages`, create a page with status=published, is_public=1.
2. Visit `/{slug}` — page renders.
3. Rename the slug via edit — verify the old slug 301-redirects to the
   new one.
4. Log out. If "Set as guest home" was checked, `/` serves the page;
   otherwise `/` redirects to `/login`.
