# Architecture — Pages module

## Files

```
pages/
├── module.php
├── routes.php                                  # 7 routes
├── Controllers/PageController.php              # CRUD + home-page toggle
└── Views/admin/
    ├── index.php                               # Admin list
    └── form.php                                # Create + edit form
```

## Tables

- `pages` — id, title, slug, body, layout, status, is_public, seo_*,
  sort_order, created_by, published_at, timestamps
- `seo_links` — canonical-path registry; used for 301 redirects when slugs
  change
- `settings` — used to store `guest_home_page_slug`

All from `install.sql`.

## Public rendering

The reader is `/{slug}` in `routes/web.php`, NOT in this module. Reason:
it's a catch-all route that needs to coordinate with:

- `seo_links` for 301 redirects on renamed slugs
- Legacy `/page/{slug}` 301 forwarding (this module DOES include that
  minor legacy redirect)
- Ordering relative to other catch-alls in web.php

Keeping the reader in core avoids the module entangling with the SEO
subsystem. The admin CRUD (where the module's value lives) moves cleanly.

## Slug rename handling

When the edit form changes a slug:

1. `SeoManager::redirect($oldSlug, "/$newSlug")` registers a 301
2. `SeoManager::register($newSlug, "/$newSlug", 'page', $id)` records the
   new canonical
3. If `guest_home_page_slug === $oldSlug`, the setting is rolled forward
   to `$newSlug` so the homepage doesn't silently break

## Search integration

After insert/update/delete, `PageController` calls
`app(SearchIndexer::class)->sync('pages', $id, $prefetchedRow)`. Indexed
document shape: `title`, `slug`, `body` (HTML-stripped). `search:reindex
pages` rebuilds.

Visibility rule for indexing (matches public view): `status = 'published'
AND is_public = 1`.

## Authorization

- All `/admin/pages*` routes: `AuthMiddleware + RequireAdmin`
- Controller gates with `$this->auth->cannot('pages.manage')` for defense
  in depth

## Dependencies

- `claudephpframework-core` — Router, Database, Auth, View, SearchIndexer,
  SettingsService, SeoManager
- Core's `pages`, `seo_links`, `settings` tables

## Extension points

- Add custom per-page fields via a migration under
  `modules/pages/migrations/`. Extend the form view and controller
  validation. If the field is searchable, add it to the indexed doc in
  both `SearchService::reindexPages()` and `SearchIndexer::buildPageDoc()`.
- Custom layouts: drop a layout under `app/Views/layout/{name}.php` and
  it appears in the layout dropdown.
