# Import-export module

Generic CSV/JSON/TSV import with a column-mapping UI, plus streaming
CSV export for any registered entity type.

## Features

- **Pluggable handlers** — each module registers what's importable /
  exportable:
  ```php
  ImportExportService::registerHandler('users', [
      'label'      => 'Users',
      'fields'     => ['email','username','first_name','last_name'],
      'upsert'     => fn(array $row, bool $dry) => ['ok' => true, 'action' => 'created'],
      'exportRows' => fn(array $filter = []) => (function() { yield $row; ... }),
  ]);
  ```
- **Admin upload flow** — `/admin/import` → upload → map columns →
  **Dry run** shows what would happen → **Run import** writes.
- **Dry run** invokes each handler's upsert with `$dryRun=true` so
  handlers can validate without mutating.
- **Error cap** — first 200 per-row errors kept in `errors_json`;
  overflow counted in stats. Keeps row size bounded for large
  imports.
- **Streaming export** — `/admin/export/{entity}.csv` pushes rows
  through the handler's `exportRows` generator straight to the
  client without materializing the whole set.
- **Built-in `users` handler** — ships enabled; upserts on email.

## Routes

| Method | Path                                 | Purpose |
|--------|--------------------------------------|---------|
| GET    | `/admin/import`                      | Pick handler + upload |
| POST   | `/admin/import/upload`               | File upload |
| GET    | `/admin/import/{id}`                 | Mapping + dry-run |
| POST   | `/admin/import/{id}/map`             | Save mapping |
| POST   | `/admin/import/{id}/run`             | Execute (with `dry_run=1` for preview) |
| GET    | `/admin/export/{entity}.csv`         | Download CSV |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
