# Architecture — Import-export

## Files

```
import-export/
├── module.php                      # registers built-in 'users' handler
├── routes.php                      # 5 admin routes + 1 export route
├── Controllers/ImportExportAdminController.php
├── Services/ImportExportService.php
├── Views/admin/{index,show}.php
└── migrations/…_create_imports_table.php
```

## Data model

```
imports:
  id, entity_type, uploaded_by NULL, file_path, file_format ENUM,
  status ENUM('uploaded','mapped','running','completed','failed'),
  mapping_json NULL, stats_json NULL, errors_json NULL,
  row_count, processed_count, timestamps
```

## Handler registry

Static `ImportExportService::$handlers` keyed by entity type. Modules
register from their `register(Container)` method. The shape:

```php
[
    'label'      => 'Users',
    'fields'     => ['email','username', ...],
    'upsert'     => callable(array $row, bool $dryRun): ['ok','error','action'],
    'exportRows' => callable(array $filter = []): iterable,
]
```

`upsert` returns `['ok' => true, 'action' => 'created'|'updated'|'skipped']`
on success, `['ok' => false, 'error' => string]` on failure. The run
loop tallies per-action counts in `stats_json`.

## Row iteration

`iterateRows($path, $format)` is a generator — streams one row at a
time. Works for CSV/TSV (fgetcsv with the appropriate delimiter) and
JSON (json_decode, then yield each top-level item). Avoids loading a
large import into memory.

## Export streaming

`streamCsvExport($type, $filter, $delim)` writes to `php://output`
line-by-line. The handler's `exportRows` is itself a generator in the
built-in examples, so the full pipeline is lazy end-to-end.

## Security notes

- Uploaded files land under `BASE_PATH/storage/imports/` with a
  random filename. The controller never trusts client-supplied paths.
- Import permission is gated by `AuthMiddleware + RequireAdmin` at
  the route layer; apps that need a finer permission can swap in
  `ImportExport.manage` seed.
- The handler's `upsert` runs raw SQL in most cases — keep the
  handler narrow; don't let it accept arbitrary field names from the
  CSV (the mapping UI constrains target fields to the handler's
  declared `fields` list, but nothing enforces that at the
  `registerHandler` side).
