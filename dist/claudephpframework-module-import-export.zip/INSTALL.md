# Installation — Import-export

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` (creates 1 table: `imports`).
3. Ensure `storage/imports/` is writable by the web server (the
   upload handler creates it if missing).

## Register handlers from your module

```php
// In your module's register(Container) method:
use Modules\ImportExport\Services\ImportExportService;

ImportExportService::registerHandler('store_products', [
    'label'  => 'Store products',
    'fields' => ['name','slug','price_cents','description','type','sku'],
    'upsert' => function (array $row, bool $dryRun): array {
        $db = \Core\Database\Database::getInstance();
        if (empty($row['slug'])) return ['ok' => false, 'error' => 'slug required'];
        if ($dryRun) return ['ok' => true, 'action' => 'updated'];
        $existing = $db->fetchOne("SELECT id FROM store_products WHERE slug = ?", [$row['slug']]);
        if ($existing) {
            $db->update('store_products', $row, 'id = ?', [(int) $existing['id']]);
            return ['ok' => true, 'action' => 'updated'];
        }
        return ['ok' => true, 'action' => 'created', 'id' => (int) $db->insert('store_products', $row)];
    },
    'exportRows' => function (array $filter = []) {
        $db = \Core\Database\Database::getInstance();
        foreach ($db->fetchAll("SELECT * FROM store_products ORDER BY id ASC") as $r) {
            yield $r;
        }
    },
]);
```

## Deferred features

- **Async runs** — for huge imports, queue the `run()` call as a job
  instead of processing sync in the request. Stats/errors update on
  completion.
- **Resume** — if a run fails midway, a resume token + row offset.
- **Attachment to moderation** — imports that write moderation-
  relevant content (users, posts) could feed moderation checks.
- **Schema-aware column guess** — fuzzy-match source headers to
  target fields ("e-mail" → "email") so the mapping UI pre-fills.

## Verification

- Download a sample CSV of users from `/admin/export/users.csv`.
- Edit one row, re-upload to `/admin/import`.
- Map columns → Dry run → "1 updated" in stats → Run → check the
  user's row in DB reflects the edit.
