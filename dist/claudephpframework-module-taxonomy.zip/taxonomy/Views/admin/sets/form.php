<?php
$pageTitle = 'New vocabulary';
$errors = \Core\Session::get('errors', []);
$old    = \Core\Session::get('old', []);
$val    = fn(string $k, string $default = '') => e($old[$k] ?? $default);
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/taxonomy/sets" class="btn btn-sm btn-secondary">← Back</a>
    <h1 style="margin:0;font-size:1.5rem">New vocabulary</h1>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="/admin/taxonomy/sets/create">
            <?= csrf_field() ?>

            <div class="form-row">
                <label>Name *</label>
                <input type="text" name="name" value="<?= $val('name') ?>" required maxlength="191" placeholder="Product Categories">
                <?php if (!empty($errors['name'])): ?><div class="error"><?= e($errors['name'][0]) ?></div><?php endif; ?>
            </div>

            <div class="form-row">
                <label>Slug *</label>
                <input type="text" name="slug" value="<?= $val('slug') ?>" required maxlength="120" pattern="[a-z0-9-]+" placeholder="product-categories">
                <small>URL-safe identifier used by <code>taxonomy_tree('your-slug')</code>.</small>
                <?php if (!empty($errors['slug'])): ?><div class="error"><?= e($errors['slug'][0]) ?></div><?php endif; ?>
            </div>

            <div class="form-row">
                <label>Description</label>
                <textarea name="description" rows="2" maxlength="500"><?= $val('description') ?></textarea>
            </div>

            <div class="form-row">
                <label><input type="checkbox" name="allow_hierarchy" value="1" <?= !isset($old['allow_hierarchy']) || !empty($old['allow_hierarchy']) ? 'checked' : '' ?>> Allow nested terms</label>
                <small>
                    Check for categories (Electronics → Phones → Smartphones).
                    Uncheck for flat tags (just a list of labels).
                </small>
            </div>

            <button class="btn btn-primary">Create vocabulary</button>
        </form>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
