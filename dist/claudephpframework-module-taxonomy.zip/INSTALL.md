# Installation — Taxonomy module

## Prerequisites

- `claudephpframework-core` installed.
- `taxonomy.manage` permission granted to at least one admin role
  (seeded by this module's second migration). Grant via `/admin/roles`.

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-taxonomy.zip
   cp -r claudephpframework-module-taxonomy/taxonomy /path/to/project/modules/
   ```

2. Run the migrations (creates 4 tables + seeds permission):
   ```bash
   php artisan migrate
   ```

3. Refresh the module manifest if you use production caching:
   ```bash
   php artisan module:cache
   ```

## Environment variables

None.

## First-use walkthrough

1. Log in as admin, visit `/admin/taxonomy/sets`.
2. **New vocabulary** → name "Product Categories", slug
   `product-categories`, check **Allow nested terms**. Create.
3. On the manage page, add top-level terms: "Electronics", "Books",
   "Clothing". Add children under Electronics: "Phones", "Laptops".
   Add grandchildren under Phones: "Smartphones", "Feature phones".
4. In any view, render the tree:

   ```php
   <?php $tree = taxonomy_tree('product-categories'); ?>
   <ul>
   <?php foreach ($tree as $node): ?>
       <li><?= e($node['name']) ?>
       <?php if (!empty($node['children'])): ?>
           <ul>
               <?php foreach ($node['children'] as $child): ?>
                   <li><?= e($child['name']) ?></li>
               <?php endforeach; ?>
           </ul>
       <?php endif; ?>
       </li>
   <?php endforeach; ?>
   </ul>
   ```

5. Attach a term to an entity from a controller:

   ```php
   attach_term('content', $item['id'], 'product-categories', 'smartphones');
   ```

6. Read attached terms in a view:

   ```php
   <?php foreach (terms_for('content', $item['id']) as $t): ?>
       <span class="badge"><?= e($t['name']) ?></span>
   <?php endforeach; ?>
   ```

## Important limitations (MVP)

- **Term moves are not supported** in this release. Once a term has a
  parent, its `parent_id` can't be changed through the service — closure-
  table updates on a move are non-trivial and we preferred shipping a
  correct smaller surface. Workaround: delete + recreate under the new
  parent (you'll lose its children; the FK cascade deletes them).
- **Max depth is 10 levels.** Exceeding raises `InvalidArgumentException`.
  Real taxonomies almost never need more; raise `TaxonomyService::MAX_DEPTH`
  if your use case demands.

## Verification

1. Run `./vendor/bin/phpunit` — should gain 10 new `TaxonomyServiceTest`
   tests.
2. Create a vocab, add a couple of nested terms, verify the tree renders
   correctly in a view.
3. Attach a term to a content item (via tinker or a controller), then
   `terms_for('content', $id)` should return it.

## Troubleshooting

- **"Max tree depth (10) exceeded"** — you're adding a term more than
  10 levels deep. Either raise the cap in `TaxonomyService::MAX_DEPTH`
  or flatten the tree.
- **"That slug is already used in this vocabulary"** — term slugs are
  unique within a set. Pick a different slug or delete the existing term.
- **"Set does not allow hierarchy — no parent terms"** — the vocabulary
  was created with `allow_hierarchy = false`. Either pick a different
  vocabulary or enable hierarchy on this one (existing flat terms stay
  where they are).
