# Architecture — Taxonomy module

## Files

```
taxonomy/
├── module.php                                             # Provider — registers helpers
├── routes.php                                             # 8 admin routes
├── Controllers/
│   └── TaxonomyAdminController.php                        # Set + term admin CRUD
├── Services/
│   └── TaxonomyService.php                                # Tree logic + closure maintenance
├── Helpers/
│   └── helpers.php                                        # Global taxonomy_tree, terms_for, attach_term, detach_term
├── Views/admin/sets/
│   ├── index.php                                          # Vocabularies list
│   ├── form.php                                           # New vocabulary form
│   └── terms.php                                          # Per-set term manager (tree + add form)
└── migrations/
    ├── 2026_04_22_210000_create_taxonomy_tables.php       # 4 tables
    └── 2026_04_22_210010_seed_taxonomy_permission.php
```

## Data model

Four tables, each with a focused responsibility.

### `taxonomy_sets` — vocabularies

```
id, name, slug (unique), description, allow_hierarchy, created_at, updated_at
```

Each row is an independent tree (or flat list). Slugs are the app's stable
identifier for a set — `taxonomy_tree('product-categories')` reads by slug.

### `taxonomy_terms` — the nodes

```
id, set_id (FK cascade), parent_id (FK cascade to terms), name, slug,
description, sort_order, timestamps

UNIQUE (set_id, slug)  — slugs unique within a set, not across sets
```

Simple adjacency list. `parent_id` NULL means top-level. Cross-set parents
are rejected by `TaxonomyService::createTerm`.

### `taxonomy_closure` — ancestor/descendant pairs

```
ancestor_id, descendant_id, depth
PRIMARY KEY (ancestor_id, descendant_id)
```

Every term has a self-row (ancestor = descendant, depth = 0) plus one row
per ancestor-at-depth. For a tree `A → B → C`:

```
(A,A,0) (B,B,0) (C,C,0)   -- self rows
(A,B,1) (A,C,2) (B,C,1)   -- ancestor rows
```

Queries that would require recursive CTEs on adjacency alone are single
SELECTs:

- **"All descendants of A"** — `WHERE ancestor_id = A AND depth > 0`
- **"Path to root from C"** — `WHERE descendant_id = C AND depth > 0 ORDER BY depth DESC`

Cost: every insert adds `1 + depth` closure rows. Bounded because
`MAX_DEPTH = 10`, so the worst case is 11 row inserts. FK cascades on
both `ancestor_id` and `descendant_id` clean up automatically on term
delete.

### `taxonomy_entity_terms` — polymorphic attach

```
term_id (FK cascade), entity_type, entity_id, created_at
PRIMARY KEY (term_id, entity_type, entity_id)
```

Type strings are app-chosen labels: `'content'`, `'page'`, `'product'`,
`'user'`. Never store PHP class names — that couples schema to code
layout and widens the attack surface if the stored value could ever be
influenced.

## Closure maintenance (insert)

On `createTerm`:

```sql
-- Self-row: every term is its own depth-0 ancestor
INSERT INTO taxonomy_closure VALUES (new_id, new_id, 0);

-- Ancestor rows: copy parent's ancestry, increment depth
INSERT INTO taxonomy_closure (ancestor_id, descendant_id, depth)
  SELECT ancestor_id, new_id, depth + 1
    FROM taxonomy_closure
   WHERE descendant_id = parent_id;
```

The INSERT is wrapped in a `$db->transaction()` along with the term
insert — a half-written term that isn't in the closure is worse than no
term at all.

## Closure maintenance (delete)

The FK cascade handles everything:

- `taxonomy_terms.parent_id` cascade → deleting a parent deletes children
- `taxonomy_closure.ancestor_id` / `.descendant_id` cascade → deleting a
  term removes all closure rows mentioning it
- `taxonomy_entity_terms.term_id` cascade → detaches the term everywhere

So `DELETE FROM taxonomy_terms WHERE id = X` unwinds the subtree +
closure + attachments in one statement.

## What's NOT in MVP

- **Move operation.** Changing a term's `parent_id` after creation would
  require: (1) deleting all closure rows (A, D) where A is an ancestor
  of the moved term but D is IN the subtree; (2) inserting new (B, D)
  rows for each B in the new parent's ancestry and each D in the subtree.
  Tricky to get right, easier to write correctly with tests. Deferred to
  a dedicated pass. For now, `updateTerm()` ignores `parent_id` changes.

- **Slug regeneration on name change.** Renaming a term doesn't touch
  its slug (so outgoing links remain valid). Admins change the slug
  manually.

- **Drag-to-reorder.** The admin view has a `sort_order` column and
  inputs but no drag UI. Set sort_order numerically and save.

- **Term metadata** (colors, icons, images). Schema has `description`
  only. Extending is a migration + view update when needed.

## Authorization

| Action                  | Who                                  |
|-------------------------|--------------------------------------|
| View trees              | Anyone (via `taxonomy_tree()`)       |
| View attached terms     | Anyone (via `terms_for()`)           |
| Attach / detach via helper | Caller's responsibility            |
| Set CRUD                | `taxonomy.manage` permission         |
| Term create / delete    | `taxonomy.manage` permission         |

Attach/detach helpers don't authorize — the caller in the host module
(e.g. ContentController) is responsible for checking that the logged-in
user can edit the entity they're tagging.

## Services used (from core)

- `Core\Database\Database` — all SQL
- `Core\Auth\Auth` — audit log + admin authorization

Nothing else. The module is self-contained.

## Integration hooks (suggested)

When you want another module to use taxonomy, the minimal change:

1. Seed a vocabulary via a one-off migration in that module:
   ```php
   $this->db->query("INSERT IGNORE INTO taxonomy_sets (name, slug, allow_hierarchy) VALUES (?, ?, ?)",
     ['Article Tags', 'article-tags', 0]);
   ```
2. In the module's edit form, add a multi-select populated from
   `terms_for()`.
3. In the save handler, call
   `app(TaxonomyService::class)->syncTerms('content', $id, $postedTermIds)`.
4. In the show view, iterate `terms_for('content', $id)`.

## Dependencies

- `claudephpframework-core` (Router, Database, Auth, Validator, Session,
  View)
- `permissions` table (for the seeded `taxonomy.manage` slug)

No dependencies on other modules. Modules consume *this* one, not the
other way around.
