# Taxonomy module

Tree primitive for the framework — reusable data structure for anything
hierarchical. Powers category trees, tag clouds, org charts, subject
classifications, nested folders, or any "things that have parents."

Every other module that needs classification bolts onto this one by calling
a view helper with a type string + id. No per-case schema.

## Features

- **Multiple vocabularies** — each is a named "term set" with its own
  independent tree. Examples: `product-categories` (nested),
  `article-tags` (flat), `difficulty-levels` (flat), `org-chart` (nested).
- **Per-set hierarchy toggle** — `allow_hierarchy=false` enforces flat
  lists (no parent terms); `true` allows arbitrary nesting up to 10
  levels deep.
- **Polymorphic attachment** — `attach_term('content', $id, 'tags', 'featured')`.
  Type strings are app-chosen labels, never PHP class names.
- **Adjacency list + closure table** — fast inserts via `parent_id`, fast
  descendant/ancestor queries via the closure table, no recursion needed.
  `descendantsOf($termId)` and `ancestorsOf($termId)` are single SELECTs.
- **Global view helpers** — `taxonomy_tree()`, `terms_for()`,
  `attach_term()`, `detach_term()`. Any module's views can use them.
- **Admin surface** at `/admin/taxonomy/sets` with vocabulary CRUD and
  nested term management.

## View-helper API

```php
// Nested tree for rendering a category menu
<?php foreach (taxonomy_tree('product-categories') as $node): ?>
    <li><?= e($node['name']) ?>
        <?php if (!empty($node['children'])): ?>
            <ul>...</ul>
        <?php endif; ?>
    </li>
<?php endforeach; ?>

// Terms attached to a specific entity
<?php foreach (terms_for('content', $item['id']) as $term): ?>
    <span class="badge"><?= e($term['name']) ?></span>
<?php endforeach; ?>

// Attach / detach from application code
attach_term('content', $item['id'], 'article-tags', 'featured');
detach_term('content', $item['id'], 'article-tags', 'featured');
```

## Routes

All admin routes require `Auth + RequireAdmin + taxonomy.manage`.

| Method | Path                                             | Purpose                |
|--------|--------------------------------------------------|------------------------|
| GET    | `/admin/taxonomy/sets`                           | List vocabularies      |
| GET/POST | `/admin/taxonomy/sets/create`                  | Create vocabulary      |
| GET    | `/admin/taxonomy/sets/{id}`                      | Manage terms           |
| POST   | `/admin/taxonomy/sets/{id}`                      | Save vocabulary meta   |
| POST   | `/admin/taxonomy/sets/{id}/delete`               | Delete vocabulary      |
| POST   | `/admin/taxonomy/sets/{id}/terms`                | Add term               |
| POST   | `/admin/taxonomy/terms/{id}/delete`              | Delete term (cascades) |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
