# Installation — Invoicing module

## Prerequisites

- `claudephpframework-core`.
- `claudephpframework-module-store` for the `store_order` source path.
- `claudephpframework-module-subscriptions` for the `subscription` source.
- **Optional:** `composer require dompdf/dompdf` for real PDF
  generation. Without it, the PDF URL serves the HTML print view.

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` (creates 3 tables, including the
   `invoice_numbering` sequence).

## Wiring auto-generation

To auto-generate invoices when a store order is paid, add one line to
the app's bootstrap or to `store/Services/OrderService::markPaid`:

```php
// After markPaid finishes its work:
if (class_exists(\Modules\Invoicing\Services\InvoiceService::class)) {
    (new \Modules\Invoicing\Services\InvoiceService())
        ->createFromStoreOrder($orderId);
}
```

For subscriptions, hook into the `invoice.paid` webhook handler in
`subscriptions/Services/SubscriptionService` after the subscription
status update:

```php
if (class_exists(\Modules\Invoicing\Services\InvoiceService::class)) {
    (new \Modules\Invoicing\Services\InvoiceService())
        ->createFromSubscription(
            (int) $existing['id'],
            (int) ($invoice['amount_paid'] ?? 0),
            strtoupper((string) ($invoice['currency'] ?? 'USD')),
            !empty($sub['current_period_end'])
                ? date('Y-m-d H:i:s', (int) $sub['current_period_end'])
                : null
        );
}
```

Both are idempotent — re-running the webhook is safe.

## Deferred features

- **Email delivery** — "Send invoice" action that emails the PDF via
  `MailService`. Hook live; MailService wiring is a 20-line job.
- **Manual / ad-hoc invoices** — the schema supports `source='manual'`
  with NULL source_id; a form for it is deferred.
- **Credit notes** — negative invoices for refunds.
- **Number prefix customization** — today `INV-YYYY-` is hardcoded in
  `nextNumber`. Move to config if per-company/per-country prefixes
  are needed.
