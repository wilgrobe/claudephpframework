# Invoicing module

Invoices auto-generated from paid store orders and subscription
renewals, plus a customer download surface and admin management.
PDFs via dompdf when available; HTML print view as graceful fallback
when the optional dep isn't installed.

## Features

- **Invoice numbering** — `INV-YYYY-NNNNNN` monotonic by year,
  atomic via `invoice_numbering` sequence table.
- **Sources**: `store_order`, `subscription`, `manual`. UNIQUE
  (source, source_id) makes `createFromStoreOrder` idempotent.
- **Snapshots** at creation — later edits on the source don't change
  the invoice (legally important, also user-friendly).
- **Customer surface** — `/billing/invoices` list, per-invoice HTML
  view, PDF download.
- **Admin** — `/admin/invoices` with status tabs, status
  transitions, "generate from order" action.
- **Graceful PDF** — `InvoicePdfService` uses dompdf if installed
  (composer require dompdf/dompdf), else streams the HTML print view.

## Routes

| Method | Path                                      | Purpose           |
|--------|-------------------------------------------|-------------------|
| GET    | `/billing/invoices`                       | Customer list     |
| GET    | `/billing/invoices/{number}`              | HTML print view   |
| GET    | `/billing/invoices/{number}/pdf`          | PDF download      |
| GET    | `/admin/invoices`                         | Admin list        |
| GET    | `/admin/invoices/{id}`                    | Admin detail      |
| GET    | `/admin/invoices/{id}/pdf`                | Admin PDF         |
| POST   | `/admin/invoices/{id}/status/{status}`    | Status change     |
| POST   | `/admin/invoices/from-order/{oid}`        | Generate manually |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
