# Architecture — Invoicing module

## Files

```
invoicing/
├── module.php
├── routes.php                      # 8 routes
├── Controllers/
│   ├── InvoiceController.php       # Customer /billing/invoices
│   └── InvoiceAdminController.php  # /admin/invoices
├── Services/
│   ├── InvoiceService.php          # Create, reads, status, numbering
│   └── InvoicePdfService.php       # Render via dompdf (or HTML fallback)
├── Views/
│   ├── public/{index,show}.php
│   └── admin/{index,show}.php
└── migrations/…_create_invoicing_tables.php
```

## Data model

```
invoices:
  id, number (unique), source ENUM, source_id,
  user_id, customer_email, customer_name, billing_address,
  currency, subtotal_cents, shipping_cents, tax_cents, discount_cents,
  total_cents, status ENUM, issued_at, due_at, paid_at, notes,
  timestamps
  UNIQUE (source, source_id)

invoice_lines:
  id, invoice_id CASCADE, description, qty, unit_cents, total_cents,
  sort_order, created_at

invoice_numbering:
  year PK, seq
```

## Numbering

`nextNumber()` does `INSERT ... ON DUPLICATE KEY UPDATE seq = seq + 1`
against `invoice_numbering`, then re-reads the post-increment. MySQL
handles the atomicity — concurrent callers never collide on the same
value.

## Source idempotency

`UNIQUE (source, source_id)` guarantees one invoice per store order
and one per subscription. `createFromStoreOrder($id)` returns the
existing invoice id if one already exists. Callers don't need
de-dup logic; they can call on every webhook delivery without worry.

## PDF degradation

`InvoicePdfService::render` checks `class_exists(\Dompdf\Dompdf::class)`.
When present, returns `['ok' => true, 'pdf' => bytes]`. When absent,
returns `['ok' => false, 'html' => ...]` and the controller streams
the HTML with `Content-Type: text/html` — users can still print.
