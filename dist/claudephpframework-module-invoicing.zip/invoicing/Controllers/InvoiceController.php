<?php
// modules/invoicing/Controllers/InvoiceController.php
namespace Modules\Invoicing\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Invoicing\Services\InvoicePdfService;
use Modules\Invoicing\Services\InvoiceService;

/**
 * Customer-facing invoicing.
 *   GET /billing/invoices              — list of the user's invoices
 *   GET /billing/invoices/{number}     — HTML print view
 *   GET /billing/invoices/{number}/pdf — PDF download (falls back to HTML if dompdf absent)
 */
class InvoiceController
{
    private Auth              $auth;
    private InvoiceService    $svc;
    private InvoicePdfService $pdf;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new InvoiceService();
        $this->pdf  = new InvoicePdfService();
    }

    public function index(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        return Response::view('invoicing::public.index', [
            'invoices' => $this->svc->forUser((int) $this->auth->id()),
        ]);
    }

    public function show(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $num = (string) $request->param(0);
        $inv = $this->svc->findByNumber($num);
        if (!$inv || (int) ($inv['user_id'] ?? 0) !== (int) $this->auth->id()) {
            return new Response('Invoice not found', 404);
        }
        return Response::view('invoicing::public.show', [
            'invoice' => $inv,
            'lines'   => $this->svc->linesFor((int) $inv['id']),
        ]);
    }

    public function pdf(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $num = (string) $request->param(0);
        $inv = $this->svc->findByNumber($num);
        if (!$inv || (int) ($inv['user_id'] ?? 0) !== (int) $this->auth->id()) {
            return new Response('Invoice not found', 404);
        }
        $lines = $this->svc->linesFor((int) $inv['id']);
        $res = $this->pdf->render($inv, $lines);
        if (!$res['ok']) {
            // dompdf not installed — stream the HTML as the print view.
            return (new Response($res['html'], 200, ['Content-Type' => 'text/html; charset=UTF-8']));
        }
        return new Response(
            $res['pdf'], 200,
            [
                'Content-Type'        => 'application/pdf',
                'Content-Disposition' => 'attachment; filename="' . $res['filename'] . '"',
            ]
        );
    }
}
