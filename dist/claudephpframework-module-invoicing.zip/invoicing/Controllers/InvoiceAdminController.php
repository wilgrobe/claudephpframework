<?php
// modules/invoicing/Controllers/InvoiceAdminController.php
namespace Modules\Invoicing\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Invoicing\Services\InvoicePdfService;
use Modules\Invoicing\Services\InvoiceService;

/**
 * Admin invoicing.
 *   GET  /admin/invoices                    — list
 *   GET  /admin/invoices/{id}               — detail
 *   GET  /admin/invoices/{id}/pdf           — download PDF
 *   POST /admin/invoices/{id}/status/{s}    — status transition
 *   POST /admin/invoices/from-order/{oid}   — manually (re-)generate from a store order
 */
class InvoiceAdminController
{
    private Auth              $auth;
    private InvoiceService    $svc;
    private InvoicePdfService $pdf;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new InvoiceService();
        $this->pdf  = new InvoicePdfService();
    }

    public function index(Request $request): Response
    {
        $status = (string) $request->query('status');
        $page   = max(1, (int) $request->query('page', 1));
        $res = $this->svc->listAll($status ?: null, $page, 50);
        return Response::view('invoicing::admin.index', $res + ['status' => $status]);
    }

    public function show(Request $request): Response
    {
        $id = (int) $request->param(0);
        $inv = $this->svc->find($id);
        if (!$inv) return new Response('Not found', 404);
        return Response::view('invoicing::admin.show', [
            'invoice' => $inv,
            'lines'   => $this->svc->linesFor($id),
        ]);
    }

    public function pdf(Request $request): Response
    {
        $id = (int) $request->param(0);
        $inv = $this->svc->find($id);
        if (!$inv) return new Response('Not found', 404);
        $res = $this->pdf->render($inv, $this->svc->linesFor($id));
        if (!$res['ok']) {
            return new Response($res['html'], 200, ['Content-Type' => 'text/html; charset=UTF-8']);
        }
        return new Response($res['pdf'], 200, [
            'Content-Type'        => 'application/pdf',
            'Content-Disposition' => 'attachment; filename="' . $res['filename'] . '"',
        ]);
    }

    public function setStatus(Request $request): Response
    {
        $id     = (int) $request->param(0);
        $status = (string) $request->param(1);
        try { $this->svc->setStatus($id, $status); }
        catch (\InvalidArgumentException $e) {
            return Response::redirect("/admin/invoices/$id")->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/admin/invoices/$id");
    }

    public function generateFromOrder(Request $request): Response
    {
        $orderId = (int) $request->param(0);
        $invId = $this->svc->createFromStoreOrder($orderId);
        if ($invId === null) return Response::redirect('/admin/invoices')->withFlash('error', 'Order not found.');
        return Response::redirect("/admin/invoices/$invId")->withFlash('success', 'Invoice generated.');
    }
}
