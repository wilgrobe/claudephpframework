<?php
// modules/invoicing/Services/InvoiceService.php
namespace Modules\Invoicing\Services;

use Core\Database\Database;

/**
 * Invoice creation + reads + status transitions.
 *
 * Invoice numbers: INV-YYYY-NNNNNN. Monotonic within the year,
 * reset each new year. `invoice_numbering` is a tiny sequence table;
 * `nextNumber()` uses a transactional SELECT-FOR-UPDATE to keep
 * concurrent `createFromStoreOrder` callers from colliding on the
 * seq.
 *
 * Source dedup: UNIQUE (source, source_id) guarantees one invoice per
 * store_order (and per subscription). Idempotent calls — a second
 * `createFromStoreOrder` for the same order returns the existing
 * invoice rather than creating a duplicate.
 */
class InvoiceService
{
    public const STATUSES = ['draft','sent','paid','void','refunded'];
    public const SOURCES  = ['store_order','subscription','manual'];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Reads ─────────────────────────────────────────────────────────────

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM invoices WHERE id = ?", [$id]);
    }

    public function findByNumber(string $number): ?array
    {
        return $this->db->fetchOne("SELECT * FROM invoices WHERE number = ?", [$number]);
    }

    public function findBySource(string $source, int $sourceId): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM invoices WHERE source = ? AND source_id = ?",
            [$source, $sourceId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function linesFor(int $invoiceId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM invoice_lines WHERE invoice_id = ? ORDER BY sort_order ASC, id ASC",
            [$invoiceId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function forUser(int $userId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM invoices WHERE user_id = ? ORDER BY created_at DESC",
            [$userId]
        );
    }

    /**
     * @return array{items: array<int, array<string, mixed>>, total: int}
     */
    public function listAll(?string $status = null, int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        if ($status && in_array($status, self::STATUSES, true)) {
            $where = 'WHERE status = ?'; $bind = [$status];
        } else {
            $where = ''; $bind = [];
        }
        $items = $this->db->fetchAll(
            "SELECT * FROM invoices $where ORDER BY created_at DESC LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM invoices $where", $bind
        );
        return ['items' => $items, 'total' => $total];
    }

    // ── Creation from sources ────────────────────────────────────────────

    /**
     * Create an invoice from a paid store_orders row. Idempotent per
     * order_id. Returns the invoice id (new or existing).
     */
    public function createFromStoreOrder(int $orderId): ?int
    {
        $existing = $this->findBySource('store_order', $orderId);
        if ($existing) return (int) $existing['id'];

        $order = $this->db->fetchOne("SELECT * FROM store_orders WHERE id = ?", [$orderId]);
        if (!$order) return null;

        $shipping = $order['shipping_address_json'] ? json_decode((string) $order['shipping_address_json'], true) : null;

        $invoiceId = (int) $this->db->insert('invoices', [
            'number'          => $this->nextNumber(),
            'source'          => 'store_order',
            'source_id'       => $orderId,
            'user_id'         => $order['user_id'],
            'customer_email'  => (string) $order['email'],
            'customer_name'   => $shipping ? (string) ($shipping['name'] ?? '') : null,
            'billing_address' => $shipping ? $this->formatAddress($shipping) : null,
            'currency'        => (string) $order['currency'],
            'subtotal_cents'  => (int) $order['subtotal_cents'],
            'shipping_cents'  => (int) $order['shipping_cents'],
            'tax_cents'       => (int) $order['tax_cents'],
            'discount_cents'  => (int) ($order['discount_cents'] ?? 0),
            'total_cents'     => (int) $order['total_cents'],
            'status'          => (string) $order['status'] === 'paid' ? 'paid' : 'sent',
            'issued_at'       => (string) ($order['placed_at'] ?? date('Y-m-d H:i:s')),
            'paid_at'         => (string) $order['status'] === 'paid' ? (string) ($order['placed_at'] ?? date('Y-m-d H:i:s')) : null,
        ]);

        // Copy line items from the order.
        $items = $this->db->fetchAll(
            "SELECT * FROM store_order_items WHERE order_id = ? ORDER BY id ASC", [$orderId]
        );
        $i = 1;
        foreach ($items as $it) {
            $this->db->insert('invoice_lines', [
                'invoice_id'  => $invoiceId,
                'description' => (string) $it['name_snap'],
                'qty'         => (int) $it['qty'],
                'unit_cents'  => (int) $it['price_cents'],
                'total_cents' => (int) $it['total_cents'],
                'sort_order'  => $i++,
            ]);
        }
        return $invoiceId;
    }

    /**
     * Create an invoice from a subscription event. $periodStart/$periodEnd
     * come from the Stripe invoice.paid event; $amountCents is Stripe's
     * invoice total. Idempotent per (subscription, period_start) by
     * convention — we set source_id = subscription_id but uniqueness is
     * only at that level; if a subscription charges twice in the same
     * day you'll need a finer-grained dedup.
     */
    public function createFromSubscription(int $subscriptionId, int $amountCents, string $currency, ?string $periodEnd = null): ?int
    {
        $sub = $this->db->fetchOne("SELECT * FROM subscriptions WHERE id = ?", [$subscriptionId]);
        if (!$sub) return null;
        $plan = !empty($sub['plan_id'])
            ? $this->db->fetchOne("SELECT * FROM subscription_plans WHERE id = ?", [(int) $sub['plan_id']])
            : null;
        $user = !empty($sub['user_id'])
            ? $this->db->fetchOne("SELECT email, username FROM users WHERE id = ?", [(int) $sub['user_id']])
            : null;

        $invoiceId = (int) $this->db->insert('invoices', [
            'number'          => $this->nextNumber(),
            'source'          => 'subscription',
            'source_id'       => $subscriptionId,
            'user_id'         => $sub['user_id'] ?? null,
            'customer_email'  => (string) ($user['email'] ?? ''),
            'customer_name'   => $user['username'] ?? null,
            'currency'        => $currency,
            'subtotal_cents'  => $amountCents,
            'shipping_cents'  => 0,
            'tax_cents'       => 0,
            'discount_cents'  => 0,
            'total_cents'     => $amountCents,
            'status'          => 'paid',
            'issued_at'       => date('Y-m-d H:i:s'),
            'paid_at'         => date('Y-m-d H:i:s'),
            'due_at'          => $periodEnd,
        ]);

        $desc = $plan ? (string) $plan['name'] : 'Subscription renewal';
        if ($periodEnd) $desc .= ' (period ends ' . date('M j, Y', strtotime($periodEnd)) . ')';

        $this->db->insert('invoice_lines', [
            'invoice_id'  => $invoiceId,
            'description' => $desc,
            'qty'         => 1,
            'unit_cents'  => $amountCents,
            'total_cents' => $amountCents,
            'sort_order'  => 1,
        ]);
        return $invoiceId;
    }

    // ── Status ───────────────────────────────────────────────────────────

    public function setStatus(int $invoiceId, string $status): void
    {
        if (!in_array($status, self::STATUSES, true)) {
            throw new \InvalidArgumentException("Unknown status: $status");
        }
        $updates = ['status' => $status];
        if ($status === 'paid') $updates['paid_at'] = date('Y-m-d H:i:s');
        $this->db->update('invoices', $updates, 'id = ?', [$invoiceId]);
    }

    // ── Numbering ────────────────────────────────────────────────────────

    /**
     * Atomic next number. Uses a transaction + INSERT ... ON DUPLICATE
     * KEY UPDATE pattern on invoice_numbering so concurrent callers
     * don't collide on the same seq.
     */
    public function nextNumber(): string
    {
        $year = (int) date('Y');
        // MySQL-specific but matches the framework's stack. Increments
        // atomically; returns the incremented value.
        $this->db->query(
            "INSERT INTO invoice_numbering (year, seq) VALUES (?, 1)
               ON DUPLICATE KEY UPDATE seq = seq + 1",
            [$year]
        );
        $seq = (int) $this->db->fetchColumn(
            "SELECT seq FROM invoice_numbering WHERE year = ?", [$year]
        );
        return sprintf('INV-%04d-%06d', $year, $seq);
    }

    private function formatAddress(array $addr): string
    {
        $parts = array_filter([
            $addr['line1']   ?? null,
            $addr['line2']   ?? null,
            trim(trim(($addr['city'] ?? '') . ', ' . ($addr['region'] ?? '')) . ' ' . ($addr['postal'] ?? '')),
            $addr['country'] ?? null,
        ]);
        return implode("\n", $parts);
    }
}
