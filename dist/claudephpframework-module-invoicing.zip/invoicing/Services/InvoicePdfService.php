<?php
// modules/invoicing/Services/InvoicePdfService.php
namespace Modules\Invoicing\Services;

/**
 * Render an invoice as a PDF.
 *
 * Uses dompdf when available (composer install dompdf/dompdf). Falls
 * back to rendering the HTML-only view when it isn't — the customer
 * can still view/print the invoice, they just can't download a real
 * PDF file. Keeping dompdf as an optional dependency avoids a heavy
 * default composer requirement for apps that don't care about PDFs.
 *
 * Output shape:
 *   ['ok' => true,  'pdf' => <bytes>, 'filename' => 'INV-...pdf']
 *   ['ok' => false, 'html' => <html>, 'reason' => 'no_pdf_library']
 *
 * Callers handle both — the InvoiceController sends the bytes as an
 * application/pdf download on `ok`, or redirects to an HTML print
 * view otherwise.
 */
class InvoicePdfService
{
    public function render(array $invoice, array $lines): array
    {
        $html = $this->html($invoice, $lines);
        $filename = preg_replace('~[^A-Za-z0-9\-]~', '', (string) $invoice['number']) . '.pdf';

        if (class_exists(\Dompdf\Dompdf::class)) {
            $dompdf = new \Dompdf\Dompdf(['isRemoteEnabled' => false]);
            $dompdf->loadHtml($html, 'UTF-8');
            $dompdf->setPaper('letter', 'portrait');
            $dompdf->render();
            return [
                'ok'       => true,
                'pdf'      => $dompdf->output(),
                'filename' => $filename,
            ];
        }

        // Graceful degradation.
        return [
            'ok'     => false,
            'html'   => $html,
            'reason' => 'no_pdf_library',
        ];
    }

    /**
     * HTML for both the PDF render and the fallback print view.
     * Minimal styling — printable, monochrome-friendly, no external
     * assets (dompdf can't fetch remote URLs when isRemoteEnabled=false).
     */
    public function html(array $invoice, array $lines): string
    {
        $brand = htmlspecialchars((string) (config('app.name') ?? 'Your Store'), ENT_QUOTES | ENT_HTML5);
        $num   = htmlspecialchars((string) $invoice['number']);
        $email = htmlspecialchars((string) $invoice['customer_email']);
        $name  = htmlspecialchars((string) ($invoice['customer_name'] ?? ''));
        $addr  = nl2br(htmlspecialchars((string) ($invoice['billing_address'] ?? '')));
        $status = htmlspecialchars((string) $invoice['status']);
        $issued = !empty($invoice['issued_at']) ? date('M j, Y', strtotime((string) $invoice['issued_at'])) : '—';
        $due    = !empty($invoice['due_at'])    ? date('M j, Y', strtotime((string) $invoice['due_at']))    : '—';
        $cur    = htmlspecialchars((string) $invoice['currency']);

        $linesHtml = '';
        foreach ($lines as $l) {
            $linesHtml .= '<tr>'
                . '<td>' . htmlspecialchars((string) $l['description']) . '</td>'
                . '<td style="text-align:right">' . (int) $l['qty'] . '</td>'
                . '<td style="text-align:right">' . number_format((int) $l['unit_cents']  / 100, 2) . '</td>'
                . '<td style="text-align:right">' . number_format((int) $l['total_cents'] / 100, 2) . '</td>'
                . '</tr>';
        }

        $discountRow = (int) $invoice['discount_cents'] > 0
            ? '<tr><td colspan="3" style="text-align:right;color:#059669">Discount</td><td style="text-align:right;color:#059669">−' . number_format((int) $invoice['discount_cents'] / 100, 2) . '</td></tr>'
            : '';

        $sub      = number_format((int) $invoice['subtotal_cents'] / 100, 2);
        $shipping = number_format((int) $invoice['shipping_cents'] / 100, 2);
        $tax      = number_format((int) $invoice['tax_cents']      / 100, 2);
        $total    = number_format((int) $invoice['total_cents']    / 100, 2);

        return <<<HTML
<!doctype html>
<html><head><meta charset="UTF-8"><title>Invoice $num</title>
<style>
  body { font-family: Helvetica, Arial, sans-serif; font-size: 12px; color: #111827; }
  h1 { font-size: 20px; margin: 0 0 .25rem 0; }
  .muted { color: #6b7280; }
  .header { display: flex; justify-content: space-between; margin-bottom: 2rem; }
  table.lines { width: 100%; border-collapse: collapse; margin-top: 1rem; }
  table.lines th, table.lines td { padding: .5rem; border-bottom: 1px solid #e5e7eb; }
  table.lines thead th { text-align: left; color: #6b7280; text-transform: uppercase; font-size: 11px; }
  .totals { width: 100%; border-collapse: collapse; }
  .totals td { padding: .3rem .5rem; }
  .status-paid { color: #059669; font-weight: 600; }
  .status-sent { color: #f59e0b; font-weight: 600; }
  .status-void { color: #6b7280; text-decoration: line-through; }
</style></head>
<body>
  <div class="header">
    <div>
      <h1>$brand</h1>
      <div class="muted">Invoice $num</div>
    </div>
    <div style="text-align:right">
      <div class="muted">Issued: $issued</div>
      <div class="muted">Due: $due</div>
      <div class="status-$status">$status</div>
    </div>
  </div>

  <div style="margin-bottom:1rem">
    <div class="muted">Bill to</div>
    <div><strong>$name</strong></div>
    <div>$email</div>
    <div class="muted" style="margin-top:.25rem">$addr</div>
  </div>

  <table class="lines">
    <thead><tr><th>Description</th><th style="text-align:right">Qty</th><th style="text-align:right">Unit</th><th style="text-align:right">Line total</th></tr></thead>
    <tbody>$linesHtml</tbody>
  </table>

  <table class="totals" style="margin-top:1rem">
    <tr><td colspan="3" style="text-align:right" class="muted">Subtotal</td><td style="text-align:right">$sub</td></tr>
    <tr><td colspan="3" style="text-align:right" class="muted">Shipping</td><td style="text-align:right">$shipping</td></tr>
    <tr><td colspan="3" style="text-align:right" class="muted">Tax</td><td style="text-align:right">$tax</td></tr>
    $discountRow
    <tr><td colspan="3" style="text-align:right;font-weight:600;font-size:14px">Total ($cur)</td><td style="text-align:right;font-weight:600;font-size:14px">$total</td></tr>
  </table>
</body></html>
HTML;
    }
}
