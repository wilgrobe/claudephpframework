<?php $pageTitle = 'Your invoices'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Invoices</h1>

<?php if (empty($invoices)): ?>
<div class="card"><div class="card-body" style="color:#9ca3af;text-align:center;padding:3rem 1rem">
    No invoices yet.
</div></div>
<?php else: ?>
<div class="card">
    <table class="table">
        <thead><tr><th>Number</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($invoices as $i): ?>
        <tr>
            <td><code><?= e((string) $i['number']) ?></code></td>
            <td style="font-size:13px"><?= e(date('M j, Y', strtotime((string) ($i['issued_at'] ?? $i['created_at'])))) ?></td>
            <td><?= e((string) $i['currency']) ?> <?= number_format((int) $i['total_cents'] / 100, 2) ?></td>
            <td><span class="badge"><?= e((string) $i['status']) ?></span></td>
            <td>
                <a href="/billing/invoices/<?= e((string) $i['number']) ?>" class="btn btn-sm btn-secondary">View</a>
                <a href="/billing/invoices/<?= e((string) $i['number']) ?>/pdf" class="btn btn-sm btn-primary">PDF</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
