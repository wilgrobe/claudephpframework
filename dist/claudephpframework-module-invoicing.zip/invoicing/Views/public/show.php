<?php $pageTitle = 'Invoice ' . $invoice['number']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:760px;margin:0 auto">
<a href="/billing/invoices" style="color:#6b7280;font-size:13px;text-decoration:none">← Invoices</a>

<div style="display:flex;justify-content:space-between;align-items:baseline;margin-top:.5rem">
    <h1 style="margin:0">Invoice <?= e((string) $invoice['number']) ?></h1>
    <a href="/billing/invoices/<?= e((string) $invoice['number']) ?>/pdf" class="btn btn-primary">Download PDF</a>
</div>

<?php
$svc = new \Modules\Invoicing\Services\InvoicePdfService();
echo $svc->html($invoice, $lines);
?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
