<?php $pageTitle = 'Invoices'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header"><h2 style="margin:0">Invoices <span style="color:#9ca3af;font-size:13px">(<?= (int) ($total ?? 0) ?>)</span></h2></div>
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem;flex-wrap:wrap">
        <a href="/admin/invoices" class="btn btn-sm <?= empty($status) ? 'btn-primary' : 'btn-secondary' ?>">All</a>
        <?php foreach (['draft','sent','paid','void','refunded'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= ($status ?? '') === $s ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($s) ?></a>
        <?php endforeach; ?>
    </div>
    <?php if (empty($items)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No invoices in this status.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Number</th><th>Source</th><th>Customer</th><th>Total</th><th>Issued</th><th>Status</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($items as $i): ?>
        <tr>
            <td><code><?= e((string) $i['number']) ?></code></td>
            <td style="font-size:12px"><?= e((string) $i['source']) ?><?= $i['source_id'] ? ' #' . (int) $i['source_id'] : '' ?></td>
            <td><?= e((string) $i['customer_email']) ?></td>
            <td><?= e((string) $i['currency']) ?> <?= number_format((int) $i['total_cents'] / 100, 2) ?></td>
            <td style="font-size:12px"><?= $i['issued_at'] ? e(date('M j, Y', strtotime((string) $i['issued_at']))) : '—' ?></td>
            <td><?= e((string) $i['status']) ?></td>
            <td><a href="/admin/invoices/<?= (int) $i['id'] ?>" class="btn btn-sm btn-secondary">View</a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
