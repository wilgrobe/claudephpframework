<?php $pageTitle = 'Invoice ' . $invoice['number']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<a href="/admin/invoices" style="color:#6b7280;font-size:13px;text-decoration:none">← Invoices</a>

<div style="display:flex;justify-content:space-between;align-items:baseline;margin-top:.5rem">
    <h1 style="margin:0">Invoice <?= e((string) $invoice['number']) ?></h1>
    <div>
        <a href="/admin/invoices/<?= (int) $invoice['id'] ?>/pdf" class="btn btn-primary">PDF</a>
        <span class="badge" style="margin-left:.5rem"><?= e((string) $invoice['status']) ?></span>
    </div>
</div>

<div style="display:grid;gap:1rem;grid-template-columns:2fr 1fr;margin-top:1rem">
<div>
<?php
$svc = new \Modules\Invoicing\Services\InvoicePdfService();
echo $svc->html($invoice, $lines);
?>
</div>

<aside>
    <div class="card">
        <div class="card-header"><strong>Status</strong></div>
        <div class="card-body">
            <?php foreach (['draft','sent','paid','void','refunded'] as $s): if ($s === $invoice['status']) continue; ?>
            <form method="post" action="/admin/invoices/<?= (int) $invoice['id'] ?>/status/<?= e($s) ?>" style="display:inline-block;margin:.15rem">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-sm btn-secondary"><?= ucfirst($s) ?></button>
            </form>
            <?php endforeach; ?>
        </div>
    </div>
</aside>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
