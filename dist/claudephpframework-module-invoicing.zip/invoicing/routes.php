<?php
// modules/invoicing/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$C = 'Modules\Invoicing\Controllers\InvoiceController';
$A = 'Modules\Invoicing\Controllers\InvoiceAdminController';

// Customer
$router->get('/billing/invoices',              "$C@index", [AuthMiddleware::class]);
$router->get('/billing/invoices/{number}',     "$C@show",  [AuthMiddleware::class]);
$router->get('/billing/invoices/{number}/pdf', "$C@pdf",   [AuthMiddleware::class]);

// Admin
$admin     = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];
$router->get ('/admin/invoices',                         "$A@index",              $admin);
$router->get ('/admin/invoices/{id}',                    "$A@show",               $admin);
$router->get ('/admin/invoices/{id}/pdf',                "$A@pdf",                $admin);
$router->post('/admin/invoices/{id}/status/{status}',    "$A@setStatus",          $adminCsrf);
$router->post('/admin/invoices/from-order/{oid}',        "$A@generateFromOrder",  $adminCsrf);
