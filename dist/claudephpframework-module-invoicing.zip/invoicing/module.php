<?php
// modules/invoicing/module.php
use Core\Container\Container;
use Core\Database\Database;
use Core\Module\ModuleProvider;

/**
 * Invoicing module — invoices generated from store orders and
 * subscription renewals, plus a customer download surface and admin
 * management.
 *
 * PDF generation uses dompdf when installed (optional composer dep).
 * Without it, the PDF route falls back to an HTML print view so
 * customers can still print their invoice — the integration path
 * degrades gracefully rather than 500ing.
 *
 * Auto-generation wires:
 *   store — the store's OrderService::markPaid doesn't call into this
 *     module directly (avoids a hard coupling). Apps that want
 *     auto-generation set up a one-line hook in their app bootstrap,
 *     or use the /admin/invoices/from-order/{id} form. A follow-up
 *     can add an event bus for decoupled integration.
 *   subscriptions — same pattern. A webhook handler addition in the
 *     subscriptions module can call
 *     InvoiceService::createFromSubscription on invoice.paid events.
 *     Not wired here to keep modules independent.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'invoicing'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
