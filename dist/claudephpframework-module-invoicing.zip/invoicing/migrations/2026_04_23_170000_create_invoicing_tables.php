<?php
// modules/invoicing/migrations/2026_04_23_170000_create_invoicing_tables.php
use Core\Database\Migration;

/**
 * Schema for the invoicing module.
 *
 *   invoices         — the header. `number` is customer-facing
 *                      (INV-YYYY-NNNNNN monotonic by year). `source`
 *                      links back to what produced it —
 *                      'store_order' + source_id = store_orders.id,
 *                      'subscription' + source_id = subscriptions.id.
 *                      For future standalone invoices, source='manual'
 *                      with source_id NULL.
 *                      Totals are snapshotted at invoice creation so
 *                      later edits on the source row don't change the
 *                      invoice.
 *
 *   invoice_lines    — line items (description + qty + unit_cents +
 *                      total_cents). Mirrored from the source order's
 *                      items or the subscription's plan.
 *
 *   invoice_renders  — cache of generated PDFs. One row per (invoice,
 *                      render_key) so re-downloads don't re-generate.
 *                      `render_key` = sha256(invoice state) so content
 *                      changes invalidate the cache by producing a new
 *                      key; stale rows can be GC'd out of band.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE invoices (
                id                INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                number            VARCHAR(32)  NOT NULL,
                source            ENUM('store_order','subscription','manual') NOT NULL,
                source_id         INT UNSIGNED NULL,
                user_id           INT UNSIGNED NULL,
                customer_email    VARCHAR(191) NOT NULL,
                customer_name     VARCHAR(191) NULL,
                billing_address   TEXT NULL,
                currency          VARCHAR(8)   NOT NULL DEFAULT 'USD',
                subtotal_cents    INT UNSIGNED NOT NULL DEFAULT 0,
                shipping_cents    INT UNSIGNED NOT NULL DEFAULT 0,
                tax_cents         INT UNSIGNED NOT NULL DEFAULT 0,
                discount_cents    INT UNSIGNED NOT NULL DEFAULT 0,
                total_cents       INT UNSIGNED NOT NULL DEFAULT 0,
                status            ENUM('draft','sent','paid','void','refunded') NOT NULL DEFAULT 'draft',
                issued_at         DATETIME NULL,
                due_at            DATETIME NULL,
                paid_at           DATETIME NULL,
                notes             TEXT NULL,
                created_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at        DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_number (number),
                UNIQUE KEY uq_source (source, source_id),
                KEY idx_user_status   (user_id, status),
                KEY idx_status_issued (status, issued_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE invoice_lines (
                id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                invoice_id   INT UNSIGNED NOT NULL,
                description  VARCHAR(500) NOT NULL,
                qty          INT UNSIGNED NOT NULL DEFAULT 1,
                unit_cents   INT UNSIGNED NOT NULL DEFAULT 0,
                total_cents  INT UNSIGNED NOT NULL DEFAULT 0,
                sort_order   INT UNSIGNED NOT NULL DEFAULT 0,
                created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                KEY idx_invoice (invoice_id),
                CONSTRAINT fk_il_invoice FOREIGN KEY (invoice_id)
                    REFERENCES invoices (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE invoice_numbering (
                year  SMALLINT UNSIGNED NOT NULL PRIMARY KEY,
                seq   INT UNSIGNED NOT NULL DEFAULT 0
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS invoice_numbering");
        $this->db->query("DROP TABLE IF EXISTS invoice_lines");
        $this->db->query("DROP TABLE IF EXISTS invoices");
    }
};
