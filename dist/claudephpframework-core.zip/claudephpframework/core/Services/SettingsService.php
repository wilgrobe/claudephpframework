<?php
// core/Services/SettingsService.php
namespace Core\Services;

use Core\Database\Database;

/**
 * SettingsService — key-value configuration store with scope support.
 *
 * Scopes: site | page | function | group
 */
class SettingsService
{
    private Database $db;
    private array    $cache = [];

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function get(string $key, mixed $default = null, string $scope = 'site', ?string $scopeKey = null): mixed
    {
        $cacheKey = "$scope:$scopeKey:$key";
        if (isset($this->cache[$cacheKey])) {
            return $this->cache[$cacheKey];
        }

        $row = $this->db->fetchOne(
            "SELECT value, type FROM settings WHERE `key` = ? AND scope = ? AND scope_key <=> ?",
            [$key, $scope, $scopeKey]
        );
        if (!$row) return $default;

        $value = $this->cast($row['value'], $row['type']);
        $this->cache[$cacheKey] = $value;
        return $value;
    }

    public function set(string $key, mixed $value, string $scope = 'site', ?string $scopeKey = null, string $type = 'string'): void
    {
        $encoded = is_array($value) ? json_encode($value) : (string) $value;
        $existing = $this->db->fetchOne(
            "SELECT id FROM settings WHERE `key` = ? AND scope = ? AND scope_key <=> ?",
            [$key, $scope, $scopeKey]
        );
        if ($existing) {
            $this->db->update('settings', ['value' => $encoded, 'type' => $type], 'id = ?', [$existing['id']]);
        } else {
            $this->db->insert('settings', [
                'scope'     => $scope,
                'scope_key' => $scopeKey,
                'key'       => $key,
                'value'     => $encoded,
                'type'      => $type,
            ]);
        }
        // Invalidate cache
        unset($this->cache["$scope:$scopeKey:$key"]);
    }

    public function all(string $scope = 'site', ?string $scopeKey = null): array
    {
        $rows = $this->db->fetchAll(
            "SELECT `key`, value, type FROM settings WHERE scope = ? AND scope_key <=> ?",
            [$scope, $scopeKey]
        );
        $result = [];
        foreach ($rows as $row) {
            $result[$row['key']] = $this->cast($row['value'], $row['type']);
        }
        return $result;
    }

    public function delete(string $key, string $scope = 'site', ?string $scopeKey = null): void
    {
        $this->db->delete('settings',
            '`key` = ? AND scope = ? AND scope_key <=> ?',
            [$key, $scope, $scopeKey]
        );
    }

    private function cast(mixed $value, string $type): mixed
    {
        return match ($type) {
            'integer' => (int) $value,
            'boolean' => $value === 'true' || $value === '1',
            'json'    => json_decode($value, true),
            default   => $value,
        };
    }
}
