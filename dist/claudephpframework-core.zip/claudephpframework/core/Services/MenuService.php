<?php
// core/Services/MenuService.php
namespace Core\Services;

use Core\Database\Database;
use Core\Auth\Auth;

/**
 * MenuService — loads menus with full conditional visibility filtering.
 *
 * Visibility rules:
 *   always       — always visible
 *   logged_in    — only for authenticated users
 *   logged_out   — only for guests
 *   role         — user must have condition_value role slug
 *   permission   — user must have condition_value permission slug
 *   group        — user must be in condition_value group slug
 */
class MenuService
{
    private Database $db;
    private Auth     $auth;

    public function __construct()
    {
        $this->db   = Database::getInstance();
        $this->auth = Auth::getInstance();
    }

    /**
     * Get a fully nested, visibility-filtered menu tree by location.
     */
    public function getMenu(string $location, string $currentPath = '/'): array
    {
        $menu = $this->db->fetchOne(
            "SELECT * FROM menus WHERE location = ? AND is_active = 1",
            [$location]
        );
        if (!$menu) return [];

        $allItems = $this->db->fetchAll(
            "SELECT * FROM menu_items WHERE menu_id = ? AND is_active = 1 ORDER BY sort_order ASC",
            [$menu['id']]
        );

        // Filter by visibility
        $visible = array_filter($allItems, fn($item) => $this->isVisible($item, $currentPath));

        return $this->buildTree($visible);
    }

    /**
     * Get all menus for admin management.
     */
    public function getAllMenus(): array
    {
        return $this->db->fetchAll("SELECT * FROM menus ORDER BY location, name");
    }

    public function getMenuItems(int $menuId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM menu_items WHERE menu_id = ? ORDER BY sort_order ASC",
            [$menuId]
        );
    }

    private function isVisible(array $item, string $currentPath): bool
    {
        // Page restriction check
        if (!empty($item['show_on_pages'])) {
            $pages = json_decode($item['show_on_pages'], true) ?? [];
            if (!empty($pages) && !in_array(ltrim($currentPath, '/'), $pages, true)) {
                return false;
            }
        }

        $v = $item['visibility'] ?? 'always';

        switch ($v) {
            case 'always':
                return true;
            case 'logged_in':
                return $this->auth->check();
            case 'logged_out':
                return $this->auth->guest();
            case 'role':
                return $this->auth->check() && $this->auth->hasRole($item['condition_value'] ?? '');
            case 'permission':
                return $this->auth->check() && $this->auth->hasPermission($item['condition_value'] ?? '');
            case 'group':
                return $this->auth->check() && $this->auth->inGroup($item['condition_value'] ?? '');
            default:
                return true;
        }
    }

    /**
     * Build a nested tree from a flat array of items.
     * O(n): bucket items by parent_id in a single pass, then assemble.
     */
    private function buildTree(array $items, ?int $parentId = null): array
    {
        // Bucket items by parent id (0 / null both map to "root").
        $byParent = [];
        foreach ($items as $item) {
            $pid = empty($item['parent_id']) ? 0 : (int) $item['parent_id'];
            $byParent[$pid][] = $item;
        }
        return $this->assembleTree($byParent, $parentId ?? 0);
    }

    private function assembleTree(array &$byParent, int $parentId): array
    {
        if (empty($byParent[$parentId])) return [];
        $tree = [];
        foreach ($byParent[$parentId] as $item) {
            $item['children'] = $this->assembleTree($byParent, (int) $item['id']);
            $tree[] = $item;
        }
        return $tree;
    }

    // ── Admin CRUD ────────────────────────────────────────────────────────────

    public function createMenu(array $data): int
    {
        return $this->db->insert('menus', $data);
    }

    public function updateMenu(int $id, array $data): int
    {
        return $this->db->update('menus', $data, 'id = ?', [$id]);
    }

    public function deleteMenu(int $id): int
    {
        return $this->db->delete('menus', 'id = ?', [$id]);
    }

    public function createItem(array $data): int
    {
        return $this->db->insert('menu_items', $data);
    }

    public function updateItem(int $id, array $data): int
    {
        return $this->db->update('menu_items', $data, 'id = ?', [$id]);
    }

    public function deleteItem(int $id): int
    {
        return $this->db->delete('menu_items', 'id = ?', [$id]);
    }

    public function reorderItems(array $order): void
    {
        foreach ($order as $sortOrder => $itemId) {
            $this->db->update('menu_items', ['sort_order' => $sortOrder], 'id = ?', [(int) $itemId]);
        }
    }
}
