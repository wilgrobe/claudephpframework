<?php
// core/Services/MailService.php
namespace Core\Services;

use Core\Contracts\MailDriver;
use Core\Database\Database;
use Core\Services\IntegrationConfig;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

/**
 * MailService — sends email via configured SMTP or API integrations.
 *
 * All config now lives in .env. The driver selector (MAIL_DRIVER) plus the
 * driver-specific credentials are read via IntegrationConfig::config('email').
 * On local dev this defaults to smtp4dev (localhost:25, no auth); inspect
 * caught mail at http://localhost:5000.
 *
 * Every send attempt is logged to message_log.
 */
class MailService implements MailDriver
{
    private Database $db;
    private array    $config;

    public function __construct()
    {
        $this->db     = Database::getInstance();
        $this->config = $this->loadConfig();
    }

    /**
     * Read mail config from env. The shape returned here matches the flat
     * keys the rest of the class expects (host, port, username, password,
     * from_address, from_name, etc.), so nothing downstream had to change
     * when DB-backed integrations went away.
     */
    private function loadConfig(): array
    {
        $env = IntegrationConfig::config('email');

        return [
            'driver'            => $env['driver']           ?? 'smtp',
            'host'              => $env['host']             ?? 'localhost',
            'port'              => (int) ($env['port']      ?? 25),
            'encryption'        => $env['encryption']       ?? '',
            'username'          => $env['username']         ?? '',
            'password'          => $env['password']         ?? '',
            'from_address'      => $env['from_address']     ?? 'noreply@example.com',
            'from_name'         => $env['from_name']        ?? ($_ENV['APP_NAME'] ?? 'App'),
            // API provider credentials (only one block is used at a time,
            // depending on driver). Stored alongside SMTP creds so callers
            // that bypass driver dispatch can still reach them.
            'sendgrid_api_key'  => $env['api_key']          ?? '',   // MAIL_SENDGRID_API_KEY
            'mailgun_api_key'   => $env['api_key']          ?? '',   // MAIL_MAILGUN_API_KEY (same short key)
            'mailgun_domain'    => $env['domain']           ?? '',
            'mailgun_endpoint'  => $env['endpoint']         ?? 'api.mailgun.net',
            'ses_region'        => $env['region']           ?? '',
            'ses_access_key'    => $env['access_key']       ?? '',
            'ses_secret_key'    => $env['secret_key']       ?? '',
            // smtp4dev / self-signed cert tolerance: on in non-prod.
            'allow_self_signed' => ($_ENV['APP_ENV'] ?? 'production') !== 'production',
        ];
    }

    /**
     * Default retry policy: 3 attempts total with exponential backoff.
     * Delays are in minutes and indexed by attempt count AFTER the failure.
     * After index 0, we've failed attempt #1 → schedule next at +1 min.
     * After index 1, we've failed attempt #2 → schedule next at +5 min.
     * After index 2, we've failed attempt #3 → attempts == max_attempts → terminal.
     */
    private const RETRY_BACKOFF_MINUTES = [1, 5, 25];
    private const MAX_ATTEMPTS          = 3;

    /**
     * Send an email. Falls back to PHP mail() only if driver is 'mail'.
     * On failure, the log row is marked 'failed' with attempts=1 and a
     * next_attempt_at time so the retry worker can pick it up.
     */
    public function send(string $to, string $subject, string $htmlBody, string $textBody = ''): bool
    {
        $logId = $this->db->insert('message_log', [
            'channel'      => 'email',
            'recipient'    => $to,
            'subject'      => $subject,
            'body'         => $htmlBody,
            'status'       => 'queued',
            'provider'     => $this->config['driver'] ?? 'smtp',
            'max_attempts' => self::MAX_ATTEMPTS,
        ]);

        return $this->attemptSend($logId, $to, $subject, $htmlBody, $textBody);
    }

    /**
     * Re-dispatch a previously-logged message by ID. Used by the retry worker
     * and by the admin "Retry" button. Does NOT insert a new log row; it
     * updates the existing one in place so the history is preserved.
     *
     * Returns true on success, false otherwise. Callers generally don't need
     * the return value — inspect message_log for the final status.
     */
    public function resend(int $logId): bool
    {
        $row = $this->db->fetchOne(
            "SELECT * FROM message_log WHERE id = ? AND channel = 'email' LIMIT 1",
            [$logId]
        );
        if (!$row) return false;

        // If someone hits retry on a row that's already sent, no-op.
        if ($row['status'] === 'sent') return true;

        return $this->attemptSend(
            (int)$row['id'],
            (string)$row['recipient'],
            (string)($row['subject'] ?? ''),
            (string)($row['body']    ?? ''),
            '' // textBody — we don't store the plaintext variant
        );
    }

    /**
     * Shared attempt pipeline: runs doSend(), updates the log row with
     * success/failure + retry bookkeeping, never throws. Increments
     * `attempts` exactly once per call.
     */
    private function attemptSend(int $logId, string $to, string $subject, string $html, string $text): bool
    {
        try {
            $success = $this->doSend($to, $subject, $html, $text);
            if ($success) {
                $this->db->update('message_log',
                    [
                        'status'             => 'sent',
                        'sent_at'            => date('Y-m-d H:i:s'),
                        'last_attempted_at'  => date('Y-m-d H:i:s'),
                        'next_attempt_at'    => null,
                        'attempts'           => $this->currentAttempts($logId) + 1,
                        'error'              => null,
                    ],
                    'id = ?', [$logId]
                );
                return true;
            }
            $this->markFailed($logId, 'Transport returned false (no exception).');
            return false;
        } catch (\Throwable $e) {
            $this->markFailed($logId, $e->getMessage());
            return false;
        }
    }

    private function currentAttempts(int $logId): int
    {
        $row = $this->db->fetchOne("SELECT attempts FROM message_log WHERE id = ?", [$logId]);
        return (int)($row['attempts'] ?? 0);
    }

    /**
     * Mark a row as failed and schedule (or terminate) the next retry
     * based on the configured backoff schedule.
     */
    private function markFailed(int $logId, string $errorMessage): void
    {
        $row = $this->db->fetchOne("SELECT attempts, max_attempts FROM message_log WHERE id = ?", [$logId]);
        $attempts = (int)($row['attempts'] ?? 0) + 1;
        $max      = (int)($row['max_attempts'] ?? self::MAX_ATTEMPTS);

        // Choose backoff: RETRY_BACKOFF_MINUTES is indexed by the attempt that
        // JUST failed (0-based). If we're past the end, no more retries.
        $delayMinutes = self::RETRY_BACKOFF_MINUTES[$attempts - 1] ?? null;
        $nextAt = ($attempts < $max && $delayMinutes !== null)
            ? date('Y-m-d H:i:s', time() + ($delayMinutes * 60))
            : null;

        $this->db->update('message_log',
            [
                'status'            => 'failed',
                'error'             => substr($errorMessage, 0, 65000),
                'attempts'          => $attempts,
                'last_attempted_at' => date('Y-m-d H:i:s'),
                'next_attempt_at'   => $nextAt,
            ],
            'id = ?', [$logId]
        );
    }

    private function doSend(string $to, string $subject, string $html, string $text): bool
    {
        $driver = strtolower($this->config['driver'] ?? 'smtp');

        if ($driver === 'smtp') {
            return $this->sendSmtp($to, $subject, $html, $text);
        }

        // Fallback: PHP mail() — only used if driver is explicitly set to 'mail'.
        $headers  = "MIME-Version: 1.0\r\nContent-type: text/html; charset=utf-8\r\n";
        $headers .= "From: " . $this->config['from_name'] . " <" . $this->config['from_address'] . ">\r\n";
        return mail($to, $subject, $html, $headers);
    }

    /**
     * Real SMTP send via PHPMailer. Works against smtp4dev on localhost:25
     * with no auth, and against production SMTP with TLS + credentials.
     */
    private function sendSmtp(string $to, string $subject, string $html, string $text): bool
    {
        if (!class_exists(PHPMailer::class)) {
            throw new \RuntimeException(
                'PHPMailer is not installed. Run: composer require phpmailer/phpmailer'
            );
        }

        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host    = $this->config['host'];
        $mail->Port    = (int)$this->config['port'];
        $mail->CharSet = 'UTF-8';

        // Auth is optional — smtp4dev accepts anonymous connections.
        if (!empty($this->config['username'])) {
            $mail->SMTPAuth = true;
            $mail->Username = $this->config['username'];
            $mail->Password = $this->config['password'] ?? '';
        } else {
            $mail->SMTPAuth = false;
        }

        // Encryption: '', 'tls', 'ssl'. smtp4dev defaults to none.
        $encryption = strtolower((string)($this->config['encryption'] ?? ''));
        if ($encryption === 'tls') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        } elseif ($encryption === 'ssl') {
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        } else {
            $mail->SMTPSecure  = false;
            $mail->SMTPAutoTLS = false; // don't try to upgrade against smtp4dev
        }

        // Loose TLS checks are fine in local/dev (smtp4dev uses self-signed certs).
        if (!empty($this->config['allow_self_signed'])) {
            $mail->SMTPOptions = [
                'ssl' => [
                    'verify_peer'       => false,
                    'verify_peer_name'  => false,
                    'allow_self_signed' => true,
                ],
            ];
        }

        $mail->setFrom($this->config['from_address'], $this->config['from_name']);
        $mail->addAddress($to);
        $mail->Subject = $subject;
        $mail->isHTML(true);
        $mail->Body    = $html;
        $mail->AltBody = $text !== '' ? $text : trim(strip_tags($html));

        return $mail->send();
    }

    /**
     * Send a templated email using a view file.
     */
    public function sendTemplate(string $to, string $subject, string $template, array $vars = []): bool
    {
        ob_start();
        extract($vars, EXTR_SKIP);
        $templatePath = BASE_PATH . "/app/Views/emails/$template.php";
        if (file_exists($templatePath)) {
            include $templatePath;
        }
        $html = ob_get_clean();
        return $this->send($to, $subject, $html);
    }
}
