<?php
// core/Services/NotificationService.php
namespace Core\Services;

use Core\Database\Database;

class NotificationService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Send an in-app notification (and optionally email/SMS).
     */
    public function send(int $userId, string $type, string $title, string $body, array $data = [], string $channels = 'in_app'): string
    {
        $uuid = $this->uuid4();
        $this->db->insert('notifications', [
            'id'         => $uuid,
            'user_id'    => $userId,
            'type'       => $type,
            'title'      => $title,
            'body'       => $body,
            'data'       => json_encode($data),
            'channel'    => $channels,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
        return $uuid;
    }

    public function markRead(string $notificationId, int $userId): void
    {
        $this->db->update('notifications',
            ['read_at' => date('Y-m-d H:i:s')],
            'id = ? AND user_id = ?',
            [$notificationId, $userId]
        );
    }

    /**
     * Permanently delete a notification. Guarded by canDelete() — callers
     * should verify before invoking, but the owner filter here is a
     * second line of defense against cross-user deletes.
     */
    public function delete(string $notificationId, int $userId): void
    {
        $this->db->delete('notifications', 'id = ? AND user_id = ?', [$notificationId, $userId]);
    }

    /**
     * True when the notification is safe to dismiss: it's been read AND
     * any action it represents (transfer request, invitation, owner
     * removal) has been resolved one way or another.
     *
     * Plain informational notifications with no linked action fall through
     * to "just needs to be read" via actionResolved() returning true.
     */
    public function canDelete(array $notification): bool
    {
        if (empty($notification['read_at'])) return false;
        return $this->actionResolved($notification);
    }

    /**
     * True when the action this notification points at is no longer
     * pending. Covers the action types we currently dispatch; anything
     * unknown is treated as "no action to wait on" so users aren't blocked
     * from dismissing older notifications when new types ship.
     */
    public function actionResolved(array $notification): bool
    {
        $type = (string)($notification['type'] ?? '');
        $data = !empty($notification['data']) ? json_decode((string)$notification['data'], true) : [];
        if (!is_array($data)) $data = [];

        switch ($type) {
            case 'content.transfer_request':
            case 'content.transfer_offer':
                $rid = (int)($data['request_id'] ?? 0);
                if ($rid <= 0) return true;
                $row = $this->db->fetchOne(
                    "SELECT status FROM content_transfer_requests WHERE id = ?",
                    [$rid]
                );
                return !$row || $row['status'] !== 'pending';

            case 'group.owner_removal_request':
                $rid = (int)($data['request_id'] ?? 0);
                if ($rid <= 0) return true;
                $row = $this->db->fetchOne(
                    "SELECT status FROM group_owner_removal_requests WHERE id = ?",
                    [$rid]
                );
                return !$row || $row['status'] !== 'pending';

            case 'group.invitation':
                // Token lives in data.join_url — extract it rather than
                // storing it separately so existing invitation notifications
                // still work.
                $url = (string)($data['join_url'] ?? '');
                if (!$url || !preg_match('#/join/([A-Za-z0-9]+)#', $url, $m)) return true;
                $row = $this->db->fetchOne(
                    "SELECT status FROM group_invitations WHERE token = ?",
                    [$m[1]]
                );
                return !$row || $row['status'] !== 'pending';

            default:
                return true;
        }
    }

    /**
     * Convenience: enrich a list of notifications with a computed
     * `can_delete` flag so views don't have to re-implement the rules.
     */
    public function annotate(array $notifications): array
    {
        foreach ($notifications as &$n) {
            $n['can_delete'] = $this->canDelete($n);
        }
        return $notifications;
    }

    public function getUnread(int $userId, int $limit = 20): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM notifications WHERE user_id = ? AND read_at IS NULL ORDER BY created_at DESC LIMIT ?",
            [$userId, $limit]
        );
    }

    public function getAll(int $userId, int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT ?",
            [$userId, $limit]
        );
    }

    private function uuid4(): string
    {
        $data = random_bytes(16);
        $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
        $data[8] = chr(ord($data[8]) & 0x3f | 0x80);
        return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
    }
}
