<?php
// core/Module/ModuleRegistry.php
namespace Core\Module;

use Core\Container\Container;
use Core\Router\Router;
use Core\View;

/**
 * Discovers and orchestrates modules under modules/.
 *
 * Lifecycle:
 *   1. discover($dir)
 *        - Scans $dir for module.php files
 *        - Requires each; each returns a ModuleProvider instance
 *        - Registers an autoloader for Modules\{Name}\... → modules/{name}/...
 *        - Registers View namespaces for modules that expose viewsPath()
 *        - Calls $provider->register($container) to let the module bind services
 *
 *   2. loadRoutes($router)
 *        - Requires each module's routesFile() with $router in scope
 *
 *   3. boot($router, $container)
 *        - Calls $provider->boot($router, $container) on each provider
 *
 * Also exposes migrationPaths() so the Migrator can scan per-module migration dirs.
 */
class ModuleRegistry
{
    /** @var ModuleProvider[] */
    private array $providers = [];

    /** @var array<string, string> moduleName => absolute module directory */
    private array $paths = [];

    private Container $container;

    /** Tracks whether the PSR-4 autoloader for Modules\ has been registered. */
    private bool $autoloaderRegistered = false;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Default location for the deploy-time module manifest. When present,
     * discover() skips the DirectoryIterator scan and requires only the
     * module.php files listed here. See dumpCache() + `php artisan module:cache`.
     */
    public const DEFAULT_CACHE_FILE = 'storage/cache/modules.php';

    /**
     * Scan $modulesDir for modules. Safe to call when the directory doesn't
     * exist — no modules are registered in that case.
     *
     * Skips the filesystem scan when a manifest exists at
     * BASE_PATH . '/' . DEFAULT_CACHE_FILE. The manifest is a plain PHP file
     * returning ['moduleName' => '/abs/path/to/module/dir', ...]. Opcache
     * caches the manifest's compiled bytecode so subsequent requests pay
     * only the `require` cost, not a directory scan.
     *
     * Production deploys should run `php artisan module:cache` after deploy.
     * Dev and fresh installs work without the cache — the scan is the
     * fallback, not a failure mode.
     */
    public function discover(string $modulesDir): void
    {
        if (!is_dir($modulesDir)) {
            return;
        }

        $this->registerAutoloader($modulesDir);

        $cached = $this->loadCache();
        if ($cached !== null) {
            foreach ($cached as $name => $moduleDir) {
                $this->registerFromDir((string) $name, (string) $moduleDir);
            }
            return;
        }

        foreach (new \DirectoryIterator($modulesDir) as $entry) {
            if ($entry->isDot() || !$entry->isDir()) continue;
            $moduleDir    = $entry->getPathname();
            $providerFile = $moduleDir . '/module.php';
            if (!is_file($providerFile)) continue;

            $this->registerFromDir(null, $moduleDir);
        }
    }

    /**
     * Require a module's provider file and wire it up. Shared between the
     * cached path (name + dir known ahead of time) and the scan path
     * (name pulled from provider->name()).
     */
    private function registerFromDir(?string $knownName, string $moduleDir): void
    {
        $providerFile = $moduleDir . '/module.php';
        if (!is_file($providerFile)) return;

        /** @var ModuleProvider $provider */
        $provider = require $providerFile;
        if (!$provider instanceof ModuleProvider) {
            throw new \RuntimeException(
                "module.php at [$moduleDir] must return an instance of Core\\Module\\ModuleProvider"
            );
        }

        $name = $knownName ?? $provider->name();
        $this->providers[$name] = $provider;
        $this->paths[$name]     = $moduleDir;

        if ($viewsPath = $provider->viewsPath()) {
            if (is_dir($viewsPath)) {
                View::addNamespace($name, $viewsPath);
            }
        }

        $provider->register($this->container);
    }

    /**
     * Return the cached manifest or null if absent/unreadable. Fails soft —
     * a broken cache never blocks the app; scan is the fallback.
     *
     * @return array<string, string>|null  moduleName => absolute moduleDir
     */
    private function loadCache(): ?array
    {
        if (!defined('BASE_PATH')) return null;
        $path = BASE_PATH . '/' . self::DEFAULT_CACHE_FILE;
        if (!is_file($path)) return null;

        try {
            $data = require $path;
        } catch (\Throwable) {
            return null;
        }
        return is_array($data) ? $data : null;
    }

    /**
     * Write the current module manifest to disk. Called from the
     * `module:cache` artisan command after a deploy.
     *
     * @param string $modulesDir  directory to scan (typically BASE_PATH/modules)
     * @param string $cacheFile   absolute path to write
     * @return array<string, string>  the list that was written (name => dir)
     */
    public function dumpCache(string $modulesDir, string $cacheFile): array
    {
        if (!is_dir($modulesDir)) return [];

        // Do a fresh scan to collect names. We can't just look at $this->providers
        // because in a normal request the registry may have been built from a
        // stale cache; regenerating requires a fresh discover from disk.
        $entries = [];
        foreach (new \DirectoryIterator($modulesDir) as $entry) {
            if ($entry->isDot() || !$entry->isDir()) continue;
            $dir  = $entry->getPathname();
            $file = $dir . '/module.php';
            if (!is_file($file)) continue;

            /** @var ModuleProvider $provider */
            $provider = require $file;
            if (!$provider instanceof ModuleProvider) continue;
            $entries[$provider->name()] = $dir;
        }

        $dir = dirname($cacheFile);
        if (!is_dir($dir)) {
            @mkdir($dir, 0755, true);
        }

        $export = var_export($entries, true);
        $header = "<?php\n// Generated by `php artisan module:cache` — do not edit by hand.\n// Safe to delete; the registry falls back to a filesystem scan.\n";
        file_put_contents($cacheFile, $header . "return $export;\n", LOCK_EX);

        return $entries;
    }

    /**
     * Include each module's routes file so route registrations land on the
     * shared Router. Module routes are loaded BEFORE routes/web.php; web.php
     * wins on collision (last writer wins in the router's ordered list).
     */
    public function loadRoutes(Router $router): void
    {
        foreach ($this->providers as $provider) {
            $routesFile = $provider->routesFile();
            if ($routesFile && is_file($routesFile)) {
                // $router and $container are in scope for the required file
                $container = $this->container;
                require $routesFile;
            }
        }
    }

    /** Call boot() on every registered provider. Final phase of bootstrap. */
    public function boot(Router $router): void
    {
        foreach ($this->providers as $provider) {
            $provider->boot($router, $this->container);
        }
    }

    /** @return string[] directories the migrator should also scan */
    public function migrationPaths(): array
    {
        $paths = [];
        foreach ($this->providers as $provider) {
            if ($p = $provider->migrationsPath()) {
                if (is_dir($p)) $paths[] = $p;
            }
        }
        return $paths;
    }

    /** @return ModuleProvider[] — useful for introspection / admin UIs */
    public function all(): array
    {
        return $this->providers;
    }

    public function get(string $name): ?ModuleProvider
    {
        return $this->providers[$name] ?? null;
    }

    /**
     * Register a PSR-4 autoloader for Modules\{Name}\...
     *
     *   Modules\Pages\Controllers\PageController
     *   → modules/pages/Controllers/PageController.php
     *
     * Module directory names are lowercased; class namespace uses StudlyCase.
     * We resolve both conventions by normalizing: the segment after "Modules\"
     * is lowercased to find the directory.
     */
    private function registerAutoloader(string $modulesDir): void
    {
        if ($this->autoloaderRegistered) return;
        $this->autoloaderRegistered = true;

        spl_autoload_register(function (string $class) use ($modulesDir): void {
            if (!str_starts_with($class, 'Modules\\')) return;

            $parts = explode('\\', $class);
            array_shift($parts); // drop 'Modules'
            if (empty($parts)) return;

            $module = strtolower(array_shift($parts));
            $tail   = implode('/', $parts) . '.php';
            $file   = $modulesDir . '/' . $module . '/' . $tail;

            if (is_file($file)) {
                require $file;
            }
        });
    }
}
