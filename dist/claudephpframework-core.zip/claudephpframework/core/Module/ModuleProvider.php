<?php
// core/Module/ModuleProvider.php
namespace Core\Module;

use Core\Container\Container;
use Core\Router\Router;

/**
 * Base class for a module's `module.php` entrypoint.
 *
 * A module lives at modules/{name}/ and ships a module.php like:
 *
 *   <?php
 *   use Core\Module\ModuleProvider;
 *
 *   return new class extends ModuleProvider {
 *       public function name(): string { return 'blog'; }
 *
 *       public function routesFile(): ?string {
 *           return __DIR__ . '/routes.php';
 *       }
 *
 *       public function viewsPath(): ?string {
 *           return __DIR__ . '/Views';
 *       }
 *
 *       public function migrationsPath(): ?string {
 *           return __DIR__ . '/migrations';
 *       }
 *
 *       public function register(Container $c): void {
 *           // Optional: bind module-specific services.
 *       }
 *
 *       public function boot(Router $router, Container $c): void {
 *           // Optional: programmatic setup that needs the router or container.
 *       }
 *   };
 *
 * The ModuleRegistry calls each hook at the right point during bootstrap.
 * Only `name()` is required; everything else has a sensible default (null).
 */
abstract class ModuleProvider
{
    /**
     * Unique, lowercase, snake-case identifier. Doubles as the view
     * namespace (e.g. `pages::show` resolves to modules/pages/Views/show.php).
     */
    abstract public function name(): string;

    /**
     * Path to the module's routes file, or null if it has none.
     * Registered after the router is built but before dispatch.
     */
    public function routesFile(): ?string { return null; }

    /**
     * Path to the module's Views directory, or null. When returned, the
     * ModuleRegistry registers it with View::addNamespace() under name().
     */
    public function viewsPath(): ?string { return null; }

    /**
     * Path to the module's migrations directory, or null. When returned,
     * artisan migrate picks it up alongside database/migrations/.
     */
    public function migrationsPath(): ?string { return null; }

    /**
     * Bind module-specific services into the container.
     * Called during discovery, before boot() and before routes load.
     */
    public function register(Container $c): void {}

    /**
     * Runtime wiring that needs the router or resolved dependencies.
     * Called after all modules have been registered and the routes file
     * has been pulled in — a good place for event listeners, view composers, etc.
     */
    public function boot(Router $router, Container $c): void {}

    /**
     * Artisan commands contributed by this module. Return an array of
     * Command instances OR class names — the registry resolves both.
     *
     *   public function commands(): array {
     *       return [
     *           \Modules\Blog\Console\ImportFeedCommand::class,
     *           \Modules\Blog\Console\RebuildIndexCommand::class,
     *       ];
     *   }
     */
    public function commands(): array { return []; }
}
