<?php
// core/Auth/Auth.php
namespace Core\Auth;

use Core\Database\Database;

/**
 * Auth — singleton authentication / authorization engine.
 *
 * Supports:
 *  - Standard email+password login
 *  - OAuth social login (Google, Microsoft, Apple, Facebook, LinkedIn)
 *  - Superadmin toggle + user emulation (fully audited)
 *  - Multi-group membership with per-group roles
 *  - Group-scoped permission checks
 */
class Auth
{
    private static ?Auth $instance = null;
    private Database     $db;

    private ?array $user        = null;
    private ?array $roles       = null;   // global system roles
    private ?array $permissions = null;   // global permissions
    private ?array $groups      = null;   // groups with per-group role info

    /** Original (real) user when emulating someone else */
    private ?array $realUser    = null;

    private function __construct()
    {
        $this->db = Database::getInstance();
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }
        $this->bootFromSession();
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // ── Session Boot ──────────────────────────────────────────────────────────

    private function bootFromSession(): void
    {
        if (!empty($_SESSION['user_id'])) {
            $this->loadUser((int) $_SESSION['user_id']);
        }
        if (!empty($_SESSION['real_user_id']) && !empty($_SESSION['emulating'])) {
            $this->realUser = $this->db->fetchOne(
                "SELECT id, username, email, first_name, last_name, is_superadmin
                 FROM users WHERE id = ?",
                [(int) $_SESSION['real_user_id']]
            );
        }
    }

    // ── Login / Logout ────────────────────────────────────────────────────────

    /**
     * Attempt password-based login.
     */
    /**
     * Attempt password-based login.
     *
     * Returns:
     *   true             — login fully complete (no 2FA required)
     *   '2fa_required'   — credentials valid but 2FA challenge needed;
     *                      caller should redirect to /auth/2fa/challenge
     *   false            — invalid credentials
     */
    public function attempt(string $email, string $password): bool|string
    {
        $user = $this->db->fetchOne(
            "SELECT * FROM users WHERE email = ? AND is_active = 1",
            [strtolower(trim($email))]
        );
        if (!$user || empty($user['password']) || !password_verify($password, $user['password'])) {
            return false;
        }

        // Check if 2FA is enabled and confirmed for this user
        if (!empty($user['two_factor_enabled']) && !empty($user['two_factor_confirmed'])) {
            // Store pending user in session — NOT logged in yet
            if (session_status() === PHP_SESSION_NONE) session_start();
            session_regenerate_id(true);
            $_SESSION['2fa_pending_user_id'] = $user['id'];
            $this->auditLog('auth.2fa_initiated', 'users', $user['id'], null, [
                'method' => $user['two_factor_method'] ?? 'unknown',
            ]);
            return '2fa_required';
        }

        $this->startSession($user);
        $this->db->query("UPDATE users SET last_login_at = NOW() WHERE id = ?", [$user['id']]);
        $this->auditLog('auth.login', 'users', $user['id']);
        return true;
    }

    /**
     * Login or register via OAuth provider.
     * Returns true on success.
     */
    public function attemptOAuth(string $provider, string $providerId, array $providerData): bool
    {
        $allowed = ['google','microsoft','apple','facebook','linkedin'];
        if (!in_array($provider, $allowed, true)) return false;

        // Try existing OAuth link
        $oauth = $this->db->fetchOne(
            "SELECT user_id FROM user_oauth WHERE provider = ? AND provider_id = ?",
            [$provider, $providerId]
        );

        if ($oauth) {
            $user = $this->db->fetchOne(
                "SELECT * FROM users WHERE id = ? AND is_active = 1",
                [$oauth['user_id']]
            );
        } else {
            // Check by email first
            $user = null;
            if (!empty($providerData['email'])) {
                $user = $this->db->fetchOne(
                    "SELECT * FROM users WHERE email = ?",
                    [$providerData['email']]
                );
            }
            if (!$user) {
                // Auto-register
                $userId = $this->db->insert('users', [
                    'email'      => $providerData['email']  ?? null,
                    'first_name' => $providerData['first_name'] ?? null,
                    'last_name'  => $providerData['last_name']  ?? null,
                    'avatar'     => $providerData['avatar']     ?? null,
                    'is_active'  => 1,
                    'email_verified_at' => date('Y-m-d H:i:s'),
                ]);
                // Assign default viewer role
                $viewerRole = $this->db->fetchOne("SELECT id FROM roles WHERE slug = 'viewer'");
                if ($viewerRole) {
                    $this->db->insert('user_roles', ['user_id' => $userId, 'role_id' => $viewerRole['id']]);
                }
                $user = $this->db->fetchOne("SELECT * FROM users WHERE id = ?", [$userId]);
            }
            // Link provider — encrypt the access token at rest
            $this->db->insert('user_oauth', [
                'user_id'     => $user['id'],
                'provider'    => $provider,
                'provider_id' => $providerId,
                'token'       => $providerData['token'] ? $this->encryptToken($providerData['token']) : null,
            ]);
        }

        if (!$user || !$user['is_active']) return false;

        // SECURITY: OAuth must also respect 2FA — do not bypass it.
        // Fetch full user row (SELECT * earlier may not include 2FA fields).
        $fullUser = $this->db->fetchOne("SELECT * FROM users WHERE id = ?", [$user['id']]);
        if ($fullUser && !empty($fullUser['two_factor_enabled']) && !empty($fullUser['two_factor_confirmed'])) {
            if (session_status() === PHP_SESSION_NONE) session_start();
            session_regenerate_id(true);
            $_SESSION['2fa_pending_user_id'] = $fullUser['id'];
            $_SESSION['2fa_oauth_provider']  = $provider; // for audit on completion
            $this->auditLog('auth.2fa_initiated', 'users', $fullUser['id'], null, [
                'method'   => $fullUser['two_factor_method'] ?? 'unknown',
                'via'      => 'oauth',
                'provider' => $provider,
            ]);
            return '2fa_required';
        }

        $this->startSession($user);
        $this->db->query("UPDATE users SET last_login_at = NOW() WHERE id = ?", [$user['id']]);
        $this->auditLog('auth.oauth_login', 'users', $user['id'], null, ['provider' => $provider]);
        return true;
    }

    /**
     * Validate and return a safe internal redirect path.
     * Rejects absolute URLs, protocol-relative URLs, and anything
     * that would take the user off-site.
     *
     * SECURITY: Prevents open-redirect via the 'intended' session value.
     */
    public static function safeRedirect(string $url, string $default = '/dashboard'): string
    {
        // Must start with exactly one slash (internal path), not // or http://
        if (!preg_match('#^/[^/]#', $url) && $url !== '/') {
            return $default;
        }
        // Strip null bytes and whitespace
        $url = trim(str_replace("\0", '', $url));
        // Reject anything that still looks like an absolute URL after trimming
        if (preg_match('#^[a-zA-Z][a-zA-Z0-9+\-.]*://#', $url)) {
            return $default;
        }
        return $url;
    }

    public function logout(): void
    {
        if ($this->user) {
            $this->auditLog('auth.logout', 'users', $this->user['id']);
        }
        $this->user = $this->realUser = $this->roles = $this->permissions = $this->groups = null;
        $_SESSION = [];
        if (ini_get('session.use_cookies')) {
            $p = session_get_cookie_params();
            setcookie(session_name(), '', time() - 42000,
                $p['path'], $p['domain'], $p['secure'], $p['httponly']);
        }
        session_destroy();
    }

    // ── Superadmin Toggle ─────────────────────────────────────────────────────

    /**
     * Toggle superadmin mode.
     *
     * SECURITY: Mode is tracked only in the PHP session, NOT in the database.
     * This ensures that destroying all sessions (e.g. during an incident)
     * automatically revokes any active superadmin mode — no DB state to reset.
     * The DB column superadmin_mode should be dropped via migration.
     */
    public function toggleSuperadminMode(bool $enable): bool
    {
        if (!$this->user || !$this->user['is_superadmin']) return false;
        // Session-only storage — never write to DB
        $_SESSION['superadmin_mode'] = $enable;
        $this->user['_session_superadmin_mode'] = $enable;
        $this->auditLog('superadmin.mode_toggle', 'users', $this->user['id'],
            ['mode' => !$enable], ['mode' => $enable]);
        return true;
    }

    /**
     * Returns true only when:
     *   1. The authenticated user has is_superadmin = 1 (DB capability flag)
     *   2. AND the session toggle is explicitly set to true this session
     *
     * SECURITY: Reading from session only — DB superadmin_mode column is ignored.
     */
    public function isSuperadminModeOn(): bool
    {
        return $this->user
            && $this->user['is_superadmin']
            && !empty($_SESSION['superadmin_mode']);
    }

    // ── User Emulation ────────────────────────────────────────────────────────

    /**
     * Superadmin begins emulating $targetUserId.
     */
    public function startEmulating(int $targetUserId): bool
    {
        if (!$this->isSuperadminModeOn()) return false;
        $target = $this->db->fetchOne("SELECT * FROM users WHERE id = ?", [$targetUserId]);
        if (!$target) return false;

        // Save real user
        $_SESSION['real_user_id'] = $this->user['id'];
        $_SESSION['emulating']    = true;
        $this->realUser           = $this->user;

        $this->auditLog('superadmin.emulate_start', 'users', $targetUserId);

        $this->startSession($target, false); // don't regenerate session ID to keep real_user_id
        return true;
    }

    public function stopEmulating(): bool
    {
        if (!$this->isEmulating()) return false;
        $this->auditLog('superadmin.emulate_stop', 'users', $this->user['id']);
        $realId = (int) $_SESSION['real_user_id'];
        $_SESSION['emulating']    = false;
        $_SESSION['real_user_id'] = null;
        $this->realUser = null;
        $this->loadUser($realId);
        $_SESSION['user_id'] = $realId;
        return true;
    }

    public function isEmulating(): bool
    {
        return !empty($_SESSION['emulating']) && !empty($_SESSION['real_user_id']);
    }

    public function realUser(): ?array { return $this->realUser; }

    // ── Dev-Only Login Bypass ────────────────────────────────────────────────

    /**
     * Log in as an arbitrary user without credentials. Short-circuits the
     * email/password and OAuth flows entirely — intended for local dev so
     * you don't round-trip through Google/Microsoft for every test login.
     *
     * HARD-GATED: refuses in production or when APP_DEV_LOGIN is not set
     * to '1'. Both guards are belt-and-suspenders: a misconfigured prod
     * env would still need an attacker to hit the /dev/login-as endpoint,
     * which the controller also checks, and the button only renders in
     * non-production.
     */
    public function devLoginAs(int $userId): bool
    {
        if (($_ENV['APP_ENV'] ?? 'production') === 'production') return false;
        if (($_ENV['APP_DEV_LOGIN'] ?? '1') !== '1')             return false;

        $user = $this->db->fetchOne(
            "SELECT id, email, is_active FROM users WHERE id = ?",
            [$userId]
        );
        if (!$user || (int)$user['is_active'] !== 1) return false;

        $this->startSession($user);
        $this->auditLog('auth.dev_login', 'users', (int)$user['id'], null, ['via' => 'dev-bypass']);
        return true;
    }

    // ── Session Helpers ───────────────────────────────────────────────────────

    private function startSession(array $user, bool $regenerate = true): void
    {
        if ($regenerate) session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $this->loadUser($user['id']);
    }

    private function loadUser(int $userId): void
    {
        $this->user = $this->db->fetchOne(
            "SELECT id, username, email, first_name, last_name, avatar, bio,
                    is_active, is_superadmin,
                    email_verified_at, phone, last_login_at, created_at
             FROM users WHERE id = ?",
            [$userId]
        );
        if (!$this->user) { $this->logout(); return; }

        $this->loadRoles();
        $this->loadPermissions();
        $this->loadGroups();
    }

    private function loadRoles(): void
    {
        $this->roles = $this->db->fetchAll(
            "SELECT r.id, r.name, r.slug, r.description
             FROM roles r
             JOIN user_roles ur ON ur.role_id = r.id
             WHERE ur.user_id = ?",
            [$this->user['id']]
        );
    }

    private function loadPermissions(): void
    {
        $this->permissions = $this->db->fetchAll(
            "SELECT DISTINCT p.id, p.slug
             FROM permissions p
             JOIN role_permissions rp ON rp.permission_id = p.id
             JOIN user_roles ur ON ur.role_id = rp.role_id
             WHERE ur.user_id = ?",
            [$this->user['id']]
        );
    }

    private function loadGroups(): void
    {
        $this->groups = $this->db->fetchAll(
            "SELECT g.id, g.name, g.slug, gr.slug AS group_role_slug,
                    gr.base_role, gr.name AS group_role_name, gr.id AS group_role_id,
                    ug.joined_at
             FROM `groups` g
             JOIN user_groups ug ON ug.group_id = g.id
             JOIN group_roles gr ON gr.id = ug.group_role_id
             WHERE ug.user_id = ?",
            [$this->user['id']]
        );
    }

    // ── Authorization Checks ──────────────────────────────────────────────────

    public function check(): bool  { return $this->user !== null; }
    public function guest(): bool  { return !$this->check(); }
    public function user(): ?array { return $this->user; }
    public function id(): ?int     { return $this->user ? (int) $this->user['id'] : null; }

    /** Superadmin with mode ON bypasses all permission checks. */
    public function isSuperAdmin(): bool
    {
        return $this->user && $this->user['is_superadmin'];
    }

    public function hasRole(string|array $roles): bool
    {
        if ($this->isSuperadminModeOn()) return true;
        if (!$this->roles) return false;
        $slugs = array_column($this->roles, 'slug');
        foreach ((array) $roles as $r) {
            if (in_array($r, $slugs, true)) return true;
        }
        return false;
    }

    public function hasPermission(string $permission): bool
    {
        if ($this->isSuperadminModeOn()) return true;
        if (!$this->permissions) return false;
        return in_array($permission, array_column($this->permissions, 'slug'), true);
    }

    public function can(string $permission): bool    { return $this->hasPermission($permission); }
    public function cannot(string $permission): bool { return !$this->can($permission); }

    public function inGroup(string $groupSlug): bool
    {
        if (!$this->groups) return false;
        return in_array($groupSlug, array_column($this->groups, 'slug'), true);
    }

    /**
     * Check if user has a specific base_role within a given group.
     * Hierarchy: group_owner > group_admin > manager > editor > member
     */
    public function hasGroupRole(int $groupId, string $minBaseRole): bool
    {
        if ($this->isSuperadminModeOn()) return true;
        if (!$this->groups) return false;

        $hierarchy = ['group_owner' => 5, 'group_admin' => 4, 'manager' => 3, 'editor' => 2, 'member' => 1];
        $minLevel  = $hierarchy[$minBaseRole] ?? 0;

        foreach ($this->groups as $g) {
            if ((int) $g['id'] === $groupId) {
                $userLevel = $hierarchy[$g['base_role']] ?? 0;
                return $userLevel >= $minLevel;
            }
        }
        return false;
    }

    public function isGroupOwner(int $groupId): bool  { return $this->hasGroupRole($groupId, 'group_owner'); }
    public function isGroupAdmin(int $groupId): bool   { return $this->hasGroupRole($groupId, 'group_admin'); }

    public function roles(): array       { return $this->roles      ?? []; }
    public function permissions(): array { return $this->permissions ?? []; }
    public function groups(): array      { return $this->groups      ?? []; }

    public function refreshUser(): void
    {
        if ($this->user) $this->loadUser($this->user['id']);
    }

    // ── Token Encryption Helpers ──────────────────────────────────────────────

    /**
     * Encrypt a short string (OAuth token) using libsodium.
     * Same scheme as IntegrationService: base64(nonce . ciphertext).
     */
    private function encryptToken(string $token): string
    {
        $key   = $this->deriveKey();
        $nonce = random_bytes(SODIUM_CRYPTO_SECRETBOX_NONCEBYTES);
        $ct    = sodium_crypto_secretbox($token, $nonce, $key);
        sodium_memzero($key);
        return base64_encode($nonce . $ct);
    }

    public function decryptToken(string $encoded): ?string
    {
        try {
            $raw    = base64_decode($encoded, true);
            $nLen   = SODIUM_CRYPTO_SECRETBOX_NONCEBYTES;
            if (!$raw || strlen($raw) < $nLen + SODIUM_CRYPTO_SECRETBOX_MACBYTES) return null;
            $key    = $this->deriveKey();
            $plain  = sodium_crypto_secretbox_open(substr($raw, $nLen), substr($raw, 0, $nLen), $key);
            sodium_memzero($key);
            return $plain === false ? null : $plain;
        } catch (\Throwable) {
            return null;
        }
    }

    private function deriveKey(): string
    {
        $appKey = config('app.key', '');
        if (str_starts_with($appKey, 'base64:')) {
            $appKey = base64_decode(substr($appKey, 7));
        }
        return hash('sha256', $appKey, true);
    }

    // ── Audit Helper ──────────────────────────────────────────────────────────

    public function auditLog(
        string  $action,
        ?string $model    = null,
        ?int    $modelId  = null,
        ?array  $oldVals  = null,
        ?array  $newVals  = null,
        ?string $notes    = null
    ): void {
        // SECURITY: Truncate User-Agent to prevent log injection and storage bloat.
        // A client can send arbitrarily large headers; cap at 500 chars.
        $userAgent = isset($_SERVER['HTTP_USER_AGENT'])
            ? substr(strip_tags($_SERVER['HTTP_USER_AGENT']), 0, 500)
            : null;

        $this->db->insert('audit_log', [
            'actor_user_id'    => $this->user['id'] ?? null,
            'emulated_user_id' => $this->isEmulating() ? (int) $_SESSION['real_user_id'] : null,
            'superadmin_mode'  => $this->isSuperadminModeOn() ? 1 : 0,
            'action'           => $action,
            'model'            => $model,
            'model_id'         => $modelId,
            'old_values'       => $oldVals ? json_encode($oldVals) : null,
            'new_values'       => $newVals ? json_encode($newVals) : null,
            'ip_address'       => $_SERVER['REMOTE_ADDR'] ?? null,
            'user_agent'       => $userAgent,
            'notes'            => $notes,
        ]);
    }
}
