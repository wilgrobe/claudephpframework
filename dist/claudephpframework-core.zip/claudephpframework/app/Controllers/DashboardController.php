<?php
// app/Controllers/DashboardController.php
namespace App\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Services\NotificationService;
use Core\Database\Database;
use App\Models\Group;

class DashboardController
{
    public function index(Request $request): Response
    {
        $auth  = Auth::getInstance();
        $user  = $auth->user();
        $db    = Database::getInstance();
        $notif = new NotificationService();
        $group = new Group();

        $myGroups      = $group->getUserGroups($auth->id());
        $notifications = $notif->annotate($notif->getAll($auth->id(), 10));
        $unreadCount   = count($notif->getUnread($auth->id(), 99));

        // ── Content feed ──────────────────────────────────────────────────
        //
        // Two lanes that feed the dashboard "Content" block:
        //   • personal — owned or created by this user
        //   • byGroup  — owned by any group this user is a member of,
        //                keyed by group_id so the view can subsection them
        //
        // Limited to 50 rows per lane. The dashboard is a high-level
        // overview; deeper browsing happens at /content.
        $userId   = (int) $auth->id();
        $groupIds = array_map(fn($g) => (int)$g['id'], $myGroups);

        // "Personal" = content currently owned by this user. We intentionally
        // do NOT fall back to created_by here — otherwise a group owner who
        // originally authored an item that's since been transferred to someone
        // else still sees it in their personal list, and after a
        // group→individual approval both the requester and the original
        // creator end up claiming the same item. Ownership is the single
        // source of truth; created_by is preserved for audit only.
        $personal = $db->fetchAll(
            "SELECT id, title, slug, type, status, created_at, updated_at,
                    owner_type, owner_user_id, owner_group_id
               FROM content_items
              WHERE owner_type = 'user'
                AND owner_user_id = ?
              ORDER BY updated_at DESC
              LIMIT 50",
            [$userId]
        );

        $byGroup = [];
        if (!empty($groupIds)) {
            $placeholders = implode(',', array_fill(0, count($groupIds), '?'));
            $rows = $db->fetchAll(
                "SELECT ci.id, ci.title, ci.slug, ci.type, ci.status,
                        ci.created_at, ci.updated_at,
                        ci.owner_type, ci.owner_group_id,
                        g.name AS group_name, g.slug AS group_slug
                   FROM content_items ci
                   JOIN `groups` g ON g.id = ci.owner_group_id
                  WHERE ci.owner_type = 'group'
                    AND ci.owner_group_id IN ($placeholders)
                  ORDER BY ci.updated_at DESC
                  LIMIT 200",
                $groupIds
            );
            // Bucket by group; preserve arrival order so the most recently
            // updated group floats to the top of the subsection list.
            foreach ($rows as $r) {
                $gid = (int)$r['owner_group_id'];
                if (!isset($byGroup[$gid])) {
                    $byGroup[$gid] = [
                        'group_id'   => $gid,
                        'group_name' => $r['group_name'],
                        'group_slug' => $r['group_slug'],
                        'items'      => [],
                    ];
                }
                $byGroup[$gid]['items'][] = $r;
            }
        }

        $stats = [];
        if ($auth->hasRole(['super-admin', 'admin'])) {
            // Cache the full-table COUNT(*)s for 5 minutes. InnoDB has no
            // fast exact count without a full index scan, so these become
            // noticeable once the users/groups tables pass ~100k rows. A
            // stale count by a few minutes on an admin dashboard is fine;
            // if an admin needs real-time they can clear the cache.
            $cache = \Core\Services\CacheService::instance();
            $stats = [
                'users'  => (int) $cache->remember('dash.count.users',  300,
                    fn() => (int) $db->fetchColumn("SELECT COUNT(*) FROM users")),
                'groups' => (int) $cache->remember('dash.count.groups', 300,
                    fn() => (int) $db->fetchColumn("SELECT COUNT(*) FROM `groups`")),
            ];
        }

        // ── Pending transfer approvals (things I can act on) ──────────────
        //
        // Two distinct flows feed this list:
        //   1. Group → individual requests that I can approve because I'm a
        //      group_owner/group_admin of the source group. The requester
        //      is excluded from their own approval (four-eyes), unless
        //      super-admin mode is on.
        //   2. Individual → individual requests where I'm the named
        //      recipient and need to accept/decline.
        //
        // Both land in one UNION so the dashboard can render a single
        // "Pending Transfer Approvals" card with per-row action buttons
        // chosen by flow.
        $approverGroupIds = $db->fetchAll(
            "SELECT ug.group_id
               FROM user_groups ug
               JOIN group_roles gr ON gr.id = ug.group_role_id
              WHERE ug.user_id = ?
                AND gr.base_role IN ('group_owner', 'group_admin')",
            [$userId]
        );
        $approverGroupIds = array_map(fn($r) => (int) $r['group_id'], $approverGroupIds);

        $pendingTransfers = [];
        $parts    = [];
        $bindings = [];

        // Group-admin approval rows
        if (!empty($approverGroupIds)) {
            $ph = implode(',', array_fill(0, count($approverGroupIds), '?'));
            $selfFilter = $auth->isSuperadminModeOn() ? '' : 'AND tr.requested_by <> ?';
            $parts[] = "
                SELECT tr.id, tr.content_id, tr.requested_by, tr.to_user_id, tr.created_at,
                       tr.from_type, tr.to_type,
                       ci.title, ci.slug, ci.owner_group_id,
                       g.name  AS group_name,
                       CONCAT(ru.first_name,' ',ru.last_name) AS requester_name,
                       CONCAT(tu.first_name,' ',tu.last_name) AS recipient_name,
                       'group_admin' AS flow
                  FROM content_transfer_requests tr
                  JOIN content_items ci ON ci.id = tr.content_id
                  JOIN `groups`       g ON g.id = ci.owner_group_id
                  LEFT JOIN users ru ON ru.id = tr.requested_by
                  LEFT JOIN users tu ON tu.id = tr.to_user_id
                 WHERE tr.status = 'pending'
                   AND tr.from_type = 'group'
                   AND ci.owner_group_id IN ($ph)
                   $selfFilter
            ";
            foreach ($approverGroupIds as $gid) $bindings[] = $gid;
            if (!$auth->isSuperadminModeOn()) $bindings[] = $userId;
        }

        // Recipient acceptance rows (user → user transfers addressed to me)
        $parts[] = "
            SELECT tr.id, tr.content_id, tr.requested_by, tr.to_user_id, tr.created_at,
                   tr.from_type, tr.to_type,
                   ci.title, ci.slug, ci.owner_group_id,
                   NULL AS group_name,
                   CONCAT(ru.first_name,' ',ru.last_name) AS requester_name,
                   CONCAT(tu.first_name,' ',tu.last_name) AS recipient_name,
                   'recipient' AS flow
              FROM content_transfer_requests tr
              JOIN content_items ci ON ci.id = tr.content_id
              LEFT JOIN users ru ON ru.id = tr.requested_by
              LEFT JOIN users tu ON tu.id = tr.to_user_id
             WHERE tr.status = 'pending'
               AND tr.from_type = 'user'
               AND tr.to_type   = 'user'
               AND tr.to_user_id = ?
        ";
        $bindings[] = $userId;

        if (!empty($parts)) {
            $sql = '(' . implode(") UNION ALL (", $parts) . ') ORDER BY created_at DESC LIMIT 50';
            $pendingTransfers = $db->fetchAll($sql, $bindings);
        }

        // ── My outgoing pending requests (things I can cancel) ────────────
        //
        // Shown so requesters aren't left wondering "where did my request
        // go?" — especially for the group→individual case where their own
        // request is (correctly) invisible to them in the approval list.
        $outgoingTransfers = $db->fetchAll(
            "SELECT tr.id, tr.content_id, tr.from_type, tr.to_type, tr.to_user_id,
                    tr.to_group_id, tr.created_at,
                    ci.title, ci.slug,
                    g.name  AS group_name,
                    CONCAT(tu.first_name,' ',tu.last_name) AS recipient_name
               FROM content_transfer_requests tr
               JOIN content_items ci ON ci.id = tr.content_id
               LEFT JOIN `groups` g  ON g.id  = tr.to_group_id
               LEFT JOIN users   tu ON tu.id = tr.to_user_id
              WHERE tr.status = 'pending'
                AND tr.requested_by = ?
              ORDER BY tr.created_at DESC
              LIMIT 25",
            [$userId]
        );

        return Response::view('dashboard.index', compact(
            'user', 'myGroups', 'notifications', 'unreadCount', 'stats',
            'personal', 'byGroup', 'pendingTransfers', 'outgoingTransfers'
        ));
    }
}
