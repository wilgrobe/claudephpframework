<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Global CSRF token so JS helpers (csrfPost in app.js) can always find
         one, regardless of whether the current page happens to render a form
         with csrf_field(). Without this, AJAX POSTs silently 419 on pages
         where no form is present — which is exactly how the notification × /
         Mark Read actions fail on the dashboard and notifications index. -->
    <meta name="csrf-token" content="<?= htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8') ?>">
    <?= \Core\SEO\SeoManager::metaTags([
        'title'       => ($seoTitle ?? $pageTitle ?? 'Dashboard') . ' — ' . setting('site_name', 'App'),
        'description' => $seoDescription ?? setting('site_tagline', ''),
        'canonical'   => $canonical ?? null,
    ]) ?>
    <link rel="stylesheet" href="<?= e(asset('/assets/css/app.css')) ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
    *, *::before, *::after { box-sizing: border-box; }
    :root {
        --color-primary: #4f46e5;
        --color-primary-dark: #3730a3;
        --color-secondary: #0ea5e9;
        --color-success: #10b981;
        --color-danger: #ef4444;
        --color-warning: #f59e0b;
        --color-info: #3b82f6;
        --color-gray-50: #f9fafb;
        --color-gray-100: #f3f4f6;
        --color-gray-200: #e5e7eb;
        --color-gray-300: #d1d5db;
        --color-gray-500: #6b7280;
        --color-gray-700: #374151;
        --color-gray-900: #111827;
        --font: 'Inter', system-ui, sans-serif;
        --radius: 8px;
        --shadow: 0 1px 3px rgba(0,0,0,.1), 0 1px 2px rgba(0,0,0,.06);
        --shadow-md: 0 4px 6px -1px rgba(0,0,0,.1);
        --sidebar-width: 240px;
    }
    body {
        margin: 0;
        font-family: var(--font);
        background: var(--color-gray-50);
        color: var(--color-gray-900);
        font-size: 14px;
        line-height: 1.6;
    }

    /* Superadmin / emulation banners */
    .banner-superadmin {
        background: #7c3aed; color: #fff;
        padding: .5rem 1rem; text-align: center; font-size: 13px; font-weight: 600;
        display: flex; align-items: center; justify-content: center; gap: 1rem;
    }
    .banner-emulating {
        background: #dc2626; color: #fff;
        padding: .5rem 1rem; text-align: center; font-size: 13px; font-weight: 600;
        display: flex; align-items: center; justify-content: center; gap: 1rem;
        animation: pulse 2s infinite;
    }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:.85} }
    .banner-emulating form, .banner-superadmin form { display:inline; }
    .banner-emulating button, .banner-superadmin button {
        background: rgba(255,255,255,.2); border: 1px solid rgba(255,255,255,.4);
        color: #fff; padding: .2rem .7rem; border-radius: 4px; cursor: pointer; font-size: 12px;
    }

    /* Layout */
    .layout { display: flex; min-height: 100vh; }
    .sidebar {
        width: var(--sidebar-width); background: #1e1b4b;
        color: #c7d2fe; display: flex; flex-direction: column;
        position: sticky; top: 0; height: 100vh; overflow-y: auto; flex-shrink: 0;
    }
    .sidebar-logo {
        padding: 1.25rem 1.5rem; font-size: 1.1rem; font-weight: 700;
        color: #fff; border-bottom: 1px solid rgba(255,255,255,.08);
        text-decoration: none; display: block;
    }
    .sidebar-nav { padding: .75rem 0; flex: 1; }
    .sidebar-nav a, .sidebar-nav button {
        display: flex; align-items: center; gap: .6rem;
        padding: .55rem 1.5rem; color: #c7d2fe; text-decoration: none;
        font-size: 13.5px; border: none; background: none; width: 100%; text-align: left;
        cursor: pointer; border-radius: 0; transition: background .15s, color .15s;
    }
    .sidebar-nav a:hover, .sidebar-nav button:hover { background: rgba(255,255,255,.07); color: #fff; }
    .sidebar-nav a.active { background: var(--color-primary); color: #fff; }
    .sidebar-section { padding: .5rem 1.5rem .25rem; font-size: 10px; font-weight: 700;
        text-transform: uppercase; letter-spacing: .08em; color: #6366f1; margin-top: .5rem; }
    .sidebar-nav .submenu { padding-left: 1rem; display: none; }
    .sidebar-nav .has-submenu.open .submenu { display: block; }
    .sidebar-nav .submenu a { padding-left: 2.2rem; font-size: 13px; color: #a5b4fc; }

    /* Main area */
    .main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
    .topbar {
        background: #fff; border-bottom: 1px solid var(--color-gray-200);
        padding: .75rem 1.5rem; display: flex; align-items: center;
        justify-content: space-between; gap: 1rem; position: sticky; top: 0; z-index: 10;
        box-shadow: var(--shadow);
    }
    .topbar-left { display: flex; align-items: center; gap: 1rem; }
    .topbar-right { display: flex; align-items: center; gap: .75rem; }
    .page-title { font-size: 1rem; font-weight: 600; color: var(--color-gray-900); margin: 0; }

    /* Content */
    .content { padding: 1.5rem; flex: 1; }

    /* Cards */
    .card {
        background: #fff; border-radius: var(--radius); box-shadow: var(--shadow);
        border: 1px solid var(--color-gray-200);
    }
    .card-header {
        padding: 1rem 1.25rem; border-bottom: 1px solid var(--color-gray-200);
        display: flex; align-items: center; justify-content: space-between;
    }
    .card-header h2 { margin: 0; font-size: .95rem; font-weight: 600; }
    .card-body { padding: 1.25rem; }

    /* Alert / Flash */
    .alert {
        padding: .85rem 1rem; border-radius: var(--radius); margin-bottom: 1rem;
        font-size: 13.5px; display: flex; align-items: center; gap: .5rem;
    }
    .alert-success { background: #d1fae5; color: #065f46; border: 1px solid #6ee7b7; }
    .alert-error   { background: #fee2e2; color: #991b1b; border: 1px solid #fca5a5; }
    .alert-warning  { background: #fef3c7; color: #92400e; border: 1px solid #fcd34d; }
    .alert-info    { background: #dbeafe; color: #1e40af; border: 1px solid #93c5fd; }

    /* Forms */
    .form-group { margin-bottom: 1rem; }
    .form-group label { display: block; font-weight: 500; margin-bottom: .35rem; font-size: 13.5px; }
    .form-control {
        width: 100%; padding: .55rem .75rem; border: 1px solid var(--color-gray-300);
        border-radius: 6px; font-size: 14px; font-family: var(--font);
        transition: border-color .15s, box-shadow .15s; background: #fff;
    }
    .form-control:focus {
        outline: none; border-color: var(--color-primary);
        box-shadow: 0 0 0 3px rgba(79,70,229,.15);
    }
    .form-control.is-invalid { border-color: var(--color-danger); }
    .form-error { color: var(--color-danger); font-size: 12px; margin-top: .25rem; display: block; }
    textarea.form-control { resize: vertical; min-height: 100px; }
    select.form-control { appearance: none; background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' fill='%236b7280' viewBox='0 0 16 16'%3E%3Cpath d='M7.247 11.14 2.451 5.658C1.885 5.013 2.345 4 3.204 4h9.592a1 1 0 0 1 .753 1.659l-4.796 5.48a1 1 0 0 1-1.506 0z'/%3E%3C/svg%3E"); background-repeat: no-repeat; background-position: right .75rem center; padding-right: 2rem; }

    /* Buttons */
    .btn {
        display: inline-flex; align-items: center; gap: .4rem;
        padding: .5rem 1rem; border-radius: 6px; font-weight: 500; font-size: 13.5px;
        cursor: pointer; text-decoration: none; border: 1px solid transparent;
        transition: all .15s; font-family: var(--font); line-height: 1.4;
    }
    .btn-primary   { background: var(--color-primary); color: #fff; border-color: var(--color-primary); }
    .btn-primary:hover { background: var(--color-primary-dark); border-color: var(--color-primary-dark); }
    .btn-secondary { background: #fff; color: var(--color-gray-700); border-color: var(--color-gray-300); }
    .btn-secondary:hover { background: var(--color-gray-50); }
    .btn-danger    { background: var(--color-danger); color: #fff; border-color: var(--color-danger); }
    .btn-danger:hover { background: #dc2626; }
    .btn-success   { background: var(--color-success); color: #fff; border-color: var(--color-success); }
    .btn-sm { padding: .3rem .65rem; font-size: 12.5px; }
    .btn-xs { padding: .2rem .5rem; font-size: 11.5px; }

    /* Tables */
    .table { width: 100%; border-collapse: collapse; font-size: 13.5px; }
    .table th, .table td { padding: .65rem 1rem; text-align: left; border-bottom: 1px solid var(--color-gray-100); }
    .table th { font-weight: 600; color: var(--color-gray-500); font-size: 12px; text-transform: uppercase; letter-spacing: .04em; background: var(--color-gray-50); }
    .table tbody tr:hover { background: var(--color-gray-50); }
    .table-responsive { overflow-x: auto; }

    /* Badges */
    .badge {
        display: inline-block; padding: .2rem .55rem; border-radius: 999px;
        font-size: 11px; font-weight: 600; line-height: 1;
    }
    .badge-primary { background: #e0e7ff; color: #3730a3; }
    .badge-success { background: #d1fae5; color: #065f46; }
    .badge-danger  { background: #fee2e2; color: #991b1b; }
    .badge-warning { background: #fef3c7; color: #92400e; }
    .badge-gray    { background: var(--color-gray-100); color: var(--color-gray-700); }

    /* Grid */
    .grid { display: grid; gap: 1rem; }
    .grid-2 { grid-template-columns: repeat(2, 1fr); }
    .grid-3 { grid-template-columns: repeat(3, 1fr); }
    .grid-4 { grid-template-columns: repeat(4, 1fr); }

    /* Stats card */
    .stat-card {
        background: #fff; border-radius: var(--radius); padding: 1.25rem;
        border: 1px solid var(--color-gray-200); box-shadow: var(--shadow);
    }
    .stat-card .stat-label { font-size: 12px; color: var(--color-gray-500); font-weight: 500; text-transform: uppercase; letter-spacing: .04em; }
    .stat-card .stat-value { font-size: 2rem; font-weight: 700; color: var(--color-gray-900); line-height: 1.2; margin-top: .25rem; }

    /* Toggle switch */
    .toggle-switch { position: relative; display: inline-block; width: 44px; height: 24px; }
    .toggle-switch input { opacity: 0; width: 0; height: 0; }
    .toggle-slider {
        position: absolute; inset: 0; background: var(--color-gray-300);
        border-radius: 999px; cursor: pointer; transition: background .2s;
    }
    .toggle-slider::before {
        content: ''; position: absolute; width: 18px; height: 18px;
        left: 3px; top: 3px; background: #fff; border-radius: 50%;
        transition: transform .2s; box-shadow: 0 1px 3px rgba(0,0,0,.2);
    }
    .toggle-switch input:checked + .toggle-slider { background: var(--color-primary); }
    .toggle-switch input:checked + .toggle-slider::before { transform: translateX(20px); }

    /* Avatar */
    .avatar {
        width: 32px; height: 32px; border-radius: 50%; object-fit: cover;
        background: var(--color-primary); color: #fff;
        display: inline-flex; align-items: center; justify-content: center;
        font-weight: 600; font-size: 13px;
    }

    /* User dropdown */
    .user-menu { position: relative; }
    .user-menu-toggle { background: none; border: none; cursor: pointer; display: flex; align-items: center; gap: .5rem; padding: .3rem .5rem; border-radius: 6px; }
    .user-menu-toggle:hover { background: var(--color-gray-100); }
    .dropdown-menu {
        position: absolute; right: 0; top: 100%; margin-top: .35rem;
        background: #fff; border: 1px solid var(--color-gray-200); border-radius: var(--radius);
        box-shadow: var(--shadow-md); min-width: 180px; z-index: 100; display: none;
    }
    .dropdown-menu.open { display: block; }
    .dropdown-menu a, .dropdown-menu button {
        display: block; width: 100%; text-align: left; padding: .55rem 1rem;
        font-size: 13.5px; color: var(--color-gray-700); text-decoration: none;
        background: none; border: none; cursor: pointer; font-family: var(--font);
    }
    .dropdown-menu a:hover, .dropdown-menu button:hover { background: var(--color-gray-50); }
    .dropdown-divider { border-top: 1px solid var(--color-gray-200); margin: .25rem 0; }

    /* Notifications bell */
    .notif-bell { position: relative; }
    .notif-count {
        position: absolute; top: -4px; right: -4px;
        background: var(--color-danger); color: #fff; border-radius: 999px;
        font-size: 10px; font-weight: 700; padding: 1px 5px; line-height: 1.4;
    }

    /* Pagination */
    .pagination { display: flex; gap: .35rem; align-items: center; flex-wrap: wrap; }
    .pagination a, .pagination span {
        padding: .35rem .65rem; border-radius: 6px; font-size: 13px;
        border: 1px solid var(--color-gray-200); text-decoration: none; color: var(--color-gray-700);
    }
    .pagination a:hover { background: var(--color-gray-50); }
    .pagination .current { background: var(--color-primary); color: #fff; border-color: var(--color-primary); }

    /* Responsive */
    @media (max-width: 768px) {
        .sidebar { display: none; }
        .grid-2, .grid-3, .grid-4 { grid-template-columns: 1fr; }
    }

    /* ── Topbar layout variant ─────────────────────────────────────────
       Chosen via /admin/settings/appearance. When active, the sidebar is
       hidden and the main navigation runs horizontally across the top.
       The page-title in the topbar is also hidden since a logo + nav
       takes that space; pages are responsible for their own h1. */
    .layout--topbar .sidebar    { display: none; }
    .layout--topbar .main       { width: 100%; }
    .layout--topbar .page-title { display: none; }

    .topbar-nav {
        display: flex; align-items: center; gap: .15rem .35rem;
        flex-wrap: wrap; flex: 1; min-width: 0;
    }
    .topbar-logo {
        font-weight: 700; font-size: 1.05rem; color: #111827;
        text-decoration: none; padding: 0 1rem 0 0;
        border-right: 1px solid var(--color-gray-200); margin-right: .5rem;
        white-space: nowrap;
    }
    .topbar-nav > a, .topbar-nav .topbar-dd-toggle {
        color: var(--color-gray-700); text-decoration: none;
        font-size: 13.5px; padding: .4rem .7rem; border-radius: 6px;
        background: none; border: none; cursor: pointer; white-space: nowrap;
    }
    .topbar-nav > a:hover, .topbar-nav .topbar-dd-toggle:hover {
        color: var(--color-primary); background: #f5f3ff;
    }
    .topbar-dd           { position: relative; }
    .topbar-dd-menu {
        display: none; position: absolute; top: 100%; left: 0;
        background: #fff; border: 1px solid var(--color-gray-200);
        border-radius: 6px; box-shadow: var(--shadow-md);
        min-width: 180px; padding: .35rem; z-index: 20;
    }
    .topbar-dd.open .topbar-dd-menu { display: block; }
    .topbar-dd-menu a {
        display: block; padding: .4rem .65rem; border-radius: 4px;
        color: var(--color-gray-700); text-decoration: none; font-size: 13.5px;
    }
    .topbar-dd-menu a:hover { background: #f5f3ff; color: var(--color-primary); }

    /* On narrow screens keep behavior sane even in topbar mode. Already
       under the 768px sidebar-hide rule above, so topbar is effectively
       the only option for phones. */
    @media (max-width: 640px) {
        .topbar-logo { border-right: none; padding-right: .5rem; }
    }
    </style>

    <?php
    // Theme override: emit saved color settings as a :root rule so they
    // win over the baseline palette above. Empty/missing settings fall
    // through to the baseline — we only emit rules for values that are
    // actually set. Color-name → CSS-custom-property map is fixed; a
    // stray setting key that doesn't appear here is intentionally ignored.
    $__theme_map = [
        'color_primary'      => '--color-primary',
        'color_primary_dark' => '--color-primary-dark',
        'color_secondary'    => '--color-secondary',
        'color_success'      => '--color-success',
        'color_danger'       => '--color-danger',
        'color_warning'      => '--color-warning',
        'color_info'         => '--color-info',
    ];
    $__theme_overrides = [];
    foreach ($__theme_map as $setKey => $cssVar) {
        $val = trim((string) setting($setKey, ''));
        if ($val !== '') {
            $__theme_overrides[] = "$cssVar: " . htmlspecialchars($val, ENT_QUOTES, 'UTF-8');
        }
    }
    if (!empty($__theme_overrides)):
    ?>
    <style>:root { <?= implode('; ', $__theme_overrides) ?>; }</style>
    <?php endif; ?>

    <?php
    // Analytics tracking snippet — renders the configured provider's
    // script tag (Plausible / GA / Umami), or nothing when
    // ANALYTICS_PROVIDER=none. Emitted last so custom theme styles
    // above still load first.
    echo \Core\Services\AnalyticsService::snippet();
    ?>
</head>
<body>
<a href="#main-content" class="skip-link">Skip to main content</a>
<?php $auth = \Core\Auth\Auth::getInstance(); ?>

<?php if ($auth->isEmulating()): ?>
<div class="banner-emulating">
    ⚠️ EMULATING USER: <?= e(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? '') . ' &lt;' . ($user['email'] ?? '') . '&gt;') ?>
    — All actions are being logged
    <form method="POST" action="/admin/emulate/stop"><?= csrf_field() ?>
        <button type="submit">Stop Emulating</button>
    </form>
</div>
<?php elseif ($auth->isSuperadminModeOn()): ?>
<div class="banner-superadmin">
    🛡️ SUPERADMIN MODE ACTIVE
    <form method="POST" action="/admin/superadmin/toggle-mode"><?= csrf_field() ?>
        <input type="hidden" name="enable" value="0">
        <button type="submit">Disable</button>
    </form>
</div>
<?php endif; ?>

<?php if ($auth->check() && empty($auth->user()['email_verified_at'])): ?>
<!-- Unverified-email banner — shown on every authenticated page until the
     user clicks the link in their inbox. The resend POST is rate-limited
     server-side to one per 60 seconds. -->
<div style="background:#fef3c7;color:#92400e;border-bottom:1px solid #fde68a;padding:.6rem 1rem;font-size:13.5px;display:flex;justify-content:center;align-items:center;gap:.75rem;flex-wrap:wrap">
    <span>📬 Your email address is not verified. Check your inbox for the verification link.</span>
    <form method="POST" action="/auth/resend-verification" style="margin:0">
        <?= csrf_field() ?>
        <button type="submit" style="background:#d97706;color:#fff;border:none;padding:.3rem .75rem;border-radius:4px;font-size:12.5px;font-weight:600;cursor:pointer">
            Resend email
        </button>
    </form>
</div>
<?php endif; ?>

<?php
// Layout orientation: 'sidebar' (default) or 'topbar'. In topbar mode
// the sidebar is hidden via CSS and the topbar renders its own nav row.
// We keep the sidebar markup in both modes — easier to reason about, and
// hiding via CSS means no duplicated link lists.
$__layout_orient = (string) setting('layout_orientation', 'sidebar');
if (!in_array($__layout_orient, ['sidebar', 'topbar'], true)) $__layout_orient = 'sidebar';
?>
<div class="layout layout--<?= e($__layout_orient) ?>">
    <!-- Sidebar -->
    <aside class="sidebar">
        <a href="/dashboard" class="sidebar-logo">🚀 <?= e(setting('site_name', 'App')) ?></a>
        <nav class="sidebar-nav">
            <?php foreach (menu('header') as $menuItem): ?>
                <?php if (!empty($menuItem['children'])): ?>
                    <div class="has-submenu" onclick="this.classList.toggle('open')">
                        <?php if ($menuItem['url']): ?>
                            <a href="<?= e($menuItem['url']) ?>"><?= e($menuItem['label']) ?> ▾</a>
                        <?php else: ?>
                            <button><?= e($menuItem['label']) ?> ▾</button>
                        <?php endif; ?>
                        <div class="submenu">
                            <?php foreach ($menuItem['children'] as $menuChild): ?>
                                <a href="<?= e($menuChild['url'] ?? '#') ?>"><?= e($menuChild['label']) ?></a>
                            <?php endforeach; unset($menuChild); ?>
                        </div>
                    </div>
                <?php else: ?>
                    <a href="<?= e($menuItem['url'] ?? '#') ?>"><?= e($menuItem['label']) ?></a>
                <?php endif; ?>
            <?php endforeach; unset($menuItem); ?>

            <?php if ($auth->check()): ?>
            <a href="/content">My Content</a>
            <a href="/profile/2fa">🛡️ Two-Factor Auth</a>
            <?php endif; ?>

            <?php if ($auth->check() && $auth->hasRole(['super-admin','admin'])): ?>
            <div class="sidebar-section">Admin</div>
            <a href="/admin/users">Users</a>
            <a href="/admin/roles">Roles</a>
            <a href="/admin/groups">Groups</a>
            <a href="/admin/menus">Menus</a>
            <a href="/admin/pages">Pages</a>
            <a href="/admin/faqs">FAQ</a>
            <?php endif; ?>

            <?php if ($auth->isSuperAdmin()): ?>
            <div class="sidebar-section">Superadmin</div>
            <a href="/admin/superadmin">SA Dashboard</a>
            <a href="/admin/superadmin/users">All Users</a>
            <a href="/admin/superadmin/audit-log">Audit Log</a>
            <a href="/admin/superadmin/message-log">Message Log</a>
            <a href="/admin/settings">Site Settings</a>
            <a href="/admin/integrations">Integrations</a>
            <?php endif; ?>
        </nav>
    </aside>

    <!-- Main -->
    <div class="main">
        <header class="topbar">
            <div class="topbar-left">
                <?php if ($__layout_orient === 'topbar'): ?>
                    <a href="/dashboard" class="topbar-logo">🚀 <?= e(setting('site_name', 'App')) ?></a>
                    <nav class="topbar-nav" aria-label="Primary">
                        <?php foreach (menu('header') as $__tb_item): ?>
                            <a href="<?= e($__tb_item['url'] ?? '#') ?>"><?= e($__tb_item['label']) ?></a>
                        <?php endforeach; unset($__tb_item); ?>

                        <?php if ($auth->check()): ?>
                            <a href="/content">My Content</a>
                        <?php endif; ?>

                        <?php if ($auth->check() && $auth->hasRole(['super-admin','admin'])): ?>
                        <!-- Admin dropdown. Clicking the toggle flips .open on the
                             parent .topbar-dd; the existing body-level click handler
                             in footer.php closes dropdowns when the user clicks
                             outside (it targets .user-menu specifically, so we add
                             one here for the topbar-dd equivalents). -->
                        <div class="topbar-dd">
                            <button type="button" class="topbar-dd-toggle" onclick="this.parentElement.classList.toggle('open')">Admin ▾</button>
                            <div class="topbar-dd-menu">
                                <a href="/admin/users">Users</a>
                                <a href="/admin/roles">Roles</a>
                                <a href="/admin/groups">Groups</a>
                                <a href="/admin/menus">Menus</a>
                                <a href="/admin/pages">Pages</a>
                                <a href="/admin/faqs">FAQ</a>
                            </div>
                        </div>
                        <?php endif; ?>

                        <?php if ($auth->isSuperAdmin()): ?>
                        <div class="topbar-dd">
                            <button type="button" class="topbar-dd-toggle" onclick="this.parentElement.classList.toggle('open')">Superadmin ▾</button>
                            <div class="topbar-dd-menu">
                                <a href="/admin/superadmin">SA Dashboard</a>
                                <a href="/admin/superadmin/users">All Users</a>
                                <a href="/admin/superadmin/audit-log">Audit Log</a>
                                <a href="/admin/superadmin/message-log">Message Log</a>
                                <a href="/admin/settings">Site Settings</a>
                                <a href="/admin/integrations">Integrations</a>
                            </div>
                        </div>
                        <?php endif; ?>
                    </nav>
                <?php else: ?>
                    <h1 class="page-title"><?= e($pageTitle ?? '') ?></h1>
                <?php endif; ?>
            </div>
            <div class="topbar-right">
                <!-- Inline search -->
                <form method="GET" action="/search" style="display:flex;align-items:center">
                    <input type="text" name="q" placeholder="Search…" aria-label="Search"
                           class="form-control" style="width:180px;padding:.35rem .65rem;font-size:13px">
                </form>
                <?php if ($auth->check()): ?>
                <!-- Superadmin mode toggle -->
                <?php if ($auth->isSuperAdmin() && !$auth->isEmulating()): ?>
                <form method="POST" action="/admin/superadmin/toggle-mode" style="display:inline">
                    <?= csrf_field() ?>
                    <input type="hidden" name="enable" value="<?= $auth->isSuperadminModeOn() ? 0 : 1 ?>">
                    <label class="toggle-switch" title="Superadmin Mode">
                        <input type="checkbox" onchange="this.form.submit()" <?= $auth->isSuperadminModeOn() ? 'checked' : '' ?>>
                        <span class="toggle-slider"></span>
                    </label>
                </form>
                <?php endif; ?>

                <!-- Notifications -->
                <div class="notif-bell">
                    <a href="/notifications" style="font-size:1.2rem; text-decoration:none;">🔔</a>
                    <?php
                    $notifSvc = new \Core\Services\NotificationService();
                    $unread   = count($notifSvc->getUnread($auth->id(), 99));
                    if ($unread): ?>
                    <span class="notif-count"><?= $unread ?></span>
                    <?php endif; ?>
                </div>

                <!-- User menu -->
                <div class="user-menu">
                    <button class="user-menu-toggle" onclick="this.nextElementSibling.classList.toggle('open')">
                        <?php $u = $auth->user(); ?>
                        <span class="avatar"><?= e(strtoupper(substr($u['first_name'] ?? 'U', 0, 1))) ?></span>
                        <span><?= e(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? '')) ?></span>
                        ▾
                    </button>
                    <div class="dropdown-menu">
                        <a href="/profile">My Profile</a>
                        <a href="/profile/2fa">🛡️ Two-Factor Auth</a>
                        <a href="/groups">My Groups</a>
                        <div class="dropdown-divider"></div>
                        <form method="POST" action="/logout"><?= csrf_field() ?>
                            <button type="submit">Sign Out</button>
                        </form>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </header>

        <main class="content" id="main-content">
            <?php foreach (['success','error','warning','info'] as $flashType): ?>
                <?php $msg = \Core\Session::flash($flashType); ?>
                <?php if ($msg): ?>
                <div class="alert alert-<?= $flashType ?>">
                    <?= e($msg) ?>
                </div>
                <?php endif; ?>
            <?php endforeach; unset($flashType, $msg); ?>
