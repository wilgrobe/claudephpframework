<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    // Canonical is the root for the page that's set as the guest home, and
    // /{slug} for everything else. Prevents the home page from being indexed
    // under two distinct URLs.
    $__home_slug = setting('guest_home_page_slug', '');
    $__canonical_path = ($__home_slug !== '' && $__home_slug === $page['slug']) ? '/' : '/' . $page['slug'];
    ?>
    <?= \Core\SEO\SeoManager::metaTags([
        'title'       => ($page['seo_title'] ?: $page['title']) . ' — ' . setting('site_name', 'App'),
        'description' => $page['seo_description'] ?? '',
        'keywords'    => $page['seo_keywords'] ?? '',
        'canonical'   => config('app.url') . $__canonical_path,
    ]) ?>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <?php echo \Core\Services\AnalyticsService::snippet(); ?>
    <style>
    *, *::before, *::after { box-sizing: border-box; }
    body { margin: 0; font-family: 'Inter', system-ui, sans-serif; background: #f9fafb; color: #111827; }
    .site-header {
        background: #fff; border-bottom: 1px solid #e5e7eb; padding: .85rem 1.5rem;
        display: flex; align-items: center; justify-content: space-between;
    }
    .site-logo { font-weight: 700; font-size: 1.1rem; text-decoration: none; color: #111827; }
    .nav-links { display: flex; gap: 1.25rem; align-items: center; }
    .nav-links a { text-decoration: none; color: #374151; font-size: 14px; }
    .nav-links a:hover { color: #4f46e5; }
    .btn-login { background: #4f46e5; color: #fff !important; padding: .4rem .9rem; border-radius: 6px; font-size: 13.5px; font-weight: 500; }

    .page-hero { background: #fff; border-bottom: 1px solid #e5e7eb; padding: 3rem 1.5rem; text-align: center; }
    .page-hero h1 { font-size: 2rem; font-weight: 700; margin: 0 0 .5rem; }
    .page-hero .meta { color: #6b7280; font-size: 13.5px; }

    .page-body { max-width: <?= ($page['layout'] ?? 'default') === 'wide' ? '1100px' : '760px' ?>; margin: 2.5rem auto; padding: 0 1.5rem; line-height: 1.8; font-size: 15px; }
    .page-body h2 { font-size: 1.4rem; margin-top: 2rem; }
    .page-body h3 { font-size: 1.15rem; margin-top: 1.5rem; }
    .page-body p { margin: 0 0 1rem; }
    .page-body a { color: #4f46e5; }
    .page-body ul, .page-body ol { margin: 0 0 1rem; padding-left: 1.5rem; }

    /* .site-footer styles now live in app/Views/partials/site_footer.php so
       the authenticated layout and this public page share one appearance. */
    .site-footer { margin-top: 4rem; }
    </style>
</head>
<body>
<header class="site-header">
    <a href="/" class="site-logo">🚀 <?= e(setting('site_name', 'App')) ?></a>
    <nav class="nav-links">
        <a href="/faq">FAQ</a>
        <?php if ($user): ?>
        <a href="/dashboard">Dashboard</a>
        <?php else: ?>
        <a href="/login" class="btn-login">Sign In</a>
        <?php endif; ?>
    </nav>
</header>

<div class="page-hero">
    <h1><?= e($page['title']) ?></h1>
</div>

<article class="page-body">
    <?= \Core\Validation\Validator::sanitizeHtml($page['body'] ?? '') /* DOMDocument allowlist re-applied as defense-in-depth */ ?>
</article>

<?php include BASE_PATH . '/app/Views/partials/site_footer.php'; ?>
</body>
</html>
