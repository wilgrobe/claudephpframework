<?php $pageTitle = 'Create Account'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Create Account — <?= e(setting('site_name', 'App')) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{box-sizing:border-box}
:root{--primary:#4f46e5;--primary-dark:#3730a3;--danger:#ef4444;--gray-50:#f9fafb;--gray-200:#e5e7eb;--gray-300:#d1d5db;--gray-500:#6b7280;--gray-900:#111827}
body{margin:0;font-family:'Inter',sans-serif;background:var(--gray-50);display:flex;align-items:center;justify-content:center;min-height:100vh;padding:2rem 1rem}
.auth-card{background:#fff;border-radius:12px;box-shadow:0 4px 24px rgba(0,0,0,.08);padding:2.5rem;width:100%;max-width:460px}
h1{font-size:1.4rem;font-weight:700;margin:0 0 .25rem;text-align:center}
.subtitle{color:var(--gray-500);font-size:14px;text-align:center;margin-bottom:1.75rem}
.row{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.form-group{margin-bottom:1rem}
.form-group label{display:block;font-weight:500;font-size:13.5px;margin-bottom:.35rem}
.form-control{width:100%;padding:.6rem .8rem;border:1px solid var(--gray-300);border-radius:6px;font-size:14px;font-family:inherit;transition:border-color .15s,box-shadow .15s}
.form-control:focus{outline:none;border-color:var(--primary);box-shadow:0 0 0 3px rgba(79,70,229,.15)}
.form-control.is-invalid{border-color:var(--danger)}
.form-error{color:var(--danger);font-size:12px;margin-top:.25rem;display:block}
.btn{display:flex;align-items:center;justify-content:center;width:100%;padding:.7rem;border-radius:6px;font-weight:600;font-size:14px;cursor:pointer;border:none;font-family:inherit;background:var(--primary);color:#fff;transition:background .15s}
.btn:hover{background:var(--primary-dark)}
.btn-oauth{background:#fff;color:var(--gray-900);border:1px solid var(--gray-300);font-weight:500;margin-bottom:.5rem}
.btn-oauth:hover{background:var(--gray-50)}
.divider{display:flex;align-items:center;gap:.75rem;margin:1.25rem 0;color:var(--gray-500);font-size:12px}
.divider::before,.divider::after{content:'';flex:1;border-top:1px solid var(--gray-200)}
.footer{text-align:center;margin-top:1.5rem;font-size:13.5px;color:var(--gray-500)}
.footer a{color:var(--primary);text-decoration:none;font-weight:500}
.invite-notice{background:#ede9fe;border:1px solid #c4b5fd;color:#4c1d95;padding:.75rem 1rem;border-radius:6px;font-size:13.5px;margin-bottom:1rem}
</style>
</head>
<body>
<div class="auth-card">
    <h1>Create your account</h1>
    <p class="subtitle">Join <?= e(setting('site_name', 'App')) ?></p>

    <?php if (!empty($invite_token)): ?>
    <div class="invite-notice">🎉 You have a group invitation waiting! Create an account to accept it.</div>
    <?php endif; ?>

    <?php $errs = $errors ?? []; ?>

    <?php if (!empty($oauth_providers)): ?>
    <?php $meta = ['google'=>['G','#ea4335'],'microsoft'=>['M','#00a4ef'],'apple'=>['🍎','#000'],'facebook'=>['f','#1877f2'],'linkedin'=>['in','#0a66c2']]; ?>
    <?php foreach ($oauth_providers as $p): $m = $meta[$p] ?? ['?','#666']; ?>
    <a href="/auth/oauth/<?= e($p) ?>" class="btn btn-oauth">
        <span style="font-weight:700;color:<?= $m[1] ?>"><?= $m[0] ?></span>
        Continue with <?= e(ucfirst($p)) ?>
    </a>
    <?php endforeach; ?>
    <div class="divider">or register with email</div>
    <?php endif; ?>

    <form method="POST" action="/register">
        <?= csrf_field() ?>
        <?php if (!empty($invite_token)): ?>
        <input type="hidden" name="invite_token" value="<?= e($invite_token) ?>">
        <?php endif; ?>

        <div class="row">
            <div class="form-group">
                <label>First Name</label>
                <input type="text" name="first_name" class="form-control <?= !empty($errs['first_name']) ? 'is-invalid':'' ?>"
                       value="<?= old('first_name') ?>" required>
                <?php if (!empty($errs['first_name'])): ?><span class="form-error"><?= e($errs['first_name'][0]) ?></span><?php endif; ?>
            </div>
            <div class="form-group">
                <label>Last Name</label>
                <input type="text" name="last_name" class="form-control <?= !empty($errs['last_name']) ? 'is-invalid':'' ?>"
                       value="<?= old('last_name') ?>" required>
                <?php if (!empty($errs['last_name'])): ?><span class="form-error"><?= e($errs['last_name'][0]) ?></span><?php endif; ?>
            </div>
        </div>

        <div class="form-group">
            <label>Email address</label>
            <input type="email" name="email" class="form-control <?= !empty($errs['email']) ? 'is-invalid':'' ?>"
                   value="<?= old('email') ?>" required autocomplete="email">
            <?php if (!empty($errs['email'])): ?><span class="form-error"><?= e($errs['email'][0]) ?></span><?php endif; ?>
        </div>

        <div class="form-group">
            <label>Password <span style="color:var(--gray-500);font-weight:400">(min 12 characters)</span></label>
            <input type="password" id="password-input" name="password" class="form-control <?= !empty($errs['password']) ? 'is-invalid':'' ?>"
                   required autocomplete="new-password" minlength="12">
            <?php if (!empty($errs['password'])): ?><span class="form-error"><?= e($errs['password'][0]) ?></span><?php endif; ?>
            <?php include BASE_PATH . '/app/Views/layout/password_strength.php'; ?>
        </div>

        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="password_confirm" class="form-control <?= !empty($errs['password_confirm']) ? 'is-invalid':'' ?>"
                   required autocomplete="new-password">
            <?php if (!empty($errs['password_confirm'])): ?><span class="form-error"><?= e($errs['password_confirm'][0]) ?></span><?php endif; ?>
        </div>

        <?php $__captcha = captcha_widget(); if ($__captcha): ?>
        <div class="form-group"><?= $__captcha ?></div>
        <?php endif; ?>

        <button type="submit" class="btn">Create Account</button>
    </form>

    <div class="footer">Already have an account? <a href="/login">Sign in</a></div>
</div>
</body>
</html>
