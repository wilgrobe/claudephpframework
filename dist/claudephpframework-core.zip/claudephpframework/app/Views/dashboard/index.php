<?php $pageTitle = 'Dashboard'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<?php
// Shared renderer for a content subsection (Personal or per-group).
// Each section gets a sortable table keyed by a unique id so multiple
// tables on the same page can be sorted independently.
$renderContentSection = function (string $tableId, string $heading, array $items, ?string $sublabel = null, ?array $groupRef = null) {
    $count = count($items);
    ?>
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header">
            <div>
                <h2 style="margin:0;font-size:1rem"><?= e($heading) ?></h2>
                <?php if ($sublabel): ?>
                <div style="font-size:12px;color:#6b7280;margin-top:.15rem"><?= e($sublabel) ?></div>
                <?php endif; ?>
            </div>
            <div style="font-size:12.5px;color:#6b7280"><?= $count ?> item<?= $count === 1 ? '' : 's' ?></div>
        </div>

        <?php if (empty($items)): ?>
        <div class="card-body" style="padding:1.25rem;font-size:13.5px;color:#6b7280">
            <?php if ($groupRef): ?>
            No content yet for this group. <a href="/content/create">Create one</a>.
            <?php else: ?>
            You haven't created any personal content yet. <a href="/content/create">Create one</a>.
            <?php endif; ?>
        </div>
        <?php else: ?>
        <div class="table-responsive">
            <table class="table sortable-table" id="<?= e($tableId) ?>">
                <thead>
                    <tr>
                        <!-- data-sort-key + data-sort-type power client-side sort in the inline script below -->
                        <th data-sort-key="title"  data-sort-type="text" style="cursor:pointer">Title <span class="sort-ind"></span></th>
                        <th data-sort-key="type"   data-sort-type="text" style="cursor:pointer;width:110px">Type <span class="sort-ind"></span></th>
                        <th data-sort-key="status" data-sort-type="text" style="cursor:pointer;width:110px">Status <span class="sort-ind"></span></th>
                        <th data-sort-key="owner"  data-sort-type="text" style="cursor:pointer;width:150px">Owner <span class="sort-ind"></span></th>
                        <th data-sort-key="updated" data-sort-type="date" style="cursor:pointer;width:150px">Updated <span class="sort-ind">▼</span></th>
                        <th style="width:50px"></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($items as $row): ?>
                    <?php
                    $ownerLabel = $row['owner_type'] === 'group'
                        ? ($row['group_name'] ?? 'Group')
                        : 'Personal';
                    $ownerIcon  = $row['owner_type'] === 'group' ? '👥' : '👤';
                    $statusBadge = match ($row['status'] ?? 'draft') {
                        'published' => 'badge-success',
                        'archived'  => 'badge-warning',
                        default     => 'badge-gray',
                    };
                    ?>
                    <tr>
                        <td data-title="<?= e($row['title'] ?? '') ?>">
                            <a href="/content/<?= e($row['slug'] ?? '') ?>" style="color:#111827;text-decoration:none;font-weight:500">
                                <?= e($row['title'] ?? '(untitled)') ?>
                            </a>
                        </td>
                        <td data-type="<?= e($row['type'] ?? '') ?>">
                            <span class="badge badge-gray" style="font-size:11px"><?= e($row['type'] ?? 'post') ?></span>
                        </td>
                        <td data-status="<?= e($row['status'] ?? '') ?>">
                            <span class="badge <?= $statusBadge ?>" style="font-size:11px"><?= e($row['status'] ?? 'draft') ?></span>
                        </td>
                        <td data-owner="<?= e($ownerLabel) ?>" style="font-size:13px;color:#6b7280">
                            <?= $ownerIcon ?> <?= e($ownerLabel) ?>
                        </td>
                        <td data-updated="<?= e($row['updated_at'] ?? $row['created_at'] ?? '') ?>" style="font-size:12.5px;color:#9ca3af;white-space:nowrap">
                            <?php $dt = $row['updated_at'] ?? $row['created_at'] ?? null; ?>
                            <?= $dt ? date('M j, Y', strtotime($dt)) : '—' ?>
                        </td>
                        <td style="text-align:right">
                            <a href="/content/<?= (int)($row['id'] ?? 0) ?>/edit" style="font-size:12px;color:#4f46e5;text-decoration:none">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>
    </div>
    <?php
};
?>

<!-- ── Top stats strip ──────────────────────────────────────────────────── -->
<div class="grid grid-4" style="margin-bottom:1.5rem">
    <div class="stat-card">
        <div class="stat-label">My Groups</div>
        <div class="stat-value"><?= count($myGroups ?? []) ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Unread Notifications</div>
        <div class="stat-value"><?= (int)($unreadCount ?? 0) ?></div>
    </div>
    <?php if (auth()->hasRole(['super-admin','admin'])): ?>
    <div class="stat-card">
        <div class="stat-label">Total Users</div>
        <div class="stat-value"><?= $stats['users'] ?? '—' ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Groups</div>
        <div class="stat-value"><?= $stats['groups'] ?? '—' ?></div>
    </div>
    <?php endif; ?>
</div>

<!-- ── Main grid: content on the left, My Groups + Notifications on the right ── -->
<div style="display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:1.5rem;align-items:start">

    <!-- LEFT COLUMN: Content feed -->
    <div style="min-width:0">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:.85rem">
            <h1 style="margin:0;font-size:1.1rem;font-weight:600">Content</h1>
            <a href="/content/create" class="btn btn-sm btn-primary">+ New Content</a>
        </div>

        <!-- Pending content-transfer approvals.
             Renders for users with something to act on: group admins with a
             pending group→individual request, OR individuals who are the
             named recipient on a user→user transfer. Per-row buttons vary
             by flow. -->
        <?php if (!empty($pendingTransfers)): ?>
        <div id="pending-transfers" class="card" style="margin-bottom:1rem;border-left:3px solid #f59e0b">
            <div class="card-header">
                <h2 style="margin:0;font-size:1rem">⏳ Pending Transfer Approvals</h2>
                <div style="font-size:12.5px;color:#6b7280"><?= count($pendingTransfers) ?> awaiting review</div>
            </div>
            <div class="card-body" style="padding:0">
                <?php foreach ($pendingTransfers as $pt): ?>
                <?php $flow = $pt['flow'] ?? 'group_admin'; ?>
                <div style="padding:.85rem 1.25rem;border-bottom:1px solid #f3f4f6;display:flex;gap:1rem;align-items:center;flex-wrap:wrap">
                    <div style="flex:1;min-width:220px">
                        <div style="font-weight:500;font-size:13.5px;color:#111827">
                            <a href="/content/<?= e($pt['slug'] ?? '') ?>" style="color:#111827;text-decoration:none">
                                <?= e($pt['title'] ?? '(untitled)') ?>
                            </a>
                        </div>
                        <div style="font-size:12px;color:#6b7280;margin-top:.2rem;line-height:1.4">
                            <?php if ($flow === 'group_admin'): ?>
                                From group <strong><?= e($pt['group_name']) ?></strong>
                                to <strong><?= e(trim($pt['recipient_name'] ?? '') ?: 'an individual') ?></strong>
                            <?php else: ?>
                                Offered to you by <strong><?= e(trim($pt['requester_name'] ?? '') ?: 'someone') ?></strong>
                            <?php endif; ?>
                            · <?= date('M j, g:i A', strtotime($pt['created_at'])) ?>
                        </div>
                    </div>
                    <div style="display:flex;gap:.5rem">
                        <?php if ($flow === 'group_admin'): ?>
                        <form method="POST" action="/content/transfer/<?= (int)$pt['id'] ?>/approve" style="margin:0">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-primary"
                                    onclick="return confirm('Approve this transfer? Ownership will move immediately.')">Approve</button>
                        </form>
                        <form method="POST" action="/content/transfer/<?= (int)$pt['id'] ?>/reject" style="margin:0">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-secondary"
                                    onclick="return confirm('Reject this transfer?')">Reject</button>
                        </form>
                        <?php else: ?>
                        <form method="POST" action="/content/transfer/<?= (int)$pt['id'] ?>/accept" style="margin:0">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-primary"
                                    onclick="return confirm('Accept ownership of this content?')">Accept</button>
                        </form>
                        <form method="POST" action="/content/transfer/<?= (int)$pt['id'] ?>/decline" style="margin:0">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-secondary"
                                    onclick="return confirm('Decline this transfer?')">Decline</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Outgoing transfer requests (what I've requested and is awaiting
             someone else's action). Lets requesters see and cancel their
             own pending requests — especially useful since group→individual
             requests they submit are intentionally hidden from their own
             approval queue. -->
        <?php if (!empty($outgoingTransfers)): ?>
        <div class="card" style="margin-bottom:1rem;border-left:3px solid #6366f1">
            <div class="card-header">
                <h2 style="margin:0;font-size:1rem">📤 My Outgoing Transfer Requests</h2>
                <div style="font-size:12.5px;color:#6b7280"><?= count($outgoingTransfers) ?> awaiting someone else</div>
            </div>
            <div class="card-body" style="padding:0">
                <?php foreach ($outgoingTransfers as $ot): ?>
                <div style="padding:.85rem 1.25rem;border-bottom:1px solid #f3f4f6;display:flex;gap:1rem;align-items:center;flex-wrap:wrap">
                    <div style="flex:1;min-width:220px">
                        <div style="font-weight:500;font-size:13.5px;color:#111827">
                            <a href="/content/<?= e($ot['slug'] ?? '') ?>" style="color:#111827;text-decoration:none">
                                <?= e($ot['title'] ?? '(untitled)') ?>
                            </a>
                        </div>
                        <div style="font-size:12px;color:#6b7280;margin-top:.2rem;line-height:1.4">
                            <?php if (($ot['to_type'] ?? '') === 'group'): ?>
                                Awaiting move to group <strong><?= e($ot['group_name'] ?? '') ?></strong>
                            <?php elseif (($ot['from_type'] ?? '') === 'group'): ?>
                                Awaiting group approval · to <strong><?= e(trim($ot['recipient_name'] ?? '') ?: 'an individual') ?></strong>
                            <?php else: ?>
                                Awaiting <strong><?= e(trim($ot['recipient_name'] ?? '') ?: 'recipient') ?></strong> to accept
                            <?php endif; ?>
                            · <?= date('M j, g:i A', strtotime($ot['created_at'])) ?>
                        </div>
                    </div>
                    <div style="display:flex;gap:.5rem">
                        <a href="/content/<?= (int)$ot['content_id'] ?>/transfer" class="btn btn-sm btn-secondary">View</a>
                        <form method="POST" action="/content/transfer/<?= (int)$ot['id'] ?>/cancel" style="margin:0">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-sm btn-secondary"
                                    onclick="return confirm('Cancel your transfer request?')">Cancel</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Personal -->
        <?php $renderContentSection('tbl-personal', 'Personal', $personal, 'Content owned by you', null); ?>

        <!-- One section per group -->
        <?php foreach ($byGroup as $bucket): ?>
            <?php
            $renderContentSection(
                'tbl-group-' . (int)$bucket['group_id'],
                '👥 ' . $bucket['group_name'],
                $bucket['items'],
                'Group-owned content',
                $bucket
            );
            ?>
        <?php endforeach; ?>

        <?php if (empty($personal) && empty($byGroup)): ?>
        <!-- No content at all — show a single empty state instead of two -->
        <?php endif; ?>
    </div>

    <!-- RIGHT COLUMN: My Groups + Notifications -->
    <aside style="display:flex;flex-direction:column;gap:1rem">
        <div class="card">
            <div class="card-header">
                <h2 style="margin:0;font-size:1rem">My Groups</h2>
                <?php if (can_create_group()): ?>
                <a href="/groups/create" class="btn btn-xs btn-primary">+ New</a>
                <?php endif; ?>
            </div>
            <div class="card-body" style="padding:0">
                <?php if (empty($myGroups)): ?>
                <p style="padding:1rem 1.25rem;color:#6b7280;font-size:13px;margin:0">
                    <?php if (can_create_group()): ?>
                    You're not in any groups yet. <a href="/groups/create">Create one</a>.
                    <?php else: ?>
                    You're not in any groups yet.
                    <?php endif; ?>
                </p>
                <?php else: ?>
                    <?php foreach ($myGroups as $g): ?>
                    <a href="/groups/<?= e($g['slug']) ?>" style="display:flex;justify-content:space-between;align-items:center;padding:.75rem 1.25rem;border-bottom:1px solid #f3f4f6;text-decoration:none;color:inherit">
                        <div style="min-width:0;flex:1">
                            <div style="font-weight:500;font-size:13.5px;color:#111827;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">
                                <?= e($g['name']) ?>
                            </div>
                            <div style="font-size:11.5px;color:#9ca3af;margin-top:.1rem">
                                <?= e($g['role_name'] ?? $g['base_role'] ?? 'Member') ?>
                            </div>
                        </div>
                        <span style="font-size:14px;color:#9ca3af">›</span>
                    </a>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h2 style="margin:0;font-size:1rem">Recent Notifications</h2>
                <a href="/notifications" style="font-size:12px;color:#4f46e5;text-decoration:none">View all →</a>
            </div>
            <div class="card-body" style="padding:0">
                <?php if (empty($notifications)): ?>
                <p style="padding:1rem 1.25rem;color:#6b7280;font-size:13px;margin:0">No notifications yet.</p>
                <?php else: ?>
                    <?php foreach (array_slice($notifications, 0, 6) as $n): ?>
                    <div class="notif-row" data-id="<?= e($n['id']) ?>" style="position:relative;padding:.75rem 1.25rem;border-bottom:1px solid #f3f4f6;<?= empty($n['read_at']) ? 'background:#f5f3ff' : '' ?>">
                        <?php if (!empty($n['can_delete'])): ?>
                        <button type="button" onclick="dismissNotification(this)"
                                title="Dismiss" aria-label="Dismiss notification"
                                style="position:absolute;top:.3rem;right:.5rem;background:none;border:none;cursor:pointer;color:#9ca3af;font-size:14px;line-height:1;padding:.15rem .3rem;border-radius:4px">×</button>
                        <?php endif; ?>
                        <div style="font-weight:<?= empty($n['read_at']) ? '600' : '500' ?>;font-size:13px;color:#111827;padding-right:1rem"><?= e($n['title'] ?? '') ?></div>
                        <?php if (!empty($n['body'])): ?>
                        <div style="font-size:12px;color:#6b7280;margin-top:.15rem;line-height:1.4"><?= e($n['body']) ?></div>
                        <?php endif; ?>
                        <div style="font-size:11px;color:#9ca3af;margin-top:.25rem"><?= date('M j, g:i A', strtotime($n['created_at'])) ?></div>
                    </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </aside>

</div>

<style>
/* Sort-header indicators — small arrows that appear on the active column. */
.sortable-table th .sort-ind {
    display: inline-block; width: 10px; color: #9ca3af; margin-left: .15rem; font-size: 10px;
}
.sortable-table th.sort-asc  .sort-ind::before { content: '▲'; color: #4f46e5; }
.sortable-table th.sort-desc .sort-ind::before { content: '▼'; color: #4f46e5; }
.sortable-table th:hover { color: #4f46e5; }

/* Stack to single column on narrow screens so the sidebar doesn't crush content. */
@media (max-width: 960px) {
    div[style*="grid-template-columns:minmax(0,1fr) 320px"] {
        grid-template-columns: 1fr !important;
    }
}
</style>

<script>
/* Client-side sortable tables.
   One instance per .sortable-table on the page. Click a <th> with a
   data-sort-key/data-sort-type to sort that table's rows by that column.
   Clicking the same column toggles asc/desc; clicking a different one
   starts fresh in asc. Default sort is "updated desc" (newest first),
   indicated by the ▼ glyph we seed on the Updated header in PHP. */
document.querySelectorAll('.sortable-table').forEach(table => {
    const tbody = table.querySelector('tbody');
    if (!tbody) return;

    table.querySelectorAll('thead th[data-sort-key]').forEach(th => {
        th.addEventListener('click', () => {
            const key   = th.dataset.sortKey;
            const type  = th.dataset.sortType || 'text';
            const isAsc = !th.classList.contains('sort-asc');

            // Clear sort indicators on all columns in this table.
            table.querySelectorAll('thead th').forEach(h => h.classList.remove('sort-asc', 'sort-desc'));
            th.classList.add(isAsc ? 'sort-asc' : 'sort-desc');

            const rows = Array.from(tbody.querySelectorAll('tr'));
            rows.sort((a, b) => {
                const av = (a.querySelector(`[data-${key}]`)?.dataset[key] ?? '').toString();
                const bv = (b.querySelector(`[data-${key}]`)?.dataset[key] ?? '').toString();
                let cmp;
                if (type === 'date') {
                    cmp = (Date.parse(av) || 0) - (Date.parse(bv) || 0);
                } else {
                    cmp = av.localeCompare(bv, undefined, { sensitivity: 'base', numeric: true });
                }
                return isAsc ? cmp : -cmp;
            });
            rows.forEach(r => tbody.appendChild(r));
        });
    });
});
</script>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
