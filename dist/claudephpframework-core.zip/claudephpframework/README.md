# Claude PHP Framework — Core

A self-contained PHP MVC framework with batteries-included infrastructure for
building web applications and APIs. Ships as a working base app; functionality
like content/pages/FAQ/groups/notifications is available as optional modules
that drop into `modules/`.

## What's in the box

- **HTTP stack** — Router with middleware chains, Request/Response, View engine
  with namespaces and layouts.
- **Database layer** — PDO wrapper with enforced prepared statements,
  chainable query builder, migrations with rollback, base Model.
- **Authentication** — Session auth, OAuth (Google / Microsoft / Facebook /
  LinkedIn), 2FA (TOTP + email/SMS fallback), password resets, rate-limited
  login attempts.
- **Authorization** — Role + permission model with per-user and per-group
  role grants.
- **Queue + Scheduler** — DB-backed job queue with retry/backoff plus a
  cron-driven scheduler running declarative recurring tasks.
- **Payments** — Unified `PaymentGateway` contract with Stripe, Square, and
  Braintree drivers; third-party gateways add themselves via a config map.
- **Search** — `SearchEngine` contract with Meilisearch, Algolia, OpenSearch
  drivers plus a MySQL FULLTEXT fallback. Queue-backed incremental indexing.
- **Media + uploads** — Local filesystem or S3/MinIO via Flysystem.
  Content-type verification, random filenames, image re-encoding strips
  metadata.
- **Email / SMS / Webhooks** — Multi-driver with retry machinery shared across
  channels.
- **Observability** — Sentry client (no SDK dep), structured error logging,
  audit log.
- **Security primitives** — CSRF, rate limiting, CAPTCHA (Cloudflare Turnstile
  / reCAPTCHA / hCaptcha), SSRF guard on outbound webhooks, strict CSP headers.

## Requirements

See [`INSTALL.md`](./INSTALL.md) for full system requirements and step-by-step
setup.

## Where to learn more

- [`INSTALL.md`](./INSTALL.md) — install + first-run checklist
- [`ARCHITECTURE.md`](./ARCHITECTURE.md) — how the subsystems connect
- [`docs/payments-adding-a-gateway.md`](./docs/payments-adding-a-gateway.md) —
  plugging in a new payment provider
- [`CHANGELOG.md`](./CHANGELOG.md) — version history
- [`SECURITY.md`](./SECURITY.md) — reporting vulnerabilities

## Modules (optional)

Feature modules ship as separate zip bundles and drop into `modules/`:
`blog`, `content`, `faq`, `groups`, `integrations`, `menus`, `notifications`,
`pages`, `profile`, `settings`. Each has its own README / INSTALL /
ARCHITECTURE inside its zip (filenames: `claudephpframework-module-{name}.zip`).

## License

See project root.
