# Architecture

How the pieces fit together. Read this after `INSTALL.md` when you want to
extend the framework rather than just run it.

## Request lifecycle

```
browser → public/index.php → bootstrap → router → middleware → controller → view → response
```

1. **`public/index.php`** — entry point. Starts output buffering, loads
   `.env`, starts the session, sets security headers, requires
   `vendor/autoload.php`, then requires `core/bootstrap.php`.
2. **`core/bootstrap.php`** — builds the Container, binds core services
   (Database, Auth, Router, Request, CacheService, Queue, Scheduler,
   SearchService, PaymentsService, all message channels), loads
   `config/services.php` to bind driver contracts, and calls
   `ModuleRegistry::discover()` to register optional modules.
3. **Modules** (if any) register their services, view namespaces, and
   include their `routes.php` files. Module routes load BEFORE
   `routes/web.php` so web.php can override on collision.
4. **`routes/api.php`** (if present) loads before `routes/web.php` — API
   paths take priority over catch-all web routes.
5. **`$router->dispatch($request)`** matches the URL, runs the middleware
   chain, calls the controller, and returns a Response.
6. **Response** is sent; PHP-FPM's `fastcgi_finish_request()` flushes early
   so any post-response work (none in base, extensible via hooks) doesn't
   add latency.

## Major subsystems

### `Core\Container` — service container

Constructor-injection DI with contextual bindings. `singleton()` for shared
instances, `bind()` for per-resolve construction, `instance()` for an already-
built object. Autowires via `ReflectionClass::getConstructor()` when no
explicit binding is registered.

Resolve from anywhere with the `app()` helper:

```php
$queue = app(\Core\Queue\DatabaseQueue::class);
```

### `Core\Router` — HTTP routing

Method+path matching with middleware chains and named routes. Route groups
compound `prefix` + `middleware` + `name`. The router is registration-order
sensitive — earlier registrations win against later catch-alls.

```php
$router->group(['prefix' => '/admin', 'middleware' => [RequireAdmin::class]], function ($r) {
    $r->get('/users', 'UserController@index')->name('admin.users.index');
});
```

### `Core\Database` — PDO + query builder + migrations

Singleton PDO connection with strict SQL mode and `ATTR_EMULATE_PREPARES=false`
so every query is a real server-side prepared statement. Identifiers (table
and column names) are regex-validated before interpolation in DDL paths.

- `Database::query/fetchAll/fetchOne/fetchColumn` — raw SQL with bound params
- `Database::insert/update/delete` — structured helpers
- `Database::table('...')->where(...)->get()` — chainable QueryBuilder
- `Database::transaction(fn() => ...)` — closures rolled back on throw
- `Migrator` — discovers migrations in `database/migrations/` and each
  module's `migrations/` directory, tracks applied migrations in
  `schema_migrations`, supports `migrate:rollback`

### `Core\Auth` — authentication + authorization

- Session auth with `session_regenerate_id(true)` on login
- OAuth via `exchangeOAuthCode` / `fetchOAuthUser` (Google, Microsoft,
  Facebook, LinkedIn)
- 2FA: TOTP (authenticator apps), email, SMS — `TwoFactorService` +
  `TwoFactorController`
- Roles + permissions: `$auth->hasRole(['admin'])`, `$auth->can('users.edit')`
- Rate-limited login attempts via `RateLimiter` service
- `AuthMiddleware` / `GuestMiddleware` / `RequireAdmin` / `RequireSuperadmin`
  for route protection

### `Core\Queue` + `Core\Scheduling` — background work

DB-backed queue (`jobs` table) and declarative scheduler (`scheduled_tasks`
table). One cron every minute runs `php artisan schedule:run` which:

1. Promotes due `scheduled_tasks` rows into the `jobs` queue
2. Drains up to N ready jobs via a two-query atomic reservation
3. Advances `next_run_at` for each promoted task

Retries on transient failure with exponential backoff (60s / 5min / 15min
default). Terminal failures forward to Sentry and mark the row `failed`.
Write jobs by extending `Core\Queue\Job` with public properties for payload.

### `Core\Contracts` — driver interfaces

Swappable drivers behind type-hinted contracts, picked by config:

- `MailDriver` — currently single-driver (MailService); will split when
  extracted into discrete drivers
- `SmsDriver` — same
- `SearchEngine` — Meilisearch, Algolia, OpenSearch, MySQL fallback
- `StorageDriver` — local or S3/MinIO via Flysystem
- `PaymentGateway` — Stripe, Square, Braintree; driver map in
  `config/payments.php` accepts third-party gateways (see
  `docs/payments-adding-a-gateway.md`)

Bindings live in `config/services.php`. To swap a driver, register a new
concrete class there — no framework edits.

### `Core\Services` — concrete services

- **MailService** — SMTP / SendGrid / Mailgun / SES via `IntegrationConfig`
- **SmsService** — Twilio / Vonage; captures to `message_log` in dev
- **WebhookService** — outbound HTTP with SSRF guard (private-IP deny-list),
  production log-driver refused for safety
- **SearchService** + **SearchIndexer** — query dispatch and queue-backed
  incremental indexing on content/pages/faqs saves
- **CaptchaService** — Cloudflare Turnstile / reCAPTCHA / hCaptcha
- **FileUploadService** — Flysystem with local/S3/MinIO drivers, MIME
  verification, image re-encoding
- **SettingsService** — scoped key/value storage (`site`, `user`, arbitrary
  scope key)
- **MenuService** — persisted navigation trees, surfaced via `menu()` helper
- **MessageRetryService** — drains the retry queue in `message_log`; driven
  by the seeded `retry-messages` scheduled_task
- **SentryService** — HTTP-only error tracking client, no SDK dep
- **StripeService** / **SquareService** / **BraintreeService** — payment
  gateway drivers
- **PaymentsService** — audit wrapper that logs every gateway call to the
  `payments` table
- **IntegrationConfig** — reads provider selector + credentials from `.env`
  in one place; drives every driver's `isEnabled()` check

### `Core\Module` — optional feature modules

Each module is a directory under `modules/` with a `module.php` returning a
`ModuleProvider` instance. Providers declare:

- `name()` — logical module name (matches directory)
- `routesFile()` — path to the module's route file
- `viewsPath()` — where its views live (registered as a view namespace)
- `migrationsPath()` — per-module migrations (optional)
- `register(Container $c)` — bind services
- `boot(Router $r, Container $c)` — runs after all modules registered
- `commands()` — CLI commands to register

`ModuleRegistry::discover()` scans `modules/` per request (or reads
`storage/cache/modules.php` in production — see `module:cache` command).

### `Core\Console` — artisan CLI

Entry point `artisan`; commands under `core/Console/Commands/`:

- **Queue / scheduler** — `schedule:run`, `queue:work`, `queue:list`,
  `queue:retry`, `retry-messages`
- **Search** — `search:reindex`
- **Migrations** — `migrate`, `migrate:rollback`, `migrate:status`
- **Module cache** — `module:cache`, `module:clear`
- **Make templates** — `make:migration`, `make:controller`, `make:module`,
  `make:middleware`
- **Housekeeping** — `cleanup`, `storage:check`

Modules can contribute their own commands via `ModuleProvider::commands()`.

### `Core\View` — templates

PHP-native templates (no custom parser). Layouts via sections:

```php
@extends('layouts.app')
@section('content') ... @endsection
```

Views can live under `app/Views/` (base) or per-module namespaces
(`{modulename}::form` resolves to `modules/{modulename}/Views/form.php`).

### `Core\SEO`

`SeoManager::register($slug, $path, $type, $entityId)` records a canonical
path. When a slug changes (content/page rename), `SeoManager::redirect()`
adds a 301 entry so external links keep working.

## Data flow examples

### Content save with search indexing

```
Admin submits form
  → ContentController@update
  → db->update('content_items', ...)
  → SearchIndexer::sync('content', $id, $prefetchedRow)
  → DatabaseQueue::push(IndexDocumentJob)
Response sent.

Later (next schedule:run tick):
  → Worker::runBatch
  → IndexDocumentJob::handle
  → SearchService::indexDocument → Meilisearch HTTP POST
```

Search is eventually-consistent; a content save returns before the document
is visible in the index.

### Queue job failure → Sentry → retry

```
Worker::runOne throws
  → attempts++ already from reserve()
  → attempts < max_attempts → release(available_at = now + backoff)
  → attempts >= max_attempts → captureException + fail()
```

Only terminal failures hit Sentry. Transient retries stay out of Sentry to
avoid flooding.

### Payment charge

```
Controller: app(PaymentsService::class)->charge(1000, 'USD', $pmToken, $userId)
  → app(PaymentGateway::class) resolves the configured driver via config/payments.php
  → StripeService::charge → POST /v1/payment_intents
  → PaymentsService::log → INSERT payments row with ok/status/raw
Response shows success/failure based on returned shape.
```

## Extension points

- **New driver for an existing contract** — implement the contract, add a
  binding in `config/services.php` (or for payments, add to
  `config/payments.php`). See `docs/payments-adding-a-gateway.md`.
- **New scheduled task** — insert a row into `scheduled_tasks` via a seed
  migration or admin UI, pointing at a `Job` class name.
- **New module** — `php artisan make:module MyFeature` scaffolds the
  directory + module.php + routes.php stubs.
- **Override a route** — register in `routes/web.php`; it wins against
  module routes on collision.
- **New middleware** — `php artisan make:middleware Thing`; register on
  individual routes or in the router's global middleware list.

## Testing

PHPUnit 10.x with tests under `tests/Unit/` (fast, no DB) and `tests/Feature/`
(reserved for integration tests that need a DB — currently empty).

`tests/TestCase.php` exposes:
- `bootContainer()` — fresh container per test
- `mockDatabase($mock)` — swap the Database singleton for a test double

Pattern used throughout: `Database::newInstanceWithoutConstructor()` for
tests that don't need to hit MySQL; subclass Database with method overrides
for tests that do.
