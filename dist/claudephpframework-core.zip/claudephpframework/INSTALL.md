# Installation

## System requirements

**PHP 8.1 or newer.** The framework uses named arguments, readonly properties,
first-class callable syntax, and enum constants. PHP 8.4 and 8.5 are tested in
CI; the codebase is deprecation-free under both.

Required PHP extensions:

- `ext-dom` — HTML sanitizer for user-submitted rich text
- `ext-json`
- `ext-mbstring`
- `ext-openssl` — CSRF tokens, password-reset tokens
- `ext-pdo` + `ext-pdo_mysql`
- `ext-sodium` — envelope encryption for stored secrets
- `ext-gd` or `ext-imagick` — for image re-encoding on upload (optional if
  you don't accept image uploads)

**Database.** MySQL 8.0+ or MariaDB 10.4+. Strict SQL mode is enabled at
connection time; older MySQLs won't parse all DDL in `database/install.sql`.

**Web server.** Apache 2.4 with `mod_rewrite` and a document root pointed at
`public/`, or nginx with `try_files $uri $uri/ /index.php?$query_string` —
see `nginx.conf.example` for a ready-to-drop config.

**Composer 2.x.** Used for dependency installation. A pinned
`composer.lock` ships in the zip.

**Cron or Task Scheduler.** One minutely entry running
`php artisan schedule:run` drives the scheduled_tasks queue, message retries,
and nightly search reindex. On Windows, use Task Scheduler; on Linux/macOS,
crontab.

## Install steps

### 1. Unzip and install composer dependencies

```bash
unzip claudephpframework-core.zip -d /path/to/docroot
cd /path/to/docroot/claudephpframework
composer install --no-dev --optimize-autoloader
```

For a dev environment, drop `--no-dev` so PHPUnit + the test shims install.

### 2. Copy and edit `.env`

```bash
cp .env.example .env
```

Open `.env` and at minimum set:

- `APP_ENV` — `production` or `development`
- `APP_URL` — public URL (e.g. `https://example.com`)
- `APP_KEY` — generate with `php -r "echo base64_encode(random_bytes(32));"`
- `DB_HOST`, `DB_PORT`, `DB_DATABASE`, `DB_USERNAME`, `DB_PASSWORD`
- `MAIL_*` — SMTP credentials or a driver-specific provider (SendGrid,
  Mailgun, SES — see IntegrationConfig.php for the full list)
- `SEARCH_PROVIDER` — `none` (MySQL FULLTEXT fallback), `meilisearch`,
  `algolia`, or `opensearch`
- `CAPTCHA_PROVIDER` — `none`, `cloudflare`, `google`, or `hcaptcha`
- `SENTRY_DSN` — optional; empty disables error reporting
- `PAYMENT_GATEWAY` — `stripe` / `square` / `braintree` (only set if you
  actually accept payments)

`.env.example` is exhaustive — every integration the framework knows about
is documented in-line with the required + optional variables listed.

### 3. Create the database schema

The framework has both a **pre-migration base schema** (user + groups +
content + etc. — everything created before the migration system landed) and a
**live migration system** for changes shipped after 2026-04-21.

For a fresh install:

```bash
mysql -u root -p your_db_name < database/install.sql
php artisan migrate
```

`install.sql` creates the base schema; `php artisan migrate` applies all
migrations in `database/migrations/` (currently: jobs + scheduled_tasks +
payments tables + seed rows for retry-messages and nightly search reindex).

For an existing install, `php artisan migrate` is all you need — it tracks
applied migrations in a `schema_migrations` table.

Other files in `database/` are legacy one-off migration scripts from before
the framework's migration system (2fa_migration.sql, webhook_channel_migration.sql,
etc.). Only run these if upgrading from an older install that pre-dates the
matching feature; see each file's header comment.

### 4. Writeable storage paths

```bash
chmod -R 0775 storage
chown -R www-data:www-data storage   # adjust to your web server user
```

Web server needs write access to `storage/logs`, `storage/cache`, and
`storage/uploads` (if using local-filesystem uploads).

### 5. Web server document root

Point your vhost at `public/`. The included `nginx.conf.example` is a
drop-in starting point. For Apache:

```apache
<VirtualHost *:80>
    DocumentRoot /path/to/claudephpframework/public
    <Directory /path/to/claudephpframework/public>
        AllowOverride All
        Require all granted
    </Directory>
</VirtualHost>
```

A `public/.htaccess` shipping with the zip handles URL rewriting.

### 6. Schedule the tick

Cron (Linux/macOS):

```
* * * * * cd /path/to/claudephpframework && php artisan schedule:run >/dev/null 2>&1
```

Windows Task Scheduler:

```
php C:\path\to\claudephpframework\artisan schedule:run
```

Set the trigger to repeat every 1 minute indefinitely.

### 7. Opcache for production

Strongly recommended. Add to `php.ini`:

```ini
opcache.enable=1
opcache.memory_consumption=256
opcache.max_accelerated_files=10000
opcache.validate_timestamps=0   ; set to 1 during dev
```

With `validate_timestamps=0` you must reload PHP-FPM (or restart Apache)
after deploys.

### 8. Optional: cache the module manifest

If you have modules installed under `modules/`:

```bash
php artisan module:cache
```

This writes `storage/cache/modules.php` so `ModuleRegistry::discover()`
skips its per-request filesystem scan. Add this step to your deploy script.
Run `php artisan module:clear` after adding or renaming a module.

## Verifying the install

```bash
php artisan            # lists all commands; should succeed without errors
php artisan migrate:status
./vendor/bin/phpunit   # if you installed with dev deps
```

Then hit your site's homepage — you should see either the configured guest
home page or a redirect to `/login`.

## Upgrading

Each release ships migrations in `database/migrations/` with ISO-date
prefixes. `php artisan migrate` is always the upgrade path; the
`schema_migrations` table tracks what's been applied.

## Troubleshooting

- **"Driver not found: pdo_mysql"** — install `php-mysql` or `php-pdo-mysql`
  and restart PHP-FPM.
- **500 errors with blank page, no log** — `storage/logs/php_error.log` isn't
  writeable. Fix permissions; see step 4.
- **Sessions don't persist** — `session.save_path` isn't writeable, or a
  reverse proxy is stripping the `cphpfw_session` cookie. Check
  `session.cookie_secure` in `config/app.php` matches your scheme.
- **Email never sends in dev** — `MAIL_DRIVER=log` is the default in
  non-production, which captures to `message_log` table instead of sending.
  View in Superadmin → Message Log.
