<?php
// tests/Unit/Console/CommandRegistryTest.php
namespace Tests\Unit\Console;

use Core\Console\Command;
use Core\Console\CommandRegistry;
use Core\Container\Container;
use Tests\TestCase;

final class NoopCommand extends Command
{
    public string $lastArgv = '';
    public function name(): string        { return 'noop'; }
    public function description(): string { return 'does nothing'; }
    public function handle(array $argv): int
    {
        $this->lastArgv = implode(' ', array_slice($argv, 2));
        return 0;
    }
}

final class CommandRegistryTest extends TestCase
{
    public function test_registered_command_is_retrievable(): void
    {
        $r = new CommandRegistry(new Container());
        $r->register(new NoopCommand());
        $this->assertInstanceOf(NoopCommand::class, $r->get('noop'));
    }

    public function test_dispatch_runs_the_named_command(): void
    {
        $r = new CommandRegistry(new Container());
        $cmd = new NoopCommand();
        $r->register($cmd);
        $code = $r->dispatch(['artisan', 'noop', 'hello', 'world']);
        $this->assertSame(0, $code);
        $this->assertSame('hello world', $cmd->lastArgv);
    }

    public function test_dispatch_unknown_command_returns_nonzero(): void
    {
        $r = new CommandRegistry(new Container());
        // Capture stderr so it doesn't pollute PHPUnit output
        $stderr = fopen('php://memory', 'w+');
        // We can't easily redirect STDERR constant; instead, just assert exit code
        $code = @$r->dispatch(['artisan', 'does-not-exist']);
        $this->assertNotSame(0, $code);
    }

    public function test_all_returns_commands_sorted_by_name(): void
    {
        $r = new CommandRegistry(new Container());
        $bCmd = new class extends Command {
            public function name(): string { return 'b'; }
            public function description(): string { return ''; }
            public function handle(array $argv): int { return 0; }
        };
        $aCmd = new class extends Command {
            public function name(): string { return 'a'; }
            public function description(): string { return ''; }
            public function handle(array $argv): int { return 0; }
        };
        $r->register($bCmd);
        $r->register($aCmd);
        $names = array_keys($r->all());
        $this->assertSame(['a', 'b'], $names);
    }
}
