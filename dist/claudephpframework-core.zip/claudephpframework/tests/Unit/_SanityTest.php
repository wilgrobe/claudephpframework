<?php
// tests/Unit/_SanityTest.php
//
// Leftover from a runner-verification experiment (a test that deliberately
// fails, to confirm the runner reports failures correctly). The sandbox
// blocks file deletes, so it's now a no-op. Safe to `rm` on your local
// machine whenever you feel like it.
namespace Tests\Unit;

use Tests\TestCase;

final class _SanityTest extends TestCase
{
    public function test_sanity_check(): void
    {
        $this->assertTrue(true);
    }
}
