<?php
// modules/polls/Services/PollService.php
namespace Modules\Polls\Services;

use Core\Database\Database;

/**
 * Poll CRUD + ballot casting + result aggregation.
 *
 * Voting mechanics:
 *   single   — ballot = one option_id. castVote wipes any prior
 *              row for this (poll, user) before inserting.
 *   multiple — ballot = list of option_ids (up to max_choices, if
 *              set). castVote replaces the user's prior vote set.
 *   ranked   — ballot = list of option_ids in preference order.
 *              Stored as rank=1..N on poll_votes. Aggregation uses
 *              Borda count: each rank contributes (N - rank + 1)
 *              points to that option; highest total wins.
 *
 * Closed polls reject new ballots and (for any type) are read-only.
 *
 * All ballot writes run inside a transaction so a concurrent revote
 * can't leave a half-deleted/half-inserted set of rows.
 */
class PollService
{
    public const TYPES = ['single','multiple','ranked'];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Poll reads ───────────────────────────────────────────────────────

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM polls WHERE id = ?", [$id]);
    }

    public function findBySlug(string $slug): ?array
    {
        return $this->db->fetchOne("SELECT * FROM polls WHERE slug = ?", [$slug]);
    }

    /** @return array<int, array<string, mixed>> */
    public function listPublished(int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM polls WHERE published = 1 ORDER BY created_at DESC LIMIT ?",
            [$limit]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function listAll(): array
    {
        return $this->db->fetchAll("SELECT * FROM polls ORDER BY created_at DESC");
    }

    /** @return array<int, array<string, mixed>> */
    public function optionsFor(int $pollId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM poll_options WHERE poll_id = ? ORDER BY sort_order ASC, id ASC",
            [$pollId]
        );
    }

    public function isClosed(array $poll): bool
    {
        if (!empty($poll['closes_at']) && strtotime((string) $poll['closes_at']) < time()) return true;
        return false;
    }

    // ── Poll CRUD ────────────────────────────────────────────────────────

    public function create(array $data, array $optionLabels): int
    {
        $id = (int) $this->db->insert('polls', $this->preparePoll($data));
        $this->setOptions($id, $optionLabels);
        return $id;
    }

    public function update(int $id, array $data, array $optionLabels): void
    {
        $this->db->update('polls', $this->preparePoll($data), 'id = ?', [$id]);
        $this->setOptions($id, $optionLabels);
    }

    public function delete(int $id): void
    {
        $this->db->delete('polls', 'id = ?', [$id]);
    }

    /**
     * Replace the option list. Existing option rows with labels still in
     * the new list are preserved (keeping their ids + any votes against
     * them); rows whose label is gone are deleted. Newly-added labels
     * become new option rows.
     *
     * Preserving ids matters because poll_votes.option_id foreign-keys
     * into poll_options; an admin edit that changes "Yes" → "Yes " (with
     * a trailing space) shouldn't blow away all the existing votes.
     */
    public function setOptions(int $pollId, array $labels): void
    {
        $labels = array_values(array_filter(array_map('trim', $labels), fn($s) => $s !== ''));
        $existing = $this->db->fetchAll(
            "SELECT id, label FROM poll_options WHERE poll_id = ?", [$pollId]
        );
        $byLabel = [];
        foreach ($existing as $r) $byLabel[$r['label']] = (int) $r['id'];

        $kept = [];
        $i = 1;
        foreach ($labels as $label) {
            if (isset($byLabel[$label])) {
                $this->db->update('poll_options', ['sort_order' => $i], 'id = ?', [$byLabel[$label]]);
                $kept[] = $byLabel[$label];
            } else {
                $kept[] = (int) $this->db->insert('poll_options', [
                    'poll_id'    => $pollId,
                    'label'      => substr($label, 0, 255),
                    'sort_order' => $i,
                ]);
            }
            $i++;
        }
        // Delete any that weren't kept.
        foreach ($existing as $r) {
            if (!in_array((int) $r['id'], $kept, true)) {
                $this->db->delete('poll_options', 'id = ?', [(int) $r['id']]);
            }
        }
    }

    private function preparePoll(array $data): array
    {
        $out = [];
        foreach ([
            'slug','question','description','type','max_choices','closes_at',
            'owner_user_id','owner_group_id','published',
        ] as $k) {
            if (array_key_exists($k, $data)) $out[$k] = $data[$k];
        }
        if (isset($out['slug']))  $out['slug'] = self::slugify((string) $out['slug']);
        if (isset($out['type']) && !in_array($out['type'], self::TYPES, true)) $out['type'] = 'single';
        if (array_key_exists('max_choices', $out) && ($out['max_choices'] === '' || $out['max_choices'] === 0)) {
            $out['max_choices'] = null;
        }
        if (array_key_exists('closes_at', $out) && $out['closes_at'] === '') $out['closes_at'] = null;
        return $out;
    }

    public static function slugify(string $s): string
    {
        $s = strtolower(trim($s));
        $s = preg_replace('~[^a-z0-9]+~', '-', $s) ?? '';
        return trim($s, '-');
    }

    // ── Voting ───────────────────────────────────────────────────────────

    /**
     * Cast a ballot. $optionIds:
     *   - single   → [id]
     *   - multiple → [id, id, …]
     *   - ranked   → [id_at_rank_1, id_at_rank_2, …] (all options)
     *
     * Validates:
     *   - poll exists, published, not closed
     *   - all option_ids belong to the poll
     *   - ranked: all options must be ranked; no duplicates
     *   - multiple: respect max_choices cap
     */
    public function castVote(int $pollId, int $userId, array $optionIds): void
    {
        $poll = $this->find($pollId);
        if (!$poll || (int) $poll['published'] !== 1) {
            throw new \InvalidArgumentException('Poll not available.');
        }
        if ($this->isClosed($poll)) {
            throw new \InvalidArgumentException('Poll is closed.');
        }

        $optionIds = array_values(array_map('intval', $optionIds));
        $optionIds = array_filter($optionIds, fn($i) => $i > 0);

        // All option ids must belong to this poll.
        $validIds = array_map(static fn($r) => (int) $r['id'], $this->optionsFor($pollId));
        foreach ($optionIds as $id) {
            if (!in_array($id, $validIds, true)) {
                throw new \InvalidArgumentException('Unknown option for this poll.');
            }
        }

        if ($poll['type'] === 'single') {
            if (count($optionIds) !== 1) {
                throw new \InvalidArgumentException('Pick exactly one option.');
            }
        } elseif ($poll['type'] === 'multiple') {
            if (count($optionIds) < 1) {
                throw new \InvalidArgumentException('Pick at least one option.');
            }
            if ($poll['max_choices'] !== null && count($optionIds) > (int) $poll['max_choices']) {
                throw new \InvalidArgumentException('Too many options selected.');
            }
            if (count($optionIds) !== count(array_unique($optionIds))) {
                throw new \InvalidArgumentException('Duplicate options selected.');
            }
        } else { // ranked
            if (count($optionIds) !== count($validIds)) {
                throw new \InvalidArgumentException('Rank every option.');
            }
            if (count($optionIds) !== count(array_unique($optionIds))) {
                throw new \InvalidArgumentException('Each option can appear at most once in a ranking.');
            }
        }

        $this->db->beginTransaction();
        try {
            $this->db->delete('poll_votes', 'poll_id = ? AND user_id = ?', [$pollId, $userId]);
            $rank = 1;
            foreach ($optionIds as $oid) {
                $this->db->insert('poll_votes', [
                    'poll_id'   => $pollId,
                    'user_id'   => $userId,
                    'option_id' => $oid,
                    'rank'      => $poll['type'] === 'ranked' ? $rank : null,
                ]);
                $rank++;
            }
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * @return array<int, int>  option_id => [option_id, option_id, …] this user voted for, in rank order if ranked
     */
    public function ballotFor(int $pollId, int $userId): array
    {
        // `rank` is a MySQL 8 reserved word — backtick every bare reference.
        $rows = $this->db->fetchAll(
            "SELECT option_id, `rank` FROM poll_votes
              WHERE poll_id = ? AND user_id = ?
           ORDER BY `rank` IS NULL, `rank` ASC, id ASC",
            [$pollId, $userId]
        );
        return array_map(static fn($r) => (int) $r['option_id'], $rows);
    }

    // ── Results ──────────────────────────────────────────────────────────

    /**
     * Aggregate results. Shape per option:
     *   ['id', 'label', 'votes', 'percent', 'borda' (only for ranked)]
     *
     * For single/multiple: `votes` is the row count per option; `percent`
 *     is votes / total distinct voters (so multiple-select percentages
     * can exceed sum-to-100, intentionally).
     *
     * For ranked: `borda` is Σ(N - rank + 1) for each vote row on this
     * option. `votes` is count of rank-1 (first-choice) votes.
     *
     * @return array{options: array<int, array<string, mixed>>, total_voters: int}
     */
    public function results(int $pollId): array
    {
        $poll    = $this->find($pollId);
        if (!$poll) return ['options' => [], 'total_voters' => 0];
        $options = $this->optionsFor($pollId);
        $n       = count($options);

        $totalVoters = (int) $this->db->fetchColumn(
            "SELECT COUNT(DISTINCT user_id) FROM poll_votes WHERE poll_id = ?",
            [$pollId]
        );

        $out = [];
        foreach ($options as $o) {
            $oid = (int) $o['id'];
            $row = ['id' => $oid, 'label' => (string) $o['label']];

            if ($poll['type'] === 'ranked') {
                // Borda: SUM(n - rank + 1) for this option.
                // `rank` is backticked — reserved word in MySQL 8.
                $borda = (int) $this->db->fetchColumn(
                    "SELECT COALESCE(SUM(? - `rank` + 1), 0)
                       FROM poll_votes
                      WHERE poll_id = ? AND option_id = ? AND `rank` IS NOT NULL",
                    [$n, $pollId, $oid]
                );
                $firsts = (int) $this->db->fetchColumn(
                    "SELECT COUNT(*) FROM poll_votes
                      WHERE poll_id = ? AND option_id = ? AND `rank` = 1",
                    [$pollId, $oid]
                );
                $row['votes'] = $firsts;
                $row['borda'] = $borda;
                $row['percent'] = $totalVoters > 0 ? round(($firsts / $totalVoters) * 100, 1) : 0;
            } else {
                $votes = (int) $this->db->fetchColumn(
                    "SELECT COUNT(*) FROM poll_votes
                      WHERE poll_id = ? AND option_id = ?",
                    [$pollId, $oid]
                );
                $row['votes']   = $votes;
                $row['percent'] = $totalVoters > 0 ? round(($votes / $totalVoters) * 100, 1) : 0;
            }
            $out[] = $row;
        }

        // Sort ranked results by Borda desc; single/multiple by votes desc.
        usort($out, static function ($a, $b) use ($poll) {
            $ka = $poll['type'] === 'ranked' ? ($a['borda'] ?? 0) : ($a['votes'] ?? 0);
            $kb = $poll['type'] === 'ranked' ? ($b['borda'] ?? 0) : ($b['votes'] ?? 0);
            return $kb <=> $ka;
        });

        return ['options' => $out, 'total_voters' => $totalVoters];
    }
}
