<?php
// modules/polls/module.php
use Core\Module\ModuleProvider;

/**
 * Polls module — single-choice, multiple-choice, and ranked voting.
 *
 * Ballot storage is shared across types (poll_votes with an optional
 * `rank` column). Aggregation differs:
 *   - single/multiple → count votes per option
 *   - ranked          → Borda count (Σ (N - rank + 1) per option)
 *
 * Option-preservation logic in setOptions keeps existing option ids
 * when their label is unchanged, so minor admin edits don't wipe
 * historical votes via the poll_votes.option_id FK cascade.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'polls'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
