<?php
// modules/polls/migrations/2026_04_23_230010_seed_polls_permission.php
use Core\Database\Migration;

return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage polls',
            'polls.manage',
            'polls',
            'Create, edit, close, and delete polls.',
        ]);
    }

    public function down(): void {}
};
