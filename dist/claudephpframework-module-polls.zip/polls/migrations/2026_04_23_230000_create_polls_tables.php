<?php
// modules/polls/migrations/2026_04_23_230000_create_polls_tables.php
use Core\Database\Migration;

/**
 * Schema for the polls module.
 *
 *   polls         — the question. `type` picks the voting mechanic:
 *                     single    — pick exactly one option (radio)
 *                     multiple  — pick up to N (checkboxes)
 *                     ranked    — order all options 1..N
 *                   `max_choices` applies to `multiple` (null = no
 *                   limit). `closes_at` gates voting.
 *
 *   poll_options  — the choices, with `sort_order` for display.
 *
 *   poll_votes    — one row per (poll, voter, option).
 *                   - single/multiple: rank stays NULL; presence of row
 *                     = vote for that option.
 *                   - ranked: rank = 1..N (1 = top).
 *                   UNIQUE (poll_id, user_id, option_id) prevents
 *                   double-voting on the same option.
 *                   Casting a new ballot for a single/multiple poll
 *                   deletes the user's previous rows first — keeps
 *                   history simple (no "I voted for X then changed to
 *                   Y" audit trail; overwrite wins).
 */
return new class extends Migration {
    public function up(): void
    {
        // Defensive DROPs so a retried migration after a previous
        // partial failure doesn't trip on "table already exists" —
        // `schema_migrations` never got a row for this migration on
        // the failed attempt, so the migrator re-runs up() from the
        // top. Safe because if the migration had completed cleanly,
        // the migrator wouldn't re-run it in the first place.
        $this->db->query("DROP TABLE IF EXISTS poll_votes");
        $this->db->query("DROP TABLE IF EXISTS poll_options");
        $this->db->query("DROP TABLE IF EXISTS polls");

        $this->db->query("
            CREATE TABLE polls (
                id            INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                slug          VARCHAR(191) NOT NULL,
                question      VARCHAR(500) NOT NULL,
                description   TEXT NULL,
                type          ENUM('single','multiple','ranked') NOT NULL DEFAULT 'single',
                max_choices   INT UNSIGNED NULL,
                closes_at     DATETIME NULL,
                owner_user_id INT UNSIGNED NULL,
                owner_group_id INT UNSIGNED NULL,
                published     TINYINT(1) NOT NULL DEFAULT 1,
                created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_slug (slug),
                KEY idx_published (published, closes_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE poll_options (
                id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                poll_id    INT UNSIGNED NOT NULL,
                label      VARCHAR(255) NOT NULL,
                sort_order INT UNSIGNED NOT NULL DEFAULT 0,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                KEY idx_poll (poll_id, sort_order),
                CONSTRAINT fk_po_poll FOREIGN KEY (poll_id)
                    REFERENCES polls (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE poll_votes (
                id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                poll_id    INT UNSIGNED NOT NULL,
                user_id    INT UNSIGNED NOT NULL,
                option_id  INT UNSIGNED NOT NULL,
                `rank`     INT UNSIGNED NULL,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                UNIQUE KEY uq_vote (poll_id, user_id, option_id),
                KEY idx_poll_option (poll_id, option_id),
                KEY idx_poll_user   (poll_id, user_id),
                CONSTRAINT fk_pv_poll   FOREIGN KEY (poll_id)   REFERENCES polls        (id) ON DELETE CASCADE,
                CONSTRAINT fk_pv_option FOREIGN KEY (option_id) REFERENCES poll_options (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS poll_votes");
        $this->db->query("DROP TABLE IF EXISTS poll_options");
        $this->db->query("DROP TABLE IF EXISTS polls");
    }
};
