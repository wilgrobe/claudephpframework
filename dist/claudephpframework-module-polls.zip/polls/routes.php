<?php
// modules/polls/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$P = 'Modules\Polls\Controllers\PollController';
$A = 'Modules\Polls\Controllers\PollAdminController';

// Public
$router->get ('/polls',                 "$P@index");
$router->get ('/polls/{slug}',          "$P@show");
$router->post('/polls/{slug}',          "$P@vote", [CsrfMiddleware::class, AuthMiddleware::class]);

// Admin
$admin     = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];
$router->get ('/admin/polls',                "$A@index",      $admin);
$router->get ('/admin/polls/create',         "$A@createForm", $admin);
$router->post('/admin/polls/create',         "$A@store",      $adminCsrf);
$router->get ('/admin/polls/{id}/edit',      "$A@edit",       $admin);
$router->post('/admin/polls/{id}/edit',      "$A@update",     $adminCsrf);
$router->post('/admin/polls/{id}/delete',    "$A@delete",     $adminCsrf);
