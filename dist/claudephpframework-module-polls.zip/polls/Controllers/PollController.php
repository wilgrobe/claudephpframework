<?php
// modules/polls/Controllers/PollController.php
namespace Modules\Polls\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Polls\Services\PollService;

/**
 *   GET  /polls                — list
 *   GET  /polls/{slug}         — vote form (or results when closed/voted)
 *   POST /polls/{slug}         — cast a ballot
 */
class PollController
{
    private Auth        $auth;
    private PollService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new PollService();
    }

    public function index(Request $request): Response
    {
        return Response::view('polls::public.index', [
            'polls' => $this->svc->listPublished(),
        ]);
    }

    public function show(Request $request): Response
    {
        $slug = (string) $request->param(0);
        $poll = $this->svc->findBySlug($slug);
        if (!$poll || (int) $poll['published'] !== 1) return new Response('Poll not found', 404);

        $ballot = [];
        if (!$this->auth->guest()) {
            $ballot = $this->svc->ballotFor((int) $poll['id'], (int) $this->auth->id());
        }

        return Response::view('polls::public.show', [
            'poll'    => $poll,
            'options' => $this->svc->optionsFor((int) $poll['id']),
            'results' => $this->svc->results((int) $poll['id']),
            'ballot'  => $ballot,
            'closed'  => $this->svc->isClosed($poll),
            'voted'   => !empty($ballot),
            'me'      => $this->auth->user(),
        ]);
    }

    public function vote(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $slug = (string) $request->param(0);
        $poll = $this->svc->findBySlug($slug);
        if (!$poll || (int) $poll['published'] !== 1) return new Response('Poll not found', 404);

        // Collect option ids based on poll type.
        if ($poll['type'] === 'ranked') {
            // Ranked submit: ranks[option_id] = rank int. We sort by rank.
            $ranks = $request->post('ranks');
            if (!is_array($ranks)) {
                return Response::redirect("/polls/$slug")->withFlash('error', 'Rank every option.');
            }
            asort($ranks, SORT_NUMERIC);
            $optionIds = array_map('intval', array_keys($ranks));
        } else {
            $optionIds = (array) ($request->post('option_ids') ?: []);
            if ($poll['type'] === 'single') {
                $oid = (int) $request->post('option_id', 0);
                if ($oid > 0) $optionIds = [$oid];
            }
        }

        try {
            $this->svc->castVote((int) $poll['id'], (int) $this->auth->id(), (array) $optionIds);
        } catch (\InvalidArgumentException $e) {
            return Response::redirect("/polls/$slug")->withFlash('error', $e->getMessage());
        }

        return Response::redirect("/polls/$slug")->withFlash('success', 'Vote recorded.');
    }
}
