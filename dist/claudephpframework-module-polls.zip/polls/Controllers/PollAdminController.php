<?php
// modules/polls/Controllers/PollAdminController.php
namespace Modules\Polls\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Polls\Services\PollService;

class PollAdminController
{
    private Auth        $auth;
    private PollService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new PollService();
    }

    private function gate(): ?Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->auth->can('polls.manage') && !$this->auth->can('admin.access')) {
            return new Response('Forbidden', 403);
        }
        return null;
    }

    public function index(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        return Response::view('polls::admin.index', ['polls' => $this->svc->listAll()]);
    }

    public function createForm(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        return Response::view('polls::admin.form', ['poll' => null, 'options' => []]);
    }

    public function store(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        [$data, $labels] = $this->readForm($request);
        if (count($labels) < 2) {
            return Response::redirect('/admin/polls/create')->withFlash('error', 'At least two options required.');
        }
        $id = $this->svc->create($data, $labels);
        return Response::redirect("/admin/polls/$id/edit")->withFlash('success', 'Poll created.');
    }

    public function edit(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id = (int) $request->param(0);
        $p  = $this->svc->find($id);
        if (!$p) return new Response('Not found', 404);
        return Response::view('polls::admin.form', [
            'poll'    => $p,
            'options' => $this->svc->optionsFor($id),
            'results' => $this->svc->results($id),
        ]);
    }

    public function update(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id = (int) $request->param(0);
        [$data, $labels] = $this->readForm($request);
        if (count($labels) < 2) {
            return Response::redirect("/admin/polls/$id/edit")->withFlash('error', 'At least two options required.');
        }
        $this->svc->update($id, $data, $labels);
        return Response::redirect("/admin/polls/$id/edit")->withFlash('success', 'Saved.');
    }

    public function delete(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $this->svc->delete((int) $request->param(0));
        return Response::redirect('/admin/polls');
    }

    private function readForm(Request $request): array
    {
        $data = [
            'slug'        => (string) $request->post('slug'),
            'question'    => (string) $request->post('question'),
            'description' => (string) $request->post('description'),
            'type'        => (string) $request->post('type', 'single'),
            'max_choices' => $request->post('max_choices') !== '' && $request->post('max_choices') !== null
                                ? (int) $request->post('max_choices') : null,
            'closes_at'   => (string) $request->post('closes_at') ?: null,
            'published'   => $request->post('published') ? 1 : 0,
        ];
        $labels = array_values(array_filter(array_map('trim', (array) ($request->post('options') ?: [])), fn($s) => $s !== ''));
        return [$data, $labels];
    }
}
