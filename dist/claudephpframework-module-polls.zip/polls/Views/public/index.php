<?php $pageTitle = 'Polls'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Polls</h1>

<?php if (empty($polls)): ?>
<div class="card"><div class="card-body" style="color:#9ca3af;text-align:center;padding:3rem 1rem">No open polls.</div></div>
<?php else: ?>
<?php foreach ($polls as $p): ?>
<div class="card" style="margin-bottom:.75rem">
    <div class="card-body">
        <a href="/polls/<?= e((string) $p['slug']) ?>" style="color:inherit;text-decoration:none">
            <strong><?= e((string) $p['question']) ?></strong>
        </a>
        <div style="color:#9ca3af;font-size:12px;margin-top:.25rem">
            <?= e((string) $p['type']) ?>
            <?php if (!empty($p['closes_at'])): ?> · closes <?= e(date('M j, Y', strtotime((string) $p['closes_at']))) ?><?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
