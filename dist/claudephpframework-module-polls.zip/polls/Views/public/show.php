<?php $pageTitle = $poll['question']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:680px;margin:0 auto">
<a href="/polls" style="color:#6b7280;font-size:13px;text-decoration:none">← Polls</a>

<h1 style="margin:.5rem 0"><?= e((string) $poll['question']) ?></h1>
<div style="color:#9ca3af;font-size:12px;margin-bottom:1rem">
    Type: <?= e((string) $poll['type']) ?>
    <?php if (!empty($poll['closes_at'])): ?> · closes <?= e(date('M j, Y H:i', strtotime((string) $poll['closes_at']))) ?><?php endif; ?>
    <?php if ($closed): ?> · <strong style="color:#b91c1c">closed</strong><?php endif; ?>
</div>

<?php if (!empty($poll['description'])): ?>
<p style="color:#4b5563"><?= nl2br(e((string) $poll['description'])) ?></p>
<?php endif; ?>

<?php if ($closed || $voted): ?>
<!-- Results view -->
<div class="card">
    <div class="card-header"><strong>Results</strong>
        <span style="color:#9ca3af;font-size:12px;margin-left:.5rem"><?= (int) $results['total_voters'] ?> voters</span>
    </div>
    <div class="card-body">
        <?php foreach ($results['options'] as $o): ?>
        <div style="margin-bottom:.5rem">
            <div style="display:flex;justify-content:space-between;font-size:13px">
                <span><?= e((string) $o['label']) ?></span>
                <span>
                    <?php if ($poll['type'] === 'ranked'): ?>
                    Borda <?= (int) $o['borda'] ?> · <?= (int) $o['votes'] ?> first-choice
                    <?php else: ?>
                    <?= (int) $o['votes'] ?> (<?= number_format((float) $o['percent'], 1) ?>%)
                    <?php endif; ?>
                </span>
            </div>
            <div style="background:#f3f4f6;height:8px;border-radius:4px;overflow:hidden;margin-top:.15rem">
                <div style="background:#3b82f6;height:100%;width:<?= (float) $o['percent'] ?>%"></div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php if ($voted && !$closed): ?>
<p style="color:#6b7280;font-size:13px;margin-top:1rem">You voted. Re-casting below replaces your prior ballot.</p>
<?php endif; ?>
<?php endif; ?>

<?php if (!$closed && !empty($me)): ?>
<div class="card" style="margin-top:1rem">
    <div class="card-header"><strong>Cast your vote</strong></div>
    <form method="post" action="/polls/<?= e((string) $poll['slug']) ?>">
        <?= csrf_field() ?>
        <div class="card-body">
            <?php if ($poll['type'] === 'single'): ?>
                <?php foreach ($options as $o): ?>
                <label style="display:block;padding:.25rem 0">
                    <input type="radio" name="option_id" value="<?= (int) $o['id'] ?>" <?= in_array((int) $o['id'], $ballot, true) ? 'checked' : '' ?>>
                    <?= e((string) $o['label']) ?>
                </label>
                <?php endforeach; ?>
            <?php elseif ($poll['type'] === 'multiple'): ?>
                <?php if (!empty($poll['max_choices'])): ?>
                <p style="color:#9ca3af;font-size:12px">Select up to <?= (int) $poll['max_choices'] ?>.</p>
                <?php endif; ?>
                <?php foreach ($options as $o): ?>
                <label style="display:block;padding:.25rem 0">
                    <input type="checkbox" name="option_ids[]" value="<?= (int) $o['id'] ?>" <?= in_array((int) $o['id'], $ballot, true) ? 'checked' : '' ?>>
                    <?= e((string) $o['label']) ?>
                </label>
                <?php endforeach; ?>
            <?php else: // ranked ?>
                <p style="color:#9ca3af;font-size:12px">Assign a rank (1 = top choice) to every option. Each rank must be unique.</p>
                <?php
                $ballotRanks = [];
                foreach ($ballot as $i => $oid) $ballotRanks[(int) $oid] = $i + 1;
                $n = count($options);
                ?>
                <?php foreach ($options as $o): ?>
                <div style="display:flex;align-items:center;gap:.5rem;padding:.25rem 0">
                    <select name="ranks[<?= (int) $o['id'] ?>]" required style="width:70px">
                        <option value="">—</option>
                        <?php for ($r = 1; $r <= $n; $r++): ?>
                        <option value="<?= $r ?>" <?= ($ballotRanks[(int) $o['id']] ?? 0) === $r ? 'selected' : '' ?>><?= $r ?></option>
                        <?php endfor; ?>
                    </select>
                    <span><?= e((string) $o['label']) ?></span>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <div class="card-footer" style="padding:.5rem 1rem;text-align:right;background:#f9fafb">
            <button type="submit" class="btn btn-primary"><?= $voted ? 'Update vote' : 'Submit vote' ?></button>
        </div>
    </form>
</div>
<?php elseif (empty($me) && !$closed): ?>
<div style="margin-top:1rem;color:#9ca3af;font-size:13px"><a href="/login">Log in</a> to vote.</div>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
