<?php
$isNew = empty($poll);
$pageTitle = $isNew ? 'New poll' : 'Edit poll';
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<a href="/admin/polls" style="color:#6b7280;font-size:13px;text-decoration:none">← Polls</a>

<div class="card" style="margin-top:.5rem">
    <div class="card-header"><h2 style="margin:0"><?= $isNew ? 'New poll' : 'Edit ' . e((string) $poll['question']) ?></h2></div>
    <form method="post" action="<?= $isNew ? '/admin/polls/create' : '/admin/polls/' . (int) $poll['id'] . '/edit' ?>">
        <?= csrf_field() ?>
        <div class="card-body">
            <label>Question <input name="question" required style="width:100%" value="<?= e((string) ($poll['question'] ?? '')) ?>"></label>
            <label style="display:block;margin-top:.5rem">Slug <input name="slug" required style="width:100%" value="<?= e((string) ($poll['slug'] ?? '')) ?>"></label>
            <label style="display:block;margin-top:.5rem">Description
                <textarea name="description" rows="3" style="width:100%"><?= e((string) ($poll['description'] ?? '')) ?></textarea>
            </label>
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr 1fr;margin-top:.75rem">
                <label>Type
                    <select name="type">
                        <?php foreach (['single','multiple','ranked'] as $t): ?>
                        <option value="<?= e($t) ?>" <?= ($poll['type'] ?? 'single') === $t ? 'selected' : '' ?>><?= ucfirst($t) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>Max choices (multiple only)
                    <input type="number" name="max_choices" min="1" value="<?= e((string) ($poll['max_choices'] ?? '')) ?>" placeholder="unlimited">
                </label>
                <label>Closes at
                    <input type="datetime-local" name="closes_at" value="<?= e(!empty($poll['closes_at']) ? date('Y-m-d\TH:i', strtotime((string) $poll['closes_at'])) : '') ?>">
                </label>
            </div>

            <h3 style="margin-top:1rem">Options</h3>
            <p style="color:#9ca3af;font-size:12px">One option per line. Edit a label to rename; delete a line to remove the option (existing votes for it are dropped).</p>
            <textarea name="options_text" style="display:none"></textarea>
            <?php
            $current = !empty($options) ? array_map(fn($o) => (string) $o['label'], $options) : ['', ''];
            ?>
            <div id="options-list">
                <?php foreach ($current as $label): ?>
                <div style="display:flex;gap:.25rem;margin-bottom:.25rem">
                    <input name="options[]" value="<?= e($label) ?>" style="flex:1" placeholder="Option label">
                    <button type="button" class="btn btn-sm btn-danger" onclick="this.closest('div').remove()">×</button>
                </div>
                <?php endforeach; ?>
            </div>
            <button type="button" class="btn btn-sm btn-secondary" onclick="addOpt()">+ Add option</button>
            <script>
            function addOpt() {
                var d = document.createElement('div');
                d.style.cssText = 'display:flex;gap:.25rem;margin-bottom:.25rem';
                d.innerHTML = '<input name="options[]" style="flex:1" placeholder="Option label">' +
                              '<button type="button" class="btn btn-sm btn-danger" onclick="this.closest(\'div\').remove()">×</button>';
                document.getElementById('options-list').appendChild(d);
            }
            </script>

            <label style="display:block;margin-top:.75rem">
                <input type="checkbox" name="published" value="1" <?= !isset($poll) || !empty($poll['published']) ? 'checked' : '' ?>>
                Published
            </label>
        </div>
        <div class="card-footer" style="padding:.75rem 1.25rem;background:#f9fafb;display:flex;justify-content:space-between">
            <?php if (!$isNew): ?>
            <form method="post" action="/admin/polls/<?= (int) $poll['id'] ?>/delete" onsubmit="return confirm('Delete poll + all votes?')">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-danger">Delete</button>
            </form>
            <?php else: ?><div></div><?php endif; ?>
            <button type="submit" class="btn btn-primary"><?= $isNew ? 'Create' : 'Save' ?></button>
        </div>
    </form>
</div>

<?php if (!$isNew && !empty($results['options'])): ?>
<div class="card" style="margin-top:1rem">
    <div class="card-header"><strong>Current results</strong> <span style="color:#9ca3af;font-size:12px;margin-left:.5rem"><?= (int) $results['total_voters'] ?> voters</span></div>
    <div class="card-body">
        <?php foreach ($results['options'] as $o): ?>
        <div style="margin-bottom:.5rem;font-size:13px">
            <?= e((string) $o['label']) ?> —
            <?php if ($poll['type'] === 'ranked'): ?>
            Borda <?= (int) $o['borda'] ?> · <?= (int) $o['votes'] ?> first-choice
            <?php else: ?>
            <?= (int) $o['votes'] ?> (<?= number_format((float) $o['percent'], 1) ?>%)
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
