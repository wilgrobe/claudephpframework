<?php $pageTitle = 'Polls — admin'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Polls</h2>
        <a href="/admin/polls/create" class="btn btn-sm btn-primary">New poll</a>
    </div>
    <?php if (empty($polls)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No polls.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Question</th><th>Slug</th><th>Type</th><th>Closes</th><th>Published</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($polls as $p): ?>
        <tr>
            <td><strong><?= e((string) $p['question']) ?></strong></td>
            <td><code><?= e((string) $p['slug']) ?></code></td>
            <td><?= e((string) $p['type']) ?></td>
            <td style="font-size:12px"><?= !empty($p['closes_at']) ? e(date('M j, Y', strtotime((string) $p['closes_at']))) : '—' ?></td>
            <td><?= (int) $p['published'] ? '✓' : '—' ?></td>
            <td><a href="/admin/polls/<?= (int) $p['id'] ?>/edit" class="btn btn-sm btn-secondary">Edit</a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
