# Architecture — Polls

## Files

```
polls/
├── module.php
├── routes.php                              # 6 public/admin routes
├── Controllers/{PollController,PollAdminController}.php
├── Services/PollService.php                # CRUD + castVote + results
├── Views/{public,admin}/…
└── migrations/{create_tables, seed_permission}.php
```

## Data model

```
polls:
  id, slug (unique), question, description,
  type ENUM('single','multiple','ranked'),
  max_choices NULL, closes_at NULL,
  owner_user_id, owner_group_id, published, timestamps

poll_options:
  id, poll_id CASCADE, label, sort_order, created_at

poll_votes:
  id, poll_id CASCADE, user_id, option_id CASCADE,
  rank NULL, created_at
  UNIQUE (poll_id, user_id, option_id)
```

`rank` is null for single/multiple; 1..N for ranked.

## Ballot write

`castVote($pollId, $userId, $optionIds)`:
1. Validates `optionIds` are real options of this poll.
2. Enforces type-specific counts (single=1, multiple≤max, ranked=all).
3. Transactionally:
   - DELETE prior votes for (poll, user).
   - INSERT new rows with `rank` from 1..N (ranked) or null.

Replace-on-revote semantics. No audit of prior ballots — overwrite
wins. Simpler than maintaining ballot history, and poll results are
the user-facing truth anyway.

## Borda count

```
SELECT COALESCE(SUM(N - rank + 1), 0) AS borda
  FROM poll_votes
 WHERE poll_id = :p AND option_id = :o AND rank IS NOT NULL
```

Where `N = count(options)`. Points per voter sum to `N*(N+1)/2`
regardless of ordering — a basic sanity check.

## Option preservation on edit

`setOptions` diffs by label: existing options whose label is in the
new list keep their id (and their votes); new labels become new
rows; labels removed from the new list have their option rows
deleted (and their votes cascade-drop via the FK).

Renames are destructive at the label level — changing "Red " →
"Red" without the trailing space creates a new option and deletes
the old one. Admins should treat label strings as identities.
