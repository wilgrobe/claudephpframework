# Polls module

Single-choice, multiple-choice, and ranked voting. One ballot per
(poll, user). Admins can close polls, set a choice cap for
multiple-select, and schedule a deadline.

## Voting types

- **single** — pick exactly one option (radio).
- **multiple** — pick up to `max_choices` options (checkboxes).
  `max_choices` NULL = no cap.
- **ranked** — assign rank 1..N to every option. Results use Borda
  count — each vote contributes `(N - rank + 1)` points to its
  option; highest total wins.

## Results

Single/multiple surface vote counts + percentage of distinct voters
(multi-select totals can exceed 100%, deliberately).

Ranked surface Borda totals + first-choice counts + percentage. Sort
order is Borda desc for ranked, votes desc otherwise.

## Option preservation

Editing a poll to rename options preserves vote-rows when the new
label exists in the old set (matched by exact string). That way a
typo fix doesn't nuke existing votes via `poll_options.id` FK
cascade.

## Routes

| Method | Path                           | Purpose |
|--------|--------------------------------|---------|
| GET    | `/polls`                       | Open polls list |
| GET    | `/polls/{slug}`                | Vote form + results |
| POST   | `/polls/{slug}`                | Cast ballot |
| Admin  | `/admin/polls/*`               | CRUD |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
