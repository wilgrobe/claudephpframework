# Installation — Polls

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` (creates 3 tables + seeds permission).
3. Grant `polls.manage` to admin roles.

## First-use walkthrough

1. `/admin/polls/create` → "What's your favorite color?", type=single,
   options "Red, Green, Blue". Save.
2. Log in as a user, visit `/polls/{slug}`, pick one, submit.
3. Try again — it replaces your prior vote (re-cast semantics).
4. `/polls/{slug}` shows results after you've voted (or when the
   deadline passes).

## Borda example

Three options (Apple, Banana, Cherry), two voters:
- Voter 1: Apple=1, Banana=2, Cherry=3 → A=3, B=2, C=1 points
- Voter 2: Banana=1, Apple=2, Cherry=3 → B=3, A=2, C=1 points

Totals: A=5, B=5, C=2. A and B tie for Borda winner; first-choice
counts tie-break informally in the UI (Apple 1, Banana 1 — display
only, not a computed tie-break).

## Deferred

- **Ranked-choice instant runoff (IRV / Alternative Vote)** — a more
  nuanced ranked aggregation. Borda is what's implemented; IRV would
  be a second aggregation mode.
- **Anonymous voting** — today `user_id` is stored; flipping anonymous
  means losing the one-ballot-per-user guarantee.
- **Audience scope** — polls visible to logged-in-only vs public,
  or per-group. Currently every published poll is world-readable.
