# Events module

Event calendar with RSVPs (yes/no/maybe + guest count), capacity +
waitlist with auto-promotion, and per-event iCal export.

## Features

- **RSVP** with three-valued status (yes / no / maybe) and guest count.
  `yes` RSVPs count against capacity (`1 + guest_count` per RSVP).
- **Capacity + waitlist** — when capacity is reached, new `yes` RSVPs
  land on a waitlist. When a confirmed attendee cancels (or changes
  status to `no` / `maybe`), the oldest waitlisted RSVP that still
  fits is auto-promoted. All capacity math runs in a transaction so
  two simultaneous RSVPs can't both grab the last seat.
- **Raising capacity** sweeps the waitlist on save (no scheduled job).
- **RSVP deadline** — optional; after it passes, only cancellation
  (`no`) is accepted.
- **iCal export** — `/events/{slug}.ics` returns a valid RFC 5545
  file with escaped fields.
- **Ownership scope** — `owner_user_id` + `owner_group_id` columns
  for future moderation integration.

## Routes

| Method | Path                               | Purpose |
|--------|------------------------------------|---------|
| GET    | `/events`                          | Upcoming list |
| GET    | `/events/{slug}`                   | Detail + RSVP |
| GET    | `/events/{slug}.ics`               | iCal download |
| POST   | `/events/{slug}/rsvp`              | Upsert RSVP |
| POST   | `/events/{slug}/cancel`            | Cancel (sets `no`) |
| Admin (`events.manage`) | `/admin/events/*`     | Full CRUD + waitlist sweep |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
