# Installation — Events

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` (creates 2 tables + seeds permission).
3. Grant `events.manage` to at least one role.

## First-use walkthrough

1. `/admin/events/create` → fill in title, slug, start/end times (UTC),
   capacity=3, published ✓. Save.
2. Log in as three different users; RSVP `yes` for each. All three are
   confirmed. Fourth user RSVPs yes → waitlisted.
3. First user changes RSVP to `no`. The fourth (oldest waitlisted) is
   auto-promoted.
4. Download `/events/{slug}.ics` — opens in Calendar/Outlook/
   Google Calendar as an event.

## Deferred features

- **Email notifications** — "RSVP confirmed", "you've been promoted
  from the waitlist". Hook MailService into `upsertRsvp` +
  `promoteFromWaitlistInTx`.
- **Recurring events** — each occurrence as its own row, or a
  recurrence rule + materialized instances. Non-trivial schema
  extension.
- **Reminders** — scheduled task that emails attendees 24h before
  `starts_at`.
- **Event comments** — drop `<?= comments('event', $id) ?>` from the
  comments module into `Views/public/show.php`.
- **Check-in** — admin flips an `attended` flag at the event; useful
  for stats + follow-up targeting.
