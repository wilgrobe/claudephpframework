<?php
// modules/events/module.php
use Core\Module\ModuleProvider;

/**
 * Events module — event calendar with RSVPs (yes/no/maybe), guest
 * counts, capacity + waitlist, and per-event iCal export.
 *
 * Capacity math is transactional — two simultaneous RSVPs can't both
 * grab the last seat. When a confirmed attendee cancels, the oldest
 * waitlisted RSVP that fits is auto-promoted (no scheduled job
 * needed; promotion runs inline). Raising capacity also sweeps the
 * waitlist on save.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'events'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
