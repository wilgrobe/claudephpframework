<?php
// modules/events/migrations/2026_04_23_220000_create_events_tables.php
use Core\Database\Migration;

/**
 * Schema for the events module.
 *
 *   events       — the event definition. `capacity` is nullable (null =
 *                  uncapped). `location` is free-form. `starts_at` /
 *                  `ends_at` in UTC — views convert to whatever tz the
 *                  user prefers. `owner_user_id` / `owner_group_id`
 *                  for moderation scope compatibility with the
 *                  comments-registry pattern. `published` gates the
 *                  public listing.
 *
 *   event_rsvps  — one row per (event, user). Status ENUM
 *                  yes/no/maybe. `guest_count` adds to headcount when
 *                  status='yes' (counts against capacity). `waitlisted`
 *                  TINYINT flags RSVPs that landed after capacity was
 *                  reached; when a yes-RSVP cancels, the oldest
 *                  waitlisted row is auto-promoted.
 *
 * Capacity accounting:
 *   confirmed_headcount = SUM(1 + guest_count) where status='yes' AND waitlisted=0
 *   capacity_remaining  = max(0, capacity - confirmed_headcount)
 *   A new 'yes' RSVP either:
 *     - fits entirely within remaining → stored with waitlisted=0
 *     - doesn't fit → stored with waitlisted=1; placement at tail
 *   Promotion from waitlist runs the same math against the new
 *   remaining after each cancellation.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE events (
                id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                slug            VARCHAR(191) NOT NULL,
                title           VARCHAR(191) NOT NULL,
                description     TEXT NULL,
                location        VARCHAR(255) NULL,
                starts_at       DATETIME NOT NULL,
                ends_at         DATETIME NOT NULL,
                timezone        VARCHAR(64) NOT NULL DEFAULT 'UTC',
                capacity        INT UNSIGNED NULL,
                rsvp_deadline   DATETIME NULL,
                owner_user_id   INT UNSIGNED NULL,
                owner_group_id  INT UNSIGNED NULL,
                published       TINYINT(1) NOT NULL DEFAULT 0,
                created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_slug (slug),
                KEY idx_published_starts (published, starts_at),
                KEY idx_group (owner_group_id, starts_at),
                CONSTRAINT chk_event_times CHECK (ends_at > starts_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE event_rsvps (
                id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                event_id       INT UNSIGNED NOT NULL,
                user_id        INT UNSIGNED NOT NULL,
                status         ENUM('yes','no','maybe') NOT NULL DEFAULT 'yes',
                guest_count    INT UNSIGNED NOT NULL DEFAULT 0,
                waitlisted     TINYINT(1)   NOT NULL DEFAULT 0,
                note           VARCHAR(500) NULL,
                created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_event_user (event_id, user_id),
                KEY idx_event_status (event_id, status, waitlisted, created_at),
                CONSTRAINT fk_rsvp_event FOREIGN KEY (event_id)
                    REFERENCES events (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS event_rsvps");
        $this->db->query("DROP TABLE IF EXISTS events");
    }
};
