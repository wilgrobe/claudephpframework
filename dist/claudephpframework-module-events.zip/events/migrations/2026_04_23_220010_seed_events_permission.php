<?php
// modules/events/migrations/2026_04_23_220010_seed_events_permission.php
use Core\Database\Migration;

return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage events',
            'events.manage',
            'events',
            'Create, edit, and manage events + RSVP lists.',
        ]);
    }

    public function down(): void {}
};
