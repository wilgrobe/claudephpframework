<?php
// modules/events/Controllers/EventController.php
namespace Modules\Events\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Events\Services\EventService;

/**
 *   GET  /events                  — upcoming events list
 *   GET  /events/{slug}           — detail + RSVP form
 *   GET  /events/{slug}.ics       — iCal download
 *   POST /events/{slug}/rsvp      — upsert this user's RSVP
 *   POST /events/{slug}/cancel    — cancel (sets status='no')
 */
class EventController
{
    private Auth         $auth;
    private EventService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new EventService();
    }

    public function index(Request $request): Response
    {
        return Response::view('events::public.index', [
            'events' => $this->svc->upcomingPublished(),
        ]);
    }

    public function show(Request $request): Response
    {
        $slug  = (string) $request->param(0);
        $event = $this->svc->findBySlug($slug);
        if (!$event || (int) $event['published'] !== 1) return new Response('Event not found', 404);

        $my = null;
        if (!$this->auth->guest()) {
            $my = $this->svc->findRsvp((int) $event['id'], (int) $this->auth->id());
        }
        return Response::view('events::public.show', [
            'event'      => $event,
            'confirmed'  => $this->svc->confirmedRsvps((int) $event['id']),
            'waitlist'   => $this->svc->waitlist((int) $event['id']),
            'confirmed_headcount' => $this->svc->confirmedHeadcount((int) $event['id']),
            'remaining'  => $this->svc->remainingCapacity($event),
            'my'         => $my,
            'me'         => $this->auth->user(),
        ]);
    }

    public function ical(Request $request): Response
    {
        $slug  = (string) $request->param(0);
        $event = $this->svc->findBySlug($slug);
        if (!$event || (int) $event['published'] !== 1) return new Response('Event not found', 404);

        $body = $this->svc->toICal($event);
        return new Response($body, 200, [
            'Content-Type'        => 'text/calendar; charset=UTF-8',
            'Content-Disposition' => 'attachment; filename="' . preg_replace('~[^a-z0-9-]~', '', (string) $event['slug']) . '.ics"',
        ]);
    }

    public function rsvp(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $slug  = (string) $request->param(0);
        $event = $this->svc->findBySlug($slug);
        if (!$event || (int) $event['published'] !== 1) return new Response('Event not found', 404);

        try {
            $this->svc->upsertRsvp(
                (int) $event['id'],
                (int) $this->auth->id(),
                (string) $request->post('status', 'yes'),
                (int) $request->post('guest_count', 0),
                (string) $request->post('note') ?: null
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect("/events/$slug")->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/events/$slug")->withFlash('success', 'RSVP saved.');
    }

    public function cancel(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $slug  = (string) $request->param(0);
        $event = $this->svc->findBySlug($slug);
        if (!$event) return new Response('Event not found', 404);
        $this->svc->upsertRsvp((int) $event['id'], (int) $this->auth->id(), 'no', 0, null);
        return Response::redirect("/events/$slug")->withFlash('success', 'RSVP cancelled.');
    }
}
