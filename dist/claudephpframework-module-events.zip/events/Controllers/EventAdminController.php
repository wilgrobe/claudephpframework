<?php
// modules/events/Controllers/EventAdminController.php
namespace Modules\Events\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Events\Services\EventService;

/**
 *   GET  /admin/events                    — list
 *   GET  /admin/events/create             — new
 *   POST /admin/events/create             — save new
 *   GET  /admin/events/{id}/edit          — edit + RSVP panel
 *   POST /admin/events/{id}/edit          — update
 *   POST /admin/events/{id}/delete        — delete
 *   POST /admin/events/{id}/promote       — force a waitlist re-sweep
 */
class EventAdminController
{
    private Auth         $auth;
    private EventService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new EventService();
    }

    private function gate(): ?Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->auth->can('events.manage') && !$this->auth->can('admin.access')) {
            return new Response('Forbidden', 403);
        }
        return null;
    }

    public function index(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $filter = (string) $request->query('filter') ?: null;
        $res = $this->svc->listAll($filter, (int) $request->query('page', 1) ?: 1, 50);
        return Response::view('events::admin.index', $res);
    }

    public function createForm(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        return Response::view('events::admin.form', ['event' => null]);
    }

    public function store(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id = $this->svc->createEvent($this->readForm($request));
        return Response::redirect("/admin/events/$id/edit")->withFlash('success', 'Event created.');
    }

    public function edit(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id = (int) $request->param(0);
        $e  = $this->svc->find($id);
        if (!$e) return new Response('Not found', 404);
        return Response::view('events::admin.form', [
            'event'      => $e,
            'confirmed'  => $this->svc->confirmedRsvps($id),
            'waitlist'   => $this->svc->waitlist($id),
            'others'     => $this->svc->otherRsvps($id),
            'headcount'  => $this->svc->confirmedHeadcount($id),
            'remaining'  => $this->svc->remainingCapacity($e),
        ]);
    }

    public function update(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id = (int) $request->param(0);
        $this->svc->updateEvent($id, $this->readForm($request));
        // If capacity was raised, sweep the waitlist so newly-available seats
        // are allocated without waiting for a cancellation.
        $this->svc->promoteFromWaitlist($id);
        return Response::redirect("/admin/events/$id/edit")->withFlash('success', 'Event updated.');
    }

    public function delete(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $this->svc->deleteEvent((int) $request->param(0));
        return Response::redirect('/admin/events')->withFlash('success', 'Event deleted.');
    }

    public function promote(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id = (int) $request->param(0);
        $this->svc->promoteFromWaitlist($id);
        return Response::redirect("/admin/events/$id/edit")->withFlash('success', 'Waitlist swept.');
    }

    private function readForm(Request $request): array
    {
        return [
            'slug'           => (string) $request->post('slug'),
            'title'          => (string) $request->post('title'),
            'description'    => (string) $request->post('description'),
            'location'       => (string) $request->post('location'),
            'starts_at'      => (string) $request->post('starts_at'),
            'ends_at'        => (string) $request->post('ends_at'),
            'timezone'       => (string) $request->post('timezone', 'UTC'),
            'capacity'       => $request->post('capacity') !== '' && $request->post('capacity') !== null
                                   ? (int) $request->post('capacity') : null,
            'rsvp_deadline'  => (string) $request->post('rsvp_deadline') ?: null,
            'published'      => $request->post('published') ? 1 : 0,
        ];
    }
}
