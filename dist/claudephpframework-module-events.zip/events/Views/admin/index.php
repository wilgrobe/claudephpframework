<?php $pageTitle = 'Events — admin'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Events <span style="color:#9ca3af;font-size:13px">(<?= (int) $total ?>)</span></h2>
        <a href="/admin/events/create" class="btn btn-sm btn-primary">New event</a>
    </div>
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem">
        <a href="/admin/events" class="btn btn-sm <?= empty($filter) ? 'btn-primary' : 'btn-secondary' ?>">All</a>
        <a href="?filter=upcoming" class="btn btn-sm <?= ($filter ?? '') === 'upcoming' ? 'btn-primary' : 'btn-secondary' ?>">Upcoming</a>
        <a href="?filter=past"     class="btn btn-sm <?= ($filter ?? '') === 'past'     ? 'btn-primary' : 'btn-secondary' ?>">Past</a>
    </div>
    <?php if (empty($items)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No events.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Title</th><th>When</th><th>Capacity</th><th>Published</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($items as $e): ?>
        <tr>
            <td><strong><?= e((string) $e['title']) ?></strong><div style="color:#9ca3af;font-size:12px"><code><?= e((string) $e['slug']) ?></code></div></td>
            <td style="font-size:13px"><?= e(date('M j, Y H:i', strtotime((string) $e['starts_at']))) ?></td>
            <td><?= $e['capacity'] !== null ? (int) $e['capacity'] : '—' ?></td>
            <td><?= (int) $e['published'] ? '✓' : '—' ?></td>
            <td>
                <a href="/admin/events/<?= (int) $e['id'] ?>/edit" class="btn btn-sm btn-secondary">Edit</a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
