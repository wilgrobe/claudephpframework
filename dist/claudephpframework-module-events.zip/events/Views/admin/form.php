<?php
$isNew = empty($event);
$pageTitle = $isNew ? 'New event' : 'Edit ' . $event['title'];
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<a href="/admin/events" style="color:#6b7280;font-size:13px;text-decoration:none">← Events</a>

<div class="card" style="margin-top:.5rem">
    <div class="card-header"><h2 style="margin:0"><?= $isNew ? 'New event' : e((string) $event['title']) ?></h2></div>
    <form method="post" action="<?= $isNew ? '/admin/events/create' : '/admin/events/' . (int) $event['id'] . '/edit' ?>">
        <?= csrf_field() ?>
        <div class="card-body">
            <div style="display:grid;gap:.75rem;grid-template-columns:2fr 1fr">
                <label>Title <input name="title" required value="<?= e((string) ($event['title'] ?? '')) ?>" style="width:100%"></label>
                <label>Slug  <input name="slug"  required value="<?= e((string) ($event['slug'] ?? '')) ?>" style="width:100%"></label>
            </div>
            <label style="display:block;margin-top:.75rem">Description
                <textarea name="description" rows="5" style="width:100%"><?= e((string) ($event['description'] ?? '')) ?></textarea>
            </label>
            <label style="display:block;margin-top:.75rem">Location
                <input name="location" value="<?= e((string) ($event['location'] ?? '')) ?>" style="width:100%">
            </label>
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr 1fr;margin-top:.75rem">
                <label>Starts at (UTC)
                    <input type="datetime-local" name="starts_at" required value="<?= e($event && !empty($event['starts_at']) ? date('Y-m-d\TH:i', strtotime((string) $event['starts_at'])) : '') ?>">
                </label>
                <label>Ends at (UTC)
                    <input type="datetime-local" name="ends_at" required value="<?= e($event && !empty($event['ends_at']) ? date('Y-m-d\TH:i', strtotime((string) $event['ends_at'])) : '') ?>">
                </label>
                <label>Timezone (display)
                    <input name="timezone" value="<?= e((string) ($event['timezone'] ?? 'UTC')) ?>">
                </label>
            </div>
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr;margin-top:.75rem">
                <label>Capacity (blank = uncapped)
                    <input type="number" name="capacity" min="0" value="<?= e((string) ($event['capacity'] ?? '')) ?>">
                </label>
                <label>RSVP deadline (blank = until start)
                    <input type="datetime-local" name="rsvp_deadline" value="<?= e($event && !empty($event['rsvp_deadline']) ? date('Y-m-d\TH:i', strtotime((string) $event['rsvp_deadline'])) : '') ?>">
                </label>
            </div>
            <label style="display:block;margin-top:.75rem">
                <input type="checkbox" name="published" value="1" <?= !empty($event['published']) ? 'checked' : '' ?>>
                Published (visible at /events)
            </label>
        </div>
        <div class="card-footer" style="padding:.75rem 1.25rem;background:#f9fafb;display:flex;justify-content:space-between">
            <?php if (!$isNew): ?>
            <div>
                <form method="post" action="/admin/events/<?= (int) $event['id'] ?>/promote" style="display:inline">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-secondary">Sweep waitlist</button>
                </form>
                <form method="post" action="/admin/events/<?= (int) $event['id'] ?>/delete" style="display:inline" onsubmit="return confirm('Delete event + all RSVPs?')">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </div>
            <?php else: ?><div></div><?php endif; ?>
            <button type="submit" class="btn btn-primary"><?= $isNew ? 'Create' : 'Save' ?></button>
        </div>
    </form>
</div>

<?php if (!$isNew): ?>
<div style="display:grid;gap:1rem;grid-template-columns:1fr 1fr 1fr;margin-top:1rem">
    <div class="card">
        <div class="card-header"><strong>Attending</strong> (<?= count($confirmed ?? []) ?>)</div>
        <div class="card-body" style="font-size:13px">
            <div style="color:#9ca3af;margin-bottom:.25rem">Headcount: <?= (int) ($headcount ?? 0) ?><?= $remaining !== null ? ' · ' . (int) $remaining . ' seats left' : '' ?></div>
            <?php foreach (($confirmed ?? []) as $r): ?>
            <div>@<?= e((string) $r['username']) ?><?= (int) $r['guest_count'] > 0 ? ' +' . (int) $r['guest_count'] : '' ?></div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="card">
        <div class="card-header"><strong>Waitlist</strong> (<?= count($waitlist ?? []) ?>)</div>
        <div class="card-body" style="font-size:13px">
            <?php foreach (($waitlist ?? []) as $r): ?>
            <div>@<?= e((string) $r['username']) ?><?= (int) $r['guest_count'] > 0 ? ' +' . (int) $r['guest_count'] : '' ?></div>
            <?php endforeach; ?>
        </div>
    </div>
    <div class="card">
        <div class="card-header"><strong>Maybe / Not going</strong></div>
        <div class="card-body" style="font-size:13px">
            <?php foreach (($others ?? []) as $r): ?>
            <div>@<?= e((string) $r['username']) ?> · <?= e((string) $r['status']) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
