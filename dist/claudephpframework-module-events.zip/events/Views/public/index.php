<?php $pageTitle = 'Events'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Events</h1>

<?php if (empty($events)): ?>
<div class="card"><div class="card-body" style="color:#9ca3af;text-align:center;padding:3rem 1rem">
    No upcoming events.
</div></div>
<?php else: ?>
<div style="display:grid;gap:1rem;grid-template-columns:repeat(auto-fit, minmax(280px, 1fr))">
    <?php foreach ($events as $e): ?>
    <a href="/events/<?= e((string) $e['slug']) ?>" class="card" style="text-decoration:none;color:inherit;padding:1rem;display:block">
        <div style="color:#6b7280;font-size:12px;text-transform:uppercase">
            <?= e(date('D M j · H:i', strtotime((string) $e['starts_at']))) ?> <?= e((string) $e['timezone']) ?>
        </div>
        <h3 style="margin:.25rem 0"><?= e((string) $e['title']) ?></h3>
        <?php if (!empty($e['location'])): ?>
        <div style="color:#4b5563;font-size:13px">📍 <?= e((string) $e['location']) ?></div>
        <?php endif; ?>
        <?php if ($e['capacity'] !== null): ?>
        <div style="color:#9ca3af;font-size:12px;margin-top:.5rem">
            Capacity <?= (int) $e['capacity'] ?>
        </div>
        <?php endif; ?>
    </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
