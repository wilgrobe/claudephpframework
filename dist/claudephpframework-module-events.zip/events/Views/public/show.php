<?php $pageTitle = $event['title']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:760px;margin:0 auto">
<a href="/events" style="color:#6b7280;font-size:13px;text-decoration:none">← Events</a>

<div class="card" style="margin-top:.5rem">
    <div class="card-body">
        <h1 style="margin:0"><?= e((string) $event['title']) ?></h1>
        <div style="color:#6b7280;margin-top:.25rem;font-size:13px">
            <?= e(date('l, M j, Y', strtotime((string) $event['starts_at']))) ?>
            · <?= e(date('H:i', strtotime((string) $event['starts_at']))) ?>
            – <?= e(date('H:i', strtotime((string) $event['ends_at']))) ?>
            <?= e((string) $event['timezone']) ?>
        </div>
        <?php if (!empty($event['location'])): ?>
        <div style="color:#4b5563;margin-top:.5rem">📍 <?= e((string) $event['location']) ?></div>
        <?php endif; ?>
        <?php if (!empty($event['description'])): ?>
        <div style="margin-top:1rem;line-height:1.6"><?= nl2br(e((string) $event['description'])) ?></div>
        <?php endif; ?>

        <div style="display:flex;gap:.5rem;margin-top:1rem;align-items:center">
            <a href="/events/<?= e((string) $event['slug']) ?>.ics" class="btn btn-sm btn-secondary">Add to calendar (.ics)</a>
            <div style="margin-left:auto;color:#9ca3af;font-size:12px">
                <?php if ($event['capacity'] !== null): ?>
                <?= (int) $confirmed_headcount ?> / <?= (int) $event['capacity'] ?> attending
                <?php if ($remaining === 0 && count($waitlist) > 0): ?>
                · <?= count($waitlist) ?> on waitlist
                <?php endif; ?>
                <?php else: ?>
                <?= (int) $confirmed_headcount ?> attending
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php if (!empty($me)): ?>
<div class="card" style="margin-top:1rem">
    <div class="card-header"><strong>Your RSVP</strong></div>
    <form method="post" action="/events/<?= e((string) $event['slug']) ?>/rsvp">
        <?= csrf_field() ?>
        <div class="card-body">
            <?php if ($my && (int) $my['waitlisted'] === 1): ?>
            <div style="color:#b45309;font-size:13px;margin-bottom:.5rem">
                You're on the waitlist. We'll auto-confirm you when a spot opens up.
            </div>
            <?php endif; ?>
            <label>Going?
                <select name="status">
                    <?php foreach (['yes' => 'Yes', 'maybe' => 'Maybe', 'no' => 'No'] as $v => $lab): ?>
                    <option value="<?= e($v) ?>" <?= ($my['status'] ?? 'yes') === $v ? 'selected' : '' ?>><?= $lab ?></option>
                    <?php endforeach; ?>
                </select>
            </label>
            <label style="display:block;margin-top:.5rem">Additional guests
                <input type="number" name="guest_count" min="0" max="20" value="<?= (int) ($my['guest_count'] ?? 0) ?>">
            </label>
            <label style="display:block;margin-top:.5rem">Note (optional)
                <input name="note" maxlength="500" value="<?= e((string) ($my['note'] ?? '')) ?>">
            </label>
        </div>
        <div class="card-footer" style="padding:.5rem 1rem;text-align:right;background:#f9fafb">
            <button type="submit" class="btn btn-primary">Save RSVP</button>
        </div>
    </form>
</div>
<?php else: ?>
<div style="margin-top:1rem;color:#9ca3af;font-size:13px"><a href="/login">Log in</a> to RSVP.</div>
<?php endif; ?>

<?php if (!empty($confirmed)): ?>
<div class="card" style="margin-top:1rem">
    <div class="card-header"><strong>Attending</strong> (<?= count($confirmed) ?>)</div>
    <div class="card-body">
        <?php foreach ($confirmed as $r): ?>
        <span style="display:inline-block;margin:.15rem .25rem;padding:.15rem .5rem;background:#ecfdf5;border-radius:4px;font-size:13px">
            @<?= e((string) ($r['username'] ?? '?')) ?><?= (int) $r['guest_count'] > 0 ? ' +' . (int) $r['guest_count'] : '' ?>
        </span>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>

<?php if (!empty($waitlist)): ?>
<div class="card" style="margin-top:1rem">
    <div class="card-header"><strong>Waitlist</strong> (<?= count($waitlist) ?>)</div>
    <div class="card-body">
        <?php foreach ($waitlist as $r): ?>
        <span style="display:inline-block;margin:.15rem .25rem;padding:.15rem .5rem;background:#fef3c7;border-radius:4px;font-size:13px">
            @<?= e((string) ($r['username'] ?? '?')) ?><?= (int) $r['guest_count'] > 0 ? ' +' . (int) $r['guest_count'] : '' ?>
        </span>
        <?php endforeach; ?>
    </div>
</div>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
