<?php
// modules/events/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$E = 'Modules\Events\Controllers\EventController';
$A = 'Modules\Events\Controllers\EventAdminController';

// Public
$router->get ('/events',                      "$E@index");
$router->get ('/events/{slug}',               "$E@show");
$router->get ('/events/{slug}.ics',           "$E@ical");
$router->post('/events/{slug}/rsvp',          "$E@rsvp",   [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/events/{slug}/cancel',        "$E@cancel", [CsrfMiddleware::class, AuthMiddleware::class]);

// Admin
$admin     = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];
$router->get ('/admin/events',                "$A@index",      $admin);
$router->get ('/admin/events/create',         "$A@createForm", $admin);
$router->post('/admin/events/create',         "$A@store",      $adminCsrf);
$router->get ('/admin/events/{id}/edit',      "$A@edit",       $admin);
$router->post('/admin/events/{id}/edit',      "$A@update",     $adminCsrf);
$router->post('/admin/events/{id}/delete',    "$A@delete",     $adminCsrf);
$router->post('/admin/events/{id}/promote',   "$A@promote",    $adminCsrf);
