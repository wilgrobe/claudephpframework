<?php
// modules/events/Services/EventService.php
namespace Modules\Events\Services;

use Core\Database\Database;

/**
 * Event CRUD + RSVP lifecycle + capacity/waitlist arithmetic +
 * iCal generation.
 *
 * The trickiest bit is the capacity accounting. The rules:
 *   confirmed headcount = Σ (1 + guest_count) over yes-RSVPs with
 *                         waitlisted=0
 *   remaining           = max(0, capacity - confirmed headcount)
 *   A new 'yes' (+g guests) going in:
 *     - if (1+g) ≤ remaining: row saved with waitlisted=0
 *     - else: row saved with waitlisted=1 (entire RSVP waitlists,
 *             including all its guests; we don't split)
 *   Cancel of a confirmed yes: run promoteFromWaitlist() which
 *   walks the waitlisted rows oldest-first and promotes any that fit.
 *
 * The math is wrapped in a transaction so two simultaneous RSVPs
 * can't both grab the last slot.
 */
class EventService
{
    public const STATUSES = ['yes','no','maybe'];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Event reads ──────────────────────────────────────────────────────

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM events WHERE id = ?", [$id]);
    }

    public function findBySlug(string $slug): ?array
    {
        return $this->db->fetchOne("SELECT * FROM events WHERE slug = ?", [$slug]);
    }

    /** @return array<int, array<string, mixed>> */
    public function upcomingPublished(int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM events
              WHERE published = 1 AND ends_at >= NOW()
           ORDER BY starts_at ASC LIMIT ?",
            [$limit]
        );
    }

    /**
     * @return array{items: array<int, array<string, mixed>>, total: int}
     */
    public function listAll(?string $filter = null, int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        $where = ''; $bind = [];
        if ($filter === 'upcoming') { $where = 'WHERE ends_at >= NOW()'; }
        if ($filter === 'past')     { $where = 'WHERE ends_at <  NOW()'; }

        $items = $this->db->fetchAll(
            "SELECT * FROM events $where ORDER BY starts_at DESC LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn("SELECT COUNT(*) FROM events $where", $bind);
        return ['items' => $items, 'total' => $total, 'filter' => $filter];
    }

    // ── RSVP reads ───────────────────────────────────────────────────────

    public function findRsvp(int $eventId, int $userId): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM event_rsvps WHERE event_id = ? AND user_id = ?",
            [$eventId, $userId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function confirmedRsvps(int $eventId): array
    {
        return $this->db->fetchAll(
            "SELECT r.*, u.username
               FROM event_rsvps r
          LEFT JOIN users u ON u.id = r.user_id
              WHERE r.event_id = ? AND r.status = 'yes' AND r.waitlisted = 0
           ORDER BY r.created_at ASC",
            [$eventId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function waitlist(int $eventId): array
    {
        return $this->db->fetchAll(
            "SELECT r.*, u.username
               FROM event_rsvps r
          LEFT JOIN users u ON u.id = r.user_id
              WHERE r.event_id = ? AND r.status = 'yes' AND r.waitlisted = 1
           ORDER BY r.created_at ASC",
            [$eventId]
        );
    }

    /** @return array<int, array<string, mixed>>  maybes + nos for admin view */
    public function otherRsvps(int $eventId): array
    {
        return $this->db->fetchAll(
            "SELECT r.*, u.username
               FROM event_rsvps r
          LEFT JOIN users u ON u.id = r.user_id
              WHERE r.event_id = ? AND r.status IN ('no','maybe')
           ORDER BY r.status ASC, r.created_at DESC",
            [$eventId]
        );
    }

    public function confirmedHeadcount(int $eventId): int
    {
        return (int) $this->db->fetchColumn(
            "SELECT COALESCE(SUM(1 + guest_count), 0) FROM event_rsvps
              WHERE event_id = ? AND status = 'yes' AND waitlisted = 0",
            [$eventId]
        );
    }

    public function remainingCapacity(array $event): ?int
    {
        if ($event['capacity'] === null) return null; // unlimited
        return max(0, (int) $event['capacity'] - $this->confirmedHeadcount((int) $event['id']));
    }

    // ── Event writes ─────────────────────────────────────────────────────

    public function createEvent(array $data): int
    {
        return (int) $this->db->insert('events', $this->prepareEvent($data));
    }

    public function updateEvent(int $id, array $data): void
    {
        $this->db->update('events', $this->prepareEvent($data), 'id = ?', [$id]);
    }

    public function deleteEvent(int $id): void
    {
        $this->db->delete('events', 'id = ?', [$id]);
    }

    private function prepareEvent(array $data): array
    {
        $out = [];
        foreach ([
            'slug','title','description','location','starts_at','ends_at','timezone',
            'capacity','rsvp_deadline','owner_user_id','owner_group_id','published',
        ] as $k) {
            if (array_key_exists($k, $data)) $out[$k] = $data[$k];
        }
        if (isset($out['slug'])) $out['slug'] = self::slugify((string) $out['slug']);
        if (array_key_exists('capacity', $out) && $out['capacity'] === '') $out['capacity'] = null;
        if (array_key_exists('rsvp_deadline', $out) && $out['rsvp_deadline'] === '') $out['rsvp_deadline'] = null;
        return $out;
    }

    public static function slugify(string $s): string
    {
        $s = strtolower(trim($s));
        $s = preg_replace('~[^a-z0-9]+~', '-', $s) ?? '';
        return trim($s, '-');
    }

    // ── RSVP writes ──────────────────────────────────────────────────────

    /**
     * Upsert an RSVP. Returns the resulting row with `waitlisted` +
     * `status` set. Capacity math lives inside a transaction.
     */
    public function upsertRsvp(int $eventId, int $userId, string $status, int $guestCount = 0, ?string $note = null): array
    {
        if (!in_array($status, self::STATUSES, true)) $status = 'yes';
        if ($guestCount < 0) $guestCount = 0;
        if ($guestCount > 20) $guestCount = 20; // sanity cap

        $event = $this->find($eventId);
        if (!$event) throw new \InvalidArgumentException('Event not found.');

        // Past the deadline? Only 'no' is allowed (cancellation).
        if (!empty($event['rsvp_deadline'])
         && strtotime((string) $event['rsvp_deadline']) < time()
         && $status !== 'no') {
            throw new \InvalidArgumentException('RSVP deadline has passed.');
        }

        $this->db->beginTransaction();
        try {
            $existing = $this->findRsvp($eventId, $userId);
            $prevStatus     = $existing['status']     ?? null;
            $prevWaitlisted = (int) ($existing['waitlisted'] ?? 0);

            $waitlisted = 0;
            if ($status === 'yes' && $event['capacity'] !== null) {
                // Compute headcount excluding this user's prior confirmed yes
                // so the new count reflects the pending change.
                $current = $this->confirmedHeadcount($eventId);
                $previousContribution = ($prevStatus === 'yes' && $prevWaitlisted === 0)
                    ? 1 + (int) ($existing['guest_count'] ?? 0)
                    : 0;
                $available = (int) $event['capacity'] - ($current - $previousContribution);
                $requested = 1 + $guestCount;
                $waitlisted = ($requested <= $available) ? 0 : 1;
            }

            if ($existing) {
                $this->db->update('event_rsvps', [
                    'status'      => $status,
                    'guest_count' => $guestCount,
                    'waitlisted'  => $waitlisted,
                    'note'        => $note !== null ? substr($note, 0, 500) : null,
                ], 'id = ?', [(int) $existing['id']]);
                $id = (int) $existing['id'];
            } else {
                $id = (int) $this->db->insert('event_rsvps', [
                    'event_id'    => $eventId,
                    'user_id'     => $userId,
                    'status'      => $status,
                    'guest_count' => $guestCount,
                    'waitlisted'  => $waitlisted,
                    'note'        => $note !== null ? substr($note, 0, 500) : null,
                ]);
            }

            // If the new state frees capacity, try to promote waitlisted rows.
            $freedUp = $prevStatus === 'yes' && $prevWaitlisted === 0
                && ($status !== 'yes' || $waitlisted === 1);
            if ($freedUp) {
                $this->promoteFromWaitlistInTx($eventId);
            }

            $this->db->commit();
            return $this->db->fetchOne("SELECT * FROM event_rsvps WHERE id = ?", [$id]) ?? [];
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Promote waitlisted 'yes' rows to confirmed, oldest-first, while
     * there's room. Called after cancellations and when capacity is
     * raised. Must run inside a transaction.
     */
    private function promoteFromWaitlistInTx(int $eventId): void
    {
        $event = $this->find($eventId);
        if (!$event || $event['capacity'] === null) return;

        $waitlisted = $this->db->fetchAll(
            "SELECT * FROM event_rsvps
              WHERE event_id = ? AND status = 'yes' AND waitlisted = 1
           ORDER BY created_at ASC",
            [$eventId]
        );
        if (empty($waitlisted)) return;

        $remaining = $this->remainingCapacity($event);
        foreach ($waitlisted as $r) {
            $need = 1 + (int) $r['guest_count'];
            if ($need <= $remaining) {
                $this->db->update('event_rsvps', ['waitlisted' => 0], 'id = ?', [(int) $r['id']]);
                $remaining -= $need;
            }
            if ($remaining <= 0) break;
        }
    }

    /** Public wrapper — used when capacity is raised via editEvent. */
    public function promoteFromWaitlist(int $eventId): void
    {
        $this->db->beginTransaction();
        try {
            $this->promoteFromWaitlistInTx($eventId);
            $this->db->commit();
        } catch (\Throwable $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    // ── iCal export ──────────────────────────────────────────────────────

    /**
     * Emit a single-event iCalendar file. DTSTART/DTEND in UTC per
     * RFC 5545 floating-time avoidance. UID includes the slug + app
     * domain so calendars can dedup edits.
     */
    public function toICal(array $event): string
    {
        $appUrl = (string) (config('app.url') ?? 'http://localhost');
        $host   = parse_url($appUrl, PHP_URL_HOST) ?: 'localhost';
        $uid    = 'event-' . (int) $event['id'] . '-' . (string) $event['slug'] . '@' . $host;

        $dt = static function (?string $s): string {
            if (!$s) return gmdate('Ymd\THis\Z');
            // Inputs are stored as DATETIME in UTC.
            return gmdate('Ymd\THis\Z', strtotime($s));
        };
        $esc = static function (string $s): string {
            // RFC 5545 TEXT escaping.
            $s = str_replace(["\\", ";", ",", "\n", "\r"], ["\\\\", "\\;", "\\,", "\\n", ""], $s);
            return $s;
        };

        $body  = "BEGIN:VCALENDAR\r\n";
        $body .= "VERSION:2.0\r\n";
        $body .= "PRODID:-//claudephpframework//events//EN\r\n";
        $body .= "CALSCALE:GREGORIAN\r\n";
        $body .= "METHOD:PUBLISH\r\n";
        $body .= "BEGIN:VEVENT\r\n";
        $body .= "UID:$uid\r\n";
        $body .= "DTSTAMP:" . gmdate('Ymd\THis\Z') . "\r\n";
        $body .= "DTSTART:" . $dt((string) $event['starts_at']) . "\r\n";
        $body .= "DTEND:"   . $dt((string) $event['ends_at'])   . "\r\n";
        $body .= "SUMMARY:" . $esc((string) $event['title']) . "\r\n";
        if (!empty($event['description'])) {
            $body .= "DESCRIPTION:" . $esc((string) $event['description']) . "\r\n";
        }
        if (!empty($event['location'])) {
            $body .= "LOCATION:" . $esc((string) $event['location']) . "\r\n";
        }
        $body .= "URL:" . rtrim($appUrl, '/') . "/events/" . (string) $event['slug'] . "\r\n";
        $body .= "END:VEVENT\r\n";
        $body .= "END:VCALENDAR\r\n";
        return $body;
    }
}
