# Architecture — Events

## Files

```
events/
├── module.php
├── routes.php
├── Controllers/{EventController,EventAdminController}.php
├── Services/EventService.php        # CRUD + capacity math + iCal
├── Views/{public,admin}/…
└── migrations/{create_tables, seed_permission}.php
```

## Data model

```
events:
  id, slug (unique), title, description, location,
  starts_at, ends_at, timezone,
  capacity NULL, rsvp_deadline NULL,
  owner_user_id, owner_group_id,
  published, timestamps
  CHECK (ends_at > starts_at)

event_rsvps:
  id, event_id CASCADE, user_id,
  status ENUM('yes','no','maybe'),
  guest_count UNSIGNED, waitlisted TINYINT, note, timestamps
  UNIQUE (event_id, user_id)
```

## Capacity math

```
confirmed_headcount = SUM(1 + guest_count) WHERE status='yes' AND waitlisted=0
remaining           = max(0, capacity - confirmed_headcount)

New 'yes' RSVP (+g guests):
  prior_contribution = IF prev was yes+not-waitlisted: 1+prev.guest_count else 0
  available = capacity - (current_headcount - prior_contribution)
  if 1+g <= available: save waitlisted=0
  else:                save waitlisted=1
```

Wrapped in a DB transaction so concurrent RSVPs can't both treat the
same seat as available.

When a confirmed RSVP cancels (or flips to `no`/`maybe`), the
`promoteFromWaitlistInTx` sweep walks the waitlisted rows oldest-
first and promotes any that fit the now-larger remaining. No guest
count splitting — an RSVP that needs 3 seats stays waitlisted if
only 2 open up.

## iCal

`toICal($event)` builds RFC 5545 with:
- `UID = event-{id}-{slug}@{host}` — stable across edits so
  calendars update rather than duplicate.
- `DTSTART` / `DTEND` in UTC (`Ymd'T'His'Z'`).
- TEXT-escaped summary/description/location (backslashes, semicolons,
  commas, newlines → `\\`, `\;`, `\,`, `\n`).
- `URL` pointing back at `/events/{slug}` so clicking in the calendar
  lands on the app.
