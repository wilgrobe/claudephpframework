# Installation — FAQ module

## Prerequisites

- `claudephpframework-core` installed.
- Core schema includes `faqs` and `faq_categories` tables (shipped in
  `database/install.sql`).
- `faq.manage` permission granted to at least one admin role. Seed this
  via the Roles admin or a migration if it's not already present.

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-faq.zip
   cp -r claudephpframework-module-faq/faq /path/to/project/modules/
   ```

2. Run migrations (no schema ships with this module):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if enabled in production:
   ```bash
   php artisan module:cache
   ```

## MySQL version note

`FaqController::publicIndex` uses `JSON_ARRAYAGG` (MySQL 5.7+) with a
PHP-side fallback for older MySQLs. No action needed — the fallback
triggers automatically on servers without that aggregate.

## Verification

- Browse to `/faq` — you should see an empty "No FAQs yet" state.
- Log in as an admin, visit `/admin/faqs/categories`, add a category.
- Add an FAQ under that category via `/admin/faqs`, mark public + active.
- Refresh `/faq` — the entry appears grouped under its category.
