<?php
// modules/faq/module.php
use Core\Module\ModuleProvider;

/**
 * FAQ module — categorized Q&A with admin CRUD and a public /faq page.
 * The public JSON_ARRAYAGG query in FaqController::publicIndex includes a
 * fallback for MySQL versions without that aggregate — preserved verbatim
 * from the original App\Controllers\Admin\FaqController.
 */
return new class extends ModuleProvider {
    public function name(): string { return 'faq'; }

    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
