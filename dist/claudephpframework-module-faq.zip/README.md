# FAQ module

Categorized Q&A with admin CRUD and a public `/faq` landing page. Indexed
alongside content + pages in the framework's search layer.

## Features

- Public FAQ page with grouped-by-category rendering
- Admin CRUD for FAQ entries and categories
- `is_public` / `is_active` flags control visibility independently
- Rich-text answers sanitized via `Validator::sanitizeHtml` (DOMDocument +
  allowlist)
- Live search integration: FAQs surface in the site's `/search` results
  alongside content + pages

## Routes

| Method | Path                                       | Middleware              | Purpose                     |
|--------|--------------------------------------------|-------------------------|-----------------------------|
| GET    | `/faq`                                     | —                       | Public FAQ page             |
| GET    | `/admin/faqs`                              | Auth + Admin            | FAQ admin list              |
| POST   | `/admin/faqs`                              | Csrf + Auth + Admin     | Create FAQ                  |
| GET    | `/admin/faqs/{id}/edit`                    | Auth + Admin            | Edit form                   |
| POST   | `/admin/faqs/{id}/edit`                    | Csrf + Auth + Admin     | Save changes                |
| POST   | `/admin/faqs/{id}/delete`                  | Csrf + Auth + Admin     | Delete                      |
| GET    | `/admin/faqs/categories`                   | Auth + Admin            | Categories admin            |
| POST   | `/admin/faqs/categories`                   | Csrf + Auth + Admin     | Create category             |
| POST   | `/admin/faqs/categories/{id}/delete`       | Csrf + Auth + Admin     | Delete category             |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
