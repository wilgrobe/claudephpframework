# Architecture — FAQ module

## Files

```
faq/
├── module.php
├── routes.php                          # 9 route registrations
├── Controllers/FaqController.php       # CRUD + public page + categories
└── Views/
    ├── public.php                      # /faq landing
    ├── admin/index.php                 # Admin list
    ├── admin/edit.php                  # Edit form
    └── admin/categories.php            # Category management
```

## Tables

- `faqs` — id, category_id (nullable), question, answer, sort_order,
  is_public, is_active, created_by, created_at
- `faq_categories` — id, name, slug, sort_order

Both shipped with core's `install.sql`.

## Data flow — public page

`FaqController::publicIndex`:

1. One SQL query pulls categories + aggregated FAQ rows using
   `JSON_ARRAYAGG(JSON_OBJECT(...))` GROUPed by category.
2. If the server is pre-MySQL-5.7, a fallback path fires two queries and
   groups in PHP.
3. Categories with no visible FAQs are filtered out before rendering.

## Search integration

Every insert/update/delete in the admin calls:

```php
app(\Core\Services\SearchIndexer::class)->sync('faqs', $id, $prefetchedRow);
```

The indexer queues an IndexDocumentJob or DeleteDocumentJob based on
`is_public AND is_active`. `search:reindex faqs` rebuilds the index.

Indexed shape: `id`, `question`, `answer` (HTML-stripped).

## Authorization

- Public page: no auth
- All `/admin/faqs*` routes require `AuthMiddleware + RequireAdmin`
- Controller methods also check `$this->auth->cannot('faq.manage')` for
  defense-in-depth

## HTML sanitization

Answers are stored HTML-sanitized via `Core\Validation\Validator::sanitizeHtml`:

- Allowlist: `p, br, strong, em, u, ul, ol, li, h2, h3, h4, blockquote, a`
- `<a href>` restricted to `http`, `https`, or relative paths
- No `<img>`, no event handlers, no `<script>`

## Dependencies

- `claudephpframework-core` — Auth, Validator, View, Database, SearchIndexer
- Core's `faqs` + `faq_categories` tables
- `faq.manage` permission registered in the role system
