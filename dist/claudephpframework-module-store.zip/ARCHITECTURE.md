# Architecture — Store module

## Files

```
store/
├── module.php
├── routes.php                                          # 25 routes
├── Controllers/
│   ├── ShopController.php                              # Public shop + cart + checkout + downloads
│   ├── StoreAdminController.php                        # Products/shipping/tax/orders admin CRUD
│   └── StoreWebhookController.php                      # Stripe webhook receiver
├── Services/
│   ├── ProductService.php                              # Catalog CRUD + stock adjust
│   ├── CartService.php                                 # Guest + user carts, totals, merge
│   ├── ShippingService.php                             # Zone matching + rate calc + CRUD
│   ├── TaxService.php                                  # Rate lookup + per-line calc + CRUD
│   ├── OrderService.php                                # Pending/paid lifecycle + tokens
│   └── CheckoutService.php                             # Stripe Checkout session + webhook dispatch
├── Views/
│   ├── public/
│   │   ├── index.php                                   # /shop
│   │   ├── product.php                                 # /shop/product/{slug}
│   │   ├── cart.php                                    # /cart
│   │   ├── checkout.php                                # /checkout (address form)
│   │   ├── checkout_success.php                        # /checkout/success
│   │   ├── my_orders.php                               # /orders
│   │   └── order_detail.php                            # /orders/{id}
│   └── admin/
│       ├── products/{index,form}.php
│       ├── shipping/{index,form}.php
│       ├── tax/{index,form}.php
│       └── orders/{index,show}.php
└── migrations/
    ├── 2026_04_22_230000_create_store_tables.php               # 8 tables
    ├── 2026_04_22_230010_seed_store_permission.php
    └── 2026_04_22_230020_add_store_variants_and_rich_fields.php  # +3 tables, rich fields
```

## Data model

### `store_products`

```
id, name, slug (unique), description, short_description,
meta_title, meta_description, canonical_url,
brand, barcode, product_type,
option1_name, option2_name, option3_name,
type ENUM('physical','digital'),
price_cents, currency, sku, stock_tracked, stock, weight_grams,
tax_class, digital_file_path, image_url, active, timestamps
```

`stock_tracked=0` means "unlimited" — common for print-on-demand physical
goods and digital goods. Stock adjustments only run when `stock_tracked=1`.
The `optionN_name` columns are the axis labels (e.g. "Color"); leaving
one null disables that axis. Shopify's covers-99%-of-stores cap of three
axes per product.

### `store_product_variants`

```
id, product_id FK CASCADE,
sku (unique), price_cents NULL, weight_grams NULL,
stock_tracked, stock,
option1_value, option2_value, option3_value,
image_url, sort_order, active, timestamps
UNIQUE (product_id, option1_value, option2_value, option3_value)
```

One row per option combination. `price_cents` and `weight_grams` are
nullable — NULL means "use the product's value" (variant-as-override
pattern). A product with no variants sells at the product-level price.
Pricing precedence is encoded in `ProductService::effectivePrice`.

### `store_product_images`

```
id, product_id FK CASCADE, url, alt, sort_order, timestamps
```

Ordered gallery. `ProductService::primaryImageUrl` returns the first
image (by sort_order) or falls back to `store_products.image_url`.

### `store_product_specs`

```
id, product_id FK CASCADE, label, value, sort_order, created_at
```

Key-value spec sheet, bulk-replaced by `ProductService::setSpecs`
(the admin form submits the whole list each save; wipe + re-insert is
simpler than diffing at O(n)≪100).

### `store_shipping_zones`

```
id, name, countries (CSV ISO-2), flat_rate_cents, free_over_cents,
sort_order, active, timestamps
```

Zones are scanned in `sort_order` ASC. First zone whose `countries`
contains the destination wins. A zone with empty `countries` is the
catch-all.

### `store_tax_rates`

```
id, country (ISO-2), region (nullable), rate_bps, label, tax_class,
active, timestamps
```

Rate lookup per cart line item: (country, region, tax_class) →
(country, NULL, tax_class) → 0. Basis points (10000 = 100%) keep
percentages integer.

### `store_carts` + `store_cart_items`

```
carts:       id, user_id NULL, session_id NULL, timestamps
cart_items:  id, cart_id, product_id, variant_id NULL, qty, price_cents, timestamps
             UNIQUE (cart_id, product_id, variant_id)
```

One cart per user or per session. The price snapshot on each cart_item
means mid-session price changes don't retroactively rewrite totals.
`variant_id` is nullable so products without option axes still get
cart rows; the triple-column unique index means Red/M and Blue/M are
separate cart lines even though they share a product_id.

### `store_orders`

```
id, user_id NULL, email, status ENUM,
subtotal_cents, shipping_cents, tax_cents, total_cents, currency,
shipping_address_json, billing_address_json,
stripe_session_id (unique, nullable), stripe_payment_intent_id,
tracking_number, notes, placed_at, shipped_at, refunded_at, timestamps
```

`stripe_session_id` is the correlation key webhooks use to find the
local order; it's also unique, so a duplicate session id from a replay
can't create a second row.

### `store_order_items`

```
id, order_id, product_id FK(SET NULL), variant_id NULL,
name_snap, type_snap, sku_snap, variant_options_snap,
qty, price_cents, total_cents, created_at
```

Snapshots matter here — products + variants can be edited or deleted
after purchase and the order should still display what was sold.
`variant_options_snap` holds "Red / M" frozen at purchase time;
`name_snap` concatenates product name + options so the order detail
renders cleanly without joining back to variants.

### `store_download_tokens`

```
id, order_item_id FK CASCADE, token (unique), expires_at, downloaded_at,
download_count, created_at
```

Opaque 48-char tokens, default 7-day expiry. `issueDownloadToken()` is
idempotent per order_item — a second call returns the existing
unexpired token rather than minting a new one.

## Checkout flow

```
 [browser] /cart
     │
     ▼
 /checkout       (GET)  — form renders shipping address + totals preview
     │
     │ POST email + address
     ▼
 CheckoutController::checkoutStart
     │
     ├─ CartService::totals(country, region)  — recompute with address
     ├─ OrderService::createPendingFromCart   — order row + items
     ├─ CheckoutService::startCheckout        — Stripe Checkout session
     │                                          (order_id in metadata)
     ├─ CartService::clear(cartId)            — cart empties
     └─ 302 → stripe.com checkout URL
```

On Stripe's page the shopper pays, is redirected to `/checkout/success`,
and near-simultaneously Stripe calls the webhook:

```
 POST /webhooks/stripe/store
  ├─ signature verify (StripeService::verifyWebhook)
  ├─ CheckoutService::applyWebhookEvent($event, OrderService)
  │    ├─ checkout.session.completed → OrderService::markPaid
  │    │     ├─ status pending → paid
  │    │     ├─ placed_at = NOW
  │    │     ├─ ProductService::adjustStock(-qty) per line item
  │    │     └─ issueDownloadToken for each digital line item
  │    └─ payment_intent.payment_failed → OrderService::transitionStatus(cancelled)
```

`markPaid` is idempotent — re-delivery of the same event is a no-op
because the `pending → paid` gate only opens once. This means stock
isn't double-decremented and tokens aren't double-issued on retry.

## Cancellation flow

When the shopper clicks cancel on Stripe's page, they land on
`/checkout/cancel?order={id}`. The handler:

1. Finds the pending order.
2. Re-adds every line item to the (now-empty) cart via
   `CartService::add` — which preserves current product prices rather
   than resurrecting the order's price snapshot (intentional: prices may
   have changed since the cart was assembled, and we want the shopper
   to see the current catalog).
3. Marks the order `cancelled`.

A webhook `payment_intent.payment_failed` on an already-`cancelled`
order is a no-op.

## Extensibility

- **Adding a payment gateway** — the store never imports
  `StripeService` directly outside `CheckoutService`. Swap
  `CheckoutService` or fork it per gateway; the
  `applyWebhookEvent($event, OrderService)` shape is provider-agnostic.
- **Discount codes** — add a `store_discounts` table and a discount
  column on `store_orders`. Apply at checkout time before the Stripe
  session is created so the discount lands as a negative line item.
- **Inventory reservations** — add a `store_reservations` table tied
  to `store_cart_items`, reserve stock at cart-add time, expire
  reservations via a scheduled task. `ProductService::canPurchase`
  would consult reserved vs. free stock.
- **Multi-currency** — per-row `currency` is already there; the
  only thing missing is a display-time conversion helper and a UI
  that lets users pick a preferred currency.
- **Order events log** — currently lifecycle is stored as columns on
  `store_orders`. A `store_order_events` table drops in cleanly if an
  audit trail becomes necessary.

## Testing notes

- Unit-level — `CartService::totals` is the single place tax + shipping
  math lands; assert on it with a synthetic `items` array and
  representative zones + tax rates.
- Integration — use Stripe's CLI to replay
  `checkout.session.completed` against the running app and assert the
  order flips to `paid` + stock decrements + a download token exists.
- Idempotency — replay the same event twice; the second delivery must
  not change any row.
