# Store module

Shopping cart, products, checkout, and orders for the framework.
Shopify-shaped product model: rich product fields, up to three option
axes per product, discrete variants with their own SKU / price / stock
/ weight / image, an image gallery, and a structured spec sheet.
Physical goods, digital goods, and mixed carts. Checkout goes through
the framework's configured Stripe gateway via a hosted Checkout
Session; the webhook at `/webhooks/stripe/store` promotes pending
orders to `paid`, decrements stock once, and issues download tokens
for digital line items.

## Features

### Product model

- **Physical + digital products** via `store_products.type`. Physical
  items track optional stock, weight, tax class; digital items carry a
  `digital_file_path` and ship via one-time download tokens.
- **Variants** — up to three option axes per product (e.g. Color /
  Size / Material). Each variant row carries its own SKU, price, stock,
  weight, and optional image. Pricing precedence at cart time: variant
  price overrides product price when set.
- **Rich fields** — `short_description` for listings, `meta_title` +
  `meta_description` + `canonical_url` for SEO, `brand`, `barcode`
  (GTIN/UPC/EAN), `product_type` filter tag. Covers the Shopify /
  Amazon core information set.
- **Image gallery** — `store_product_images` holds an ordered list of
  URLs per product. First image wins for listings; the rest render as a
  thumb strip on the detail page. Legacy `store_products.image_url`
  remains as a fallback when the gallery is empty.
- **Spec sheet** — `store_product_specs` is a per-product key-value
  table (label + value + sort_order). Rendered as a simple two-column
  table on the product page.

### Commerce

- **Cart persistence** for both guests (session-keyed) and users
  (user-keyed), with guest→user merging on login via
  `CartService::mergeGuestCartToUser`. Cart uniqueness is per
  (cart, product, variant) so adding Red/M and Blue/M lands as two
  line items.
- **Flat-rate shipping** by zone — a zone is a named list of ISO country
  codes + flat rate + optional `free_over_cents` threshold. Zones are
  ordered; the first match wins.
- **Simple tax** — basis-point rate by (country, region, tax_class).
  Multi-jurisdiction apps should plug in a third-party service; this is
  a scaffold, not a tax engine.
- **Stripe Checkout** — cart is sent as `price_data` line items (no
  pre-registered Stripe prices needed), shipping + tax appear as
  separate line items, and the order id round-trips via
  `metadata[order_id]` so the webhook reliably correlates.
- **Order lifecycle**: `pending → paid → shipped → delivered`, with
  side tracks to `cancelled` and `refunded`. Digital orders typically
  skip `shipped`/`delivered`. Order line items snapshot the variant
  name ("T-shirt (Red / M)") and SKU so order history renders cleanly
  even after products are edited or deleted.

### Admin

- **Admin surfaces** at `/admin/store/{products,shipping,tax,orders}`.
  The product editor is segmented: Basics, Inventory & fulfillment,
  Catalog metadata, SEO, Option axes, Spec sheet, Images, Variants.
- **Taxonomy integration** — use `attach_term('store_product', id, ...)`
  from the taxonomy module's helper to put products into categories.

## Routes

### Public

| Method | Path                                  | Purpose                          |
|--------|---------------------------------------|----------------------------------|
| GET    | `/shop`                               | Catalog grid                     |
| GET    | `/shop/product/{slug}`                | Product detail                   |
| GET    | `/cart`                               | Cart review                      |
| POST   | `/cart/add`                           | Add product to cart              |
| POST   | `/cart/items/{id}/update`             | Update qty                       |
| POST   | `/cart/items/{id}/remove`             | Remove item                      |
| GET    | `/checkout`                           | Address + email form             |
| POST   | `/checkout`                           | Create pending order + redirect  |
| GET    | `/checkout/success`                   | Post-Stripe landing              |
| GET    | `/checkout/cancel`                    | Restore cart from pending order  |
| GET    | `/orders`                             | Logged-in user's orders          |
| GET    | `/orders/{id}`                        | Order detail + downloads         |
| GET    | `/download/{token}`                   | Signed digital delivery          |
| POST   | `/webhooks/stripe/store`              | Stripe webhook (no auth/csrf)    |

### Admin (`Auth + RequireAdmin`, `store.manage` permission)

| Surface     | Routes                                                         |
|-------------|----------------------------------------------------------------|
| Products    | `/admin/store/products` + `/create`, `/{id}/edit`, `/delete`   |
| Shipping    | `/admin/store/shipping` + same CRUD suffixes                   |
| Tax         | `/admin/store/tax` + same CRUD suffixes                        |
| Orders      | `/admin/store/orders`, `/{id}`, `/{id}/status/{status}`        |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
