<?php
// modules/store/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$S = 'Modules\Store\Controllers\ShopController';
$A = 'Modules\Store\Controllers\StoreAdminController';
$W = 'Modules\Store\Controllers\StoreWebhookController';

// ── Public shop + cart + checkout ─────────────────────────────────────────
$router->get ('/shop',                   "$S@index");
$router->get ('/shop/product/{slug}',    "$S@product");

$router->get ('/cart',                          "$S@cart");
$router->post('/cart/add',                      "$S@addToCart",        [CsrfMiddleware::class]);
$router->post('/cart/items/{id}/update',        "$S@updateCartItem",   [CsrfMiddleware::class]);
$router->post('/cart/items/{id}/remove',        "$S@removeCartItem",   [CsrfMiddleware::class]);

$router->get ('/checkout',                      "$S@checkoutForm");
$router->post('/checkout',                      "$S@checkoutStart",    [CsrfMiddleware::class]);
$router->get ('/checkout/success',              "$S@successLanding");
$router->get ('/checkout/cancel',               "$S@cancelLanding");

$router->get ('/orders',                        "$S@myOrders",         [AuthMiddleware::class]);
$router->get ('/orders/{id}',                   "$S@orderDetail",      [AuthMiddleware::class]);

$router->get ('/download/{token}',              "$S@download",         [AuthMiddleware::class]);

// ── Stripe webhook (no auth, no CSRF — signature is the boundary) ────────
$router->post('/webhooks/stripe/store',         "$W@receive");

// ── Admin: products ───────────────────────────────────────────────────────
$admin = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];

$router->get ('/admin/store/products',                   "$A@productsIndex",  $admin);
$router->get ('/admin/store/products/create',            "$A@productCreate",  $admin);
$router->post('/admin/store/products/create',            "$A@productStore",   $adminCsrf);
$router->get ('/admin/store/products/{id}/edit',         "$A@productEdit",    $admin);
$router->post('/admin/store/products/{id}/edit',         "$A@productUpdate",  $adminCsrf);
$router->post('/admin/store/products/{id}/delete',       "$A@productDelete",  $adminCsrf);

// Product images
$router->post('/admin/store/products/{id}/images',                 "$A@productAddImage",     $adminCsrf);
$router->post('/admin/store/products/{id}/images/{imgId}/delete',  "$A@productDeleteImage",  $adminCsrf);

// Product variants
$router->post('/admin/store/products/{id}/variants',                   "$A@productAddVariant",    $adminCsrf);
$router->post('/admin/store/products/{id}/variants/{vid}/update',      "$A@productUpdateVariant", $adminCsrf);
$router->post('/admin/store/products/{id}/variants/{vid}/delete',      "$A@productDeleteVariant", $adminCsrf);

// ── Admin: shipping zones ────────────────────────────────────────────────
$router->get ('/admin/store/shipping',                   "$A@shippingIndex",  $admin);
$router->get ('/admin/store/shipping/create',            "$A@shippingCreate", $admin);
$router->post('/admin/store/shipping/create',            "$A@shippingStore",  $adminCsrf);
$router->get ('/admin/store/shipping/{id}/edit',         "$A@shippingEdit",   $admin);
$router->post('/admin/store/shipping/{id}/edit',         "$A@shippingUpdate", $adminCsrf);
$router->post('/admin/store/shipping/{id}/delete',       "$A@shippingDelete", $adminCsrf);

// ── Admin: tax rates ──────────────────────────────────────────────────────
$router->get ('/admin/store/tax',                        "$A@taxIndex",       $admin);
$router->get ('/admin/store/tax/create',                 "$A@taxCreate",      $admin);
$router->post('/admin/store/tax/create',                 "$A@taxStore",       $adminCsrf);
$router->get ('/admin/store/tax/{id}/edit',              "$A@taxEdit",        $admin);
$router->post('/admin/store/tax/{id}/edit',              "$A@taxUpdate",      $adminCsrf);
$router->post('/admin/store/tax/{id}/delete',            "$A@taxDelete",      $adminCsrf);

// ── Admin: orders ─────────────────────────────────────────────────────────
$router->get ('/admin/store/orders',                     "$A@ordersIndex",    $admin);
$router->get ('/admin/store/orders/{id}',                "$A@orderShow",      $admin);
$router->post('/admin/store/orders/{id}/status/{st}',    "$A@orderSetStatus", $adminCsrf);
