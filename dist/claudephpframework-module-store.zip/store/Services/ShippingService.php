<?php
// modules/store/Services/ShippingService.php
namespace Modules\Store\Services;

use Core\Database\Database;

/**
 * Flat-rate shipping by country list.
 *
 * Zones are picked in `sort_order` ASC, and the first zone whose
 * `countries` CSV contains the destination wins. Zones with an empty
 * `countries` field are catch-alls — typically used as a last-resort
 * "rest of world" row.
 *
 * `free_over_cents` waives the fee when the cart subtotal meets the
 * threshold. Threshold comparison is >= to avoid "99¢ short" edge cases.
 *
 * When no zone matches (e.g. a country we don't ship to and no catch-all),
 * returns 0 — the controller layer is responsible for blocking checkout
 * in that case; returning a silent 0 would let the order go through with
 * no shipping charged.
 */
class ShippingService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Shipping rate in cents for a destination country + subtotal.
     * Pass null country to force the catch-all (used before an address
     * is collected).
     */
    public function rateFor(?string $country, int $subtotalCents): int
    {
        $zone = $this->zoneFor($country);
        if (!$zone) return 0;

        $free = $zone['free_over_cents'];
        if ($free !== null && $subtotalCents >= (int) $free) return 0;
        return (int) $zone['flat_rate_cents'];
    }

    public function zoneFor(?string $country): ?array
    {
        $zones = $this->db->fetchAll(
            "SELECT * FROM store_shipping_zones WHERE active = 1 ORDER BY sort_order ASC, id ASC"
        );
        if (!$zones) return null;

        $cc = $country ? strtoupper(trim($country)) : '';

        // Match a specific-country row first.
        foreach ($zones as $z) {
            $codes = array_filter(array_map('trim', explode(',', strtoupper((string) $z['countries']))));
            if ($codes && in_array($cc, $codes, true)) return $z;
        }

        // Fallback: first zone with empty countries is the catch-all.
        foreach ($zones as $z) {
            $codes = array_filter(array_map('trim', explode(',', (string) $z['countries'])));
            if (empty($codes)) return $z;
        }

        return null;
    }

    /** @return array<int, array<string, mixed>> */
    public function allZones(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_shipping_zones ORDER BY sort_order ASC, id ASC"
        );
    }

    public function findZone(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM store_shipping_zones WHERE id = ?", [$id]);
    }

    public function createZone(array $data): int
    {
        return (int) $this->db->insert('store_shipping_zones', $this->prepare($data));
    }

    public function updateZone(int $id, array $data): void
    {
        $this->db->update('store_shipping_zones', $this->prepare($data), 'id = ?', [$id]);
    }

    public function deleteZone(int $id): void
    {
        $this->db->delete('store_shipping_zones', 'id = ?', [$id]);
    }

    private function prepare(array $data): array
    {
        $out = [];
        foreach (['name','countries','flat_rate_cents','free_over_cents','sort_order','active'] as $k) {
            if (array_key_exists($k, $data)) $out[$k] = $data[$k];
        }
        if (isset($out['countries'])) {
            $out['countries'] = strtoupper(preg_replace('~\s+~', '', (string) $out['countries']));
        }
        if (array_key_exists('free_over_cents', $out) && $out['free_over_cents'] === '') {
            $out['free_over_cents'] = null;
        }
        return $out;
    }
}
