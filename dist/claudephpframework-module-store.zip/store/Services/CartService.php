<?php
// modules/store/Services/CartService.php
namespace Modules\Store\Services;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Session;

/**
 * Cart persistence. Each visitor gets one cart: logged-in users have it
 * keyed on user_id; guests have it keyed on a stable session_id. When a
 * guest logs in, their cart is merged into whatever cart already exists
 * on the user (quantities sum; price snapshot is the newer row's price).
 *
 * Pricing uses a snapshot stored in store_cart_items.price_cents so that
 * catalog price changes mid-session don't rewrite the user's cart total
 * underneath them. The snapshot is refreshed when the product is
 * re-added; tweaking qty alone preserves the original price.
 */
class CartService
{
    private Database       $db;
    private ProductService $products;

    public function __construct()
    {
        $this->db       = Database::getInstance();
        $this->products = new ProductService();
    }

    /**
     * Return the current cart (creating if needed). A cart row is a
     * cheap INSERT; we create eagerly so downstream "get cart id" calls
     * never get a null.
     */
    public function current(): array
    {
        $auth = Auth::getInstance();
        if (!$auth->guest()) {
            $uid = (int) $auth->id();
            $row = $this->db->fetchOne("SELECT * FROM store_carts WHERE user_id = ? ORDER BY id DESC LIMIT 1", [$uid]);
            if ($row) return $row;
            $id = (int) $this->db->insert('store_carts', ['user_id' => $uid]);
            return ['id' => $id, 'user_id' => $uid, 'session_id' => null];
        }

        $sid = $this->guestSessionId();
        $row = $this->db->fetchOne("SELECT * FROM store_carts WHERE session_id = ? ORDER BY id DESC LIMIT 1", [$sid]);
        if ($row) return $row;
        $id = (int) $this->db->insert('store_carts', ['session_id' => $sid]);
        return ['id' => $id, 'user_id' => null, 'session_id' => $sid];
    }

    /**
     * Add a product (optionally a specific variant) to the cart, or bump
     * its qty if already present. Refreshes the price snapshot when
     * adding — if a user adds the same product+variant twice after a
     * price change, the current price wins.
     *
     * Variant rules:
     *   • If the product has any active variants, a $variantId is required
     *     (the public controller is responsible for surfacing the
     *     selector; this layer just validates).
     *   • If the product has no variants, $variantId must be null.
     *   • A variant must belong to the product passed.
     */
    public function add(int $productId, int $qty, ?int $variantId = null): bool
    {
        if ($qty < 1) $qty = 1;
        $product = $this->products->find($productId);
        if (!$product || (int) $product['active'] !== 1) return false;

        $variant = null;
        if ($variantId !== null) {
            $variant = $this->products->findVariant($variantId);
            if (!$variant || (int) $variant['product_id'] !== $productId) return false;
            if ((int) $variant['active'] !== 1) return false;
        }

        $effectivePrice = $this->products->effectivePrice($product, $variant);

        $cart     = $this->current();
        $existing = $this->db->fetchOne(
            "SELECT * FROM store_cart_items
              WHERE cart_id = ? AND product_id = ? AND (variant_id <=> ?)",
            [(int) $cart['id'], $productId, $variantId]
        );
        if ($existing) {
            $newQty = (int) $existing['qty'] + $qty;
            if (!$this->products->canPurchaseVariant($product, $variant, $newQty)) return false;
            $this->db->update('store_cart_items',
                ['qty' => $newQty, 'price_cents' => $effectivePrice],
                'id = ?', [(int) $existing['id']]
            );
            return true;
        }

        if (!$this->products->canPurchaseVariant($product, $variant, $qty)) return false;
        $this->db->insert('store_cart_items', [
            'cart_id'     => (int) $cart['id'],
            'product_id'  => $productId,
            'variant_id'  => $variantId,
            'qty'         => $qty,
            'price_cents' => $effectivePrice,
        ]);
        return true;
    }

    public function updateQty(int $cartItemId, int $qty): void
    {
        if ($qty < 1) { $this->remove($cartItemId); return; }

        $item = $this->db->fetchOne("SELECT * FROM store_cart_items WHERE id = ?", [$cartItemId]);
        if (!$item) return;
        $cart = $this->current();
        if ((int) $item['cart_id'] !== (int) $cart['id']) return; // not yours

        $product = $this->products->find((int) $item['product_id']);
        if (!$product || !$this->products->canPurchase($product, $qty)) return;

        $this->db->update('store_cart_items', ['qty' => $qty], 'id = ?', [$cartItemId]);
    }

    public function remove(int $cartItemId): void
    {
        $cart = $this->current();
        $this->db->delete('store_cart_items', 'id = ? AND cart_id = ?', [$cartItemId, (int) $cart['id']]);
    }

    public function clear(int $cartId): void
    {
        $this->db->delete('store_cart_items', 'cart_id = ?', [$cartId]);
    }

    /**
     * Join cart items + product + variant snapshot for display. Filters
     * out orphaned rows (product deleted mid-session) so the UI doesn't
     * render blank lines. The variant join is LEFT so cart items without
     * a variant (e.g. products with no option axes) still show up.
     *
     * Shape of each row extends product fields with:
     *   variant_option1/2/3_value — the selected option values
     *   variant_options_display    — pre-joined "Red / M" string for views
     *
     * @return array<int, array<string, mixed>>
     */
    public function items(int $cartId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT ci.*,
                    p.name, p.slug, p.type, p.image_url, p.tax_class, p.weight_grams,
                    p.stock_tracked AS product_stock_tracked, p.stock AS product_stock,
                    v.option1_value AS variant_option1_value,
                    v.option2_value AS variant_option2_value,
                    v.option3_value AS variant_option3_value,
                    v.image_url     AS variant_image_url,
                    v.sku           AS variant_sku
               FROM store_cart_items ci
               JOIN store_products p          ON p.id = ci.product_id
          LEFT JOIN store_product_variants v  ON v.id = ci.variant_id
              WHERE ci.cart_id = ?
           ORDER BY ci.created_at ASC",
            [$cartId]
        );

        foreach ($rows as &$r) {
            if ($r['variant_id']) {
                $r['variant_options_display'] = \Modules\Store\Services\ProductService::formatVariantOptions([
                    'option1_value' => $r['variant_option1_value'],
                    'option2_value' => $r['variant_option2_value'],
                    'option3_value' => $r['variant_option3_value'],
                ]);
            } else {
                $r['variant_options_display'] = null;
            }
            // Back-compat: keep a top-level stock_tracked/stock on the row
            // so older calls that read those fields still work.
            $r['stock_tracked'] = $r['product_stock_tracked'];
            $r['stock']         = $r['product_stock'];
        }
        unset($r);
        return $rows;
    }

    /**
     * Merge a guest cart into a user cart on login. Called from the login
     * controller (or a session-start hook) so shoppers don't lose their
     * cart when authenticating mid-checkout.
     *
     * Strategy: for each guest cart item, increment the matching product
     * line on the user cart, or insert if absent. Then delete the guest
     * cart row. Idempotent — a second call is a no-op.
     */
    public function mergeGuestCartToUser(string $sessionId, int $userId): void
    {
        $guest = $this->db->fetchOne("SELECT * FROM store_carts WHERE session_id = ?", [$sessionId]);
        if (!$guest) return;

        $user = $this->db->fetchOne("SELECT * FROM store_carts WHERE user_id = ?", [$userId]);
        if (!$user) {
            // Promote the guest row to a user row — simplest merge.
            $this->db->update('store_carts',
                ['user_id' => $userId, 'session_id' => null],
                'id = ?', [(int) $guest['id']]
            );
            return;
        }

        $guestItems = $this->items((int) $guest['id']);
        foreach ($guestItems as $gi) {
            $existing = $this->db->fetchOne(
                "SELECT * FROM store_cart_items WHERE cart_id = ? AND product_id = ?",
                [(int) $user['id'], (int) $gi['product_id']]
            );
            if ($existing) {
                $this->db->update('store_cart_items',
                    ['qty' => (int) $existing['qty'] + (int) $gi['qty']],
                    'id = ?', [(int) $existing['id']]
                );
            } else {
                $this->db->insert('store_cart_items', [
                    'cart_id'     => (int) $user['id'],
                    'product_id'  => (int) $gi['product_id'],
                    'qty'         => (int) $gi['qty'],
                    'price_cents' => (int) $gi['price_cents'],
                ]);
            }
        }
        $this->db->delete('store_carts', 'id = ?', [(int) $guest['id']]);
    }

    /**
     * Session id for guests. Tied to PHP's session so it survives
     * navigation within the same browser but rotates on logout.
     */
    private function guestSessionId(): string
    {
        Session::start();
        if (empty($_SESSION['store_guest_cart'])) {
            $_SESSION['store_guest_cart'] = bin2hex(random_bytes(16));
        }
        return (string) $_SESSION['store_guest_cart'];
    }

    /**
     * Totals snapshot for a given cart + optional shipping address.
     * Returns items + subtotal + shipping + tax + total and a flag for
     * whether the cart contains any physical goods (used to decide
     * whether the checkout form collects a shipping address).
     *
     * When a coupon code is passed (or stashed in the session by the
     * coupons module), and the coupons module is installed, the
     * returned totals include `coupon_code`, `coupon_id`, and
     * `discount_cents`. The `total_cents` already reflects the
     * discount. A failed-coupon application is silent here —
     * `coupon_error` is set on the returned array for the view to
     * surface.
     *
     * @return array{items: array<int, array<string, mixed>>, subtotal_cents: int, shipping_cents: int, tax_cents: int, total_cents: int, has_physical: bool, has_digital: bool, currency: string, discount_cents?: int, coupon_code?: string, coupon_id?: int, coupon_error?: string}
     */
    public function totals(
        int $cartId,
        ?string $country = null,
        ?string $region = null,
        ?string $couponCode = null
    ): array {
        $items = $this->items($cartId);
        $currency = 'USD';
        $subtotal = 0;
        $hasPhysical = false;
        $hasDigital  = false;
        foreach ($items as $it) {
            $line = (int) $it['price_cents'] * (int) $it['qty'];
            $subtotal += $line;
            if ($it['type'] === 'physical') $hasPhysical = true;
            if ($it['type'] === 'digital')  $hasDigital  = true;
        }

        $shipping = $hasPhysical ? (new ShippingService())->rateFor($country, $subtotal) : 0;
        $tax      = (new TaxService())->totalTax($items, $country, $region);
        $total    = $subtotal + $shipping + $tax;

        $out = [
            'items'          => $items,
            'subtotal_cents' => $subtotal,
            'shipping_cents' => $shipping,
            'tax_cents'      => $tax,
            'total_cents'    => $total,
            'has_physical'   => $hasPhysical,
            'has_digital'    => $hasDigital,
            'currency'       => $currency,
            'discount_cents' => 0,
        ];

        // Coupon integration — optional. Checked at each call so cart
        // totals reflect the active coupon on every page render. The
        // coupons module is an optional dependency; guarded by
        // class_exists so the store stays runnable without it.
        $code = $couponCode ?: self::sessionCouponCode();
        if ($code !== null && class_exists(\Modules\Coupons\Services\CouponService::class)) {
            $auth = \Core\Auth\Auth::getInstance();
            $uid  = $auth->guest() ? null : (int) $auth->id();
            $res  = (new \Modules\Coupons\Services\CouponService())->apply($code, $out, $uid);
            if ($res['ok']) {
                $out = $res['totals'];
            } else {
                $out['coupon_error'] = $res['error'];
            }
        }
        return $out;
    }

    /**
     * Read the coupons module's session key, if set. Null when no
     * coupon is active or the coupons module isn't installed.
     */
    private static function sessionCouponCode(): ?string
    {
        if (!class_exists(\Modules\Coupons\Controllers\CouponController::class)) return null;
        \Core\Session::start();
        $k = \Modules\Coupons\Controllers\CouponController::SESSION_KEY;
        return isset($_SESSION[$k]) && $_SESSION[$k] !== '' ? (string) $_SESSION[$k] : null;
    }
}
