<?php
// modules/store/Services/OrderService.php
namespace Modules\Store\Services;

use Core\Database\Database;

/**
 * Order reads + lifecycle transitions.
 *
 * An order is created in status=`pending` when the user redirects to
 * Stripe Checkout and promoted to `paid` by the webhook handler. Admins
 * then walk it through `shipped` → `delivered` (physical), and can
 * transition to `cancelled` or `refunded`. Digital-only orders may skip
 * straight from `paid` to `delivered` — the admin UI exposes every
 * transition and trusts the operator.
 *
 * State is deliberately stored on the order row (not an event log) —
 * there's no history here beyond the timestamps on `placed_at`,
 * `shipped_at`, `refunded_at`. If finer audit is needed later, a
 * `store_order_events` table drops in cleanly.
 */
class OrderService
{
    public const STATUSES = ['pending','paid','shipped','delivered','cancelled','refunded'];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Create a pending order + its items from a cart snapshot. Returns
     * the new order id. Called just before redirecting the user to
     * Stripe Checkout so the webhook has a row to correlate against.
     *
     * @param array $totals     from CartService::totals()
     * @param array $addresses  ['shipping' => [...], 'billing' => [...]]
     */
    public function createPendingFromCart(
        ?int $userId,
        string $email,
        array $totals,
        array $addresses,
        string $currency = 'USD'
    ): int {
        $orderData = [
            'user_id'                => $userId,
            'email'                  => $email,
            'status'                 => 'pending',
            'subtotal_cents'         => (int) $totals['subtotal_cents'],
            'shipping_cents'         => (int) $totals['shipping_cents'],
            'tax_cents'              => (int) $totals['tax_cents'],
            'total_cents'            => (int) $totals['total_cents'],
            'currency'               => $currency,
            'shipping_address_json'  => json_encode($addresses['shipping'] ?? null, JSON_UNESCAPED_SLASHES),
            'billing_address_json'   => json_encode($addresses['billing']  ?? null, JSON_UNESCAPED_SLASHES),
        ];
        // Coupon fields — only set when the coupons module applied one.
        // Lives on store_orders via the later migration (see
        // modules/store/migrations/2026_04_23_120000_add_coupon_fields_to_orders.php).
        if (!empty($totals['coupon_id'])) {
            $orderData['coupon_id']      = (int) $totals['coupon_id'];
            $orderData['coupon_code']    = (string) ($totals['coupon_code'] ?? '');
            $orderData['discount_cents'] = (int) ($totals['discount_cents'] ?? 0);
        }
        $orderId = (int) $this->db->insert('store_orders', $orderData);

        foreach ($totals['items'] as $it) {
            $qty        = (int) $it['qty'];
            $price      = (int) $it['price_cents'];
            $variantOpts = $it['variant_options_display'] ?? null;
            // Name snapshot includes variant options when present — "T-shirt (Red / M)"
            // — so order history renders unambiguously even after the product
            // or variant is later edited or deleted.
            $nameSnap   = (string) $it['name'];
            if ($variantOpts) $nameSnap .= ' (' . $variantOpts . ')';

            $this->db->insert('store_order_items', [
                'order_id'             => $orderId,
                'product_id'           => (int) $it['product_id'],
                'variant_id'           => !empty($it['variant_id']) ? (int) $it['variant_id'] : null,
                'name_snap'            => $nameSnap,
                'type_snap'            => (string) $it['type'],
                'sku_snap'             => $it['variant_sku'] ?? null,
                'variant_options_snap' => $variantOpts,
                'qty'                  => $qty,
                'price_cents'          => $price,
                'total_cents'          => $price * $qty,
            ]);
        }
        return $orderId;
    }

    public function attachStripeSession(int $orderId, string $sessionId): void
    {
        $this->db->update('store_orders',
            ['stripe_session_id' => substr($sessionId, 0, 191)],
            'id = ?', [$orderId]
        );
    }

    /**
     * Webhook-driven: mark an order paid. Idempotent — re-delivery of
     * the same event leaves the row untouched past the first promotion.
     * Also decrements stock (once) and issues download tokens for any
     * digital items.
     */
    public function markPaid(int $orderId, ?string $paymentIntentId = null): void
    {
        $order = $this->find($orderId);
        if (!$order) return;
        if ($order['status'] !== 'pending') return; // already processed

        $this->db->update('store_orders',
            [
                'status'                   => 'paid',
                'placed_at'                => date('Y-m-d H:i:s'),
                'stripe_payment_intent_id' => $paymentIntentId ? substr($paymentIntentId, 0, 191) : null,
            ],
            'id = ?', [$orderId]
        );

        // Stock + digital fulfillment — both one-time operations tied to
        // the pending→paid transition so webhook replays don't double-dip.
        // Variant-level stock wins when the item carries a variant_id;
        // otherwise fall back to product-level stock. This matches the
        // check at canPurchaseVariant time so reservations and decrements
        // target the same column.
        $products = new ProductService();
        foreach ($this->itemsFor($orderId) as $item) {
            if (!empty($item['variant_id'])) {
                $products->adjustVariantStock((int) $item['variant_id'], -(int) $item['qty']);
            } elseif ($item['product_id']) {
                $products->adjustStock((int) $item['product_id'], -(int) $item['qty']);
            }
            if ($item['type_snap'] === 'digital') {
                $this->issueDownloadToken((int) $item['id']);
            }
        }

        // Log coupon redemption — gated on the coupons module being
        // installed. Done at markPaid (not createPending) so a cancelled
        // checkout doesn't burn a redemption slot against a usage limit.
        if (!empty($order['coupon_id']) && class_exists(\Modules\Coupons\Services\CouponService::class)) {
            (new \Modules\Coupons\Services\CouponService())->recordRedemption(
                (int) $order['coupon_id'],
                $order['user_id'] ? (int) $order['user_id'] : null,
                $orderId,
                (int) ($order['discount_cents'] ?? 0)
            );
        }
    }

    public function transitionStatus(int $orderId, string $newStatus): bool
    {
        if (!in_array($newStatus, self::STATUSES, true)) return false;

        $order = $this->find($orderId);
        if (!$order) return false;

        $updates = ['status' => $newStatus];
        if ($newStatus === 'shipped'  && empty($order['shipped_at']))  $updates['shipped_at']  = date('Y-m-d H:i:s');
        if ($newStatus === 'refunded' && empty($order['refunded_at'])) $updates['refunded_at'] = date('Y-m-d H:i:s');

        $this->db->update('store_orders', $updates, 'id = ?', [$orderId]);
        return true;
    }

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM store_orders WHERE id = ?", [$id]);
    }

    public function findByStripeSession(string $sessionId): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM store_orders WHERE stripe_session_id = ?",
            [$sessionId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function itemsFor(int $orderId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_order_items WHERE order_id = ? ORDER BY id ASC",
            [$orderId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function forUser(int $userId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_orders WHERE user_id = ? ORDER BY created_at DESC",
            [$userId]
        );
    }

    /**
     * @return array{items: array<int, array<string, mixed>>, total: int}
     */
    public function listAll(?string $status = null, int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        if ($status && in_array($status, self::STATUSES, true)) {
            $where = "WHERE status = ?";
            $bind  = [$status];
        } else {
            $where = '';
            $bind  = [];
        }
        $items = $this->db->fetchAll(
            "SELECT * FROM store_orders $where ORDER BY created_at DESC LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM store_orders $where",
            $bind
        );
        return ['items' => $items, 'total' => $total];
    }

    /**
     * Issue a signed download token for a digital order_item. The token is
     * opaque; a 7-day expiry is long enough for a user to click "download"
     * from a confirmation email later in the week, short enough that a
     * leaked link doesn't float around forever.
     *
     * Idempotent per order_item — returns the existing unexpired token
     * if one exists.
     */
    public function issueDownloadToken(int $orderItemId, int $ttlDays = 7): string
    {
        $existing = $this->db->fetchOne(
            "SELECT token FROM store_download_tokens
              WHERE order_item_id = ? AND expires_at > NOW()
              ORDER BY id DESC LIMIT 1",
            [$orderItemId]
        );
        if ($existing) return (string) $existing['token'];

        $token   = bin2hex(random_bytes(24));
        $expires = date('Y-m-d H:i:s', time() + ($ttlDays * 86400));
        $this->db->insert('store_download_tokens', [
            'order_item_id' => $orderItemId,
            'token'         => $token,
            'expires_at'    => $expires,
        ]);
        return $token;
    }

    public function findDownloadToken(string $token): ?array
    {
        return $this->db->fetchOne(
            "SELECT dt.*, oi.order_id, oi.name_snap, oi.type_snap,
                    p.digital_file_path, p.name AS product_name
               FROM store_download_tokens dt
               JOIN store_order_items oi ON oi.id = dt.order_item_id
          LEFT JOIN store_products p      ON p.id = oi.product_id
              WHERE dt.token = ?",
            [$token]
        );
    }

    public function markTokenDownloaded(int $tokenId): void
    {
        $this->db->query(
            "UPDATE store_download_tokens
                SET downloaded_at = COALESCE(downloaded_at, NOW()),
                    download_count = download_count + 1
              WHERE id = ?",
            [$tokenId]
        );
    }
}
