<?php
// modules/store/Services/TaxService.php
namespace Modules\Store\Services;

use Core\Database\Database;

/**
 * Tax is deliberately simple: a flat percentage per (country, region,
 * tax_class). Good enough for the common case of a single jurisdiction
 * and a few tax classes (standard / reduced / zero). Apps with real
 * multi-jurisdiction tax obligations should plug in a third-party tax
 * service (TaxJar, Avalara) — this is a scaffold, not a tax engine.
 *
 * Lookup order per line item:
 *   1. (country, region, tax_class)  — most specific
 *   2. (country, NULL,   tax_class)  — country-wide fallback
 *   3. rate 0 (no tax)
 */
class TaxService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Total tax in cents for a cart at a destination. Computed line-by-line
     * because tax_class varies per product — a single "cart subtotal × rate"
     * would get it wrong when mixing standard-rate and zero-rate goods.
     *
     * @param array<int, array<string, mixed>> $items rows from CartService::items()
     */
    public function totalTax(array $items, ?string $country, ?string $region): int
    {
        if (!$country) return 0;

        $total = 0;
        foreach ($items as $it) {
            $bps = $this->rateBps($country, $region, (string) ($it['tax_class'] ?? 'standard'));
            if ($bps <= 0) continue;
            $line = (int) $it['price_cents'] * (int) $it['qty'];
            // Basis points: 10000 = 100%. Rounded half-up.
            $total += (int) round($line * $bps / 10000);
        }
        return $total;
    }

    public function rateBps(string $country, ?string $region, string $taxClass): int
    {
        $cc = strtoupper($country);
        $tc = $taxClass ?: 'standard';

        if ($region !== null && $region !== '') {
            $row = $this->db->fetchOne(
                "SELECT rate_bps FROM store_tax_rates
                  WHERE active = 1 AND country = ? AND region = ? AND tax_class = ?
                  LIMIT 1",
                [$cc, $region, $tc]
            );
            if ($row) return (int) $row['rate_bps'];
        }

        $row = $this->db->fetchOne(
            "SELECT rate_bps FROM store_tax_rates
              WHERE active = 1 AND country = ? AND region IS NULL AND tax_class = ?
              LIMIT 1",
            [$cc, $tc]
        );
        return $row ? (int) $row['rate_bps'] : 0;
    }

    /** @return array<int, array<string, mixed>> */
    public function all(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_tax_rates ORDER BY country ASC, region ASC, tax_class ASC"
        );
    }

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM store_tax_rates WHERE id = ?", [$id]);
    }

    public function create(array $data): int
    {
        return (int) $this->db->insert('store_tax_rates', $this->prepare($data));
    }

    public function update(int $id, array $data): void
    {
        $this->db->update('store_tax_rates', $this->prepare($data), 'id = ?', [$id]);
    }

    public function delete(int $id): void
    {
        $this->db->delete('store_tax_rates', 'id = ?', [$id]);
    }

    private function prepare(array $data): array
    {
        $out = [];
        foreach (['country','region','rate_bps','label','tax_class','active'] as $k) {
            if (array_key_exists($k, $data)) $out[$k] = $data[$k];
        }
        if (isset($out['country'])) $out['country'] = strtoupper(substr((string) $out['country'], 0, 2));
        if (array_key_exists('region', $out) && $out['region'] === '') $out['region'] = null;
        if (isset($out['tax_class']) && $out['tax_class'] === '') $out['tax_class'] = 'standard';
        return $out;
    }
}
