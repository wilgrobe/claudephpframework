<?php
// modules/store/Services/CheckoutService.php
namespace Modules\Store\Services;

use Core\Services\StripeService;

/**
 * Stripe Checkout session creation for one-off orders.
 *
 * Mirrors the subscriptions module's pattern: pre-create a local order
 * row (status=`pending`, see OrderService::createPendingFromCart), hand
 * Stripe a Checkout session that carries the order id in metadata, and
 * let the webhook promote the order to `paid` once the customer finishes
 * payment on Stripe's hosted page.
 *
 * Line items are built from the cart snapshot — each item becomes a
 * `price_data` line with `unit_amount` in cents. Shipping and tax are
 * added as separate flat-amount line items rather than leaning on
 * Stripe's own Tax product, which keeps tax logic in our hands and
 * avoids coupling to Stripe-specific tax geometry.
 */
class CheckoutService
{
    private StripeService $stripe;

    public function __construct()
    {
        $this->stripe = new StripeService();
    }

    public function isEnabled(): bool
    {
        return $this->stripe->isEnabled();
    }

    /**
     * Create a Stripe Checkout session for an order. Returns the hosted
     * URL or null on failure (caller should surface "payment unavailable"
     * rather than crashing the checkout page).
     *
     * @param array $totals from CartService::totals()
     */
    public function startCheckout(
        int    $orderId,
        string $email,
        array  $totals,
        string $successUrl,
        string $cancelUrl,
        string $currency = 'USD'
    ): ?string {
        if (!$this->isEnabled()) return null;

        $body = [
            'mode'                  => 'payment',
            'success_url'           => $successUrl,
            'cancel_url'            => $cancelUrl,
            'customer_email'        => $email,
            'client_reference_id'   => (string) $orderId,
        ];

        $i = 0;
        foreach ($totals['items'] as $it) {
            $body["line_items[$i][price_data][currency]"]                = strtolower($currency);
            $body["line_items[$i][price_data][unit_amount]"]             = (int) $it['price_cents'];
            $body["line_items[$i][price_data][product_data][name]"]      = substr((string) $it['name'], 0, 250);
            $body["line_items[$i][quantity]"]                            = (int) $it['qty'];
            $i++;
        }

        if ((int) $totals['shipping_cents'] > 0) {
            $body["line_items[$i][price_data][currency]"]           = strtolower($currency);
            $body["line_items[$i][price_data][unit_amount]"]        = (int) $totals['shipping_cents'];
            $body["line_items[$i][price_data][product_data][name]"] = 'Shipping';
            $body["line_items[$i][quantity]"]                       = 1;
            $i++;
        }
        if ((int) $totals['tax_cents'] > 0) {
            $body["line_items[$i][price_data][currency]"]           = strtolower($currency);
            $body["line_items[$i][price_data][unit_amount]"]        = (int) $totals['tax_cents'];
            $body["line_items[$i][price_data][product_data][name]"] = 'Tax';
            $body["line_items[$i][quantity]"]                       = 1;
            $i++;
        }

        // Coupon discount — Stripe Checkout won't accept a negative line
        // item so we use its native coupons: create a one-off Stripe coupon
        // with amount_off = our discount, then attach it via discounts[].
        // The local order already carries the discounted total; Stripe's
        // math arrives at the same number by subtracting the coupon from
        // the regular line items.
        $discount = (int) ($totals['discount_cents'] ?? 0);
        if ($discount > 0) {
            $couponRes = $this->stripe->call('POST', '/v1/coupons', [
                'amount_off' => $discount,
                'currency'   => strtolower($currency),
                'duration'   => 'once',
                'name'       => !empty($totals['coupon_code']) ? "Coupon {$totals['coupon_code']}" : 'Discount',
            ]);
            if (!empty($couponRes['id'])) {
                $body['discounts[0][coupon]'] = (string) $couponRes['id'];
            }
            // If Stripe coupon creation failed, we still want to let the
            // customer pay the undiscounted amount rather than hard-fail.
            // The local redemption log will capture the discrepancy.
        }

        // Stash the order id on the session and the resulting payment intent
        // so the webhook can route either event type back to our row.
        $body['metadata[order_id]']                       = (string) $orderId;
        $body['payment_intent_data[metadata][order_id]']  = (string) $orderId;

        $session = $this->stripe->call('POST', '/v1/checkout/sessions', $body);
        return $session['url'] ?? null;
    }

    /**
     * Route a Stripe webhook event to the order lifecycle. Only two event
     * types matter for one-off orders: checkout.session.completed (success)
     * and payment_intent.payment_failed (unpaid / expired session).
     */
    public function applyWebhookEvent(array $event, OrderService $orders): void
    {
        $type = (string) ($event['type'] ?? '');
        $obj  = $event['data']['object'] ?? [];
        if (!is_array($obj)) $obj = [];

        switch ($type) {
            case 'checkout.session.completed':
                $orderId = (int) ($obj['metadata']['order_id'] ?? $obj['client_reference_id'] ?? 0);
                if ($orderId > 0) {
                    $orders->markPaid(
                        $orderId,
                        (string) ($obj['payment_intent'] ?? '') ?: null
                    );
                }
                break;

            case 'payment_intent.payment_failed':
                $orderId = (int) ($obj['metadata']['order_id'] ?? 0);
                if ($orderId > 0) {
                    $order = $orders->find($orderId);
                    if ($order && $order['status'] === 'pending') {
                        $orders->transitionStatus($orderId, 'cancelled');
                    }
                }
                break;

            default:
                // Ignore — other event types don't affect one-off orders.
                break;
        }
    }
}
