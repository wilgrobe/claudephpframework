<?php
// modules/store/Services/ProductService.php
namespace Modules\Store\Services;

use Core\Database\Database;

/**
 * Product catalog reads + writes. Keeps the controller thin — anything
 * that touches `store_products` goes through here so product lookups by
 * id or slug have one canonical implementation.
 */
class ProductService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /** @return array<int, array<string, mixed>> */
    public function active(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_products WHERE active = 1 ORDER BY name ASC"
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function all(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_products ORDER BY created_at DESC"
        );
    }

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM store_products WHERE id = ?", [$id]);
    }

    public function findBySlug(string $slug): ?array
    {
        return $this->db->fetchOne("SELECT * FROM store_products WHERE slug = ?", [$slug]);
    }

    /**
     * Adjust stock by $delta (positive or negative). No-op for products
     * with stock_tracked=0. Used by the checkout flow to reserve inventory.
     */
    public function adjustStock(int $productId, int $delta): bool
    {
        $p = $this->find($productId);
        if (!$p) return false;
        if ((int) $p['stock_tracked'] !== 1) return true;

        $new = (int) $p['stock'] + $delta;
        if ($new < 0) return false;

        $this->db->update('store_products', ['stock' => $new], 'id = ?', [$productId]);
        return true;
    }

    /**
     * True when the product can be purchased in the given quantity.
     * Digital goods and untracked-stock physical goods always return true.
     */
    public function canPurchase(array $product, int $qty): bool
    {
        if ((int) $product['active'] !== 1) return false;
        if ((int) $product['stock_tracked'] !== 1) return true;
        return (int) $product['stock'] >= $qty;
    }

    public function create(array $data): int
    {
        return (int) $this->db->insert('store_products', $this->prepare($data));
    }

    public function update(int $id, array $data): bool
    {
        return $this->db->update('store_products', $this->prepare($data), 'id = ?', [$id]) > 0;
    }

    public function delete(int $id): void
    {
        $this->db->delete('store_products', 'id = ?', [$id]);
    }

    private function prepare(array $data): array
    {
        $out = [];
        foreach ([
            'name','slug','description','short_description',
            'meta_title','meta_description','canonical_url',
            'brand','barcode','product_type',
            'option1_name','option2_name','option3_name',
            'type','price_cents','currency','sku',
            'stock_tracked','stock','weight_grams','tax_class','digital_file_path',
            'image_url','active',
        ] as $k) {
            if (array_key_exists($k, $data)) $out[$k] = $data[$k];
        }
        if (isset($out['slug']))     $out['slug']     = self::slugify((string) $out['slug']);
        if (isset($out['currency'])) $out['currency'] = strtoupper(substr((string) $out['currency'], 0, 8));
        if (isset($out['type']) && !in_array($out['type'], ['physical','digital'], true)) {
            $out['type'] = 'physical';
        }
        // Blank strings on the nullable rich fields become NULL so empty
        // form submits clear rather than replace with empty-string
        // (which would break IS NULL checks elsewhere).
        foreach (['short_description','meta_title','meta_description','canonical_url',
                 'brand','barcode','product_type','option1_name','option2_name','option3_name'] as $k) {
            if (array_key_exists($k, $out) && $out[$k] === '') $out[$k] = null;
        }
        return $out;
    }

    public static function slugify(string $s): string
    {
        $s = strtolower(trim($s));
        $s = preg_replace('~[^a-z0-9]+~', '-', $s) ?? '';
        return trim($s, '-');
    }

    // ── Variants ──────────────────────────────────────────────────────────

    /** @return array<int, array<string, mixed>> */
    public function variantsFor(int $productId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_product_variants
              WHERE product_id = ?
           ORDER BY sort_order ASC, id ASC",
            [$productId]
        );
    }

    public function findVariant(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM store_product_variants WHERE id = ?", [$id]);
    }

    public function findVariantByOptions(int $productId, ?string $v1, ?string $v2, ?string $v3): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM store_product_variants
              WHERE product_id = ?
                AND (option1_value <=> ?)
                AND (option2_value <=> ?)
                AND (option3_value <=> ?)",
            [$productId, $v1, $v2, $v3]
        );
    }

    /**
     * Effective price for a cart/order line: variant price overrides
     * product price when set. Units are cents. Used at add-to-cart time
     * to snapshot the price.
     */
    public function effectivePrice(array $product, ?array $variant): int
    {
        if ($variant && $variant['price_cents'] !== null) return (int) $variant['price_cents'];
        return (int) $product['price_cents'];
    }

    public function effectiveWeight(array $product, ?array $variant): int
    {
        if ($variant && $variant['weight_grams'] !== null) return (int) $variant['weight_grams'];
        return (int) $product['weight_grams'];
    }

    /**
     * Whether the product+variant combo can be purchased in the given qty.
     * Variant stock beats product stock when the variant tracks its own.
     */
    public function canPurchaseVariant(array $product, ?array $variant, int $qty): bool
    {
        if ((int) $product['active'] !== 1) return false;

        if ($variant) {
            if ((int) $variant['active'] !== 1) return false;
            if ((int) $variant['stock_tracked'] === 1) {
                return (int) $variant['stock'] >= $qty;
            }
        }
        if ((int) $product['stock_tracked'] === 1) {
            return (int) $product['stock'] >= $qty;
        }
        return true;
    }

    /**
     * Decrement stock for a specific variant. Prefers the variant's own
     * stock_tracked flag; falls back to product-level tracking.
     */
    public function adjustVariantStock(int $variantId, int $delta): bool
    {
        $variant = $this->findVariant($variantId);
        if (!$variant) return false;
        if ((int) $variant['stock_tracked'] === 1) {
            $new = (int) $variant['stock'] + $delta;
            if ($new < 0) return false;
            $this->db->update('store_product_variants', ['stock' => $new], 'id = ?', [$variantId]);
            return true;
        }
        // Fall through to the product-level stock.
        return $this->adjustStock((int) $variant['product_id'], $delta);
    }

    public function createVariant(int $productId, array $data): int
    {
        return (int) $this->db->insert('store_product_variants',
            $this->prepareVariant(['product_id' => $productId] + $data));
    }

    public function updateVariant(int $id, array $data): void
    {
        $this->db->update('store_product_variants', $this->prepareVariant($data), 'id = ?', [$id]);
    }

    public function deleteVariant(int $id): void
    {
        $this->db->delete('store_product_variants', 'id = ?', [$id]);
    }

    private function prepareVariant(array $data): array
    {
        $out = [];
        foreach ([
            'product_id','sku','price_cents','weight_grams',
            'stock_tracked','stock','option1_value','option2_value','option3_value',
            'image_url','sort_order','active',
        ] as $k) {
            if (array_key_exists($k, $data)) $out[$k] = $data[$k];
        }
        foreach (['sku','option1_value','option2_value','option3_value','image_url'] as $k) {
            if (array_key_exists($k, $out) && $out[$k] === '') $out[$k] = null;
        }
        foreach (['price_cents','weight_grams'] as $k) {
            if (array_key_exists($k, $out) && ($out[$k] === '' || $out[$k] === null)) {
                $out[$k] = null;
            }
        }
        return $out;
    }

    /**
     * Concatenate non-empty option values for display. Used to snapshot
     * "Red / Medium" onto order line items.
     */
    public static function formatVariantOptions(?array $variant): ?string
    {
        if (!$variant) return null;
        $parts = array_filter([
            $variant['option1_value'] ?? null,
            $variant['option2_value'] ?? null,
            $variant['option3_value'] ?? null,
        ], static fn($v) => $v !== null && $v !== '');
        return $parts ? implode(' / ', $parts) : null;
    }

    // ── Images ────────────────────────────────────────────────────────────

    /** @return array<int, array<string, mixed>> */
    public function imagesFor(int $productId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_product_images WHERE product_id = ? ORDER BY sort_order ASC, id ASC",
            [$productId]
        );
    }

    /**
     * The URL to show in listings. First image in the gallery wins; if
     * the gallery is empty, fall back to the legacy image_url column.
     */
    public function primaryImageUrl(array $product): ?string
    {
        $first = $this->db->fetchOne(
            "SELECT url FROM store_product_images WHERE product_id = ? ORDER BY sort_order ASC, id ASC LIMIT 1",
            [(int) $product['id']]
        );
        if ($first) return (string) $first['url'];
        return !empty($product['image_url']) ? (string) $product['image_url'] : null;
    }

    public function addImage(int $productId, string $url, ?string $alt = null, int $sortOrder = 0): int
    {
        return (int) $this->db->insert('store_product_images', [
            'product_id' => $productId,
            'url'        => $url,
            'alt'        => $alt,
            'sort_order' => $sortOrder,
        ]);
    }

    public function deleteImage(int $imageId): void
    {
        $this->db->delete('store_product_images', 'id = ?', [$imageId]);
    }

    // ── Specs ─────────────────────────────────────────────────────────────

    /** @return array<int, array<string, mixed>> */
    public function specsFor(int $productId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM store_product_specs WHERE product_id = ? ORDER BY sort_order ASC, id ASC",
            [$productId]
        );
    }

    /**
     * Bulk replace specs for a product. Admin form submits a whole list
     * each save; simplest is to wipe and re-insert. O(n) rows in a
     * product's spec list, not enough to matter in practice.
     *
     * @param array<int, array{label: string, value: string}> $specs
     */
    public function setSpecs(int $productId, array $specs): void
    {
        $this->db->delete('store_product_specs', 'product_id = ?', [$productId]);
        $i = 1;
        foreach ($specs as $s) {
            $label = trim((string) ($s['label'] ?? ''));
            $value = trim((string) ($s['value'] ?? ''));
            if ($label === '' || $value === '') continue;
            $this->db->insert('store_product_specs', [
                'product_id' => $productId,
                'label'      => $label,
                'value'      => $value,
                'sort_order' => $i++,
            ]);
        }
    }
}
