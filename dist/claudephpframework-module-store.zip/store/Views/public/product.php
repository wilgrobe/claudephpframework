<?php
// modules/store/Views/public/product.php
// Expects: $product (row from store_products), optionally $images, $variants, $specs.
//
// If the caller (ShopController::product) didn't pre-load the sub-resources,
// load them here so the template works both from the rich path and from
// simpler callers.
use Modules\Store\Services\ProductService;
if (!isset($images) || !isset($variants) || !isset($specs)) {
    $svc = new ProductService();
    $images   = $images   ?? $svc->imagesFor((int) $product['id']);
    $variants = $variants ?? $svc->variantsFor((int) $product['id']);
    $specs    = $specs    ?? $svc->specsFor((int) $product['id']);
}

$pageTitle = !empty($product['meta_title']) ? (string) $product['meta_title'] : (string) $product['name'];
$metaDesc  = !empty($product['meta_description']) ? (string) $product['meta_description'] : '';
$canonical = !empty($product['canonical_url']) ? (string) $product['canonical_url'] : '';
$activeVariants = array_values(array_filter($variants, static fn($v) => (int) $v['active'] === 1));
$priceRange = null;
if ($activeVariants) {
    $prices = array_map(static fn($v) => $v['price_cents'] !== null ? (int) $v['price_cents'] : (int) $product['price_cents'], $activeVariants);
    $priceRange = ['min' => min($prices), 'max' => max($prices)];
}
$primaryImage = !empty($images) ? (string) $images[0]['url'] : (string) ($product['image_url'] ?? '');
?>
<?php
// Stash SEO into the head via the layout's $pageMetaTags hook if present;
// otherwise a plain include will still emit the title from $pageTitle.
$pageMetaDescription = $metaDesc ?: null;
$pageCanonical       = $canonical ?: null;
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<?php if ($metaDesc || $canonical): ?>
<!-- SEO tags (append-only; layout may already emit a description). -->
<?php if ($metaDesc): ?><meta name="description" content="<?= e($metaDesc) ?>"><?php endif; ?>
<?php if ($canonical): ?><link rel="canonical" href="<?= e($canonical) ?>"><?php endif; ?>
<?php endif; ?>

<div style="max-width:960px;margin:0 auto">
<a href="/shop" style="color:#6b7280;font-size:13px;text-decoration:none">← Back to shop</a>

<div class="card" style="margin-top:.75rem">
<div style="display:grid;gap:1.5rem;grid-template-columns:1fr 1fr">
    <!-- Gallery -->
    <div>
        <?php if ($primaryImage): ?>
        <img id="primary-image" src="<?= e($primaryImage) ?>" alt="<?= e($product['name']) ?>" style="width:100%;border-radius:4px;object-fit:cover;max-height:420px">
        <?php endif; ?>
        <?php if (count($images) > 1): ?>
        <div style="display:flex;gap:.5rem;flex-wrap:wrap;margin-top:.5rem">
            <?php foreach ($images as $img): ?>
            <a href="<?= e($img['url']) ?>" onclick="document.getElementById('primary-image').src=this.href;return false;">
                <img src="<?= e($img['url']) ?>" alt="<?= e((string) ($img['alt'] ?? '')) ?>" style="width:60px;height:60px;object-fit:cover;border-radius:4px;cursor:pointer;border:1px solid #e5e7eb">
            </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>

    <!-- Info + purchase -->
    <div style="padding:1rem 0">
        <?php if (!empty($product['brand'])): ?>
        <div style="color:#9ca3af;font-size:12px;text-transform:uppercase;letter-spacing:.5px"><?= e($product['brand']) ?></div>
        <?php endif; ?>
        <h1 style="margin:.25rem 0"><?= e($product['name']) ?></h1>
        <div style="color:#6b7280;font-size:12px;text-transform:uppercase;letter-spacing:.5px">
            <?= e($product['type']) ?>
            <?php if (!empty($product['product_type'])): ?> · <?= e($product['product_type']) ?><?php endif; ?>
        </div>

        <?php if ($priceRange && $priceRange['min'] !== $priceRange['max']): ?>
        <div style="font-size:1.5rem;font-weight:600;margin:.75rem 0">
            <?= e($product['currency']) ?> <?= number_format($priceRange['min'] / 100, 2) ?>
            <span style="color:#9ca3af;font-size:.8em">–</span>
            <?= number_format($priceRange['max'] / 100, 2) ?>
        </div>
        <?php else: ?>
        <div style="font-size:1.5rem;font-weight:600;margin:.75rem 0">
            <?= e($product['currency']) ?> <?= number_format((int) $product['price_cents'] / 100, 2) ?>
        </div>
        <?php endif; ?>

        <?php if (!empty($product['short_description'])): ?>
        <p style="color:#4b5563;font-size:14px"><?= nl2br(e((string) $product['short_description'])) ?></p>
        <?php endif; ?>

        <form method="post" action="/cart/add" style="margin-top:1rem">
            <?= csrf_field() ?>
            <input type="hidden" name="product_id" value="<?= (int) $product['id'] ?>">

            <?php if (!empty($activeVariants)): ?>
            <label style="display:block;font-size:13px;color:#6b7280">Options
                <select name="variant_id" required style="width:100%;padding:.5rem;border:1px solid #d1d5db;border-radius:4px">
                    <option value="">— choose —</option>
                    <?php foreach ($activeVariants as $v): ?>
                    <?php
                    $label = ProductService::formatVariantOptions($v) ?? ('Variant #' . (int) $v['id']);
                    $price = $v['price_cents'] !== null ? (int) $v['price_cents'] : (int) $product['price_cents'];
                    $outOfStock = (int) $v['stock_tracked'] === 1 && (int) $v['stock'] <= 0;
                    ?>
                    <option value="<?= (int) $v['id'] ?>" <?= $outOfStock ? 'disabled' : '' ?>>
                        <?= e($label) ?> — <?= e($product['currency']) ?> <?= number_format($price / 100, 2) ?>
                        <?= $outOfStock ? '(sold out)' : '' ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </label>
            <?php endif; ?>

            <div style="display:flex;gap:.5rem;align-items:flex-end;margin-top:.75rem">
                <label style="display:flex;flex-direction:column;font-size:13px;color:#6b7280">
                    Quantity
                    <input type="number" name="qty" value="1" min="1" style="width:80px">
                </label>
                <button type="submit" class="btn btn-primary" style="margin-left:auto">Add to cart</button>
            </div>
        </form>
    </div>
</div>

<!-- Full description -->
<?php if (!empty($product['description'])): ?>
<div class="card-body" style="border-top:1px solid #e5e7eb">
    <h3>Description</h3>
    <div style="color:#374151;line-height:1.6"><?= nl2br(e((string) $product['description'])) ?></div>
</div>
<?php endif; ?>

<!-- Specs table -->
<?php if (!empty($specs)): ?>
<div class="card-body" style="border-top:1px solid #e5e7eb">
    <h3>Specifications</h3>
    <table class="table">
        <tbody>
        <?php foreach ($specs as $s): ?>
        <tr>
            <th style="width:30%;text-align:left;color:#6b7280;font-weight:600"><?= e($s['label']) ?></th>
            <td><?= e($s['value']) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<!-- Barcode footer -->
<?php if (!empty($product['barcode'])): ?>
<div style="padding:.5rem 1.25rem;color:#9ca3af;font-size:11px;border-top:1px solid #e5e7eb">
    <?= e($product['barcode']) ?>
</div>
<?php endif; ?>
</div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
