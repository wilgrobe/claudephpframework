<?php $pageTitle = 'Order complete'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:640px;margin:2rem auto;text-align:center">
    <h1>Thank you!</h1>
    <?php if ($order): ?>
        <p style="color:#6b7280">Order #<?= (int) $order['id'] ?> is being processed. A confirmation will arrive at <strong><?= e($order['email']) ?></strong>.</p>
        <?php if ($order['status'] === 'paid'): ?>
            <a href="/orders/<?= (int) $order['id'] ?>" class="btn btn-primary">View your order →</a>
        <?php else: ?>
            <p style="color:#9ca3af;font-size:13px">Payment confirmation may take a moment. Refresh your order page in a minute.</p>
            <?php if (!empty($order['user_id'])): ?>
            <a href="/orders" class="btn btn-secondary">Go to your orders</a>
            <?php endif; ?>
        <?php endif; ?>
    <?php else: ?>
        <p style="color:#6b7280">Your payment was accepted.</p>
        <a href="/shop" class="btn btn-secondary">Keep shopping</a>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
