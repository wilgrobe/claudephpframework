<?php $pageTitle = 'Shop'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <h1 style="margin:0;font-size:1.5rem">Shop</h1>
    <a href="/cart" class="btn btn-sm btn-secondary" style="margin-left:auto">Cart</a>
</div>

<?php if (empty($products)): ?>
<div class="card"><div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
    No products available yet. Check back soon.
</div></div>
<?php else: ?>
<div style="display:grid;gap:1rem;grid-template-columns:repeat(auto-fit, minmax(260px, 1fr))">
    <?php foreach ($products as $p): ?>
    <a href="/shop/product/<?= e($p['slug']) ?>" class="card" style="text-decoration:none;color:inherit;padding:1rem;display:block">
        <?php if (!empty($p['image_url'])): ?>
        <img src="<?= e($p['image_url']) ?>" alt="<?= e($p['name']) ?>" style="width:100%;height:160px;object-fit:cover;border-radius:4px;margin-bottom:.75rem">
        <?php endif; ?>
        <h3 style="margin:0 0 .25rem 0;font-size:1.1rem"><?= e($p['name']) ?></h3>
        <div style="color:#6b7280;font-size:12px;text-transform:uppercase;letter-spacing:.5px">
            <?= e($p['type']) ?><?php if ($p['type'] === 'physical' && (int) $p['stock_tracked'] === 1): ?>
              · <?= ((int) $p['stock'] > 0) ? ((int) $p['stock']) . ' in stock' : 'sold out' ?>
            <?php endif; ?>
        </div>
        <div style="font-size:1.25rem;font-weight:600;margin-top:.5rem">
            <?= e($p['currency']) ?> <?= number_format((int) $p['price_cents'] / 100, 2) ?>
        </div>
    </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
