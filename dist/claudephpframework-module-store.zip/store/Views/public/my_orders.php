<?php $pageTitle = 'Your orders'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Your orders</h1>

<?php if (empty($orders)): ?>
<div class="card"><div class="card-body" style="color:#6b7280;text-align:center;padding:3rem 1rem">
    You haven't placed any orders yet. <a href="/shop">Browse the shop →</a>
</div></div>
<?php else: ?>
<div class="card">
    <table class="table">
        <thead><tr><th>#</th><th>Date</th><th>Status</th><th>Total</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($orders as $o): ?>
        <tr>
            <td>#<?= (int) $o['id'] ?></td>
            <td style="font-size:13px"><?= e(date('M j, Y', strtotime((string) $o['created_at']))) ?></td>
            <td>
                <?php $cls = match($o['status']) {
                    'paid'=>'badge-success','shipped'=>'badge-info','delivered'=>'badge-success',
                    'cancelled'=>'badge-gray','refunded'=>'badge-warning',default=>'badge-gray'}; ?>
                <span class="badge <?= $cls ?>"><?= e(ucfirst((string) $o['status'])) ?></span>
            </td>
            <td><?= e((string) $o['currency']) ?> <?= number_format((int) $o['total_cents'] / 100, 2) ?></td>
            <td><a href="/orders/<?= (int) $o['id'] ?>" class="btn btn-sm btn-secondary">View</a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
