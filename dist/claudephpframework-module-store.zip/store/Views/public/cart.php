<?php $pageTitle = 'Your cart'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Your cart</h1>

<?php if (empty($totals['items'])): ?>
<div class="card"><div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
    Your cart is empty. <a href="/shop">Browse the shop →</a>
</div></div>
<?php else: ?>
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Item</th><th>Price</th><th>Qty</th><th>Total</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($totals['items'] as $it): ?>
            <tr>
                <td>
                    <a href="/shop/product/<?= e($it['slug']) ?>" style="color:inherit;text-decoration:none"><strong><?= e($it['name']) ?></strong></a>
                    <?php if (!empty($it['variant_options_display'])): ?>
                    <div style="color:#6b7280;font-size:12px"><?= e($it['variant_options_display']) ?></div>
                    <?php endif; ?>
                    <div style="color:#9ca3af;font-size:11px;text-transform:uppercase"><?= e($it['type']) ?></div>
                </td>
                <td><?= number_format((int) $it['price_cents'] / 100, 2) ?></td>
                <td>
                    <form method="post" action="/cart/items/<?= (int) $it['id'] ?>/update" style="display:flex;gap:.25rem">
                        <?= csrf_field() ?>
                        <input type="number" name="qty" value="<?= (int) $it['qty'] ?>" min="0" style="width:70px">
                        <button type="submit" class="btn btn-sm btn-secondary">Update</button>
                    </form>
                </td>
                <td>
                    <?= number_format((int) $it['price_cents'] * (int) $it['qty'] / 100, 2) ?>
                </td>
                <td>
                    <form method="post" action="/cart/items/<?= (int) $it['id'] ?>/remove">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-danger">Remove</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr><td colspan="3" style="text-align:right;color:#6b7280">Subtotal</td><td><?= number_format($totals['subtotal_cents'] / 100, 2) ?></td><td></td></tr>
                <?php if (!empty($totals['discount_cents']) && (int) $totals['discount_cents'] > 0): ?>
                <tr>
                    <td colspan="3" style="text-align:right;color:#16a34a">Discount (<?= e((string) ($totals['coupon_code'] ?? '')) ?>)</td>
                    <td style="color:#16a34a">−<?= number_format((int) $totals['discount_cents'] / 100, 2) ?></td>
                    <td>
                        <form method="post" action="/coupon/remove" style="display:inline">
                            <?= csrf_field() ?>
                            <input type="hidden" name="return_url" value="/cart">
                            <button type="submit" class="btn btn-sm btn-secondary">Remove</button>
                        </form>
                    </td>
                </tr>
                <?php endif; ?>
                <?php if ($totals['has_physical']): ?>
                <tr><td colspan="3" style="text-align:right;color:#6b7280">Shipping <span style="font-size:11px">(estimated at checkout)</span></td><td>—</td><td></td></tr>
                <?php endif; ?>
                <tr><td colspan="3" style="text-align:right;color:#6b7280">Tax</td><td>calculated at checkout</td><td></td></tr>
            </tfoot>
        </table>
    </div>

    <?php // Coupon code input — only when the coupons module is installed. ?>
    <?php if (class_exists(\Modules\Coupons\Controllers\CouponController::class)): ?>
    <div class="card-body" style="border-top:1px solid #e5e7eb;background:#f9fafb">
        <?php if (!empty($totals['coupon_error'])): ?>
        <div style="color:#b91c1c;font-size:13px;margin-bottom:.5rem"><?= e((string) $totals['coupon_error']) ?></div>
        <?php endif; ?>
        <?php if (empty($totals['coupon_code'])): ?>
        <form method="post" action="/coupon/apply" style="display:flex;gap:.5rem;align-items:flex-end;max-width:420px">
            <?= csrf_field() ?>
            <input type="hidden" name="return_url" value="/cart">
            <label style="flex:1;font-size:13px;color:#6b7280">Coupon code
                <input name="code" style="width:100%;padding:.4rem;text-transform:uppercase" placeholder="SAVE10">
            </label>
            <button type="submit" class="btn btn-secondary">Apply</button>
        </form>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="card-body" style="text-align:right">
        <a href="/checkout" class="btn btn-primary">Proceed to checkout</a>
    </div>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
