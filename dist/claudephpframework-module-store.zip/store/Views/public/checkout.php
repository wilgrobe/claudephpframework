<?php $pageTitle = 'Checkout'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:720px;margin:0 auto">
<h1 style="margin:0 0 1rem 0">Checkout</h1>

<?php if (!$enabled): ?>
<div class="alert alert-error">Payments aren't configured. Set STRIPE_SECRET_KEY in the environment.</div>
<?php else: ?>

<form method="post" action="/checkout">
    <?= csrf_field() ?>

    <div class="card">
        <div class="card-body">
            <h3 style="margin-top:0">Contact</h3>
            <label style="display:block;font-size:13px;color:#6b7280">Email
                <input type="email" name="email" required value="<?= e($user['email'] ?? '') ?>" style="width:100%;padding:.5rem;border:1px solid #d1d5db;border-radius:4px">
            </label>
        </div>
    </div>

    <?php if ($totals['has_physical']): ?>
    <div class="card" style="margin-top:1rem">
        <div class="card-body">
            <h3 style="margin-top:0">Shipping address</h3>
            <label>Name <input name="shipping_name" required style="width:100%"></label>
            <label style="margin-top:.5rem;display:block">Address line 1 <input name="shipping_line1" required style="width:100%"></label>
            <label style="margin-top:.5rem;display:block">Address line 2 <input name="shipping_line2" style="width:100%"></label>
            <div style="display:grid;gap:.5rem;grid-template-columns:2fr 1fr 1fr;margin-top:.5rem">
                <label>City <input name="shipping_city" required style="width:100%"></label>
                <label>Region <input name="region" style="width:100%"></label>
                <label>Postal <input name="shipping_postal" required style="width:100%"></label>
            </div>
            <label style="margin-top:.5rem;display:block">Country (ISO-2, e.g. US)
                <input name="country" required maxlength="2" style="width:100%;text-transform:uppercase">
            </label>
            <p style="font-size:12px;color:#6b7280;margin-top:.5rem">
                Shipping and tax are computed after you submit this address and shown on the Stripe page before payment.
            </p>
        </div>
    </div>
    <?php endif; ?>

    <div class="card" style="margin-top:1rem">
        <div class="card-body">
            <h3 style="margin-top:0">Summary</h3>
            <?php foreach ($totals['items'] as $it): ?>
            <div style="display:flex;justify-content:space-between;padding:.25rem 0;border-bottom:1px solid #f3f4f6">
                <span><?= e($it['name']) ?> × <?= (int) $it['qty'] ?></span>
                <span><?= number_format((int) $it['price_cents'] * (int) $it['qty'] / 100, 2) ?></span>
            </div>
            <?php endforeach; ?>
            <div style="display:flex;justify-content:space-between;margin-top:.5rem;font-weight:600">
                <span>Subtotal</span>
                <span><?= e($totals['currency']) ?> <?= number_format($totals['subtotal_cents'] / 100, 2) ?></span>
            </div>
        </div>
    </div>

    <div style="margin-top:1rem;text-align:right">
        <a href="/cart" class="btn btn-secondary">Back to cart</a>
        <button type="submit" class="btn btn-primary">Continue to payment →</button>
    </div>
</form>

<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
