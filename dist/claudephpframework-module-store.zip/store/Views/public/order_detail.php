<?php $pageTitle = 'Order #' . (int) $order['id']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:760px;margin:0 auto">
<a href="/orders" style="color:#6b7280;font-size:13px;text-decoration:none">← All orders</a>

<div class="card" style="margin-top:.75rem">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Order #<?= (int) $order['id'] ?></h2>
        <span class="badge badge-info"><?= e(ucfirst((string) $order['status'])) ?></span>
    </div>
    <div class="card-body">
        <div style="color:#6b7280;font-size:13px;margin-bottom:1rem">
            Placed <?= e(date('M j, Y H:i', strtotime((string) $order['created_at']))) ?> · <?= e($order['email']) ?>
        </div>

        <table class="table">
            <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Line total</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
            <tr>
                <td>
                    <?= e($it['name_snap']) ?>
                    <div style="color:#9ca3af;font-size:11px;text-transform:uppercase"><?= e($it['type_snap']) ?></div>
                    <?php if (!empty($it['download_token'])): ?>
                    <a href="/download/<?= e($it['download_token']) ?>" class="btn btn-sm btn-primary" style="margin-top:.25rem">Download</a>
                    <?php endif; ?>
                </td>
                <td><?= (int) $it['qty'] ?></td>
                <td><?= number_format((int) $it['price_cents'] / 100, 2) ?></td>
                <td><?= number_format((int) $it['total_cents'] / 100, 2) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr><td colspan="3" style="text-align:right">Subtotal</td><td><?= number_format($order['subtotal_cents'] / 100, 2) ?></td></tr>
                <tr><td colspan="3" style="text-align:right">Shipping</td><td><?= number_format($order['shipping_cents'] / 100, 2) ?></td></tr>
                <tr><td colspan="3" style="text-align:right">Tax</td><td><?= number_format($order['tax_cents'] / 100, 2) ?></td></tr>
                <tr><td colspan="3" style="text-align:right;font-weight:600">Total</td><td style="font-weight:600"><?= e($order['currency']) ?> <?= number_format($order['total_cents'] / 100, 2) ?></td></tr>
            </tfoot>
        </table>

        <?php if (!empty($order['tracking_number'])): ?>
        <div style="margin-top:1rem;padding:.75rem;background:#f9fafb;border-radius:4px;font-size:13px">
            <strong>Tracking:</strong> <?= e((string) $order['tracking_number']) ?>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
