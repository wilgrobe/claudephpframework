<?php $pageTitle = 'Order #' . (int) $order['id']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>
<?php $shipping = $order['shipping_address_json'] ? json_decode((string) $order['shipping_address_json'], true) : null; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Order #<?= (int) $order['id'] ?></h2>
        <div>
            <a href="/admin/store/orders" class="btn btn-sm btn-secondary">← All orders</a>
        </div>
    </div>
    <div class="card-body">
        <div style="display:grid;gap:1rem;grid-template-columns:2fr 1fr">
            <div>
                <div style="color:#6b7280;font-size:13px;margin-bottom:.5rem">
                    <?= e(date('M j, Y H:i', strtotime((string) $order['created_at']))) ?> · <?= e($order['email']) ?>
                </div>
                <div style="margin-bottom:.5rem"><strong>Status:</strong> <span class="badge"><?= e(ucfirst((string) $order['status'])) ?></span></div>
                <?php if ($shipping): ?>
                <div style="margin-top:1rem;font-size:13px;padding:.75rem;background:#f9fafb;border-radius:4px">
                    <strong>Ship to:</strong><br>
                    <?= e((string) ($shipping['name']    ?? '')) ?><br>
                    <?= e((string) ($shipping['line1']   ?? '')) ?><br>
                    <?php if (!empty($shipping['line2'])): ?><?= e($shipping['line2']) ?><br><?php endif; ?>
                    <?= e((string) ($shipping['city']    ?? '')) ?>, <?= e((string) ($shipping['region'] ?? '')) ?> <?= e((string) ($shipping['postal'] ?? '')) ?><br>
                    <?= e((string) ($shipping['country'] ?? '')) ?>
                </div>
                <?php endif; ?>
            </div>
            <div>
                <h4 style="margin-top:0">Change status</h4>
                <?php foreach (['paid','shipped','delivered','cancelled','refunded'] as $st): ?>
                <form method="post" action="/admin/store/orders/<?= (int) $order['id'] ?>/status/<?= e($st) ?>" style="display:inline-block;margin-bottom:.25rem">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-secondary"><?= e(ucfirst($st)) ?></button>
                </form>
                <?php endforeach; ?>
            </div>
        </div>

        <table class="table" style="margin-top:1rem">
            <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Line total</th></tr></thead>
            <tbody>
            <?php foreach ($items as $it): ?>
            <tr>
                <td><?= e($it['name_snap']) ?> <span style="color:#9ca3af">(<?= e($it['type_snap']) ?>)</span></td>
                <td><?= (int) $it['qty'] ?></td>
                <td><?= number_format((int) $it['price_cents'] / 100, 2) ?></td>
                <td><?= number_format((int) $it['total_cents'] / 100, 2) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr><td colspan="3" style="text-align:right">Subtotal</td><td><?= number_format($order['subtotal_cents'] / 100, 2) ?></td></tr>
                <tr><td colspan="3" style="text-align:right">Shipping</td><td><?= number_format($order['shipping_cents'] / 100, 2) ?></td></tr>
                <tr><td colspan="3" style="text-align:right">Tax</td><td><?= number_format($order['tax_cents'] / 100, 2) ?></td></tr>
                <tr><td colspan="3" style="text-align:right;font-weight:600">Total</td><td style="font-weight:600"><?= e($order['currency']) ?> <?= number_format($order['total_cents'] / 100, 2) ?></td></tr>
            </tfoot>
        </table>

        <?php if (!empty($order['stripe_session_id'])): ?>
        <div style="color:#9ca3af;font-size:12px;margin-top:1rem">Stripe session: <code><?= e((string) $order['stripe_session_id']) ?></code></div>
        <?php endif; ?>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
