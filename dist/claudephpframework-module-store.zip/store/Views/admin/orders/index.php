<?php $pageTitle = 'Store — Orders'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Orders <span style="color:#9ca3af;font-size:13px">(<?= (int) $total ?>)</span></h2>
        <div>
            <a href="/admin/store/products" class="btn btn-sm btn-secondary">Products</a>
        </div>
    </div>
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem;flex-wrap:wrap">
        <a href="/admin/store/orders" class="btn btn-sm <?= empty($status) ? 'btn-primary' : 'btn-secondary' ?>">All</a>
        <?php foreach (['pending','paid','shipped','delivered','cancelled','refunded'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= $status === $s ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($s) ?></a>
        <?php endforeach; ?>
    </div>
    <?php if (empty($orders)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No orders in this status.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>#</th><th>Date</th><th>Customer</th><th>Status</th><th>Total</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($orders as $o): ?>
        <tr>
            <td>#<?= (int) $o['id'] ?></td>
            <td style="font-size:13px"><?= e(date('M j, Y H:i', strtotime((string) $o['created_at']))) ?></td>
            <td><?= e($o['email']) ?></td>
            <td><span class="badge"><?= e(ucfirst((string) $o['status'])) ?></span></td>
            <td><?= e($o['currency']) ?> <?= number_format((int) $o['total_cents'] / 100, 2) ?></td>
            <td><a href="/admin/store/orders/<?= (int) $o['id'] ?>" class="btn btn-sm btn-secondary">View</a></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
