<?php $pageTitle = $rate ? 'Edit tax rate' : 'New tax rate'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>
<?php $r = $rate ?: []; $action = $rate ? '/admin/store/tax/' . (int) $r['id'] . '/edit' : '/admin/store/tax/create'; ?>

<div class="card">
    <div class="card-header"><h2 style="margin:0"><?= $rate ? 'Edit tax rate' : 'New tax rate' ?></h2></div>
    <form method="post" action="<?= e($action) ?>">
        <?= csrf_field() ?>
        <div class="card-body">
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 2fr 1fr">
                <label>Country (ISO-2)
                    <input name="country" maxlength="2" required value="<?= e($r['country'] ?? '') ?>" style="text-transform:uppercase">
                </label>
                <label>Region (blank = whole country)
                    <input name="region" value="<?= e($r['region'] ?? '') ?>">
                </label>
                <label>Tax class
                    <input name="tax_class" value="<?= e($r['tax_class'] ?? 'standard') ?>">
                </label>
            </div>
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr;margin-top:.75rem">
                <label>Rate (basis points; 2000 = 20%)
                    <input type="number" name="rate_bps" min="0" max="10000" required value="<?= (int) ($r['rate_bps'] ?? 0) ?>">
                </label>
                <label>Label (shown to customer)
                    <input name="label" value="<?= e($r['label'] ?? 'Tax') ?>">
                </label>
            </div>
            <label style="display:block;margin-top:.75rem"><input type="checkbox" name="active" value="1" <?= !isset($r['active']) || (int) $r['active'] === 1 ? 'checked' : '' ?>> Active</label>
        </div>
        <div class="card-footer" style="padding:.75rem 1.25rem;background:#f9fafb">
            <a href="/admin/store/tax" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary"><?= $rate ? 'Save' : 'Create' ?></button>
        </div>
    </form>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
