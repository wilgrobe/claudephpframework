<?php $pageTitle = 'Store — Tax rates'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Tax rates</h2>
        <div>
            <a href="/admin/store/products" class="btn btn-sm btn-secondary">Products</a>
            <a href="/admin/store/tax/create" class="btn btn-sm btn-primary">New rate</a>
        </div>
    </div>
    <?php if (empty($rates)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">
        No tax rates configured. Orders won't charge tax until rates exist for the destination country.
    </div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Country</th><th>Region</th><th>Class</th><th>Label</th><th>Rate</th><th>Active</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($rates as $r): ?>
        <tr>
            <td><?= e($r['country']) ?></td>
            <td><?= e((string) ($r['region'] ?? '')) ?: '<span style="color:#9ca3af">any</span>' ?></td>
            <td><?= e($r['tax_class']) ?></td>
            <td><?= e($r['label']) ?></td>
            <td><?= number_format((int) $r['rate_bps'] / 100, 2) ?>%</td>
            <td><?= (int) $r['active'] ? '✓' : '—' ?></td>
            <td>
                <a href="/admin/store/tax/<?= (int) $r['id'] ?>/edit" class="btn btn-sm btn-secondary">Edit</a>
                <form method="post" action="/admin/store/tax/<?= (int) $r['id'] ?>/delete" style="display:inline">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
