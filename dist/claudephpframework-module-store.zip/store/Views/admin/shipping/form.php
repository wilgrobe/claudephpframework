<?php $pageTitle = $zone ? 'Edit shipping zone' : 'New shipping zone'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>
<?php $z = $zone ?: []; $action = $zone ? '/admin/store/shipping/' . (int) $z['id'] . '/edit' : '/admin/store/shipping/create'; ?>

<div class="card">
    <div class="card-header"><h2 style="margin:0"><?= $zone ? 'Edit shipping zone' : 'New shipping zone' ?></h2></div>
    <form method="post" action="<?= e($action) ?>">
        <?= csrf_field() ?>
        <div class="card-body">
            <label style="display:block">Name
                <input name="name" required value="<?= e($z['name'] ?? '') ?>" style="width:100%">
            </label>
            <label style="display:block;margin-top:.75rem">Countries (comma-separated ISO-2 codes — leave blank for catch-all)
                <input name="countries" value="<?= e($z['countries'] ?? '') ?>" style="width:100%" placeholder="US, CA">
            </label>
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr 1fr;margin-top:.75rem">
                <label>Flat rate (cents)
                    <input type="number" name="flat_rate_cents" min="0" required value="<?= (int) ($z['flat_rate_cents'] ?? 0) ?>">
                </label>
                <label>Free over (cents, blank = never)
                    <input type="number" name="free_over_cents" min="0" value="<?= $z['free_over_cents'] ?? '' ?>">
                </label>
                <label>Sort order
                    <input type="number" name="sort_order" value="<?= (int) ($z['sort_order'] ?? 0) ?>">
                </label>
            </div>
            <label style="display:block;margin-top:.75rem"><input type="checkbox" name="active" value="1" <?= !isset($z['active']) || (int) $z['active'] === 1 ? 'checked' : '' ?>> Active</label>
        </div>
        <div class="card-footer" style="padding:.75rem 1.25rem;background:#f9fafb">
            <a href="/admin/store/shipping" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary"><?= $zone ? 'Save' : 'Create' ?></button>
        </div>
    </form>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
