<?php $pageTitle = 'Store — Shipping zones'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Shipping zones</h2>
        <div>
            <a href="/admin/store/products" class="btn btn-sm btn-secondary">Products</a>
            <a href="/admin/store/shipping/create" class="btn btn-sm btn-primary">New zone</a>
        </div>
    </div>
    <?php if (empty($zones)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">
        No zones yet. Physical orders won't charge shipping until you add at least one zone (or a catch-all with empty countries).
    </div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Name</th><th>Countries</th><th>Rate</th><th>Free over</th><th>Sort</th><th>Active</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($zones as $z): ?>
        <tr>
            <td><strong><?= e($z['name']) ?></strong></td>
            <td style="font-family:monospace;font-size:12px"><?= e((string) $z['countries']) ?: '<span style="color:#9ca3af">any (catch-all)</span>' ?></td>
            <td><?= number_format((int) $z['flat_rate_cents'] / 100, 2) ?></td>
            <td><?= $z['free_over_cents'] !== null ? number_format((int) $z['free_over_cents'] / 100, 2) : '—' ?></td>
            <td><?= (int) $z['sort_order'] ?></td>
            <td><?= (int) $z['active'] ? '✓' : '—' ?></td>
            <td>
                <a href="/admin/store/shipping/<?= (int) $z['id'] ?>/edit" class="btn btn-sm btn-secondary">Edit</a>
                <form method="post" action="/admin/store/shipping/<?= (int) $z['id'] ?>/delete" style="display:inline" onsubmit="return confirm('Delete zone?')">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
