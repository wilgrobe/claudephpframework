<?php $pageTitle = 'Store — Products'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Products</h2>
        <div>
            <a href="/admin/store/shipping" class="btn btn-sm btn-secondary">Shipping</a>
            <a href="/admin/store/tax" class="btn btn-sm btn-secondary">Tax</a>
            <a href="/admin/store/orders" class="btn btn-sm btn-secondary">Orders</a>
            <a href="/admin/store/products/create" class="btn btn-sm btn-primary">New product</a>
        </div>
    </div>
    <?php if (empty($products)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No products yet.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Name</th><th>Type</th><th>Price</th><th>Stock</th><th>Active</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($products as $p): ?>
        <tr>
            <td><strong><?= e($p['name']) ?></strong><div style="color:#9ca3af;font-size:12px">/<?= e($p['slug']) ?></div></td>
            <td><?= e($p['type']) ?></td>
            <td><?= e($p['currency']) ?> <?= number_format((int) $p['price_cents'] / 100, 2) ?></td>
            <td>
                <?php if ((int) $p['stock_tracked'] === 1): ?>
                <?= (int) $p['stock'] ?>
                <?php else: ?>
                <span style="color:#9ca3af">—</span>
                <?php endif; ?>
            </td>
            <td><?= (int) $p['active'] ? '✓' : '—' ?></td>
            <td>
                <a href="/admin/store/products/<?= (int) $p['id'] ?>/edit" class="btn btn-sm btn-secondary">Edit</a>
                <form method="post" action="/admin/store/products/<?= (int) $p['id'] ?>/delete" style="display:inline" onsubmit="return confirm('Delete product?')">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
