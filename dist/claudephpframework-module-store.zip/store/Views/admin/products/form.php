<?php
// modules/store/Views/admin/products/form.php
$pageTitle = $product ? 'Edit product' : 'New product';
$p        = $product ?: [];
$isCreate = !$product;
$action   = $product
    ? '/admin/store/products/' . (int) $p['id'] . '/edit'
    : '/admin/store/products/create';
$images   = $images   ?? [];
$variants = $variants ?? [];
$specs    = $specs    ?? [];
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/store/products" style="color:#6b7280;text-decoration:none;font-size:13px">← All products</a>
    <h1 style="margin:0;font-size:1.5rem;flex:1"><?= $isCreate ? 'New product' : e((string) $p['name']) ?></h1>
</div>

<form method="post" action="<?= e($action) ?>" id="product-form">
    <?= csrf_field() ?>

    <!-- ── Basics ──────────────────────────────────────────────────── -->
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header"><h3 style="margin:0">Basics</h3></div>
        <div class="card-body">
            <div style="display:grid;gap:.75rem;grid-template-columns:2fr 1fr">
                <label>Name
                    <input name="name" required value="<?= e($p['name'] ?? '') ?>" style="width:100%">
                </label>
                <label>Slug
                    <input name="slug" required value="<?= e($p['slug'] ?? '') ?>" style="width:100%">
                </label>
            </div>
            <label style="display:block;margin-top:.75rem">Short description <span style="color:#9ca3af;font-size:12px">— shown in listings + search snippets</span>
                <textarea name="short_description" rows="2" style="width:100%"><?= e($p['short_description'] ?? '') ?></textarea>
            </label>
            <label style="display:block;margin-top:.75rem">Full description
                <textarea name="description" rows="5" style="width:100%"><?= e($p['description'] ?? '') ?></textarea>
            </label>
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr 1fr;margin-top:.75rem">
                <label>Type
                    <select name="type">
                        <option value="physical" <?= ($p['type'] ?? '') === 'physical' ? 'selected' : '' ?>>Physical</option>
                        <option value="digital"  <?= ($p['type'] ?? '') === 'digital'  ? 'selected' : '' ?>>Digital</option>
                    </select>
                </label>
                <label>Price (cents)
                    <input type="number" name="price_cents" min="0" value="<?= (int) ($p['price_cents'] ?? 0) ?>" required>
                </label>
                <label>Currency
                    <input name="currency" maxlength="8" value="<?= e($p['currency'] ?? 'USD') ?>">
                </label>
            </div>
            <label style="display:block;margin-top:.75rem">
                <input type="checkbox" name="active" value="1" <?= !isset($p['active']) || (int) $p['active'] === 1 ? 'checked' : '' ?>>
                Active (visible in shop)
            </label>
        </div>
    </div>

    <!-- ── Inventory / shipping / digital ──────────────────────────── -->
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header"><h3 style="margin:0">Inventory &amp; fulfillment</h3></div>
        <div class="card-body">
            <p style="color:#6b7280;font-size:13px;margin-top:0">
                These settings apply when the product has no variants. When variants exist, each variant carries its own SKU / price / stock / weight below.
            </p>
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr 1fr">
                <label>SKU
                    <input name="sku" value="<?= e($p['sku'] ?? '') ?>">
                </label>
                <label>Barcode (GTIN / UPC / EAN)
                    <input name="barcode" value="<?= e($p['barcode'] ?? '') ?>">
                </label>
                <label>Tax class
                    <input name="tax_class" value="<?= e($p['tax_class'] ?? 'standard') ?>">
                </label>
            </div>
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr 1fr;margin-top:.75rem">
                <label>
                    <input type="checkbox" name="stock_tracked" value="1" <?= !empty($p['stock_tracked']) ? 'checked' : '' ?>>
                    Track stock
                </label>
                <label>Stock
                    <input type="number" name="stock" value="<?= (int) ($p['stock'] ?? 0) ?>">
                </label>
                <label>Weight (g)
                    <input type="number" name="weight_grams" min="0" value="<?= (int) ($p['weight_grams'] ?? 0) ?>">
                </label>
            </div>
            <label style="display:block;margin-top:.75rem">Digital file path <span style="color:#9ca3af;font-size:12px">(only for digital goods)</span>
                <input name="digital_file_path" value="<?= e($p['digital_file_path'] ?? '') ?>" style="width:100%" placeholder="storage/store/ebook-42.pdf">
            </label>
        </div>
    </div>

    <!-- ── Catalog metadata ────────────────────────────────────────── -->
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header"><h3 style="margin:0">Catalog metadata</h3></div>
        <div class="card-body">
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr">
                <label>Brand
                    <input name="brand" value="<?= e($p['brand'] ?? '') ?>">
                </label>
                <label>Product type tag <span style="color:#9ca3af;font-size:12px">(filter)</span>
                    <input name="product_type" value="<?= e($p['product_type'] ?? '') ?>">
                </label>
            </div>
            <label style="display:block;margin-top:.75rem">Legacy image URL <span style="color:#9ca3af;font-size:12px">— only used if no gallery images exist</span>
                <input name="image_url" value="<?= e($p['image_url'] ?? '') ?>" style="width:100%">
            </label>
        </div>
    </div>

    <!-- ── SEO ────────────────────────────────────────────────────── -->
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header"><h3 style="margin:0">SEO</h3></div>
        <div class="card-body">
            <label style="display:block">Meta title
                <input name="meta_title" maxlength="191" value="<?= e($p['meta_title'] ?? '') ?>" style="width:100%">
            </label>
            <label style="display:block;margin-top:.75rem">Meta description
                <textarea name="meta_description" rows="2" maxlength="500" style="width:100%"><?= e($p['meta_description'] ?? '') ?></textarea>
            </label>
            <label style="display:block;margin-top:.75rem">Canonical URL
                <input name="canonical_url" value="<?= e($p['canonical_url'] ?? '') ?>" style="width:100%" placeholder="https://example.com/shop/product/slug">
            </label>
        </div>
    </div>

    <!-- ── Option axes ────────────────────────────────────────────── -->
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header"><h3 style="margin:0">Option axes <span style="font-weight:normal;color:#9ca3af;font-size:13px">(up to 3; e.g. Color, Size, Material)</span></h3></div>
        <div class="card-body">
            <div style="display:grid;gap:.5rem;grid-template-columns:1fr 1fr 1fr">
                <label>Option 1 name
                    <input name="option1_name" value="<?= e($p['option1_name'] ?? '') ?>" placeholder="Color">
                </label>
                <label>Option 2 name
                    <input name="option2_name" value="<?= e($p['option2_name'] ?? '') ?>" placeholder="Size">
                </label>
                <label>Option 3 name
                    <input name="option3_name" value="<?= e($p['option3_name'] ?? '') ?>" placeholder="Material">
                </label>
            </div>
            <p style="color:#9ca3af;font-size:12px;margin-top:.5rem">
                Leave blank to disable an axis. Variants below fill in values for each active axis.
            </p>
        </div>
    </div>

    <!-- ── Specs table ────────────────────────────────────────────── -->
    <div class="card" style="margin-bottom:1rem">
        <div class="card-header"><h3 style="margin:0">Spec sheet <span style="font-weight:normal;color:#9ca3af;font-size:13px">(rendered as a table on the product page)</span></h3></div>
        <div class="card-body">
            <table class="table" id="specs-table">
                <thead><tr><th style="width:30%">Label</th><th>Value</th><th></th></tr></thead>
                <tbody>
                    <?php foreach ($specs as $s): ?>
                    <tr>
                        <td><input name="spec_label[]" value="<?= e($s['label']) ?>" style="width:100%"></td>
                        <td><input name="spec_value[]" value="<?= e($s['value']) ?>" style="width:100%"></td>
                        <td><button type="button" class="btn btn-sm btn-danger" onclick="this.closest('tr').remove()">×</button></td>
                    </tr>
                    <?php endforeach; ?>
                    <!-- Blank row for adding. Extend via the button below. -->
                    <tr>
                        <td><input name="spec_label[]" style="width:100%" placeholder="Material"></td>
                        <td><input name="spec_value[]" style="width:100%" placeholder="100% cotton"></td>
                        <td><button type="button" class="btn btn-sm btn-danger" onclick="this.closest('tr').remove()">×</button></td>
                    </tr>
                </tbody>
            </table>
            <button type="button" class="btn btn-sm btn-secondary" onclick="addSpecRow()">+ Add spec row</button>
            <script>
                function addSpecRow() {
                    var row = document.createElement('tr');
                    row.innerHTML = '<td><input name="spec_label[]" style="width:100%"></td>' +
                                    '<td><input name="spec_value[]" style="width:100%"></td>' +
                                    '<td><button type="button" class="btn btn-sm btn-danger" onclick="this.closest(\'tr\').remove()">×</button></td>';
                    document.querySelector('#specs-table tbody').appendChild(row);
                }
            </script>
        </div>
    </div>

    <!-- Save main product fields (specs are saved here too; images and variants below have their own forms) -->
    <div style="text-align:right;margin-bottom:1rem">
        <a href="/admin/store/products" class="btn btn-secondary">Cancel</a>
        <button type="submit" class="btn btn-primary"><?= $isCreate ? 'Create product' : 'Save product' ?></button>
    </div>
</form>

<?php if (!$isCreate): ?>
<!-- ── Images gallery (separate forms — each action is independent) ─ -->
<div class="card" style="margin-bottom:1rem">
    <div class="card-header"><h3 style="margin:0">Images</h3></div>
    <div class="card-body">
        <?php if (empty($images)): ?>
        <div style="color:#9ca3af;font-size:13px;padding:.5rem 0">No gallery images yet.</div>
        <?php else: ?>
        <table class="table">
            <thead><tr><th>Preview</th><th>URL</th><th>Alt</th><th>Sort</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($images as $img): ?>
            <tr>
                <td><img src="<?= e($img['url']) ?>" alt="" style="height:48px;width:48px;object-fit:cover;border-radius:4px"></td>
                <td style="font-family:monospace;font-size:12px;word-break:break-all"><?= e($img['url']) ?></td>
                <td><?= e((string) ($img['alt'] ?? '')) ?></td>
                <td><?= (int) $img['sort_order'] ?></td>
                <td>
                    <form method="post" action="/admin/store/products/<?= (int) $p['id'] ?>/images/<?= (int) $img['id'] ?>/delete" style="display:inline">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
        <form method="post" action="/admin/store/products/<?= (int) $p['id'] ?>/images" style="display:grid;gap:.5rem;grid-template-columns:3fr 2fr 1fr auto;align-items:end;margin-top:.5rem">
            <?= csrf_field() ?>
            <label>Image URL
                <input name="url" required style="width:100%">
            </label>
            <label>Alt text
                <input name="alt" style="width:100%">
            </label>
            <label>Sort
                <input type="number" name="sort_order" value="0" style="width:80px">
            </label>
            <button type="submit" class="btn btn-primary">Add image</button>
        </form>
    </div>
</div>

<!-- ── Variants ─────────────────────────────────────────────────── -->
<div class="card" style="margin-bottom:1rem">
    <div class="card-header"><h3 style="margin:0">Variants</h3></div>
    <div class="card-body">
        <?php if (empty($p['option1_name'])): ?>
        <div style="color:#9ca3af;font-size:13px">
            No option axes defined — the product sells at its base price above. Add an option axis (e.g. "Size") above, save, then come back to add variant rows.
        </div>
        <?php else: ?>
            <?php if (empty($variants)): ?>
            <div style="color:#9ca3af;font-size:13px">No variants yet — add one below.</div>
            <?php else: ?>
            <table class="table">
                <thead>
                    <tr>
                        <?php if (!empty($p['option1_name'])): ?><th><?= e($p['option1_name']) ?></th><?php endif; ?>
                        <?php if (!empty($p['option2_name'])): ?><th><?= e($p['option2_name']) ?></th><?php endif; ?>
                        <?php if (!empty($p['option3_name'])): ?><th><?= e($p['option3_name']) ?></th><?php endif; ?>
                        <th>SKU</th><th>Price</th><th>Stock</th><th>Weight</th><th>Active</th><th></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($variants as $v): ?>
                <tr>
                    <form method="post" action="/admin/store/products/<?= (int) $p['id'] ?>/variants/<?= (int) $v['id'] ?>/update" style="display:contents">
                        <?= csrf_field() ?>
                        <?php if (!empty($p['option1_name'])): ?><td><input name="option1_value" value="<?= e((string) ($v['option1_value'] ?? '')) ?>" style="width:100%"></td><?php endif; ?>
                        <?php if (!empty($p['option2_name'])): ?><td><input name="option2_value" value="<?= e((string) ($v['option2_value'] ?? '')) ?>" style="width:100%"></td><?php endif; ?>
                        <?php if (!empty($p['option3_name'])): ?><td><input name="option3_value" value="<?= e((string) ($v['option3_value'] ?? '')) ?>" style="width:100%"></td><?php endif; ?>
                        <td><input name="sku" value="<?= e((string) ($v['sku'] ?? '')) ?>" style="width:100%"></td>
                        <td><input type="number" name="price_cents" value="<?= $v['price_cents'] !== null ? (int) $v['price_cents'] : '' ?>" placeholder="base" style="width:80px"></td>
                        <td>
                            <label style="font-size:11px"><input type="checkbox" name="stock_tracked" value="1" <?= (int) $v['stock_tracked'] === 1 ? 'checked' : '' ?>> track</label>
                            <input type="number" name="stock" value="<?= (int) $v['stock'] ?>" style="width:70px">
                        </td>
                        <td><input type="number" name="weight_grams" value="<?= $v['weight_grams'] !== null ? (int) $v['weight_grams'] : '' ?>" placeholder="base" style="width:70px"></td>
                        <td><input type="checkbox" name="active" value="1" <?= (int) $v['active'] === 1 ? 'checked' : '' ?>></td>
                        <td>
                            <button type="submit" class="btn btn-sm btn-secondary">Save</button>
                    </form>
                            <form method="post" action="/admin/store/products/<?= (int) $p['id'] ?>/variants/<?= (int) $v['id'] ?>/delete" style="display:inline">
                                <?= csrf_field() ?>
                                <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete variant?')">×</button>
                            </form>
                        </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>

            <form method="post" action="/admin/store/products/<?= (int) $p['id'] ?>/variants" style="margin-top:1rem;padding:.75rem;background:#f9fafb;border-radius:4px">
                <?= csrf_field() ?>
                <strong style="display:block;margin-bottom:.5rem">Add variant</strong>
                <div style="display:grid;gap:.5rem;grid-template-columns:repeat(4, 1fr);align-items:end">
                    <?php if (!empty($p['option1_name'])): ?>
                    <label><?= e($p['option1_name']) ?>
                        <input name="option1_value" required style="width:100%">
                    </label>
                    <?php endif; ?>
                    <?php if (!empty($p['option2_name'])): ?>
                    <label><?= e($p['option2_name']) ?>
                        <input name="option2_value" style="width:100%">
                    </label>
                    <?php endif; ?>
                    <?php if (!empty($p['option3_name'])): ?>
                    <label><?= e($p['option3_name']) ?>
                        <input name="option3_value" style="width:100%">
                    </label>
                    <?php endif; ?>
                    <label>SKU <input name="sku"></label>
                    <label>Price (cents) <span style="color:#9ca3af;font-size:11px">blank = base</span>
                        <input type="number" name="price_cents" min="0">
                    </label>
                    <label>Weight (g) <input type="number" name="weight_grams" min="0"></label>
                    <label>Stock <input type="number" name="stock" value="0"></label>
                    <label><input type="checkbox" name="stock_tracked" value="1"> Track stock</label>
                </div>
                <label style="display:block;margin-top:.5rem">Image URL (optional; overrides product image for this variant)
                    <input name="image_url" style="width:100%">
                </label>
                <label style="margin-top:.5rem;display:block">
                    <input type="checkbox" name="active" value="1" checked> Active
                </label>
                <div style="text-align:right;margin-top:.5rem">
                    <button type="submit" class="btn btn-primary">Add variant</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
