<?php
// modules/store/Controllers/ShopController.php
namespace Modules\Store\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Session;
use Modules\Store\Services\CartService;
use Modules\Store\Services\CheckoutService;
use Modules\Store\Services\OrderService;
use Modules\Store\Services\ProductService;

/**
 * Public-facing shop.
 *
 *   GET  /shop                       — catalog grid
 *   GET  /shop/product/{slug}        — single product page
 *   GET  /cart                       — cart review
 *   POST /cart/add                   — add product_id + qty
 *   POST /cart/items/{id}/update     — set qty on a cart item
 *   POST /cart/items/{id}/remove     — remove a cart item
 *   GET  /checkout                   — address form + totals preview
 *   POST /checkout                   — create pending order + Stripe redirect
 *   GET  /checkout/success           — post-redirect landing (webhook does the work)
 *   GET  /checkout/cancel            — back to cart with a flash
 *   GET  /orders                     — signed-in user's orders
 *   GET  /orders/{id}                — detail + download links for digital items
 *   GET  /download/{token}           — signed digital delivery
 */
class ShopController
{
    private Auth            $auth;
    private ProductService  $products;
    private CartService     $cart;
    private OrderService    $orders;
    private CheckoutService $checkout;

    public function __construct()
    {
        $this->auth     = Auth::getInstance();
        $this->products = new ProductService();
        $this->cart     = new CartService();
        $this->orders   = new OrderService();
        $this->checkout = new CheckoutService();
    }

    // ── Catalog ───────────────────────────────────────────────────────────

    public function index(Request $request): Response
    {
        return Response::view('store::public.index', [
            'products' => $this->products->active(),
        ]);
    }

    public function product(Request $request): Response
    {
        $slug    = (string) $request->param(0);
        $product = $this->products->findBySlug($slug);
        if (!$product || (int) $product['active'] !== 1) {
            return new Response('Product not found', 404);
        }
        // Pre-load variants/images/specs so the view renders in one pass
        // with no lazy service calls at template time.
        return Response::view('store::public.product', [
            'product'  => $product,
            'images'   => $this->products->imagesFor((int) $product['id']),
            'variants' => $this->products->variantsFor((int) $product['id']),
            'specs'    => $this->products->specsFor((int) $product['id']),
        ]);
    }

    // ── Cart ──────────────────────────────────────────────────────────────

    public function cart(Request $request): Response
    {
        $c       = $this->cart->current();
        $totals  = $this->cart->totals((int) $c['id']);
        return Response::view('store::public.cart', ['totals' => $totals]);
    }

    public function addToCart(Request $request): Response
    {
        $pid = (int) $request->post('product_id');
        $qty = max(1, (int) $request->post('qty', 1));
        $vid = (int) $request->post('variant_id', 0) ?: null;
        if ($pid <= 0) return Response::redirect('/shop');

        $ok = $this->cart->add($pid, $qty, $vid);
        $flash = $ok
            ? ['success', 'Added to cart.']
            : ['error', 'Could not add — out of stock, variant required, or unavailable.'];
        return Response::redirect('/cart')->withFlash(...$flash);
    }

    public function updateCartItem(Request $request): Response
    {
        $id  = (int) $request->param(0);
        $qty = (int) $request->post('qty', 0);
        $this->cart->updateQty($id, $qty);
        return Response::redirect('/cart');
    }

    public function removeCartItem(Request $request): Response
    {
        $id = (int) $request->param(0);
        $this->cart->remove($id);
        return Response::redirect('/cart');
    }

    // ── Checkout ──────────────────────────────────────────────────────────

    public function checkoutForm(Request $request): Response
    {
        $c      = $this->cart->current();
        $totals = $this->cart->totals((int) $c['id']);
        if (empty($totals['items'])) {
            return Response::redirect('/cart')->withFlash('error', 'Your cart is empty.');
        }

        return Response::view('store::public.checkout', [
            'totals'       => $totals,
            'enabled'      => $this->checkout->isEnabled(),
            'user'         => $this->auth->user(),
            'guestAllowed' => true,
        ]);
    }

    public function checkoutStart(Request $request): Response
    {
        if (!$this->checkout->isEnabled()) {
            return Response::redirect('/cart')->withFlash('error', 'Payments not configured.');
        }

        $c      = $this->cart->current();
        $items  = $this->cart->items((int) $c['id']);
        if (!$items) return Response::redirect('/cart');

        $country = strtoupper((string) $request->post('country', ''));
        $region  = (string) $request->post('region', '');
        $totals  = $this->cart->totals((int) $c['id'], $country ?: null, $region ?: null);

        $email = trim((string) $request->post('email', ''));
        if (!$this->auth->guest()) {
            $email = (string) ($this->auth->user()['email'] ?? $email);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return Response::redirect('/checkout')->withFlash('error', 'Please enter a valid email.');
        }

        $shipping = null;
        if ($totals['has_physical']) {
            $shipping = [
                'name'     => (string) $request->post('shipping_name', ''),
                'line1'    => (string) $request->post('shipping_line1', ''),
                'line2'    => (string) $request->post('shipping_line2', ''),
                'city'     => (string) $request->post('shipping_city', ''),
                'region'   => $region,
                'postal'   => (string) $request->post('shipping_postal', ''),
                'country'  => $country,
            ];
            if (!$shipping['name'] || !$shipping['line1'] || !$shipping['city'] || !$shipping['postal'] || !$country) {
                return Response::redirect('/checkout')->withFlash('error', 'Shipping address incomplete.');
            }
        }

        $orderId = $this->orders->createPendingFromCart(
            userId:    $this->auth->guest() ? null : (int) $this->auth->id(),
            email:     $email,
            totals:    $totals,
            addresses: ['shipping' => $shipping, 'billing' => $shipping],
            currency:  (string) $totals['currency']
        );

        $appUrl  = (string) config('app.url');
        $url = $this->checkout->startCheckout(
            orderId:    $orderId,
            email:      $email,
            totals:     $totals,
            successUrl: "$appUrl/checkout/success?order=$orderId",
            cancelUrl:  "$appUrl/checkout/cancel?order=$orderId",
            currency:   (string) $totals['currency']
        );
        if (!$url) {
            return Response::redirect('/cart')->withFlash('error', 'Checkout unavailable. Try again later.');
        }

        // Clear the cart now — the pending order holds everything. If the
        // user abandons checkout on Stripe's page, the cancel handler
        // restores the items from the pending order (see cancelLanding).
        $this->cart->clear((int) $c['id']);

        return Response::redirect($url);
    }

    public function successLanding(Request $request): Response
    {
        $orderId = (int) $request->query('order');
        $order   = $orderId ? $this->orders->find($orderId) : null;

        return Response::view('store::public.checkout_success', [
            'order' => $order,
            'items' => $order ? $this->orders->itemsFor($orderId) : [],
        ]);
    }

    public function cancelLanding(Request $request): Response
    {
        // Put the items back into the cart so the user can retry.
        $orderId = (int) $request->query('order');
        if ($orderId > 0) {
            $order = $this->orders->find($orderId);
            if ($order && $order['status'] === 'pending') {
                $cart = $this->cart->current();
                foreach ($this->orders->itemsFor($orderId) as $it) {
                    if ($it['product_id']) {
                        $this->cart->add(
                            (int) $it['product_id'],
                            (int) $it['qty'],
                            !empty($it['variant_id']) ? (int) $it['variant_id'] : null
                        );
                    }
                }
                $this->orders->transitionStatus($orderId, 'cancelled');
            }
        }
        return Response::redirect('/cart')->withFlash('info', 'Checkout cancelled — your cart is back.');
    }

    // ── Orders / downloads ────────────────────────────────────────────────

    public function myOrders(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $list = $this->orders->forUser((int) $this->auth->id());
        return Response::view('store::public.my_orders', ['orders' => $list]);
    }

    public function orderDetail(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id    = (int) $request->param(0);
        $order = $this->orders->find($id);
        if (!$order || (int) $order['user_id'] !== (int) $this->auth->id()) {
            return new Response('Order not found', 404);
        }
        $items = $this->orders->itemsFor($id);

        // Attach download tokens for digital items (already issued at paid time).
        foreach ($items as &$it) {
            if ($it['type_snap'] === 'digital' && $order['status'] === 'paid') {
                $it['download_token'] = $this->orders->issueDownloadToken((int) $it['id']);
            }
        }
        unset($it);

        return Response::view('store::public.order_detail', [
            'order' => $order, 'items' => $items,
        ]);
    }

    /**
     * Digital delivery. Token lookups join the product row so we can
     * stream the file from disk (via X-Accel-Redirect if nginx provides
     * it, otherwise readfile()).
     */
    public function download(Request $request): Response
    {
        $token = (string) $request->param(0);
        $row   = $this->orders->findDownloadToken($token);
        if (!$row)                                  return new Response('Invalid token', 404);
        if (strtotime((string) $row['expires_at']) < time()) return new Response('Expired token', 410);
        if (empty($row['digital_file_path']))       return new Response('File missing', 410);

        $path = (string) $row['digital_file_path'];
        // Accept both app-relative and absolute paths. Relative paths are
        // resolved against BASE_PATH so content outside the framework
        // directory can still be served by explicit absolute path.
        if ($path[0] !== '/') $path = BASE_PATH . '/' . ltrim($path, '/');
        if (!is_file($path))  return new Response('File missing', 410);

        $this->orders->markTokenDownloaded((int) $row['id']);

        $filename = basename((string) $row['digital_file_path']);
        $size     = filesize($path);
        $mime     = function_exists('mime_content_type') ? (string) mime_content_type($path) : 'application/octet-stream';

        header("Content-Type: $mime");
        header("Content-Disposition: attachment; filename=\"$filename\"");
        if ($size !== false) header("Content-Length: $size");
        header('X-Content-Type-Options: nosniff');
        readfile($path);
        exit;
    }
}
