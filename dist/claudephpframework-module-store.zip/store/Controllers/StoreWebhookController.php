<?php
// modules/store/Controllers/StoreWebhookController.php
namespace Modules\Store\Controllers;

use Core\Request;
use Core\Response;
use Core\Services\StripeService;
use Modules\Store\Services\CheckoutService;
use Modules\Store\Services\OrderService;

/**
 * Stripe webhook receiver for one-off store orders.
 *
 * Route: POST /webhooks/stripe/store — NO auth, NO CSRF. Stripe's own
 * signature (HMAC over the raw body with STRIPE_WEBHOOK_SECRET) is the
 * security boundary.
 *
 * Shares STRIPE_WEBHOOK_SECRET with the subscriptions module. Stripe's
 * webhook endpoint configuration determines which events land here vs.
 * at /webhooks/stripe/subscriptions — checkout.session.completed events
 * carrying metadata[order_id] are routed to this module by convention.
 *
 * Event types handled (others are ignored):
 *   - checkout.session.completed   → order marked paid, stock decremented,
 *                                    download tokens issued for digital items
 *   - payment_intent.payment_failed → pending order marked cancelled
 */
class StoreWebhookController
{
    public function receive(Request $request): Response
    {
        $payload   = (string) @file_get_contents('php://input');
        $signature = (string) ($_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '');

        $stripe = new StripeService();
        $event  = $stripe->verifyWebhook($payload, $signature);
        if (!$event) return new Response('Invalid signature', 400);

        try {
            (new CheckoutService())->applyWebhookEvent($event, new OrderService());
        } catch (\Throwable $e) {
            error_log('[store webhook] ' . $e->getMessage());
            return new Response('retry', 500);
        }
        return new Response('ok', 200);
    }
}
