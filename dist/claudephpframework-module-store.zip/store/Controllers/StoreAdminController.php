<?php
// modules/store/Controllers/StoreAdminController.php
namespace Modules\Store\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Store\Services\OrderService;
use Modules\Store\Services\ProductService;
use Modules\Store\Services\ShippingService;
use Modules\Store\Services\TaxService;

/**
 * Admin surface for the store. Gated by AuthMiddleware + RequireAdmin
 * (see routes.php) — no per-action permission check on top; the
 * `store.manage` permission is seeded for role wiring.
 */
class StoreAdminController
{
    private ProductService  $products;
    private ShippingService $shipping;
    private TaxService      $tax;
    private OrderService    $orders;

    public function __construct()
    {
        $this->products = new ProductService();
        $this->shipping = new ShippingService();
        $this->tax      = new TaxService();
        $this->orders   = new OrderService();
    }

    // ── Products ──────────────────────────────────────────────────────────

    public function productsIndex(Request $request): Response
    {
        return Response::view('store::admin.products.index', [
            'products' => $this->products->all(),
        ]);
    }

    public function productCreate(Request $request): Response
    {
        return Response::view('store::admin.products.form', [
            'product' => null,
        ]);
    }

    public function productStore(Request $request): Response
    {
        $data = $this->readProductForm($request);
        if (!$data['name'] || !$data['slug']) {
            return Response::redirect('/admin/store/products/create')
                ->withFlash('error', 'Name and slug required.');
        }
        $this->products->create($data);
        return Response::redirect('/admin/store/products')->withFlash('success', 'Product created.');
    }

    public function productEdit(Request $request): Response
    {
        $id = (int) $request->param(0);
        $p  = $this->products->find($id);
        if (!$p) return new Response('Not found', 404);
        return Response::view('store::admin.products.form', [
            'product'  => $p,
            'images'   => $this->products->imagesFor($id),
            'variants' => $this->products->variantsFor($id),
            'specs'    => $this->products->specsFor($id),
        ]);
    }

    public function productUpdate(Request $request): Response
    {
        $id   = (int) $request->param(0);
        $data = $this->readProductForm($request);
        $this->products->update($id, $data);

        // Specs come in as parallel arrays (label[] + value[]); save in bulk.
        $labels = $request->post('spec_label');
        $values = $request->post('spec_value');
        if (is_array($labels) && is_array($values)) {
            $specs = [];
            foreach ($labels as $i => $lbl) {
                $specs[] = ['label' => (string) $lbl, 'value' => (string) ($values[$i] ?? '')];
            }
            $this->products->setSpecs($id, $specs);
        }

        return Response::redirect('/admin/store/products/' . $id . '/edit')
            ->withFlash('success', 'Product updated.');
    }

    // ── Product sub-resources (image, variant) ───────────────────────────

    public function productAddImage(Request $request): Response
    {
        $id  = (int) $request->param(0);
        $url = trim((string) $request->post('url'));
        if ($url === '') return Response::redirect("/admin/store/products/$id/edit")
            ->withFlash('error', 'Image URL required.');
        $this->products->addImage(
            $id, $url,
            (string) $request->post('alt') ?: null,
            (int) $request->post('sort_order', 0)
        );
        return Response::redirect("/admin/store/products/$id/edit")
            ->withFlash('success', 'Image added.');
    }

    public function productDeleteImage(Request $request): Response
    {
        $productId = (int) $request->param(0);
        $imageId   = (int) $request->param(1);
        $this->products->deleteImage($imageId);
        return Response::redirect("/admin/store/products/$productId/edit");
    }

    public function productAddVariant(Request $request): Response
    {
        $productId = (int) $request->param(0);
        $data = $this->readVariantForm($request);
        try {
            $this->products->createVariant($productId, $data);
        } catch (\Throwable $e) {
            return Response::redirect("/admin/store/products/$productId/edit")
                ->withFlash('error', 'Could not add variant — likely duplicate option values.');
        }
        return Response::redirect("/admin/store/products/$productId/edit")
            ->withFlash('success', 'Variant added.');
    }

    public function productUpdateVariant(Request $request): Response
    {
        $productId = (int) $request->param(0);
        $variantId = (int) $request->param(1);
        $this->products->updateVariant($variantId, $this->readVariantForm($request));
        return Response::redirect("/admin/store/products/$productId/edit")
            ->withFlash('success', 'Variant updated.');
    }

    public function productDeleteVariant(Request $request): Response
    {
        $productId = (int) $request->param(0);
        $variantId = (int) $request->param(1);
        $this->products->deleteVariant($variantId);
        return Response::redirect("/admin/store/products/$productId/edit")
            ->withFlash('success', 'Variant deleted.');
    }

    private function readVariantForm(Request $request): array
    {
        return [
            'sku'           => (string) $request->post('sku'),
            'price_cents'   => $request->post('price_cents') !== '' && $request->post('price_cents') !== null
                                  ? (int) $request->post('price_cents') : null,
            'weight_grams'  => $request->post('weight_grams') !== '' && $request->post('weight_grams') !== null
                                  ? (int) $request->post('weight_grams') : null,
            'stock_tracked' => $request->post('stock_tracked') ? 1 : 0,
            'stock'         => (int) $request->post('stock', 0),
            'option1_value' => (string) $request->post('option1_value'),
            'option2_value' => (string) $request->post('option2_value'),
            'option3_value' => (string) $request->post('option3_value'),
            'image_url'     => (string) $request->post('image_url'),
            'sort_order'    => (int) $request->post('sort_order', 0),
            'active'        => $request->post('active') ? 1 : 0,
        ];
    }

    public function productDelete(Request $request): Response
    {
        $id = (int) $request->param(0);
        $this->products->delete($id);
        return Response::redirect('/admin/store/products')->withFlash('success', 'Product deleted.');
    }

    private function readProductForm(Request $request): array
    {
        return [
            'name'               => trim((string) $request->post('name')),
            'slug'               => trim((string) $request->post('slug')),
            'description'        => (string) $request->post('description'),
            'short_description'  => (string) $request->post('short_description'),
            'meta_title'         => (string) $request->post('meta_title'),
            'meta_description'   => (string) $request->post('meta_description'),
            'canonical_url'      => (string) $request->post('canonical_url'),
            'brand'              => (string) $request->post('brand'),
            'barcode'            => (string) $request->post('barcode'),
            'product_type'       => (string) $request->post('product_type'),
            'option1_name'       => (string) $request->post('option1_name'),
            'option2_name'       => (string) $request->post('option2_name'),
            'option3_name'       => (string) $request->post('option3_name'),
            'type'               => (string) $request->post('type', 'physical'),
            'price_cents'        => (int) $request->post('price_cents', 0),
            'currency'           => strtoupper((string) $request->post('currency', 'USD')),
            'sku'                => (string) $request->post('sku'),
            'stock_tracked'      => $request->post('stock_tracked') ? 1 : 0,
            'stock'              => (int) $request->post('stock', 0),
            'weight_grams'       => (int) $request->post('weight_grams', 0),
            'tax_class'          => (string) $request->post('tax_class', 'standard'),
            'digital_file_path'  => (string) $request->post('digital_file_path'),
            'image_url'          => (string) $request->post('image_url'),
            'active'             => $request->post('active') ? 1 : 0,
        ];
    }

    // ── Shipping zones ────────────────────────────────────────────────────

    public function shippingIndex(Request $request): Response
    {
        return Response::view('store::admin.shipping.index', [
            'zones' => $this->shipping->allZones(),
        ]);
    }

    public function shippingCreate(Request $request): Response
    {
        return Response::view('store::admin.shipping.form', ['zone' => null]);
    }

    public function shippingStore(Request $request): Response
    {
        $this->shipping->createZone($this->readShippingForm($request));
        return Response::redirect('/admin/store/shipping')->withFlash('success', 'Zone created.');
    }

    public function shippingEdit(Request $request): Response
    {
        $zone = $this->shipping->findZone((int) $request->param(0));
        if (!$zone) return new Response('Not found', 404);
        return Response::view('store::admin.shipping.form', ['zone' => $zone]);
    }

    public function shippingUpdate(Request $request): Response
    {
        $this->shipping->updateZone((int) $request->param(0), $this->readShippingForm($request));
        return Response::redirect('/admin/store/shipping')->withFlash('success', 'Zone updated.');
    }

    public function shippingDelete(Request $request): Response
    {
        $this->shipping->deleteZone((int) $request->param(0));
        return Response::redirect('/admin/store/shipping')->withFlash('success', 'Zone deleted.');
    }

    private function readShippingForm(Request $request): array
    {
        return [
            'name'            => trim((string) $request->post('name')),
            'countries'       => (string) $request->post('countries'),
            'flat_rate_cents' => (int) $request->post('flat_rate_cents', 0),
            'free_over_cents' => $request->post('free_over_cents') !== '' && $request->post('free_over_cents') !== null
                                    ? (int) $request->post('free_over_cents') : null,
            'sort_order'      => (int) $request->post('sort_order', 0),
            'active'          => $request->post('active') ? 1 : 0,
        ];
    }

    // ── Tax ───────────────────────────────────────────────────────────────

    public function taxIndex(Request $request): Response
    {
        return Response::view('store::admin.tax.index', ['rates' => $this->tax->all()]);
    }

    public function taxCreate(Request $request): Response
    {
        return Response::view('store::admin.tax.form', ['rate' => null]);
    }

    public function taxStore(Request $request): Response
    {
        $this->tax->create($this->readTaxForm($request));
        return Response::redirect('/admin/store/tax')->withFlash('success', 'Tax rate created.');
    }

    public function taxEdit(Request $request): Response
    {
        $rate = $this->tax->find((int) $request->param(0));
        if (!$rate) return new Response('Not found', 404);
        return Response::view('store::admin.tax.form', ['rate' => $rate]);
    }

    public function taxUpdate(Request $request): Response
    {
        $this->tax->update((int) $request->param(0), $this->readTaxForm($request));
        return Response::redirect('/admin/store/tax')->withFlash('success', 'Tax rate updated.');
    }

    public function taxDelete(Request $request): Response
    {
        $this->tax->delete((int) $request->param(0));
        return Response::redirect('/admin/store/tax')->withFlash('success', 'Tax rate deleted.');
    }

    private function readTaxForm(Request $request): array
    {
        return [
            'country'   => strtoupper((string) $request->post('country', '')),
            'region'    => (string) $request->post('region', ''),
            'rate_bps'  => (int) $request->post('rate_bps', 0),
            'label'     => (string) $request->post('label', 'Tax'),
            'tax_class' => (string) $request->post('tax_class', 'standard'),
            'active'    => $request->post('active') ? 1 : 0,
        ];
    }

    // ── Orders ────────────────────────────────────────────────────────────

    public function ordersIndex(Request $request): Response
    {
        $status = (string) $request->query('status', '');
        $page   = max(1, (int) $request->query('page', 1));
        $res    = $this->orders->listAll($status ?: null, $page, 50);
        return Response::view('store::admin.orders.index', [
            'orders' => $res['items'],
            'total'  => $res['total'],
            'status' => $status,
            'page'   => $page,
        ]);
    }

    public function orderShow(Request $request): Response
    {
        $id    = (int) $request->param(0);
        $order = $this->orders->find($id);
        if (!$order) return new Response('Not found', 404);

        return Response::view('store::admin.orders.show', [
            'order' => $order,
            'items' => $this->orders->itemsFor($id),
        ]);
    }

    public function orderSetStatus(Request $request): Response
    {
        $id     = (int) $request->param(0);
        $status = (string) $request->param(1);
        $this->orders->transitionStatus($id, $status);
        return Response::redirect("/admin/store/orders/$id")->withFlash('success', "Order set to $status.");
    }
}
