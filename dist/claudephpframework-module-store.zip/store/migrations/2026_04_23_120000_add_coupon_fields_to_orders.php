<?php
// modules/store/migrations/2026_04_23_120000_add_coupon_fields_to_orders.php
use Core\Database\Migration;

/**
 * Adds nullable coupon-tracking columns to `store_orders`. Populated
 * by OrderService when the coupons module applied a discount at
 * checkout time. Kept here (not in the coupons module) because the
 * columns live on store's own table — the store is the owner of the
 * order row; coupons is a consumer.
 *
 * If the coupons module is never installed these columns simply stay
 * NULL forever; the order row is unaffected.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            ALTER TABLE store_orders
              ADD COLUMN coupon_id      INT UNSIGNED NULL AFTER currency,
              ADD COLUMN coupon_code    VARCHAR(64)  NULL AFTER coupon_id,
              ADD COLUMN discount_cents INT UNSIGNED NOT NULL DEFAULT 0 AFTER coupon_code,
              ADD KEY idx_coupon (coupon_id)
        ");
    }

    public function down(): void
    {
        $this->db->query("
            ALTER TABLE store_orders
              DROP KEY idx_coupon,
              DROP COLUMN discount_cents,
              DROP COLUMN coupon_code,
              DROP COLUMN coupon_id
        ");
    }
};
