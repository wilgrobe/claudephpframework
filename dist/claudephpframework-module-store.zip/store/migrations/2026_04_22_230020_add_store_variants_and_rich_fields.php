<?php
// modules/store/migrations/2026_04_22_230020_add_store_variants_and_rich_fields.php
use Core\Database\Migration;

/**
 * Second-wave store schema — Shopify/Amazon-style rich product model.
 *
 * Adds three new tables + extends store_products with rich fields +
 * option axis names. Also adds variant_id to cart/order items so a
 * shopper can buy a specific variant (Red/M) rather than just "the
 * product".
 *
 *   store_products (additions)
 *     short_description       — ~500-char blurb for listings
 *     meta_title / meta_desc  — SEO head tags
 *     canonical_url           — tells search engines the authoritative URL
 *     brand                   — manufacturer / label
 *     barcode                 — GTIN / UPC / EAN
 *     product_type            — Shopify's "type" filter tag
 *     option1/2/3_name        — axis names ("Color", "Size", "Material").
 *                               NULL means the product doesn't use that
 *                               axis. At most three axes per product —
 *                               matches Shopify's covers-99%-of-stores
 *                               constraint.
 *
 *   store_product_images
 *     Ordered gallery. The first image (by sort_order) is the primary
 *     image. Legacy store_products.image_url stays as a fallback so
 *     pre-gallery products still render.
 *
 *   store_product_variants
 *     One row per option-value combination. Each variant carries its
 *     own SKU, price, stock, weight, and optional override image. A
 *     product with no option axes has zero variants and sells directly
 *     at the product-level price.
 *
 *     Pricing precedence at cart time: variant.price_cents if set,
 *     else product.price_cents. Similarly for weight and stock.
 *
 *   store_product_specs
 *     Key-value spec sheet ("Material: Cotton", "Weight: 500g"). Per-
 *     product, ordered. Rendered as a simple two-column table on the
 *     product page.
 *
 *   store_cart_items / store_order_items (additions)
 *     variant_id — which variant of the product the customer is buying.
 *     variant_options_snap — human-readable option values frozen at
 *       purchase time ("Red / M") for order display.
 *
 * All additions are nullable so pre-migration rows continue to work.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            ALTER TABLE store_products
              ADD COLUMN short_description  VARCHAR(500) NULL AFTER description,
              ADD COLUMN meta_title          VARCHAR(191) NULL AFTER short_description,
              ADD COLUMN meta_description    VARCHAR(500) NULL AFTER meta_title,
              ADD COLUMN canonical_url       VARCHAR(500) NULL AFTER meta_description,
              ADD COLUMN brand               VARCHAR(120) NULL AFTER canonical_url,
              ADD COLUMN barcode             VARCHAR(64)  NULL AFTER brand,
              ADD COLUMN product_type        VARCHAR(120) NULL AFTER barcode,
              ADD COLUMN option1_name        VARCHAR(60)  NULL AFTER product_type,
              ADD COLUMN option2_name        VARCHAR(60)  NULL AFTER option1_name,
              ADD COLUMN option3_name        VARCHAR(60)  NULL AFTER option2_name,
              ADD KEY idx_brand        (brand),
              ADD KEY idx_product_type (product_type)
        ");

        $this->db->query("
            CREATE TABLE store_product_images (
                id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                product_id  INT UNSIGNED NOT NULL,
                url         VARCHAR(500) NOT NULL,
                alt         VARCHAR(191) NULL,
                sort_order  INT UNSIGNED NOT NULL DEFAULT 0,
                created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_product_sort (product_id, sort_order),
                CONSTRAINT fk_spi_product FOREIGN KEY (product_id)
                    REFERENCES store_products (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_product_variants (
                id             INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                product_id     INT UNSIGNED NOT NULL,
                sku            VARCHAR(64)  NULL,
                price_cents    INT UNSIGNED NULL,
                weight_grams   INT UNSIGNED NULL,
                stock_tracked  TINYINT(1)   NOT NULL DEFAULT 0,
                stock          INT          NOT NULL DEFAULT 0,
                option1_value  VARCHAR(120) NULL,
                option2_value  VARCHAR(120) NULL,
                option3_value  VARCHAR(120) NULL,
                image_url      VARCHAR(500) NULL,
                sort_order     INT UNSIGNED NOT NULL DEFAULT 0,
                active         TINYINT(1)   NOT NULL DEFAULT 1,
                created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_product_options (product_id, option1_value, option2_value, option3_value),
                UNIQUE KEY uq_sku             (sku),
                KEY idx_product_sort (product_id, sort_order),
                KEY idx_active       (active),
                CONSTRAINT fk_spv_product FOREIGN KEY (product_id)
                    REFERENCES store_products (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_product_specs (
                id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                product_id  INT UNSIGNED NOT NULL,
                label       VARCHAR(120) NOT NULL,
                value       VARCHAR(500) NOT NULL,
                sort_order  INT UNSIGNED NOT NULL DEFAULT 0,
                created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_product_sort (product_id, sort_order),
                CONSTRAINT fk_sps_product FOREIGN KEY (product_id)
                    REFERENCES store_products (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        // variant_id on cart + order lines. No FK on cart_items.variant_id
        // so pre-variant cart rows with NULL stay valid even if the
        // variants table is dropped later; and no FK on order_items
        // variant_id so a variant deletion doesn't retroactively orphan
        // order history (order items keep their snapshotted options).
        $this->db->query("
            ALTER TABLE store_cart_items
              ADD COLUMN variant_id INT UNSIGNED NULL AFTER product_id,
              DROP INDEX uq_cart_product,
              ADD UNIQUE KEY uq_cart_product_variant
                (cart_id, product_id, variant_id)
        ");

        $this->db->query("
            ALTER TABLE store_order_items
              ADD COLUMN variant_id            INT UNSIGNED NULL  AFTER product_id,
              ADD COLUMN variant_options_snap  VARCHAR(255) NULL  AFTER sku_snap
        ");
    }

    public function down(): void
    {
        $this->db->query("
            ALTER TABLE store_order_items
              DROP COLUMN variant_options_snap,
              DROP COLUMN variant_id
        ");
        $this->db->query("
            ALTER TABLE store_cart_items
              DROP INDEX uq_cart_product_variant,
              ADD UNIQUE KEY uq_cart_product (cart_id, product_id),
              DROP COLUMN variant_id
        ");
        $this->db->query("DROP TABLE IF EXISTS store_product_specs");
        $this->db->query("DROP TABLE IF EXISTS store_product_variants");
        $this->db->query("DROP TABLE IF EXISTS store_product_images");
        $this->db->query("
            ALTER TABLE store_products
              DROP KEY idx_brand,
              DROP KEY idx_product_type,
              DROP COLUMN option3_name,
              DROP COLUMN option2_name,
              DROP COLUMN option1_name,
              DROP COLUMN product_type,
              DROP COLUMN barcode,
              DROP COLUMN brand,
              DROP COLUMN canonical_url,
              DROP COLUMN meta_description,
              DROP COLUMN meta_title,
              DROP COLUMN short_description
        ");
    }
};
