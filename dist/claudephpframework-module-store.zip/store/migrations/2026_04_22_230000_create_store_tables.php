<?php
// modules/store/migrations/2026_04_22_230000_create_store_tables.php
use Core\Database\Migration;

/**
 * Schema for the store module.
 *
 *   store_products         — catalog. `type` picks physical vs digital;
 *                            physical rows care about stock / weight /
 *                            shipping, digital rows care about
 *                            digital_file_path (served via signed download
 *                            URLs on paid orders).
 *
 *   store_shipping_zones   — flat-rate shipping per zone. `countries` is a
 *                            CSV of ISO-3166-alpha-2 codes; first matching
 *                            zone wins when computing shipping for an order.
 *                            `free_over_cents` waives the fee if the cart
 *                            subtotal meets it.
 *
 *   store_tax_rates        — region-level sales tax. Simple: country +
 *                            optional region (state/province) + rate in
 *                            basis points (10000 = 100%). First matching
 *                            row wins; a null region is the country-wide
 *                            fallback.
 *
 *   store_carts            — per-user (logged in) or per-session (guest).
 *                            Carts are persistent — guest carts migrate
 *                            to the user's row on login via CartService.
 *
 *   store_cart_items       — product × qty with a price snapshot. The
 *                            snapshot protects against price changes
 *                            between "add to cart" and "checkout".
 *
 *   store_orders           — immutable once paid. `status` workflow:
 *                              pending → paid → shipped → delivered
 *                                             ↘ refunded
 *                                             ↘ cancelled
 *                            Digital-only orders skip shipped/delivered.
 *                            `stripe_session_id` correlates the webhook
 *                            back to the local order.
 *
 *   store_order_items      — line items at the time of purchase. Name,
 *                            price, and type are snapshotted because the
 *                            source product may be edited or deleted
 *                            later.
 *
 *   store_download_tokens  — one-time-ish signed tokens for digital
 *                            deliveries. Token is opaque; link is emailed
 *                            after payment. `expires_at` defaults to
 *                            7 days from order paid time.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE store_products (
                id                 INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name               VARCHAR(191) NOT NULL,
                slug               VARCHAR(160) NOT NULL,
                description        TEXT         NULL,
                type               ENUM('physical','digital') NOT NULL DEFAULT 'physical',
                price_cents        INT UNSIGNED NOT NULL DEFAULT 0,
                currency           VARCHAR(8)   NOT NULL DEFAULT 'USD',
                sku                VARCHAR(64)  NULL,
                stock_tracked      TINYINT(1)   NOT NULL DEFAULT 0,
                stock              INT          NOT NULL DEFAULT 0,
                weight_grams       INT UNSIGNED NOT NULL DEFAULT 0,
                tax_class          VARCHAR(32)  NOT NULL DEFAULT 'standard',
                digital_file_path  VARCHAR(500) NULL,
                image_url          VARCHAR(500) NULL,
                active             TINYINT(1)   NOT NULL DEFAULT 1,
                created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_slug (slug),
                KEY idx_active_type (active, type),
                KEY idx_sku (sku)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_shipping_zones (
                id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name            VARCHAR(120) NOT NULL,
                countries       VARCHAR(1000) NOT NULL DEFAULT '',
                flat_rate_cents INT UNSIGNED NOT NULL DEFAULT 0,
                free_over_cents INT UNSIGNED NULL,
                sort_order      INT UNSIGNED NOT NULL DEFAULT 0,
                active          TINYINT(1)   NOT NULL DEFAULT 1,
                created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_active_sort (active, sort_order)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_tax_rates (
                id         INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                country    VARCHAR(2)  NOT NULL,
                region     VARCHAR(64) NULL,
                rate_bps   INT UNSIGNED NOT NULL DEFAULT 0,
                label      VARCHAR(64) NOT NULL DEFAULT 'Tax',
                tax_class  VARCHAR(32) NOT NULL DEFAULT 'standard',
                active     TINYINT(1)  NOT NULL DEFAULT 1,
                created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                KEY idx_lookup (country, region, tax_class, active)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_carts (
                id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id     INT UNSIGNED NULL,
                session_id  VARCHAR(128) NULL,
                created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                KEY idx_user    (user_id),
                KEY idx_session (session_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_cart_items (
                id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                cart_id     INT UNSIGNED NOT NULL,
                product_id  INT UNSIGNED NOT NULL,
                qty         INT UNSIGNED NOT NULL DEFAULT 1,
                price_cents INT UNSIGNED NOT NULL DEFAULT 0,
                created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_cart_product (cart_id, product_id),
                CONSTRAINT fk_ci_cart    FOREIGN KEY (cart_id)    REFERENCES store_carts    (id) ON DELETE CASCADE,
                CONSTRAINT fk_ci_product FOREIGN KEY (product_id) REFERENCES store_products (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_orders (
                id                        INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id                   INT UNSIGNED NULL,
                email                     VARCHAR(191) NOT NULL,
                status                    ENUM('pending','paid','shipped','delivered','cancelled','refunded')
                                          NOT NULL DEFAULT 'pending',
                subtotal_cents            INT UNSIGNED NOT NULL DEFAULT 0,
                shipping_cents            INT UNSIGNED NOT NULL DEFAULT 0,
                tax_cents                 INT UNSIGNED NOT NULL DEFAULT 0,
                total_cents               INT UNSIGNED NOT NULL DEFAULT 0,
                currency                  VARCHAR(8)   NOT NULL DEFAULT 'USD',
                shipping_address_json     TEXT NULL,
                billing_address_json      TEXT NULL,
                stripe_session_id         VARCHAR(191) NULL,
                stripe_payment_intent_id  VARCHAR(191) NULL,
                tracking_number           VARCHAR(120) NULL,
                notes                     TEXT NULL,
                placed_at                 DATETIME NULL,
                shipped_at                DATETIME NULL,
                refunded_at               DATETIME NULL,
                created_at                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at                DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_stripe_session (stripe_session_id),
                KEY idx_user_status (user_id, status),
                KEY idx_status_created (status, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_order_items (
                id          INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                order_id    INT UNSIGNED NOT NULL,
                product_id  INT UNSIGNED NULL,
                name_snap   VARCHAR(191) NOT NULL,
                type_snap   ENUM('physical','digital') NOT NULL,
                sku_snap    VARCHAR(64)  NULL,
                qty         INT UNSIGNED NOT NULL DEFAULT 1,
                price_cents INT UNSIGNED NOT NULL DEFAULT 0,
                total_cents INT UNSIGNED NOT NULL DEFAULT 0,
                created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                KEY idx_order (order_id),
                CONSTRAINT fk_oi_order   FOREIGN KEY (order_id)   REFERENCES store_orders   (id) ON DELETE CASCADE,
                CONSTRAINT fk_oi_product FOREIGN KEY (product_id) REFERENCES store_products (id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE store_download_tokens (
                id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                order_item_id   INT UNSIGNED NOT NULL,
                token           VARCHAR(80)  NOT NULL,
                expires_at      DATETIME     NOT NULL,
                downloaded_at   DATETIME     NULL,
                download_count  INT UNSIGNED NOT NULL DEFAULT 0,
                created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_token (token),
                KEY idx_item (order_item_id),
                CONSTRAINT fk_dt_item FOREIGN KEY (order_item_id) REFERENCES store_order_items (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS store_download_tokens");
        $this->db->query("DROP TABLE IF EXISTS store_order_items");
        $this->db->query("DROP TABLE IF EXISTS store_orders");
        $this->db->query("DROP TABLE IF EXISTS store_cart_items");
        $this->db->query("DROP TABLE IF EXISTS store_carts");
        $this->db->query("DROP TABLE IF EXISTS store_tax_rates");
        $this->db->query("DROP TABLE IF EXISTS store_shipping_zones");
        $this->db->query("DROP TABLE IF EXISTS store_products");
    }
};
