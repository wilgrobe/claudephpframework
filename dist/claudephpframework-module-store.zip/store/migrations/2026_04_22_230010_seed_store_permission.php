<?php
// modules/store/migrations/2026_04_22_230010_seed_store_permission.php
use Core\Database\Migration;

/**
 * Seed the `store.manage` permission so admin roles can be granted access
 * to manage products, shipping zones, tax rates, and orders. Idempotent
 * via INSERT IGNORE on the slug unique key.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage store',
            'store.manage',
            'store',
            'Manage store products, shipping zones, tax rates, and orders.',
        ]);
    }

    public function down(): void
    {
        // Keep permission rows intact — other roles may reference them.
    }
};
