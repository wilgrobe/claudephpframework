<?php
// modules/store/module.php
use Core\Module\ModuleProvider;

/**
 * Store module — products, cart, checkout, orders.
 *
 * Supports physical goods (with optional stock tracking, weight, and
 * flat-rate shipping by zone), digital goods (delivered via signed
 * download tokens), and mixed carts. Tax is modeled as a per-(country,
 * region, tax_class) basis-point rate; shipping is flat per zone with
 * an optional "free over X" threshold.
 *
 * Checkout goes through the framework's configured Stripe gateway via a
 * hosted Checkout session. A webhook at /webhooks/stripe/store promotes
 * pending orders to `paid` and fulfills digital deliveries.
 *
 * Categories / taxonomy attachment: use the taxonomy module's
 * attach_term() helper with entity_type='store_product'. The taxonomy
 * module's admin UI at /admin/taxonomy/sets handles category tree CRUD.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'store'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
