# Installation — Store module

## Prerequisites

- `claudephpframework-core` installed.
- `STRIPE_SECRET_KEY` + `STRIPE_WEBHOOK_SECRET` set in `.env`. (The same
  secrets used by the subscriptions module — both modules share the
  gateway.)
- `store.manage` permission granted to at least one admin role (seeded
  by the second migration). Grant via `/admin/roles`.
- Mail driver configured if you want order-confirmation emails (those
  currently run through the framework's notification pipeline; see
  deferred features for a dedicated email template).

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-store.zip
   cp -r claudephpframework-module-store/store /path/to/project/modules/
   ```

2. Run the migrations (creates 11 tables + adds rich-product columns +
   seeds the `store.manage` permission):
   ```bash
   php artisan migrate
   ```
   Four migrations run in order:
     * `..._create_store_tables.php` — base 8 tables
     * `..._seed_store_permission.php` — `store.manage` permission
     * `..._add_store_variants_and_rich_fields.php` — adds
       `store_product_images`, `store_product_variants`,
       `store_product_specs`, SEO / brand / barcode / option-axis-name
       columns on `store_products`, and `variant_id` columns on cart +
       order items.

3. Refresh module cache if you use production caching:
   ```bash
   php artisan module:cache
   ```

4. Point a Stripe webhook endpoint at
   `https://yourapp.example.com/webhooks/stripe/store` for the event
   types:
   - `checkout.session.completed`
   - `payment_intent.payment_failed`

   Use the same `STRIPE_WEBHOOK_SECRET` as other Stripe endpoints if you
   want signature verification to succeed across modules.

## First-use walkthrough

1. Log in as admin, visit `/admin/store/products` → **New product**.
   - Create a physical product (e.g. "T-shirt", price_cents=2500,
     stock_tracked ✓, stock=10), and a digital product (e.g. "E-book",
     type=digital, digital_file_path=`storage/store/ebook.pdf`).
   - Hit save. On the edit page, scroll to **Option axes**: set
     "Color" and "Size", save again. Now the **Variants** panel is
     populated — add rows for Red/S, Red/M, Blue/S, Blue/M.
   - Scroll to **Images**: paste in a few URLs. First one becomes
     the primary image.
   - Scroll to **Spec sheet**: add rows like Material / 100% cotton
     and Fit / Regular.
   - Hit save on the top-level form (spec sheet saves with the main
     form; images and variants are independent sub-resources).
2. Visit `/admin/store/shipping` → **New zone**.
   - Name "Domestic", countries `US,CA`, flat_rate_cents=500,
     free_over_cents=5000. A second catch-all zone with no countries is
     a good idea so international orders get a rate.
3. Visit `/admin/store/tax` → **New rate**.
   - Country `US`, region blank, tax_class `standard`, rate_bps=825
     (=8.25%).
4. Log out, visit `/shop`, add one of each product, go to `/cart`,
   click **Proceed to checkout**.
5. Fill in an email + shipping address. Submit. You're redirected to
   Stripe Checkout. Use Stripe's test card `4242 4242 4242 4242`.
6. Back at `/checkout/success?order={id}`, the webhook has already
   promoted the order to `paid` (in dev with Stripe CLI running). Visit
   `/orders/{id}` to see the download link for the digital item.

## Environment variables

| Name                       | Purpose                                              |
|----------------------------|------------------------------------------------------|
| `STRIPE_SECRET_KEY`        | Server-side Stripe key — enables checkout sessions.  |
| `STRIPE_PUBLIC_KEY`        | Client key (not used by this module; subscriptions) |
| `STRIPE_WEBHOOK_SECRET`    | Signature verification for `/webhooks/stripe/store`  |

## Deferred features (v2)

- **Order confirmation emails** — currently only the admin UI shows new
  orders. A `SendOrderConfirmationJob` + template slot cleanly on.
- **Discount codes / coupons** — will land as the coupons module in
  Batch 3 and hook into the Stripe Checkout session via
  `discounts[0][coupon]`.
- **Per-country shipping rates with dimensional weight** — weight is
  captured on products; a carrier integration would use it.
- **Stripe Tax / Avalara / TaxJar** integration — the `TaxService`
  interface is small enough to swap cleanly.
- **Multiple currency support** — schema carries `currency` per product
  and per order, but UI assumes a single default. Per-user currency
  preference + display-time conversion is a follow-up.
- **Refund UI + line-item refunds** — the status transition exists but
  wiring to Stripe's refund API lives in `PaymentsService::refund`
  already; one admin action to connect them.
- **Inventory reservations** — current flow decrements stock at
  webhook-paid time. Reserving at cart-add time prevents oversell on
  burst checkouts but adds a reservation-expiry job.
- **Product search + filters** — catalog uses a simple name sort.
  `SearchIndexer` could index `store_products` for full-text search.

## Verification

- `php -l modules/store/**/*.php` — lint-check.
- Walk the admin flows: create a product, create a zone, create a tax
  rate, view orders.
- Walk the shopper flow: add to cart, check shipping/tax preview is
  reasonable, checkout in Stripe test mode, verify the order status
  flips from `pending` to `paid` after the webhook fires.

## Troubleshooting

- **"Payments not configured"** on `/checkout` — `STRIPE_SECRET_KEY` is
  missing or empty. Set it and restart the PHP-FPM worker.
- **Order stuck in `pending`** after payment — the webhook isn't
  reaching the app, or the signature check is failing. Check
  `error_log` for `[store webhook]` lines and confirm Stripe's webhook
  endpoint + secret.
- **Digital download 404** — `digital_file_path` on the product
  doesn't resolve. Paths are relative to `BASE_PATH` unless they start
  with `/`. Put files under `storage/store/` and reference that path.
- **No tax charged** — no `store_tax_rates` row matches the
  destination country + tax_class. A row with `region = NULL` is the
  country-wide fallback.
