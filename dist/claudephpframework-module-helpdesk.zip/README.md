# Helpdesk module

Customer-facing support portal at `/support`, staff queue at
`/admin/helpdesk`. Four priorities with per-priority SLA policies
(first-response time + resolution time). SLAs snapshotted at create
time so later policy edits don't retroactively overdue historical
tickets.

## Features

- **Customer portal** — `/support` lists your tickets + new-ticket
  form. `/support/{reference}` shows the thread.
- **Staff queue** — `/admin/helpdesk` with status tabs, priority,
  overdue flag. "Mine" + "Unassigned" filters.
- **Replies** with internal/public flag. Internal notes are hidden
  from the customer view; public replies show up on both.
- **Auto-reopen** — customer reply on a resolved/closed ticket flips
  status to `reopened`.
- **Priority recompute** — changing a ticket's priority mid-flight
  recomputes the unfulfilled SLA clocks (response if not yet
  responded; resolution if not yet resolved).
- **Unique human-readable references** — 8-char uppercase alnum
  without confusable chars (O/0/I/1/L).

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
