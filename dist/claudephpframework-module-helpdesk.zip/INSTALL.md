# Installation — Helpdesk module

## Prerequisites

- `claudephpframework-core`.
- `helpdesk.manage` permission granted to staff roles (seeded by the
  second migration).

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` (creates 3 tables + seeds default SLA policies).
3. Grant `helpdesk.manage` to one or more roles at `/admin/roles`.

## First-use walkthrough

1. Log in as a customer, visit `/support`, file a ticket. Note the
   reference (e.g. `ABC23XY7`).
2. Log in as staff, visit `/admin/helpdesk`. The new ticket is in
   "open" with SLA clocks ticking.
3. Reply publicly ("Looking into this") — `first_responded_at` stamps;
   the response SLA is satisfied.
4. Add an internal note (check the "Internal note" box) — customer
   view won't show it.
5. Change status to `resolved`. SLA resolution clock satisfied.
6. Customer replies on the resolved ticket → auto-reopened. Status
   goes to `reopened`; the resolution clock is not reset by the flip.

## SLA defaults

Tunable at `/admin/helpdesk/sla`:

| Priority | First response | Resolution |
|----------|----------------|------------|
| low      | 48 hours       | 7 days     |
| normal   | 24 hours       | 3 days     |
| high     | 4 hours        | 24 hours   |
| urgent   | 1 hour         | 4 hours    |

## Deferred features

- **Email ingestion** — an IMAP poller that ingests tickets from an
  inbox. Template slots: a parser + a `tickets.created_via = 'email'`
  column.
- **Customer CC / email notifications** — MailService on every reply.
- **Canned responses** — staff-side snippets for common replies.
- **Time tracking** — per-reply duration field for billing.
- **Automation rules** — "if priority=urgent and age>2h unanswered,
  reassign to X" — would hang off a scheduled task.
