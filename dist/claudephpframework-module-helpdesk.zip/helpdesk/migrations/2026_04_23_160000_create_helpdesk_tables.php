<?php
// modules/helpdesk/migrations/2026_04_23_160000_create_helpdesk_tables.php
use Core\Database\Migration;

/**
 * Schema for the helpdesk module.
 *
 *   tickets           — the customer's request. `status` lifecycle:
 *                         open → in_progress → resolved → closed
 *                       with side tracks to `on_hold` and `reopened`.
 *                       Priority + SLA timestamps support the SLA
 *                       overdue flagging without a separate tracker
 *                       table (first_response_due_at + resolution_due_at
 *                       are set at create time from the priority's
 *                       SLA policy).
 *
 *   ticket_replies    — the conversation thread on a ticket. An
 *                       `internal` flag hides a reply from the
 *                       customer — staff-only notes. The comments
 *                       module isn't reused here because its schema
 *                       doesn't accommodate the "internal vs public"
 *                       flag cleanly and ticket replies have a
 *                       narrower semantic (linear thread, no nesting,
 *                       direct participants).
 *
 *   sla_policies      — per-priority SLA (response + resolution time
 *                       in minutes). Seeded with sensible defaults;
 *                       admin can tune at /admin/helpdesk/sla.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE tickets (
                id                     INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                reference              VARCHAR(20)  NOT NULL,
                subject                VARCHAR(191) NOT NULL,
                description            TEXT NOT NULL,
                customer_user_id       INT UNSIGNED NULL,
                customer_email         VARCHAR(191) NOT NULL,
                assigned_user_id       INT UNSIGNED NULL,
                priority               ENUM('low','normal','high','urgent') NOT NULL DEFAULT 'normal',
                status                 ENUM('open','in_progress','on_hold','resolved','closed','reopened')
                                       NOT NULL DEFAULT 'open',
                first_response_due_at  DATETIME NULL,
                resolution_due_at      DATETIME NULL,
                first_responded_at     DATETIME NULL,
                resolved_at            DATETIME NULL,
                closed_at              DATETIME NULL,
                created_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at             DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_reference (reference),
                KEY idx_customer (customer_user_id, status),
                KEY idx_email_status (customer_email, status),
                KEY idx_assignee (assigned_user_id, status),
                KEY idx_status_priority (status, priority, created_at),
                KEY idx_due_response (first_response_due_at, status),
                KEY idx_due_resolution (resolution_due_at, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE ticket_replies (
                id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                ticket_id    INT UNSIGNED NOT NULL,
                user_id      INT UNSIGNED NULL,
                body         TEXT NOT NULL,
                internal     TINYINT(1) NOT NULL DEFAULT 0,
                created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                KEY idx_ticket_created (ticket_id, created_at),
                CONSTRAINT fk_tr_ticket
                    FOREIGN KEY (ticket_id) REFERENCES tickets (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE helpdesk_sla_policies (
                priority                ENUM('low','normal','high','urgent') NOT NULL PRIMARY KEY,
                first_response_minutes  INT UNSIGNED NOT NULL,
                resolution_minutes      INT UNSIGNED NOT NULL,
                updated_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        // Seeded defaults: 24h first-response / 72h resolution for normal,
        // escalating up to 1h / 4h for urgent. Tune at /admin/helpdesk/sla.
        $this->db->query("
            INSERT INTO helpdesk_sla_policies (priority, first_response_minutes, resolution_minutes) VALUES
              ('low',     2880, 10080),
              ('normal',  1440, 4320),
              ('high',    240,  1440),
              ('urgent',  60,   240)
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS helpdesk_sla_policies");
        $this->db->query("DROP TABLE IF EXISTS ticket_replies");
        $this->db->query("DROP TABLE IF EXISTS tickets");
    }
};
