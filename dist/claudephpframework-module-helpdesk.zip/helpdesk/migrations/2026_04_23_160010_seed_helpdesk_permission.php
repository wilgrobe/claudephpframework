<?php
// modules/helpdesk/migrations/2026_04_23_160010_seed_helpdesk_permission.php
use Core\Database\Migration;

return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage helpdesk',
            'helpdesk.manage',
            'helpdesk',
            'Work tickets, assign staff, configure SLAs, and post internal notes.',
        ]);
    }

    public function down(): void {}
};
