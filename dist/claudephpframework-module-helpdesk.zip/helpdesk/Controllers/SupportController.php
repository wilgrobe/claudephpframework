<?php
// modules/helpdesk/Controllers/SupportController.php
namespace Modules\Helpdesk\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\Helpdesk\Services\TicketService;

/**
 * Customer-facing support surface.
 *   GET  /support                  — their ticket list + new-ticket form
 *   POST /support                  — create ticket
 *   GET  /support/{reference}      — view their own ticket
 *   POST /support/{reference}      — add a reply
 */
class SupportController
{
    private Auth          $auth;
    private TicketService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new TicketService();
    }

    public function index(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        return Response::view('helpdesk::public.index', [
            'tickets' => $this->svc->forCustomer((int) $this->auth->id()),
            'me'      => $this->auth->user(),
            'priorities' => TicketService::PRIORITIES,
        ]);
    }

    public function create(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        try {
            $id = $this->svc->create(
                (int) $this->auth->id(),
                (string) ($this->auth->user()['email'] ?? ''),
                (string) $request->post('subject'),
                (string) $request->post('description'),
                (string) $request->post('priority', 'normal')
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect('/support')->withFlash('error', $e->getMessage());
        }
        $t = $this->svc->find($id);
        return Response::redirect('/support/' . $t['reference'])->withFlash('success', 'Ticket created.');
    }

    public function show(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $ref = (string) $request->param(0);
        $t   = $this->svc->findByReference($ref);
        if (!$t || (int) ($t['customer_user_id'] ?? 0) !== (int) $this->auth->id()) {
            return new Response('Ticket not found', 404);
        }
        return Response::view('helpdesk::public.show', [
            'ticket'  => $t,
            'replies' => $this->svc->repliesFor((int) $t['id'], includeInternal: false),
            'me'      => $this->auth->user(),
        ]);
    }

    public function reply(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $ref = (string) $request->param(0);
        $t   = $this->svc->findByReference($ref);
        if (!$t || (int) ($t['customer_user_id'] ?? 0) !== (int) $this->auth->id()) {
            return new Response('Ticket not found', 404);
        }
        try {
            $this->svc->addReply(
                (int) $t['id'], (int) $this->auth->id(),
                (string) $request->post('body'),
                internal: false,
                isStaff:  false
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect('/support/' . $t['reference'])->withFlash('error', $e->getMessage());
        }
        return Response::redirect('/support/' . $t['reference']);
    }
}
