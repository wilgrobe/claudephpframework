<?php
// modules/helpdesk/Controllers/HelpdeskAdminController.php
namespace Modules\Helpdesk\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Modules\Helpdesk\Services\TicketService;

/**
 * Staff surface at /admin/helpdesk.
 *
 *   GET  /admin/helpdesk                      — queue
 *   GET  /admin/helpdesk/tickets/{id}         — detail
 *   POST /admin/helpdesk/tickets/{id}/reply   — add reply (public or internal)
 *   POST /admin/helpdesk/tickets/{id}/assign  — set assignee_user_id
 *   POST /admin/helpdesk/tickets/{id}/status  — set status
 *   POST /admin/helpdesk/tickets/{id}/priority — set priority
 *   GET  /admin/helpdesk/sla                  — SLA policies
 *   POST /admin/helpdesk/sla/{priority}       — update policy
 */
class HelpdeskAdminController
{
    private Auth          $auth;
    private Database      $db;
    private TicketService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->db   = Database::getInstance();
        $this->svc  = new TicketService();
    }

    private function requirePerm(): ?Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->auth->can('helpdesk.manage')) return new Response('Forbidden', 403);
        return null;
    }

    public function index(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;

        // Build filters. viewer_user_id always present so "mine" can
        // anchor on the caller; other filters only added when set in
        // the query string so empty values don't inadvertently filter.
        $filters = ['viewer_user_id' => (int) $this->auth->id()];
        foreach (['status', 'priority'] as $k) {
            $v = (string) $request->query($k);
            if ($v !== '') $filters[$k] = $v;
        }
        foreach (['overdue', 'mine', 'unassigned'] as $k) {
            if ((bool) $request->query($k)) $filters[$k] = true;
        }

        $page = max(1, (int) $request->query('page', 1));
        $res  = $this->svc->listForStaff($filters, $page, 50);

        return Response::view('helpdesk::admin.index', [
            'tickets' => $res['items'],
            'total'   => $res['total'],
            'filters' => $filters,
            'counts'  => $this->svc->countsByStatus(),
        ]);
    }

    public function show(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $t  = $this->svc->find($id);
        if (!$t) return new Response('Not found', 404);

        $staff = $this->db->fetchAll(
            "SELECT DISTINCT u.id, u.username, u.email
               FROM users u
               JOIN user_roles ur      ON ur.user_id = u.id
               JOIN role_permissions rp ON rp.role_id = ur.role_id
               JOIN permissions p      ON p.id       = rp.permission_id
              WHERE p.slug = 'helpdesk.manage'
           ORDER BY u.username ASC"
        );

        return Response::view('helpdesk::admin.show', [
            'ticket'  => $t,
            'replies' => $this->svc->repliesFor($id, includeInternal: true),
            'staff'   => $staff,
            'me'      => $this->auth->user(),
        ]);
    }

    public function reply(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $t  = $this->svc->find($id);
        if (!$t) return new Response('Not found', 404);
        try {
            $this->svc->addReply(
                $id, (int) $this->auth->id(),
                (string) $request->post('body'),
                internal: (bool) $request->post('internal'),
                isStaff:  true
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect("/admin/helpdesk/tickets/$id")->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/admin/helpdesk/tickets/$id");
    }

    public function assign(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $assignee = (int) $request->post('assigned_user_id', 0) ?: null;
        $this->svc->assign($id, $assignee);
        return Response::redirect("/admin/helpdesk/tickets/$id");
    }

    public function status(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id     = (int) $request->param(0);
        $status = (string) $request->post('status');
        try { $this->svc->setStatus($id, $status); }
        catch (\InvalidArgumentException $e) {
            return Response::redirect("/admin/helpdesk/tickets/$id")->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/admin/helpdesk/tickets/$id");
    }

    public function priority(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $id = (int) $request->param(0);
        $p  = (string) $request->post('priority');
        try { $this->svc->setPriority($id, $p); }
        catch (\InvalidArgumentException $e) {
            return Response::redirect("/admin/helpdesk/tickets/$id")->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/admin/helpdesk/tickets/$id");
    }

    // ── SLA ──────────────────────────────────────────────────────────────

    public function slaIndex(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        return Response::view('helpdesk::admin.sla', [
            'policies' => $this->svc->allPolicies(),
        ]);
    }

    public function slaUpdate(Request $request): Response
    {
        if ($r = $this->requirePerm()) return $r;
        $priority = (string) $request->param(0);
        try {
            $this->svc->updatePolicy(
                $priority,
                (int) $request->post('first_response_minutes', 0),
                (int) $request->post('resolution_minutes', 0)
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect('/admin/helpdesk/sla')->withFlash('error', $e->getMessage());
        }
        return Response::redirect('/admin/helpdesk/sla')->withFlash('success', 'Policy updated.');
    }
}
