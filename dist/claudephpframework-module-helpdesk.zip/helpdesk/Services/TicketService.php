<?php
// modules/helpdesk/Services/TicketService.php
namespace Modules\Helpdesk\Services;

use Core\Database\Database;

/**
 * Ticket CRUD + lifecycle + SLA math.
 *
 * Status transitions:
 *   open → in_progress → resolved → closed
 *                    ↘ on_hold
 *                    ↘ reopened (back to open-ish)
 *
 * SLAs: at create-time we snapshot the priority's policy into
 * `first_response_due_at` and `resolution_due_at` so later policy
 * edits don't retroactively overdue historical tickets.
 * `first_responded_at` is stamped the first time a staff reply lands
 * (recorded via `recordStaffReply`), which freezes the response SLA.
 *
 * Reference generator: 8-char random alnum uppercase. Collisions
 * retried up to 5 times — fine for millions of tickets.
 */
class TicketService
{
    public const STATUSES   = ['open','in_progress','on_hold','resolved','closed','reopened'];
    public const PRIORITIES = ['low','normal','high','urgent'];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Ticket reads ─────────────────────────────────────────────────────

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM tickets WHERE id = ?", [$id]);
    }

    public function findByReference(string $ref): ?array
    {
        return $this->db->fetchOne("SELECT * FROM tickets WHERE reference = ?", [strtoupper($ref)]);
    }

    /** @return array<int, array<string, mixed>> */
    public function forCustomer(int $userId, int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM tickets
              WHERE customer_user_id = ?
           ORDER BY created_at DESC
              LIMIT ?",
            [$userId, $limit]
        );
    }

    /**
     * Staff queue. Filterable by status + assignee. `overdue` flag is
     * computed in SQL from the SLA columns — no post-processing, so
     * counts and pagination stay honest.
     *
     * @return array{items: array<int, array<string, mixed>>, total: int}
     */
    public function listForStaff(array $filters = [], int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        $where  = ['1=1'];
        $bind   = [];

        if (!empty($filters['status'])) {
            $where[] = 't.status = ?';
            $bind[]  = (string) $filters['status'];
        }
        if (!empty($filters['priority'])) {
            $where[] = 't.priority = ?';
            $bind[]  = (string) $filters['priority'];
        }
        if (!empty($filters['assigned_user_id'])) {
            $where[] = 't.assigned_user_id = ?';
            $bind[]  = (int) $filters['assigned_user_id'];
        }
        if (!empty($filters['mine']) && !empty($filters['viewer_user_id'])) {
            $where[] = 't.assigned_user_id = ?';
            $bind[]  = (int) $filters['viewer_user_id'];
        }
        if (!empty($filters['unassigned'])) {
            $where[] = 't.assigned_user_id IS NULL';
        }
        if (!empty($filters['overdue'])) {
            $where[] = "(
                (t.first_responded_at IS NULL AND t.first_response_due_at < NOW())
             OR (t.resolved_at       IS NULL AND t.resolution_due_at    < NOW())
            )";
            $where[] = "t.status NOT IN ('resolved','closed')";
        }

        $whereSql = 'WHERE ' . implode(' AND ', $where);

        $items = $this->db->fetchAll(
            "SELECT t.*,
                    u.username AS customer_username,
                    a.username AS assignee_username,
                    CASE
                      WHEN t.status IN ('resolved','closed') THEN 0
                      WHEN (t.first_responded_at IS NULL AND t.first_response_due_at < NOW())
                        OR (t.resolved_at        IS NULL AND t.resolution_due_at    < NOW())
                      THEN 1 ELSE 0
                    END AS overdue
               FROM tickets t
          LEFT JOIN users u ON u.id = t.customer_user_id
          LEFT JOIN users a ON a.id = t.assigned_user_id
              $whereSql
           ORDER BY t.priority DESC, t.created_at DESC
              LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM tickets t $whereSql", $bind
        );
        return ['items' => $items, 'total' => $total];
    }

    public function countsByStatus(?int $assignedUserId = null): array
    {
        $where = ''; $bind = [];
        if ($assignedUserId !== null) {
            $where = 'WHERE assigned_user_id = ?';
            $bind[] = $assignedUserId;
        }
        $rows = $this->db->fetchAll(
            "SELECT status, COUNT(*) AS cnt FROM tickets $where GROUP BY status", $bind
        );
        $out = array_fill_keys(self::STATUSES, 0);
        foreach ($rows as $r) $out[$r['status']] = (int) $r['cnt'];
        return $out;
    }

    // ── Replies ──────────────────────────────────────────────────────────

    /** @return array<int, array<string, mixed>> */
    public function repliesFor(int $ticketId, bool $includeInternal): array
    {
        $cond = $includeInternal ? '' : 'AND internal = 0';
        return $this->db->fetchAll(
            "SELECT r.*, u.username
               FROM ticket_replies r
          LEFT JOIN users u ON u.id = r.user_id
              WHERE r.ticket_id = ? $cond
           ORDER BY r.created_at ASC",
            [$ticketId]
        );
    }

    // ── Writes ───────────────────────────────────────────────────────────

    /**
     * Customer-side ticket creation. Guests pass email + null userId;
     * logged-in users pass both for linkage to their account.
     */
    public function create(
        ?int $customerUserId, string $customerEmail,
        string $subject, string $description, string $priority = 'normal'
    ): int {
        $subject     = trim($subject);
        $description = trim($description);
        if ($subject === '' || $description === '') {
            throw new \InvalidArgumentException('Subject and description required.');
        }
        if (!in_array($priority, self::PRIORITIES, true)) $priority = 'normal';

        $policy = $this->policyFor($priority);
        $now    = time();

        // Generate a unique reference. 8 random alnum chars gives a
        // 32^8 ≈ 10^12 space; retry-on-collision handles the birthday
        // paradox for any realistic volume.
        $reference = null;
        for ($i = 0; $i < 5; $i++) {
            $cand = $this->generateReference();
            $exists = $this->db->fetchOne("SELECT 1 FROM tickets WHERE reference = ?", [$cand]);
            if (!$exists) { $reference = $cand; break; }
        }
        if ($reference === null) {
            throw new \RuntimeException('Could not generate a unique reference.');
        }

        return (int) $this->db->insert('tickets', [
            'reference'             => $reference,
            'subject'               => substr($subject, 0, 191),
            'description'           => $description,
            'customer_user_id'      => $customerUserId,
            'customer_email'        => substr($customerEmail, 0, 191),
            'priority'              => $priority,
            'status'                => 'open',
            'first_response_due_at' => date('Y-m-d H:i:s', $now + ((int) $policy['first_response_minutes']) * 60),
            'resolution_due_at'     => date('Y-m-d H:i:s', $now + ((int) $policy['resolution_minutes'])     * 60),
        ]);
    }

    public function addReply(int $ticketId, ?int $userId, string $body, bool $internal, bool $isStaff): int
    {
        $body = trim($body);
        if ($body === '') throw new \InvalidArgumentException('Reply body is empty.');

        $id = (int) $this->db->insert('ticket_replies', [
            'ticket_id' => $ticketId,
            'user_id'   => $userId,
            'body'      => $body,
            'internal'  => $internal ? 1 : 0,
        ]);

        // First staff (non-internal) reply satisfies the response SLA.
        if ($isStaff && !$internal) {
            $t = $this->find($ticketId);
            if ($t && $t['first_responded_at'] === null) {
                $this->db->update('tickets',
                    ['first_responded_at' => date('Y-m-d H:i:s')],
                    'id = ?', [$ticketId]
                );
            }
            // Reopen resolved/closed when a non-internal staff reply arrives?
            // No — the customer reopen flow handles that. Staff replies on
            // resolved tickets are follow-up clarifications.
        }

        // Customer reply on a resolved ticket → reopened.
        if (!$isStaff) {
            $t = $this->find($ticketId);
            if ($t && in_array($t['status'], ['resolved','closed'], true)) {
                $this->db->update('tickets',
                    ['status' => 'reopened'], 'id = ?', [$ticketId]
                );
            }
        }
        return $id;
    }

    public function assign(int $ticketId, ?int $userId): void
    {
        $this->db->update('tickets', ['assigned_user_id' => $userId], 'id = ?', [$ticketId]);
    }

    public function setStatus(int $ticketId, string $status): void
    {
        if (!in_array($status, self::STATUSES, true)) {
            throw new \InvalidArgumentException("Unknown status: $status");
        }
        $updates = ['status' => $status];
        if ($status === 'resolved') $updates['resolved_at'] = date('Y-m-d H:i:s');
        if ($status === 'closed')   $updates['closed_at']   = date('Y-m-d H:i:s');
        $this->db->update('tickets', $updates, 'id = ?', [$ticketId]);
    }

    public function setPriority(int $ticketId, string $priority): void
    {
        if (!in_array($priority, self::PRIORITIES, true)) {
            throw new \InvalidArgumentException("Unknown priority: $priority");
        }
        // Recompute SLAs only if the ticket hasn't been responded to yet —
        // re-prioritising a ticket after first response just re-targets the
        // resolution clock, not the response clock.
        $t = $this->find($ticketId);
        if (!$t) return;

        $policy = $this->policyFor($priority);
        $updates = ['priority' => $priority];
        $now     = time();

        if ($t['first_responded_at'] === null) {
            $updates['first_response_due_at'] = date('Y-m-d H:i:s', $now + ((int) $policy['first_response_minutes']) * 60);
        }
        if ($t['resolved_at'] === null) {
            $updates['resolution_due_at']     = date('Y-m-d H:i:s', $now + ((int) $policy['resolution_minutes'])     * 60);
        }
        $this->db->update('tickets', $updates, 'id = ?', [$ticketId]);
    }

    // ── SLA policies ─────────────────────────────────────────────────────

    public function policyFor(string $priority): array
    {
        $row = $this->db->fetchOne(
            "SELECT * FROM helpdesk_sla_policies WHERE priority = ?", [$priority]
        );
        return $row ?: [
            'priority' => $priority,
            'first_response_minutes' => 1440,
            'resolution_minutes' => 4320,
        ];
    }

    /** @return array<int, array<string, mixed>> */
    public function allPolicies(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM helpdesk_sla_policies ORDER BY FIELD(priority,'low','normal','high','urgent')"
        );
    }

    public function updatePolicy(string $priority, int $firstResponseMinutes, int $resolutionMinutes): void
    {
        if (!in_array($priority, self::PRIORITIES, true)) {
            throw new \InvalidArgumentException("Unknown priority: $priority");
        }
        $this->db->update('helpdesk_sla_policies', [
            'first_response_minutes' => max(1, $firstResponseMinutes),
            'resolution_minutes'     => max(1, $resolutionMinutes),
        ], 'priority = ?', [$priority]);
    }

    // ── Internals ────────────────────────────────────────────────────────

    private function generateReference(): string
    {
        $alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no confusables
        $out = '';
        $max = strlen($alphabet) - 1;
        for ($i = 0; $i < 8; $i++) {
            $out .= $alphabet[random_int(0, $max)];
        }
        return $out;
    }
}
