<?php $pageTitle = 'Ticket ' . $ticket['reference']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:760px;margin:0 auto">
<a href="/support" style="color:#6b7280;font-size:13px;text-decoration:none">← Your tickets</a>

<div style="display:flex;justify-content:space-between;align-items:baseline;margin-top:.75rem">
    <h1 style="margin:0"><?= e((string) $ticket['subject']) ?></h1>
    <span class="badge"><?= e((string) $ticket['status']) ?></span>
</div>
<div style="color:#9ca3af;font-size:12px;margin-bottom:1rem">
    <?= e((string) $ticket['reference']) ?> · opened <?= e(date('M j, Y', strtotime((string) $ticket['created_at']))) ?> · priority <?= e((string) $ticket['priority']) ?>
</div>

<?php include __DIR__ . '/../partials/ticket_thread.php'; ?>

<?php if (!in_array($ticket['status'], ['closed'])): ?>
<form method="post" action="/support/<?= e($ticket['reference']) ?>" style="margin-top:1rem">
    <?= csrf_field() ?>
    <label>Add a reply
        <textarea name="body" rows="5" required style="width:100%"></textarea>
    </label>
    <div style="text-align:right;margin-top:.5rem">
        <button type="submit" class="btn btn-primary">Send reply</button>
    </div>
</form>
<?php else: ?>
<div style="margin-top:1rem;color:#9ca3af;font-size:13px">This ticket is closed.</div>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
