<?php $pageTitle = 'Support'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Support</h1>

<div style="display:grid;gap:1.5rem;grid-template-columns:2fr 1fr">
<div>
    <h2 style="font-size:1.1rem">Your tickets</h2>
    <?php if (empty($tickets)): ?>
    <div class="card"><div class="card-body" style="color:#9ca3af;text-align:center;padding:2rem 1rem">
        You haven't opened any tickets yet.
    </div></div>
    <?php else: ?>
    <div class="card" style="padding:0">
    <?php foreach ($tickets as $t): ?>
    <a href="/support/<?= e($t['reference']) ?>" style="display:block;padding:.75rem 1rem;border-bottom:1px solid #f3f4f6;color:inherit;text-decoration:none">
        <div style="display:flex;justify-content:space-between;align-items:baseline">
            <div>
                <strong><?= e((string) $t['subject']) ?></strong>
                <span style="color:#9ca3af;font-size:12px">· <?= e((string) $t['reference']) ?></span>
            </div>
            <span class="badge"><?= e((string) $t['status']) ?></span>
        </div>
        <div style="color:#6b7280;font-size:12px;margin-top:.25rem">
            <?= e(date('M j, Y H:i', strtotime((string) $t['created_at']))) ?> · priority <?= e((string) $t['priority']) ?>
        </div>
    </a>
    <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<div>
    <div class="card">
        <div class="card-header"><strong>Open a ticket</strong></div>
        <form method="post" action="/support">
            <?= csrf_field() ?>
            <div class="card-body">
                <label>Subject
                    <input name="subject" required maxlength="191" style="width:100%">
                </label>
                <label style="display:block;margin-top:.5rem">Priority
                    <select name="priority">
                        <?php foreach ($priorities as $p): ?>
                        <option value="<?= e($p) ?>" <?= $p === 'normal' ? 'selected' : '' ?>><?= ucfirst($p) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label style="display:block;margin-top:.5rem">Describe the issue
                    <textarea name="description" rows="5" required style="width:100%"></textarea>
                </label>
            </div>
            <div class="card-footer" style="padding:.5rem 1rem;text-align:right;background:#f9fafb">
                <button type="submit" class="btn btn-primary">Submit ticket</button>
            </div>
        </form>
    </div>
</div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
