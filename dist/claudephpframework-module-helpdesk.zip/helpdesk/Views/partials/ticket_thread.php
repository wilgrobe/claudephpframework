<?php
// modules/helpdesk/Views/partials/ticket_thread.php
// Expects: $ticket, $replies, plus optional $showInternal (bool).
?>
<div class="card" style="margin-bottom:.75rem">
    <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start">
            <div>
                <strong><?= e((string) ($ticket['customer_username'] ?? $ticket['customer_email'] ?? 'customer')) ?></strong>
                <span style="color:#9ca3af;font-size:12px">· <?= e(date('M j, Y H:i', strtotime((string) $ticket['created_at']))) ?></span>
            </div>
        </div>
        <div style="margin-top:.5rem;white-space:pre-wrap"><?= nl2br(e((string) $ticket['description'])) ?></div>
    </div>
</div>

<?php foreach ($replies as $r): ?>
<div class="card" style="margin-bottom:.5rem;<?= (int) $r['internal'] === 1 ? 'background:#fef9c3;border-left:4px solid #f59e0b' : '' ?>">
    <div class="card-body" style="padding:.5rem .75rem">
        <div style="display:flex;justify-content:space-between;align-items:baseline">
            <div>
                <strong><?= e((string) ($r['username'] ?? 'system')) ?></strong>
                <?php if ((int) $r['internal'] === 1): ?>
                <span class="badge badge-warning" style="margin-left:.25rem">internal</span>
                <?php endif; ?>
            </div>
            <span style="color:#9ca3af;font-size:11px"><?= e(date('M j H:i', strtotime((string) $r['created_at']))) ?></span>
        </div>
        <div style="margin-top:.25rem;white-space:pre-wrap"><?= nl2br(e((string) $r['body'])) ?></div>
    </div>
</div>
<?php endforeach; ?>
