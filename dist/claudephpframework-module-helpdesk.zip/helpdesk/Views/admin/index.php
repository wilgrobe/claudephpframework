<?php $pageTitle = 'Helpdesk queue'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Helpdesk <span style="color:#9ca3af;font-size:13px">(<?= (int) $total ?>)</span></h2>
        <a href="/admin/helpdesk/sla" class="btn btn-sm btn-secondary">SLA policies</a>
    </div>
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem;flex-wrap:wrap">
        <?php foreach (['open','in_progress','on_hold','resolved','closed','reopened'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= ($filters['status'] ?? '') === $s ? 'btn-primary' : 'btn-secondary' ?>">
            <?= ucwords(str_replace('_',' ',$s)) ?> <span style="opacity:.7;margin-left:.25rem">(<?= (int) ($counts[$s] ?? 0) ?>)</span>
        </a>
        <?php endforeach; ?>
        <a href="?overdue=1" class="btn btn-sm btn-danger" style="margin-left:auto">Overdue</a>
        <a href="?mine=1" class="btn btn-sm btn-secondary">Mine</a>
        <a href="?unassigned=1" class="btn btn-sm btn-secondary">Unassigned</a>
    </div>
    <?php if (empty($tickets)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No tickets match.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Ref</th><th>Subject</th><th>Customer</th><th>Priority</th><th>Status</th><th>Assignee</th><th>Overdue</th><th>Opened</th></tr></thead>
        <tbody>
        <?php foreach ($tickets as $t): ?>
        <tr<?= (int) ($t['overdue'] ?? 0) === 1 ? ' style="background:#fef2f2"' : '' ?>>
            <td style="font-family:monospace"><a href="/admin/helpdesk/tickets/<?= (int) $t['id'] ?>"><?= e((string) $t['reference']) ?></a></td>
            <td><?= e((string) $t['subject']) ?></td>
            <td style="font-size:13px"><?= e((string) ($t['customer_username'] ?? $t['customer_email'])) ?></td>
            <td><?= e((string) $t['priority']) ?></td>
            <td><?= e((string) $t['status']) ?></td>
            <td><?= e((string) ($t['assignee_username'] ?? '—')) ?></td>
            <td><?= (int) ($t['overdue'] ?? 0) === 1 ? '⚠' : '' ?></td>
            <td style="font-size:12px"><?= e(date('M j H:i', strtotime((string) $t['created_at']))) ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
