<?php $pageTitle = 'Ticket ' . $ticket['reference']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<a href="/admin/helpdesk" style="color:#6b7280;font-size:13px;text-decoration:none">← Queue</a>
<div style="display:flex;justify-content:space-between;align-items:baseline;margin-top:.5rem">
    <h1 style="margin:0"><?= e((string) $ticket['subject']) ?></h1>
    <div>
        <code><?= e((string) $ticket['reference']) ?></code>
        <span class="badge"><?= e((string) $ticket['status']) ?></span>
        <span class="badge"><?= e((string) $ticket['priority']) ?></span>
    </div>
</div>
<div style="color:#9ca3af;font-size:12px;margin-bottom:1rem">
    Customer: <?= e((string) ($ticket['customer_email'] ?? '')) ?>
    · opened <?= e(date('M j, Y H:i', strtotime((string) $ticket['created_at']))) ?>
    <?php if (!empty($ticket['first_response_due_at']) && empty($ticket['first_responded_at'])): ?>
    · <span style="color:<?= strtotime((string) $ticket['first_response_due_at']) < time() ? '#b91c1c' : '#f59e0b' ?>">
        response due <?= e(date('M j H:i', strtotime((string) $ticket['first_response_due_at']))) ?>
      </span>
    <?php endif; ?>
    <?php if (!empty($ticket['resolution_due_at']) && empty($ticket['resolved_at'])): ?>
    · <span style="color:<?= strtotime((string) $ticket['resolution_due_at']) < time() ? '#b91c1c' : '#6b7280' ?>">
        resolution due <?= e(date('M j H:i', strtotime((string) $ticket['resolution_due_at']))) ?>
      </span>
    <?php endif; ?>
</div>

<div style="display:grid;gap:1rem;grid-template-columns:2fr 1fr">
<div>
    <?php include __DIR__ . '/../partials/ticket_thread.php'; ?>

    <form method="post" action="/admin/helpdesk/tickets/<?= (int) $ticket['id'] ?>/reply" style="margin-top:1rem">
        <?= csrf_field() ?>
        <label>Add a reply
            <textarea name="body" rows="5" required style="width:100%"></textarea>
        </label>
        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:.5rem">
            <label style="font-size:13px"><input type="checkbox" name="internal" value="1"> Internal note (staff only)</label>
            <button type="submit" class="btn btn-primary">Send</button>
        </div>
    </form>
</div>

<aside>
    <div class="card">
        <div class="card-header"><strong>Assign</strong></div>
        <form method="post" action="/admin/helpdesk/tickets/<?= (int) $ticket['id'] ?>/assign">
            <?= csrf_field() ?>
            <div class="card-body">
                <select name="assigned_user_id" style="width:100%">
                    <option value="">(unassigned)</option>
                    <?php foreach ($staff as $u): ?>
                    <option value="<?= (int) $u['id'] ?>" <?= (int) $ticket['assigned_user_id'] === (int) $u['id'] ? 'selected' : '' ?>>
                        <?= e((string) $u['username']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="card-footer" style="padding:.5rem;text-align:right;background:#f9fafb">
                <button type="submit" class="btn btn-sm btn-primary">Save</button>
            </div>
        </form>
    </div>

    <div class="card" style="margin-top:.75rem">
        <div class="card-header"><strong>Status / priority</strong></div>
        <div class="card-body">
            <form method="post" action="/admin/helpdesk/tickets/<?= (int) $ticket['id'] ?>/status" style="display:flex;gap:.5rem">
                <?= csrf_field() ?>
                <select name="status">
                    <?php foreach (['open','in_progress','on_hold','resolved','closed','reopened'] as $s): ?>
                    <option value="<?= e($s) ?>" <?= $ticket['status'] === $s ? 'selected' : '' ?>><?= ucwords(str_replace('_',' ',$s)) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-secondary">Set</button>
            </form>
            <form method="post" action="/admin/helpdesk/tickets/<?= (int) $ticket['id'] ?>/priority" style="display:flex;gap:.5rem;margin-top:.5rem">
                <?= csrf_field() ?>
                <select name="priority">
                    <?php foreach (['low','normal','high','urgent'] as $p): ?>
                    <option value="<?= e($p) ?>" <?= $ticket['priority'] === $p ? 'selected' : '' ?>><?= ucfirst($p) ?></option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-sm btn-secondary">Set</button>
            </form>
        </div>
    </div>
</aside>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
