<?php $pageTitle = 'Helpdesk SLAs'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<a href="/admin/helpdesk" style="color:#6b7280;font-size:13px;text-decoration:none">← Queue</a>

<div class="card" style="margin-top:.5rem">
    <div class="card-header"><h2 style="margin:0">SLA policies</h2></div>
    <div class="card-body">
        <p style="color:#6b7280;font-size:13px">Minutes from ticket creation until first response and until resolution. Edits don't retroactively re-date historical tickets.</p>
        <?php foreach ($policies as $p): ?>
        <form method="post" action="/admin/helpdesk/sla/<?= e($p['priority']) ?>" style="display:flex;gap:.5rem;align-items:end;padding:.5rem 0;border-bottom:1px solid #f3f4f6">
            <?= csrf_field() ?>
            <div style="width:100px"><strong><?= ucfirst((string) $p['priority']) ?></strong></div>
            <label style="flex:1">First response (min)
                <input type="number" name="first_response_minutes" value="<?= (int) $p['first_response_minutes'] ?>" style="width:100%">
            </label>
            <label style="flex:1">Resolution (min)
                <input type="number" name="resolution_minutes" value="<?= (int) $p['resolution_minutes'] ?>" style="width:100%">
            </label>
            <button type="submit" class="btn btn-sm btn-primary">Save</button>
        </form>
        <?php endforeach; ?>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
