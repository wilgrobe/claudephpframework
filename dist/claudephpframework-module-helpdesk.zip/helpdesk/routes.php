<?php
// modules/helpdesk/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$S = 'Modules\Helpdesk\Controllers\SupportController';
$A = 'Modules\Helpdesk\Controllers\HelpdeskAdminController';

// ── Customer ─────────────────────────────────────────────────────────────
$router->get ('/support',                       "$S@index",  [AuthMiddleware::class]);
$router->post('/support',                       "$S@create", [CsrfMiddleware::class, AuthMiddleware::class]);
$router->get ('/support/{ref}',                 "$S@show",   [AuthMiddleware::class]);
$router->post('/support/{ref}',                 "$S@reply",  [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Staff (helpdesk.manage checked in controller) ────────────────────────
$admin     = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];

$router->get ('/admin/helpdesk',                         "$A@index",    $admin);
$router->get ('/admin/helpdesk/tickets/{id}',            "$A@show",     $admin);
$router->post('/admin/helpdesk/tickets/{id}/reply',      "$A@reply",    $adminCsrf);
$router->post('/admin/helpdesk/tickets/{id}/assign',     "$A@assign",   $adminCsrf);
$router->post('/admin/helpdesk/tickets/{id}/status',     "$A@status",   $adminCsrf);
$router->post('/admin/helpdesk/tickets/{id}/priority',   "$A@priority", $adminCsrf);

$router->get ('/admin/helpdesk/sla',                     "$A@slaIndex", $admin);
$router->post('/admin/helpdesk/sla/{priority}',          "$A@slaUpdate",$adminCsrf);
