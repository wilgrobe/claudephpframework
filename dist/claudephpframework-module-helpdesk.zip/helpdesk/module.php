<?php
// modules/helpdesk/module.php
use Core\Module\ModuleProvider;

/**
 * Helpdesk module — ticket system with SLAs.
 *
 * Customer portal at /support, staff queue at /admin/helpdesk.
 * Four priorities × SLA policies (first-response + resolution). SLA
 * timestamps are snapshotted at create time so tuning policies later
 * doesn't retroactively overdue historical tickets.
 *
 * Reply model is self-contained (ticket_replies with an `internal`
 * flag for staff-only notes) rather than reusing the comments module;
 * the shape is narrower and the internal-flag distinction doesn't
 * translate cleanly to polymorphic commenting.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'helpdesk'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
