# Architecture — Helpdesk module

## Files

```
helpdesk/
├── module.php
├── routes.php                      # 11 routes
├── Controllers/
│   ├── SupportController.php       # Customer portal
│   └── HelpdeskAdminController.php # Staff queue + SLA
├── Services/TicketService.php      # CRUD + SLA math
├── Views/
│   ├── public/{index,show}.php
│   ├── admin/{index,show,sla}.php
│   └── partials/ticket_thread.php
└── migrations/{create_tables, seed_permission}.php
```

## Data model

```
tickets:
  id, reference (unique 8-char), subject, description,
  customer_user_id NULL, customer_email,
  assigned_user_id NULL,
  priority ENUM, status ENUM,
  first_response_due_at, resolution_due_at,
  first_responded_at, resolved_at, closed_at,
  timestamps

ticket_replies:
  id, ticket_id (CASCADE), user_id NULL, body, internal, created_at

helpdesk_sla_policies:
  priority PK, first_response_minutes, resolution_minutes
```

## SLA math

At ticket creation:
- `first_response_due_at = NOW + policy.first_response_minutes`
- `resolution_due_at     = NOW + policy.resolution_minutes`

When a ticket's priority changes and it's not yet responded/resolved,
the unfulfilled clocks re-target from NOW with the new priority's
policy. Already-met clocks stay.

The overdue flag is computed in SQL (not Python/PHP post-processing)
so filters + counts are correct across pagination:

```sql
CASE
  WHEN status IN ('resolved','closed') THEN 0
  WHEN (first_responded_at IS NULL AND first_response_due_at < NOW())
    OR (resolved_at        IS NULL AND resolution_due_at    < NOW())
  THEN 1 ELSE 0
END
```

## Reply lifecycle edge cases

- **First non-internal staff reply** → stamps `first_responded_at`.
- **Customer reply on resolved/closed** → status flips to `reopened`.
- **Staff reply on resolved** → status stays (it's a follow-up, not a
  re-open).

## Why not reuse the comments module?

Ticket replies need an `internal` flag. Comments are polymorphic and
public-by-construction. Cramming an internal-flag into comments would
muddle its semantics and cost filter-path clarity on the comments
side. The helpdesk is narrow enough (one subject per ticket, linear
thread, no nesting) that a purpose-built table is cleaner.
