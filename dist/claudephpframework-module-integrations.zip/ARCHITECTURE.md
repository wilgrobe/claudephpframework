# Architecture — Integrations module

## Files

```
integrations/
├── module.php
├── routes.php                                            # 2 routes
├── Controllers/IntegrationController.php                 # index + test probe
└── Views/index.php                                        # Dashboard UI
```

## How it works

The `index` action reads `Core\Services\IntegrationConfig::config()` for
every known integration category and displays:

- Configured driver name (from `_VAR` env)
- Whether required env vars are populated
- Per-integration `isEnabled()` result

The `test` POST endpoint dispatches on `type` (integration key) and calls
a cheap provider probe:

- `email` — queue a probe message through MailService with `to` = the
  caller's own email
- `search` — hit the provider's `/health` or equivalent
- `sms` — (requires a target phone; admin enters one in the test form)
- `payments` — trivial `call()` that hits a list endpoint
- `captcha` — validates a constant token; provider returns "invalid" which
  confirms the endpoint is reachable
- `cdn` — reads a status URL on the provider

Each probe returns `{ok: bool, message: string}`; the view flashes the
outcome.

## Authorization

Both routes require `AuthMiddleware + RequireSuperadmin`. `RequireSuperadmin`
checks both `is_superadmin = 1` in the DB and `superadmin_mode = true` in
the session.

## Why it doesn't write config

`IntegrationConfig` is strictly read-only in this codebase — all
credentials come from `.env`. Allowing admins to rotate production
secrets from a web form would make session compromise catastrophic. If
you want a config-writing surface, design it separately with additional
auditing + an envelope-encrypted store; don't extend this module.

## Dependencies

- `claudephpframework-core` — IntegrationConfig, concrete services
  (MailService, SearchService, PaymentsService, SentryService,
  CaptchaService, CdnService), Auth, View
