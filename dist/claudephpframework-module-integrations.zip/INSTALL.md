# Installation — Integrations module

## Prerequisites

- `claudephpframework-core` installed.
- At least one superadmin account (with `is_superadmin=1` in `users`).
- Superadmin mode toggled ON in the session to access
  `/admin/integrations` — this is the standard gate used throughout the
  admin surface.

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-integrations.zip
   cp -r claudephpframework-module-integrations/integrations /path/to/project/modules/
   ```

2. Run migrations (none ship):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if enabled:
   ```bash
   php artisan module:cache
   ```

## Environment variables

This module doesn't introduce any — it reads whatever `IntegrationConfig`
reads (`MAIL_*`, `SEARCH_*`, `PAYMENT_*`, `SENTRY_DSN`, `CAPTCHA_*`,
`CDN_*`, `VIDEO_*`, etc.). See core's `.env.example` for the full catalog.

## Verification

1. Log in as a superadmin, toggle superadmin mode on.
2. Visit `/admin/integrations`.
3. Each row shows: integration name, driver, status.
4. Click **Test** on one you've configured — expected outcome depends on
   the integration (see ARCHITECTURE.md for what each probe does).
