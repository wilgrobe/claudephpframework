# Integrations module

Superadmin dashboard showing the status of every third-party integration
the framework knows about (mail, SMS, search, storage, payments, Sentry,
captcha, CDN, video), plus one-click "test probe" actions that verify each
configured provider actually works.

## Features

- Read-only inventory: for each integration, shows the currently-selected
  driver and whether it's configured + reachable
- "Test" button per integration — fires a cheap live call and reports back
- No configuration surface: all credentials live in `.env` via
  `IntegrationConfig`. This module never writes config — a deliberate
  security posture so a compromised admin session can't rotate production
  secrets from the browser.

## Routes

| Method | Path                           | Middleware                   | Purpose                   |
|--------|--------------------------------|------------------------------|---------------------------|
| GET    | `/admin/integrations`          | Auth + Superadmin            | Dashboard                 |
| POST   | `/admin/integrations/test`     | Csrf + Auth + Superadmin     | Test a named integration  |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
