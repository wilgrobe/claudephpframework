# Installation — Notifications module

## Prerequisites

- `claudephpframework-core` installed (includes `NotificationService`).
- Core table `notifications` present (from `install.sql`).

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-notifications.zip
   cp -r claudephpframework-module-notifications/notifications /path/to/project/modules/
   ```

2. Run migrations (none ship):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if enabled:
   ```bash
   php artisan module:cache
   ```

## Environment variables

None.

## Including the bell badge in your layout

A typical header includes a polling bell badge:

```html
<a href="/notifications" id="bell">
  <svg>...</svg>
  <span class="badge" id="unread-count" style="display:none">0</span>
</a>
<script>
setInterval(async () => {
  const r = await fetch('/notifications/count', {credentials: 'same-origin'});
  const d = await r.json();
  const el = document.getElementById('unread-count');
  el.textContent = d.unread || 0;
  el.style.display = d.unread > 0 ? 'inline' : 'none';
}, 30000);
</script>
```

Adjust the polling interval to taste — 30s is reasonable for most apps.

## Verification

1. Log in.
2. Dispatch a test notification from a controller or console:
   ```php
   app(\Core\Services\NotificationService::class)
       ->create(userId: $auth->id(), title: 'Test', body: 'Hello');
   ```
3. Visit `/notifications` — your test notification appears.
4. GET `/notifications/count` returns `{"unread": 1}`.
