# Notifications module

Per-user notification inbox UI. Other modules dispatch notifications via
`NotificationService` (which lives in core); this module provides the
reader's experience — list, mark-read, unread-count badge.

## Features

- Paginated list of notifications scoped to the current user
- Per-notification "mark as read", "delete" actions
- Bulk "mark all read"
- JSON `/notifications/count` endpoint for header bell-badge polling

## Routes

| Method | Path                                | Middleware         | Purpose                  |
|--------|-------------------------------------|--------------------|--------------------------|
| GET    | `/notifications`                    | Auth               | Inbox view               |
| POST   | `/notifications/mark-all-read`      | Csrf + Auth        | Bulk mark-read           |
| POST   | `/notifications/{id}/read`          | Csrf + Auth        | Mark one read            |
| POST   | `/notifications/{id}/delete`        | Csrf + Auth        | Delete one               |
| GET    | `/notifications/count`              | Auth               | JSON unread count        |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
