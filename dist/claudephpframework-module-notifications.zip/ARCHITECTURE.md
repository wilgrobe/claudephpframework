# Architecture — Notifications module

## Files

```
notifications/
├── module.php
├── routes.php                                       # 5 routes
├── Controllers/NotificationsController.php          # Read + actions
└── Views/index.php                                  # Inbox
```

## Tables

- `notifications` — id, user_id, title, body, link_url (nullable), read_at
  (nullable), created_at. From core's `install.sql`.

## Service split

- **NotificationService** — in core. Has `create(int $userId, string $title,
  string $body, ?string $link = null)`. Other modules and controllers call
  this to dispatch.
- **NotificationsController** — in this module. Read-only and scoped to
  `user_id = $auth->id()` everywhere. Never fans out to other users.

This split keeps notification *creation* available everywhere (even if the
reader UI isn't installed) while the reader UI stays swappable.

## Authorization

`AuthMiddleware` on every route. Inside the controller, every query filters
by `user_id = ?` — a user can only see and modify their own notifications
(`WHERE id = ? AND user_id = ?` on mark-read / delete to enforce IDOR-safety).

## JSON endpoint

`/notifications/count` returns `{"unread": N}` for header bell-badge
polling. No pagination, no list — just a single aggregate. Cheap enough to
poll every 30s for an active user.

## Dependencies

- `claudephpframework-core` — NotificationService (creation), Auth, View
- Core's `notifications` table
