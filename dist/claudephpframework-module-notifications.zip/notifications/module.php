<?php
// modules/notifications/module.php
use Core\Module\ModuleProvider;

/**
 * Notifications module — per-user notification inbox + bell counter endpoint.
 * The NotificationService that writes notifications stays in core/Services/
 * (other modules dispatch to it); this module just owns the read/manage UI.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'notifications'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
