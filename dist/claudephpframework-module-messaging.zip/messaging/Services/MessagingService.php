<?php
// modules/messaging/Services/MessagingService.php
namespace Modules\Messaging\Services;

use Core\Database\Database;

/**
 * Direct-message domain logic.
 *
 * Participants are normalized: user_a_id < user_b_id always, so the
 * pair-unique key covers both directions with a single row. Reads
 * provide a `me` perspective — `partnerIdFor` tells a controller
 * which column to inspect for read state, and all list methods
 * take the viewer's user id so they can shape the output.
 *
 * A follow-gate can be layered externally: the social module's
 * FollowService could be consulted before `send()` to enforce a
 * "must follow me" policy. Kept out of here so messaging stands on
 * its own without a social dependency.
 */
class MessagingService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Find or create the conversation row for users $a and $b.
     * Normalizes the pair. Throws when a == b (can't DM yourself).
     */
    public function findOrCreateConversation(int $a, int $b): array
    {
        if ($a === $b) throw new \InvalidArgumentException('Cannot DM yourself.');
        [$lo, $hi] = [min($a, $b), max($a, $b)];

        $row = $this->db->fetchOne(
            "SELECT * FROM conversations WHERE user_a_id = ? AND user_b_id = ?",
            [$lo, $hi]
        );
        if ($row) return $row;

        $id = (int) $this->db->insert('conversations', [
            'user_a_id' => $lo, 'user_b_id' => $hi,
        ]);
        return [
            'id' => $id, 'user_a_id' => $lo, 'user_b_id' => $hi,
            'last_message_at' => null,
            'last_read_by_a_at' => null, 'last_read_by_b_at' => null,
        ];
    }

    public function findConversation(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM conversations WHERE id = ?", [$id]);
    }

    /** Return the other participant's user_id for a viewer — null if viewer not a participant. */
    public function partnerIdFor(array $conv, int $viewerId): ?int
    {
        if ((int) $conv['user_a_id'] === $viewerId) return (int) $conv['user_b_id'];
        if ((int) $conv['user_b_id'] === $viewerId) return (int) $conv['user_a_id'];
        return null;
    }

    public function isParticipant(array $conv, int $userId): bool
    {
        return $this->partnerIdFor($conv, $userId) !== null;
    }

    /**
     * Inbox for a user — conversations joined to the partner's username
     * and the latest message body. Newest-active-at the top.
     *
     * @return array<int, array<string, mixed>>
     */
    public function inboxFor(int $userId, int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT c.*,
                    CASE WHEN c.user_a_id = ? THEN c.user_b_id ELSE c.user_a_id END AS partner_id,
                    CASE WHEN c.user_a_id = ? THEN ub.username ELSE ua.username END AS partner_username,
                    CASE WHEN c.user_a_id = ? THEN c.last_read_by_a_at ELSE c.last_read_by_b_at END AS my_last_read_at,
                    (SELECT body FROM messages m WHERE m.conversation_id = c.id AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT 1) AS last_body,
                    (SELECT user_id FROM messages m WHERE m.conversation_id = c.id AND m.deleted_at IS NULL ORDER BY m.id DESC LIMIT 1) AS last_sender_id
               FROM conversations c
          LEFT JOIN users ua ON ua.id = c.user_a_id
          LEFT JOIN users ub ON ub.id = c.user_b_id
              WHERE c.user_a_id = ? OR c.user_b_id = ?
           ORDER BY COALESCE(c.last_message_at, c.created_at) DESC
              LIMIT ?",
            [$userId, $userId, $userId, $userId, $userId, $limit]
        );
    }

    /**
     * Messages in a conversation, oldest first. Soft-deleted rows are
     * excluded. Viewers filtered by `isParticipant` at the controller.
     *
     * @return array<int, array<string, mixed>>
     */
    public function messagesFor(int $conversationId, int $limit = 200): array
    {
        return $this->db->fetchAll(
            "SELECT m.*, u.username
               FROM messages m
          LEFT JOIN users u ON u.id = m.user_id
              WHERE m.conversation_id = ?
                AND m.deleted_at IS NULL
           ORDER BY m.created_at ASC
              LIMIT ?",
            [$conversationId, $limit]
        );
    }

    public function send(int $conversationId, int $userId, string $body): int
    {
        $body = trim($body);
        if ($body === '') throw new \InvalidArgumentException('Message body is empty.');
        if (mb_strlen($body) > 10000) throw new \InvalidArgumentException('Message is too long.');

        $conv = $this->findConversation($conversationId);
        if (!$conv || !$this->isParticipant($conv, $userId)) {
            throw new \InvalidArgumentException('Not a participant in that conversation.');
        }

        $id = (int) $this->db->insert('messages', [
            'conversation_id' => $conversationId,
            'user_id'         => $userId,
            'body'            => $body,
        ]);
        $now = date('Y-m-d H:i:s');

        // Mirror last_message_at + treat sender as "read through" their own
        // send so we don't count outgoing messages as unread for them.
        $upd = ['last_message_at' => $now];
        if ((int) $conv['user_a_id'] === $userId) $upd['last_read_by_a_at'] = $now;
        else                                      $upd['last_read_by_b_at'] = $now;

        $this->db->update('conversations', $upd, 'id = ?', [$conversationId]);
        return $id;
    }

    public function softDeleteMessage(int $messageId, int $userId): void
    {
        $m = $this->db->fetchOne("SELECT * FROM messages WHERE id = ?", [$messageId]);
        if (!$m || (int) $m['user_id'] !== $userId) return; // author-only
        $this->db->update('messages', ['deleted_at' => date('Y-m-d H:i:s')], 'id = ?', [$messageId]);
    }

    /**
     * Mark a conversation read up to now for the given viewer. Cheap —
     * one UPDATE on the conversation row.
     */
    public function markRead(int $conversationId, int $userId): void
    {
        $conv = $this->findConversation($conversationId);
        if (!$conv || !$this->isParticipant($conv, $userId)) return;
        $now = date('Y-m-d H:i:s');
        $col = ((int) $conv['user_a_id'] === $userId) ? 'last_read_by_a_at' : 'last_read_by_b_at';
        $this->db->update('conversations', [$col => $now], 'id = ?', [$conversationId]);
    }

    /**
     * Total unread-conversations count for a viewer. "Unread" means at
     * least one message exists that was sent after the viewer's
     * `last_read_by_*_at` timestamp, and the sender isn't the viewer.
     * Single query — used by the bell-badge.
     */
    public function unreadConversationCount(int $userId): int
    {
        return (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM conversations c
              WHERE (c.user_a_id = ? OR c.user_b_id = ?)
                AND c.last_message_at IS NOT NULL
                AND (
                     (c.user_a_id = ? AND (c.last_read_by_a_at IS NULL OR c.last_message_at > c.last_read_by_a_at))
                  OR (c.user_b_id = ? AND (c.last_read_by_b_at IS NULL OR c.last_message_at > c.last_read_by_b_at))
                )
                AND EXISTS (
                    SELECT 1 FROM messages m
                     WHERE m.conversation_id = c.id
                       AND m.user_id <> ?
                       AND m.deleted_at IS NULL
                )",
            [$userId, $userId, $userId, $userId, $userId]
        );
    }
}
