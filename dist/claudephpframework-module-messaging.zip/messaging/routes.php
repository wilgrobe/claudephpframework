<?php
// modules/messaging/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;

$M = 'Modules\Messaging\Controllers\MessagingController';

$router->get ('/messages',                           "$M@inbox",    [AuthMiddleware::class]);
$router->get ('/messages/with/{username}',           "$M@withUser", [AuthMiddleware::class]);
$router->get ('/messages/{id}',                      "$M@show",     [AuthMiddleware::class]);
$router->post('/messages/{id}',                      "$M@send",     [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/messages/{id}/delete-msg/{msgId}',   "$M@deleteMessage", [CsrfMiddleware::class, AuthMiddleware::class]);
