<?php
// modules/messaging/Helpers/helpers.php
/**
 * Global helpers for messaging.
 *
 *   <?= dm_unread_count() ?>         // cheap integer for badges
 *   <?= dm_link_to(@$user['username']) ?>  // "Message" button
 */

if (!function_exists('dm_unread_count')) {
    function dm_unread_count(): int
    {
        $auth = \Core\Auth\Auth::getInstance();
        if ($auth->guest()) return 0;
        return (new \Modules\Messaging\Services\MessagingService())
            ->unreadConversationCount((int) $auth->id());
    }
}

if (!function_exists('dm_link_to')) {
    /**
     * Render a "Message" link to /messages/with/{username}. Returns empty
     * string when viewer is guest or same as target.
     */
    function dm_link_to(string $username, string $label = 'Message'): string
    {
        $auth = \Core\Auth\Auth::getInstance();
        if ($auth->guest()) return '';
        $me = $auth->user();
        if (!$me || ($me['username'] ?? null) === $username) return '';

        $href = '/messages/with/' . rawurlencode($username);
        return '<a href="' . htmlspecialchars($href, ENT_QUOTES | ENT_HTML5, 'UTF-8') . '" class="btn btn-sm btn-secondary">'
             . htmlspecialchars($label, ENT_QUOTES | ENT_HTML5, 'UTF-8')
             . '</a>';
    }
}
