<?php
// modules/messaging/module.php
use Core\Container\Container;
use Core\Module\ModuleProvider;

/**
 * Messaging module — 1:1 direct messages. Polling-based (no websockets).
 *
 * Sits alongside the social module but doesn't depend on it — a site
 * without a follow graph still gets DMs. Apps that want a "mutual
 * follow required to DM" gate can layer that in their controller by
 * consulting FollowService before calling MessagingService::send.
 *
 * Global helpers: dm_unread_count() for the bell badge and
 * dm_link_to($username) for "Message" buttons on profiles.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'messaging'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }

    public function register(Container $container): void
    {
        require_once __DIR__ . '/Helpers/helpers.php';
    }
};
