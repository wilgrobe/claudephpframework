<?php $pageTitle = '@' . ($partner['username'] ?? 'thread'); ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/messages" style="color:#6b7280;text-decoration:none;font-size:13px">← Inbox</a>
    <h1 style="margin:0;font-size:1.25rem"><?= $partner ? '@' . e((string) $partner['username']) : 'Thread' ?></h1>
    <?php if ($partner): ?>
    <a href="/users/<?= e((string) $partner['username']) ?>" style="font-size:13px;color:#6b7280;margin-left:auto">Profile →</a>
    <?php endif; ?>
</div>

<div class="card" style="min-height:300px">
    <div class="card-body" style="display:flex;flex-direction:column;gap:.5rem">
        <?php if (empty($messages)): ?>
        <div style="color:#9ca3af;text-align:center;padding:2rem 0;font-size:13px">
            No messages yet — say hello.
        </div>
        <?php else: ?>
        <?php foreach ($messages as $m): $mine = (int) $m['user_id'] === (int) $me['id']; ?>
        <div style="display:flex;flex-direction:column;align-items:<?= $mine ? 'flex-end' : 'flex-start' ?>">
            <div style="max-width:70%;padding:.5rem .75rem;border-radius:12px;background:<?= $mine ? '#3b82f6' : '#f3f4f6' ?>;color:<?= $mine ? '#fff' : '#111827' ?>">
                <?= nl2br(e((string) $m['body'])) ?>
            </div>
            <div style="font-size:11px;color:#9ca3af;margin-top:.1rem">
                <?= e(date('M j H:i', strtotime((string) $m['created_at']))) ?>
                <?php if ($mine): ?>
                · <form method="post" action="/messages/<?= (int) $conversation['id'] ?>/delete-msg/<?= (int) $m['id'] ?>" style="display:inline" onsubmit="return confirm('Delete message?')">
                    <?= csrf_field() ?>
                    <button type="submit" style="background:none;border:0;color:#9ca3af;cursor:pointer;padding:0">delete</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>

<form method="post" action="/messages/<?= (int) $conversation['id'] ?>" style="margin-top:1rem">
    <?= csrf_field() ?>
    <div style="display:flex;gap:.5rem">
        <textarea name="body" rows="2" required placeholder="Write a message…" style="flex:1;padding:.5rem;border:1px solid #d1d5db;border-radius:4px"></textarea>
        <button type="submit" class="btn btn-primary">Send</button>
    </div>
</form>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
