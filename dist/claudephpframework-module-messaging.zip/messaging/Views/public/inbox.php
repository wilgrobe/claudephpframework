<?php $pageTitle = 'Messages'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Messages</h1>

<?php if (empty($conversations)): ?>
<div class="card"><div class="card-body" style="color:#6b7280;text-align:center;padding:3rem 1rem">
    No conversations yet. Start one from someone's profile.
</div></div>
<?php else: ?>
<div class="card" style="padding:0">
    <?php foreach ($conversations as $c):
        $unread = $c['last_message_at']
            && (int) ($c['last_sender_id'] ?? 0) !== (int) $me['id']
            && (empty($c['my_last_read_at']) || strtotime((string) $c['my_last_read_at']) < strtotime((string) $c['last_message_at'])); ?>
    <a href="/messages/<?= (int) $c['id'] ?>"
       style="display:block;padding:.75rem 1rem;border-bottom:1px solid #f3f4f6;color:inherit;text-decoration:none;background:<?= $unread ? '#fef9c3' : 'transparent' ?>">
        <div style="display:flex;justify-content:space-between;align-items:baseline">
            <strong>@<?= e((string) $c['partner_username']) ?></strong>
            <?php if (!empty($c['last_message_at'])): ?>
            <span style="font-size:11px;color:#9ca3af">
                <?= e(date('M j, H:i', strtotime((string) $c['last_message_at']))) ?>
            </span>
            <?php endif; ?>
        </div>
        <div style="color:#6b7280;font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
            <?php if (!empty($c['last_body'])): ?>
                <?php if ((int) $c['last_sender_id'] === (int) $me['id']): ?><span style="color:#9ca3af">You: </span><?php endif; ?>
                <?= e(mb_substr((string) $c['last_body'], 0, 140)) ?>
            <?php else: ?>
                <span style="color:#9ca3af">(no messages yet)</span>
            <?php endif; ?>
        </div>
    </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
