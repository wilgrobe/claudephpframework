<?php
// modules/messaging/migrations/2026_04_23_130000_create_messaging_tables.php
use Core\Database\Migration;

/**
 * Schema for the messaging module (1:1 DMs).
 *
 *   conversations  — two participants per row. `user_a_id` is always
 *                    the smaller user id so the UNIQUE (user_a_id,
 *                    user_b_id) pair dedups A↔B vs B↔A at the DB
 *                    layer. Controllers that resolve a conversation
 *                    normalize the pair before INSERT via
 *                    MessagingService::findOrCreateConversation.
 *                    `last_message_at` is mirrored from the latest
 *                    message for cheap inbox sorting.
 *                    Per-participant read timestamps sit on this row
 *                    (not on messages) so "unread" is a single column
 *                    compare.
 *
 *   messages       — one row per sent message. Soft-delete via
 *                    `deleted_at`; hard delete would cascade into
 *                    orphaned conversation rows which we keep for
 *                    read-receipt continuity.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE conversations (
                id                      INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_a_id               INT UNSIGNED NOT NULL,
                user_b_id               INT UNSIGNED NOT NULL,
                last_message_at         DATETIME NULL,
                last_read_by_a_at       DATETIME NULL,
                last_read_by_b_at       DATETIME NULL,
                created_at              DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                UNIQUE KEY uq_pair (user_a_id, user_b_id),
                KEY idx_user_a (user_a_id, last_message_at),
                KEY idx_user_b (user_b_id, last_message_at),
                CONSTRAINT chk_pair_order CHECK (user_a_id < user_b_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE messages (
                id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                conversation_id INT UNSIGNED NOT NULL,
                user_id         INT UNSIGNED NOT NULL,
                body            TEXT NOT NULL,
                deleted_at      DATETIME NULL,
                created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                KEY idx_conv_created (conversation_id, created_at),
                KEY idx_user_created (user_id, created_at),
                CONSTRAINT fk_msg_conv
                    FOREIGN KEY (conversation_id) REFERENCES conversations (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS messages");
        $this->db->query("DROP TABLE IF EXISTS conversations");
    }
};
