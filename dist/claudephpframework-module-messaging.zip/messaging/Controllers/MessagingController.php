<?php
// modules/messaging/Controllers/MessagingController.php
namespace Modules\Messaging\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Modules\Messaging\Services\MessagingService;

/**
 *   GET  /messages                  — inbox
 *   GET  /messages/with/{username}  — thread with a named user (creates if missing)
 *   GET  /messages/{id}             — thread by conversation id
 *   POST /messages/{id}             — send a message
 *   POST /messages/{id}/delete-msg/{msgId} — author soft-delete
 */
class MessagingController
{
    private Auth             $auth;
    private Database         $db;
    private MessagingService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->db   = Database::getInstance();
        $this->svc  = new MessagingService();
    }

    public function inbox(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        return Response::view('messaging::public.inbox', [
            'conversations' => $this->svc->inboxFor((int) $this->auth->id()),
            'me'            => $this->auth->user(),
        ]);
    }

    public function withUser(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $username = (string) $request->param(0);
        $partner  = $this->db->fetchOne("SELECT id, username FROM users WHERE username = ?", [$username]);
        if (!$partner) return new Response('User not found', 404);
        if ((int) $partner['id'] === (int) $this->auth->id()) {
            return Response::redirect('/messages')->withFlash('error', "You can't DM yourself.");
        }
        $conv = $this->svc->findOrCreateConversation((int) $this->auth->id(), (int) $partner['id']);
        return Response::redirect('/messages/' . (int) $conv['id']);
    }

    public function show(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id = (int) $request->param(0);
        $conv = $this->svc->findConversation($id);
        if (!$conv) return new Response('Conversation not found', 404);

        $uid          = (int) $this->auth->id();
        $isParticipant = $this->svc->isParticipant($conv, $uid);

        // Non-participants may view only when they can bypass scopes
        // (SA-mode). Participants read + mark-read normally; SA-mode
        // viewers bypass and DON'T touch the participants' read
        // state — the conversation shouldn't appear "read" to the
        // actual participants just because SA peeked at it. Bypass
        // leaves an audit_log row.
        if (!$isParticipant) {
            if (!$this->auth->canBypassScopes()) {
                return new Response('Conversation not found', 404);
            }
            $this->auth->auditBypass('dm_participant', 'conversations', $id);
        } else {
            $this->svc->markRead($id, $uid);
        }

        // Partner display: for participants, the other person; for
        // SA-bypass, show user_a as the nominal "partner" (just a label).
        $partnerId = $isParticipant
            ? $this->svc->partnerIdFor($conv, $uid)
            : (int) $conv['user_a_id'];
        $partner   = $partnerId ? $this->db->fetchOne("SELECT id, username FROM users WHERE id = ?", [$partnerId]) : null;

        return Response::view('messaging::public.thread', [
            'conversation' => $conv,
            'partner'      => $partner,
            'messages'     => $this->svc->messagesFor($id),
            'me'           => $this->auth->user(),
        ]);
    }

    public function send(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $id = (int) $request->param(0);
        try {
            $this->svc->send($id, (int) $this->auth->id(), (string) $request->post('body', ''));
        } catch (\InvalidArgumentException $e) {
            return Response::redirect("/messages/$id")->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/messages/$id");
    }

    public function deleteMessage(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $convId = (int) $request->param(0);
        $msgId  = (int) $request->param(1);
        $this->svc->softDeleteMessage($msgId, (int) $this->auth->id());
        return Response::redirect("/messages/$convId");
    }
}
