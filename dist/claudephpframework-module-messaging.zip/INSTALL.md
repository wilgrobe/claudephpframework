# Installation — Messaging module

## Prerequisites

- `claudephpframework-core`.

## Steps

1. Unzip into `modules/`:
   ```bash
   cp -r claudephpframework-module-messaging/messaging /path/to/project/modules/
   ```
2. Run the migration:
   ```bash
   php artisan migrate
   ```

That's it — the module is self-contained. `dm_unread_count()` and
`dm_link_to()` are registered globally.

## First-use walkthrough

1. Sign in as user A.
2. Visit `/users/bob` (or any other user profile). A "Message" button
   appears courtesy of `dm_link_to` (you may need to drop
   `<?= dm_link_to($profile['username']) ?>` into your profile
   template if it isn't there already — the social module's profile
   view doesn't include it by default).
3. Click it. You land on `/messages/with/bob`, which resolves (or
   creates) the conversation and redirects to `/messages/{id}`.
4. Send messages. Log in as bob in another browser; visit
   `/messages` and see the conversation with an unread highlight.
5. Open the thread — the highlight clears (mark-read is automatic on
   view).

## Environment variables

None.

## Deferred features (v2)

- **Real-time updates** — long-poll or server-sent events on the
  thread view. Current design assumes a page refresh to see new
  messages.
- **Typing indicators** — needs live-channels.
- **Attachments** — pipe through `FileUploadService`.
- **Mutual-follow gate** — check `FollowService::isFollowing($a, $b)`
  and `isFollowing($b, $a)` in `MessagingController::send`. The hook
  is there; the code is five lines.
- **Block list** — `messaging_blocks` table + a check at send time.
  Pair with the moderation module's report → block flow.
- **Group chats** — add `conversation_participants` and switch
  conversations to N-party. Non-trivial data-model change.
- **Message search** — index message bodies in `SearchIndexer` so
  users can find past conversations by keyword.

## Verification

- `php -l modules/messaging/**/*.php`.
- Create two users, send messages back and forth, verify
  `dm_unread_count()` returns the right number.
- Attempt to DM yourself — service throws, controller surfaces an
  error.
- Attempt to POST to a conversation you're not a participant in —
  service throws; controller returns to the thread view.
