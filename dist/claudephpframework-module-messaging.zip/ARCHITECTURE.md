# Architecture — Messaging module

## Files

```
messaging/
├── module.php
├── routes.php                                          # 5 routes
├── Controllers/
│   └── MessagingController.php                         # Inbox, thread, send, delete
├── Services/
│   └── MessagingService.php                            # Conversation resolve, send, read, counts
├── Helpers/
│   └── helpers.php                                     # dm_unread_count(), dm_link_to()
├── Views/
│   └── public/
│       ├── inbox.php
│       └── thread.php
└── migrations/
    └── 2026_04_23_130000_create_messaging_tables.php   # 2 tables
```

## Data model

### `conversations`

```
id, user_a_id, user_b_id,
last_message_at NULL,
last_read_by_a_at NULL, last_read_by_b_at NULL,
created_at
UNIQUE (user_a_id, user_b_id)
CHECK (user_a_id < user_b_id)
```

The pair is normalized (`a < b`) by the service before INSERT so the
unique key dedups A↔B vs B↔A. This is the single most important
invariant in the module — two callers trying to DM each other can't
each create their own row.

### `messages`

```
id BIGINT, conversation_id (CASCADE), user_id,
body, deleted_at NULL, timestamps
```

## Read-state mechanic

Read state is a single column on the conversation row, not per-message.
A message is "unread for user X" if:

- X is a participant, and
- `last_message_at` is set, and
- `last_read_by_{a,b}_at` is null or older than `last_message_at`, and
- at least one non-deleted message exists where `user_id <> X`.

The single-column approach trades a tiny bit of expressiveness (you
can't mark individual old messages unread) for much simpler query
shape. `unreadConversationCount()` is one correlated query — fast
enough for bell-badge polling.

## Helpers

Global, registered in `module.php::register()`:

- `dm_unread_count(): int` — current user's unread conversation count.
  Returns 0 for guests.
- `dm_link_to(string $username, string $label='Message'): string` —
  renders a `<a>` to `/messages/with/{username}`, empty string when
  viewing own profile or as a guest.

## Integration with the social module

The social module doesn't include `dm_link_to` in its profile view by
default (to stay independent of messaging). Drop it in
`modules/social/Views/public/profile.php` if you want a "Message"
button on every profile:

```php
<?= function_exists('dm_link_to') ? dm_link_to((string) $profile['username']) : '' ?>
```

## Deferred work

See INSTALL.md for the v2 backlog.
