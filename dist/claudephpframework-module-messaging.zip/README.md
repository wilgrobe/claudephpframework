# Messaging module

1:1 direct messages. Polling-based (no websockets). Minimum viable
Twitter-DM shape: inbox, thread, send, mark-read, unread badge.

## Features

- **Conversation = normalized pair** of user ids (lower id first +
  schema-level CHECK). UNIQUE (user_a_id, user_b_id) dedups A↔B vs
  B↔A at the DB layer.
- **Per-participant read state** on the conversation row
  (`last_read_by_a_at` + `last_read_by_b_at`) — single column-compare
  against `last_message_at` to know if there's unread content.
- **Soft-delete messages** via `deleted_at`. Author-only.
- **Global helpers** — `dm_unread_count()` for bell badges,
  `dm_link_to($username)` for "Message" buttons on profiles.
- **No websockets** — polling every few seconds (or on page load)
  keeps the implementation simple and framework-agnostic.

## Routes

| Method | Path                                          | Purpose             |
|--------|-----------------------------------------------|---------------------|
| GET    | `/messages`                                   | Inbox               |
| GET    | `/messages/with/{username}`                   | Start / open thread |
| GET    | `/messages/{id}`                              | Thread view (marks read) |
| POST   | `/messages/{id}`                              | Send                |
| POST   | `/messages/{id}/delete-msg/{msgId}`           | Author soft-delete  |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
