<?php
// modules/blog/Controllers/PostController.php
namespace Modules\Blog\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;

class PostController
{
    private Auth $auth;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
    }

    public function index(Request $request): Response
    {
        return Response::view('blog::index', [
            'user' => $this->auth->user(),
        ]);
    }
}
