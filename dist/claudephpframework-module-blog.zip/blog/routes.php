<?php
// modules/blog/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;

// Example route (delete once you add your own):
// $router->get('/blog', 'Modules\\Blog\\Controllers\\BlogController@index', [AuthMiddleware::class]);
