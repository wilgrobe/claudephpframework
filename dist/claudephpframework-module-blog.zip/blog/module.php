<?php
// modules/blog/module.php
use Core\Module\ModuleProvider;

return new class extends ModuleProvider {
    public function name(): string            { return 'blog'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
