# Blog module

Starter scaffold for a blog-style module. Ships as a skeleton with a
`routes.php` example and a minimal view; drop your controller + view logic
in place.

## What's included

- `module.php` — ModuleProvider wiring
- `routes.php` — commented-out example route registration
- `Views/` — one placeholder view for you to replace
- `Controllers/` — one placeholder controller

This module is deliberately minimal — it's a starting point for
app-specific blog features rather than a fully-featured blog. If you need a
richer out-of-the-box setup, the **content** module provides CMS-style
content items with ownership transfer workflows.

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
