# Installation — Blog module

## Prerequisites

- `claudephpframework-core` installed and running. See its INSTALL.md.
- No other modules required.

## Steps

1. Unzip the `blog/` directory into your project's `modules/` folder:

   ```bash
   unzip claudephpframework-module-blog.zip
   cp -r claudephpframework-module-blog/blog /path/to/project/modules/
   ```

   You should now have `modules/blog/` at your project root.

2. No migrations ship with this module. Any DB tables you add should go in
   `modules/blog/migrations/` with an ISO-date prefix
   (`2026_05_01_120000_create_posts.php`); `php artisan migrate` picks them
   up automatically.

3. If you've enabled module caching in production, refresh it:

   ```bash
   php artisan module:cache
   ```

## Environment variables

None.

## Verification

With the framework's dev server running, the module is loaded at bootstrap.
Add a test route in `modules/blog/routes.php`, hit it, and confirm it
responds. The skeleton ships with the example route commented out.
