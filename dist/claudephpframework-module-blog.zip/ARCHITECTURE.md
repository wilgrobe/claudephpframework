# Architecture — Blog module

A thin scaffold demonstrating the module structure.

## Files

```
blog/
├── module.php              # ModuleProvider: name/routes/views/migrations paths
├── routes.php              # Route registrations (example commented out)
├── Controllers/            # Your controller code
└── Views/                  # Module-scoped views — resolve via 'blog::viewname'
```

## Extension points

- **Routes** — add registrations to `routes.php`. `$router` and `$container`
  are in scope. Middleware classes like `AuthMiddleware`, `CsrfMiddleware`,
  and `RequireAdmin` are imported at the top — use them on state-changing
  routes.
- **Controllers** — namespace them `Modules\Blog\Controllers\YourController`.
  The core autoloader maps `Modules\Blog\*` to `modules/blog/*.php`.
- **Views** — reference them as `blog::template` in `Response::view()`.
  Files go under `modules/blog/Views/`.
- **Services** — if you add module-specific services (e.g. `PostService`),
  bind them in `module.php::register()`:

  ```php
  public function register(\Core\Container\Container $c): void {
      $c->bind(\Modules\Blog\Services\PostService::class);
  }
  ```

- **Migrations** — drop PHP migration files under `modules/blog/migrations/`.
  `ModuleRegistry::migrationPaths()` advertises the directory to the
  Migrator so `php artisan migrate` discovers them automatically.

## Dependencies

- `claudephpframework-core` — Router, Database, Auth, View, middleware

No dependencies on other modules.
