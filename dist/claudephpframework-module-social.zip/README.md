# Social module

Two social surfaces in one module: a Twitter-shape **follow feed** and a
Facebook-group-shape **group feed**. Each post has a `visibility` —
`public` posts flow through the follow graph, `group` posts live inside
a specific group from the groups module and are visible only to its
members.

Comments and reactions come from the comments module via the polymorphic
`comments('social_post', id)` and `reactions('social_post', id)`
helpers. That's why this module can stay small: it owns posts + follows,
and delegates the conversation.

**Moderation is automatic.** On module boot the social module registers
an ownership resolver with `CommentService` so comments on social posts
inherit the full moderation surface:

- **Site moderators** (`comments.moderate` perm) see all comments on
  social posts in `/admin/comments` just like they see comments on
  anything else.
- **Post authors** — via the user-scope path — see comments on their own
  posts in `/admin/comments` and can approve/reject/delete.
- **Group admins / owners** — via the group-scope path — moderate
  comments on any post made inside their group.

No code changes in the social module beyond the resolver registration;
the comments module does the query plumbing using denormalized
`owner_user_id` / `owner_group_id` columns on the comment row.

## Features

- **Posts** — a short body, optional `attachments_json`, soft delete
  via `deleted_at`. Capped at 10,000 chars (DB is `TEXT`, hard cap
  trimmed at the service layer).
- **Directed follow graph** — one-way follows, schema-enforced no
  self-follow, primary-key dedup so double-follow is a no-op.
- **Home feed** (`/feed`) — reverse-chron stream of public posts from
  everyone you follow, plus your own posts so new users aren't staring
  at a blank surface.
- **Group feed** (`/feed/groups/{slug}`) — visible only to members of
  the group. Non-members get redirected to the group's about page
  (from the groups module).
- **Profile page** (`/users/{username}`) — author's public posts +
  follower/following counts + follow/unfollow button.
- **People** (`/people`) — naive "people you might follow" (friend-of-
  friend with mutual count) plus a user search.
- **Compose** surfaces next to each feed — posts submitted from
  `/feed/groups/{slug}` auto-scope to `visibility='group'` with that
  group's id.

## Routes

| Method | Path                          | Purpose                     | Auth          |
|--------|-------------------------------|-----------------------------|---------------|
| GET    | `/feed`                       | Home feed                   | login         |
| GET    | `/feed/groups/{slug}`         | Group feed                  | login + member|
| GET    | `/people`                     | Search + suggestions        | login         |
| POST   | `/posts`                      | Create post                 | login         |
| POST   | `/posts/{id}/delete`          | Author/admin soft-delete    | login         |
| GET    | `/post/{id}`                  | Post detail (w/ comments)   | login if group|
| GET    | `/users/{username}`           | Profile                     | public        |
| POST   | `/users/{id}/follow`          | Follow                      | login         |
| POST   | `/users/{id}/unfollow`        | Unfollow                    | login         |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
