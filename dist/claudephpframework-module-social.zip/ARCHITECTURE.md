# Architecture — Social module

## Files

```
social/
├── module.php
├── routes.php                                          # 10 routes
├── Controllers/
│   ├── FeedController.php                              # /feed, /feed/groups/{slug}, /people
│   ├── PostController.php                              # /posts, /posts/{id}/delete, /post/{id}
│   └── ProfileController.php                           # /users/{username}, /users/{id}/{un}follow
├── Services/
│   ├── PostService.php                                 # Create, find, soft-delete
│   ├── FollowService.php                               # Follow graph CRUD + counts
│   └── FeedService.php                                 # Home, group, profile, suggestions
├── Views/
│   ├── public/
│   │   ├── feed.php                                    # /feed  — main feed + sidebar
│   │   ├── group_feed.php                              # /feed/groups/{slug}
│   │   ├── profile.php                                 # /users/{username}
│   │   ├── post.php                                    # /post/{id} (w/ comments section)
│   │   └── people.php                                  # /people — search + suggestions
│   └── partials/
│       ├── post_card.php                               # Shared post tile (feed/profile/group)
│       └── composer.php                                # Shared "new post" form
└── migrations/
    └── 2026_04_22_231000_create_social_tables.php      # 2 tables
```

## Data model

### `social_posts`

```
id BIGINT,
user_id, visibility ENUM('public','group'), group_id NULLABLE,
body TEXT, attachments_json TEXT NULL,
deleted_at NULL, timestamps
KEY (user_id, created_at)
KEY (group_id, created_at)
KEY (visibility, created_at)
KEY (deleted_at)
```

Visibility is the discriminator. `public` posts are carried by the
follow graph; `group` posts are carried by the groups membership graph.
Indexes are chosen for the three feed queries: home feed scans `visibility
+ created_at`, group feed scans `group_id + created_at`, profile scans
`user_id + created_at`.

### `social_follows`

```
follower_id, followed_id, created_at
PRIMARY KEY (follower_id, followed_id)
KEY (followed_id, follower_id)
CHECK (follower_id <> followed_id)
```

Composite PK dedups — `INSERT IGNORE` makes double-follow a no-op. The
reverse index `(followed_id, follower_id)` is for "who follows me"
lookups. Self-follow is blocked by CHECK so bad clients can't slip it
through.

## Feed queries

### Home feed

```sql
SELECT p.*, u.username, u.email
  FROM social_posts p
  JOIN users u ON u.id = p.user_id
 WHERE p.deleted_at IS NULL
   AND p.visibility = 'public'
   AND (p.user_id = :me
     OR p.user_id IN (SELECT followed_id FROM social_follows WHERE follower_id = :me))
 ORDER BY p.created_at DESC
 LIMIT :n OFFSET :o
```

The subquery is a semi-join MySQL plans well on `social_follows`
primary key. Including `p.user_id = :me` means new users with no
follows still see *something* (their own posts).

### Group feed

Simple: `visibility = 'group' AND group_id = :g`. Membership is checked
in the controller before the query — non-members don't reach this
surface.

### Profile feed

Just the user's public posts. Group-scoped posts are intentionally
excluded from profile — they belong to the group, not the author's
public face.

### Suggestions (friend-of-friend)

```sql
SELECT u.id, u.username, COUNT(*) AS mutual_count
  FROM social_follows f1
  JOIN social_follows f2 ON f2.follower_id = f1.followed_id
  JOIN users u           ON u.id = f2.followed_id
 WHERE f1.follower_id = :me
   AND f2.followed_id <> :me
   AND f2.followed_id NOT IN (SELECT followed_id FROM social_follows WHERE follower_id = :me)
 GROUP BY u.id, u.username
 ORDER BY mutual_count DESC, u.username
 LIMIT :n
```

This gets expensive as the graph grows — for serious scale, precompute
suggestions in a background job. Fine until then.

## Composition with other modules

- **groups** — group feed leans on `groups` (slug, name) + `user_groups`
  (membership). Hard requirement.
- **comments** — `post.php` uses `comments('social_post', id)`. Helper
  is guarded by `function_exists`, so comments are optional at install
  time.
- **comments / reactions** — `post_card.php` renders a reactions bar
  via `reactions('social_post', id)`. Same guard.
- **notifications** — not wired yet; see deferred features. New follow
  and new comment events would flow through `NotificationService`.
- **taxonomy** — hashtags could land by attaching taxonomy terms to
  `social_post` entities. No schema change required.

## Extending

- **A fourth visibility** (e.g. `followers_only`) — extend the enum +
  add a branch in `FeedService::homeFeed`. No column add required.
- **Quote / repost** — add a nullable `repost_of_post_id` FK on
  `social_posts`, render inline quote in `post_card.php`, and widen
  the feed query to carry the quoted post.
- **Ranked feed** — replace `ORDER BY created_at DESC` with
  `ORDER BY score DESC` where `score` is a denormalized column a job
  refreshes. Query shape stays identical.
- **Mentions** — parse `@username` at save time inside
  `PostService::create`, resolve via a `users.username` lookup, insert
  `social_mentions` rows, call `NotificationService::notify`.

## Testing notes

- Unit — `FollowService` is isolated from feed math; exercise
  follow/unfollow/double-follow/self-follow via direct calls.
- Integration — seed users A/B/C, have A follow B, post from B/C,
  assert A's `homeFeed` shows B's post and NOT C's.
- Soft-delete — post, delete, assert it's absent from every feed
  query. Assert the comments table still has rows (comments aren't
  cascaded, deliberately — audit preservation).
