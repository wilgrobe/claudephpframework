<?php
// modules/social/migrations/2026_04_22_231000_create_social_tables.php
use Core\Database\Migration;

/**
 * Schema for the social module.
 *
 *   social_posts   — user-authored posts. `visibility` picks where the
 *                    post shows up: 'public' posts appear on followers'
 *                    home feed and the author's profile; 'group' posts
 *                    appear only on the linked group's feed. A future
 *                    'followers_only' visibility drops in cleanly — kept
 *                    out of the enum so existing rows don't need a
 *                    migration when it lands.
 *
 *   social_follows — directed follow graph. (follower, followed) pair
 *                    is the primary key so double-follows are a no-op
 *                    on INSERT IGNORE. Mutual follows are represented
 *                    as two rows — one in each direction.
 *
 * Comments and reactions are NOT modeled here — posts are commentable /
 * reactable via the comments module using entity_type='social_post'.
 * The comments module's polymorphic attach is the whole reason this
 * module can stay small.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE social_posts (
                id               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id          INT UNSIGNED NOT NULL,
                visibility       ENUM('public','group') NOT NULL DEFAULT 'public',
                group_id         INT UNSIGNED NULL,
                body             TEXT NOT NULL,
                attachments_json TEXT NULL,
                deleted_at       DATETIME NULL,
                created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                KEY idx_user_created       (user_id, created_at),
                KEY idx_group_created      (group_id, created_at),
                KEY idx_visibility_created (visibility, created_at),
                KEY idx_deleted            (deleted_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE social_follows (
                follower_id INT UNSIGNED NOT NULL,
                followed_id INT UNSIGNED NOT NULL,
                created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                PRIMARY KEY (follower_id, followed_id),
                KEY idx_followed_follower (followed_id, follower_id),
                CONSTRAINT chk_no_self CHECK (follower_id <> followed_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS social_follows");
        $this->db->query("DROP TABLE IF EXISTS social_posts");
    }
};
