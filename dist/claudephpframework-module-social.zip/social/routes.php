<?php
// modules/social/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;

$F = 'Modules\Social\Controllers\FeedController';
$P = 'Modules\Social\Controllers\PostController';
$U = 'Modules\Social\Controllers\ProfileController';

// ── Feeds ─────────────────────────────────────────────────────────────────
$router->get ('/feed',                     "$F@home",       [AuthMiddleware::class]);
$router->get ('/feed/groups/{slug}',       "$F@group",      [AuthMiddleware::class]);
$router->get ('/people',                   "$F@people",     [AuthMiddleware::class]);

// ── Posts ─────────────────────────────────────────────────────────────────
$router->get ('/post/{id}',                "$P@show");
$router->post('/posts',                    "$P@store",      [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/posts/{id}/delete',        "$P@delete",     [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Profiles + follows ────────────────────────────────────────────────────
$router->get ('/users/{username}',         "$U@show");
$router->post('/users/{id}/follow',        "$U@follow",     [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/users/{id}/unfollow',      "$U@unfollow",   [CsrfMiddleware::class, AuthMiddleware::class]);
