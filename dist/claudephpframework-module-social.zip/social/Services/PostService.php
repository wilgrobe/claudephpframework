<?php
// modules/social/Services/PostService.php
namespace Modules\Social\Services;

use Core\Database\Database;

/**
 * Post CRUD. Stays small — feed assembly lives in FeedService, follow
 * management lives in FollowService. The interesting bits are the
 * "visibility + group_id" guard (group posts must name a group) and
 * soft-delete (deleted_at nulls the post from every surface without
 * leaving orphaned comments).
 */
class PostService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Create a post. For visibility='group' a group_id is required and
     * the caller is responsible for verifying the author is a member of
     * that group — PostController enforces the membership check.
     */
    public function create(int $userId, string $body, string $visibility = 'public', ?int $groupId = null, ?array $attachments = null): int
    {
        $body = trim($body);
        if ($body === '') return 0;

        if (!in_array($visibility, ['public', 'group'], true)) $visibility = 'public';
        if ($visibility === 'group' && !$groupId) $visibility = 'public';

        return (int) $this->db->insert('social_posts', [
            'user_id'          => $userId,
            'visibility'       => $visibility,
            'group_id'         => $visibility === 'group' ? $groupId : null,
            'body'             => mb_substr($body, 0, 10000),
            'attachments_json' => $attachments !== null
                ? json_encode($attachments, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
                : null,
        ]);
    }

    public function find(int $id): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM social_posts WHERE id = ? AND deleted_at IS NULL",
            [$id]
        );
    }

    /**
     * Post + author join, useful for detail pages. Returns null for
     * soft-deleted or missing rows.
     */
    public function findWithAuthor(int $id): ?array
    {
        return $this->db->fetchOne(
            "SELECT p.*, u.username, u.email
               FROM social_posts p
               JOIN users u ON u.id = p.user_id
              WHERE p.id = ? AND p.deleted_at IS NULL",
            [$id]
        );
    }

    /** Soft-delete. Only the author or an admin should call this. */
    public function softDelete(int $postId): void
    {
        $this->db->update('social_posts',
            ['deleted_at' => date('Y-m-d H:i:s')],
            'id = ?', [$postId]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function forUser(int $userId, int $limit = 50, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, u.username
               FROM social_posts p
               JOIN users u ON u.id = p.user_id
              WHERE p.user_id = ? AND p.deleted_at IS NULL
           ORDER BY p.created_at DESC
              LIMIT ? OFFSET ?",
            [$userId, $limit, $offset]
        );
    }
}
