<?php
// modules/social/Services/FollowService.php
namespace Modules\Social\Services;

use Core\Database\Database;

/**
 * Directed follow graph. `follower_id` follows `followed_id`; reverse
 * relationships require a second row. No "pending" state — this is a
 * Twitter-shape follow, not a Facebook-shape friendship.
 *
 * Schema-level CHECK `follower_id <> followed_id` prevents self-follow.
 * Primary key on (follower, followed) makes double-follow a no-op via
 * INSERT IGNORE.
 */
class FollowService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function follow(int $followerId, int $followedId): bool
    {
        if ($followerId === $followedId) return false;
        $this->db->query(
            "INSERT IGNORE INTO social_follows (follower_id, followed_id) VALUES (?, ?)",
            [$followerId, $followedId]
        );
        return true;
    }

    public function unfollow(int $followerId, int $followedId): void
    {
        $this->db->delete('social_follows',
            'follower_id = ? AND followed_id = ?',
            [$followerId, $followedId]
        );
    }

    public function isFollowing(int $followerId, int $followedId): bool
    {
        return (bool) $this->db->fetchOne(
            "SELECT 1 FROM social_follows WHERE follower_id = ? AND followed_id = ? LIMIT 1",
            [$followerId, $followedId]
        );
    }

    /** @return array<int> user ids this user follows */
    public function followingIds(int $userId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT followed_id FROM social_follows WHERE follower_id = ?",
            [$userId]
        );
        return array_map(static fn($r) => (int) $r['followed_id'], $rows);
    }

    /** @return array<int> user ids that follow this user */
    public function followerIds(int $userId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT follower_id FROM social_follows WHERE followed_id = ?",
            [$userId]
        );
        return array_map(static fn($r) => (int) $r['follower_id'], $rows);
    }

    /** @return array<int, array<string, mixed>> joined to users table */
    public function followingUsers(int $userId, int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT u.id, u.username, u.email
               FROM social_follows f
               JOIN users u ON u.id = f.followed_id
              WHERE f.follower_id = ?
           ORDER BY f.created_at DESC
              LIMIT ?",
            [$userId, $limit]
        );
    }

    /** @return array<int, array<string, mixed>> joined to users table */
    public function followerUsers(int $userId, int $limit = 50): array
    {
        return $this->db->fetchAll(
            "SELECT u.id, u.username, u.email
               FROM social_follows f
               JOIN users u ON u.id = f.follower_id
              WHERE f.followed_id = ?
           ORDER BY f.created_at DESC
              LIMIT ?",
            [$userId, $limit]
        );
    }

    public function counts(int $userId): array
    {
        return [
            'followers' => (int) $this->db->fetchColumn(
                "SELECT COUNT(*) FROM social_follows WHERE followed_id = ?",
                [$userId]
            ),
            'following' => (int) $this->db->fetchColumn(
                "SELECT COUNT(*) FROM social_follows WHERE follower_id = ?",
                [$userId]
            ),
        ];
    }
}
