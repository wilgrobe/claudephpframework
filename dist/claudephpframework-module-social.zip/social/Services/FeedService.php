<?php
// modules/social/Services/FeedService.php
namespace Modules\Social\Services;

use Core\Database\Database;

/**
 * Feed assembly for the three surfaces the social module exposes:
 *
 *   homeFeed($userId)   — posts from everyone $userId follows, plus
 *                         their own posts, visibility='public' only.
 *                         Reverse-chronological; no ranking, no ML.
 *   groupFeed($groupId) — posts with visibility='group' and matching
 *                         group_id, newest first. Membership check is
 *                         the caller's responsibility.
 *   profileFeed($userId)— author's public posts, newest first. Group-
 *                         scoped posts are excluded (they belong to
 *                         the group, not the author's profile).
 *
 * All three return joined (post + author) rows shaped identically so
 * views can reuse one partial.
 *
 * Pagination is offset-based for simplicity; cursor pagination would
 * hold up better at scale but we don't expect enough rows for that to
 * matter until a ranking pass is introduced.
 */
class FeedService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /** @return array<int, array<string, mixed>> */
    public function homeFeed(int $userId, int $limit = 50, int $offset = 0): array
    {
        // Include the user's own posts so /feed isn't blank for new users
        // who haven't followed anyone yet. Semantic: "things I care about".
        return $this->db->fetchAll(
            "SELECT p.*, u.username, u.email
               FROM social_posts p
               JOIN users u ON u.id = p.user_id
              WHERE p.deleted_at IS NULL
                AND p.visibility = 'public'
                AND (
                      p.user_id = ?
                   OR p.user_id IN (
                        SELECT followed_id FROM social_follows WHERE follower_id = ?
                      )
                )
           ORDER BY p.created_at DESC
              LIMIT ? OFFSET ?",
            [$userId, $userId, $limit, $offset]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function groupFeed(int $groupId, int $limit = 50, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, u.username, u.email
               FROM social_posts p
               JOIN users u ON u.id = p.user_id
              WHERE p.deleted_at IS NULL
                AND p.visibility = 'group'
                AND p.group_id = ?
           ORDER BY p.created_at DESC
              LIMIT ? OFFSET ?",
            [$groupId, $limit, $offset]
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function profileFeed(int $userId, int $limit = 50, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT p.*, u.username, u.email
               FROM social_posts p
               JOIN users u ON u.id = p.user_id
              WHERE p.user_id = ?
                AND p.deleted_at IS NULL
                AND p.visibility = 'public'
           ORDER BY p.created_at DESC
              LIMIT ? OFFSET ?",
            [$userId, $limit, $offset]
        );
    }

    /**
     * "People you might follow" — users that at least one of $userId's
     * follows also follows, minus users $userId already follows. Naive
     * but useful starter algorithm; swap for something smarter later.
     *
     * @return array<int, array<string, mixed>>
     */
    public function suggestions(int $userId, int $limit = 10): array
    {
        return $this->db->fetchAll(
            "SELECT u.id, u.username, u.email, COUNT(*) AS mutual_count
               FROM social_follows f1
               JOIN social_follows f2 ON f2.follower_id = f1.followed_id
               JOIN users u           ON u.id = f2.followed_id
              WHERE f1.follower_id = ?
                AND f2.followed_id <> ?
                AND f2.followed_id NOT IN (
                      SELECT followed_id FROM social_follows WHERE follower_id = ?
                    )
           GROUP BY u.id, u.username, u.email
           ORDER BY mutual_count DESC, u.username ASC
              LIMIT ?",
            [$userId, $userId, $userId, $limit]
        );
    }
}
