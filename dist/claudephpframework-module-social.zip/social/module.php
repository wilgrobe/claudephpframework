<?php
// modules/social/module.php
use Core\Container\Container;
use Core\Database\Database;
use Core\Module\ModuleProvider;

/**
 * Social module — posts + follows + feeds.
 *
 * Two surfaces in one module:
 *   • Global follow graph — posts with visibility='public' show up on
 *     the home feed of every follower.
 *   • Group feeds — posts with visibility='group' are scoped to a
 *     specific group from the groups module; only group members see
 *     them.
 *
 * Comments and reactions come "for free" via the comments module's
 * polymorphic `comments()` / `reactions()` helpers with entity_type
 * 'social_post' — this module doesn't reimplement them.
 *
 * Moderation integration: `register()` hooks a resolver into
 * CommentService so comments on social posts inherit both:
 *   • Author-scope moderation — the post's author can moderate comments
 *     on their own post via /admin/comments (filtered by owner_user_id).
 *   • Group-scope moderation — when the post is group-scoped, group
 *     admins / owners of that group can moderate via /admin/comments
 *     (filtered by owner_group_id).
 * The existing site-level moderator path keeps working via the
 * comments.moderate permission.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'social'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }

    public function register(Container $container): void
    {
        // Register with comments (optional dependency — if the comments
        // module isn't installed the class isn't loaded and the call
        // short-circuits). class_exists deliberately short-circuits
        // autoload with the second arg=false if needed, but the default
        // behaviour (autoload=true) is what we want here.
        if (class_exists(\Modules\Comments\Services\CommentService::class)) {
            \Modules\Comments\Services\CommentService::registerOwnershipResolver(
                'social_post',
                static function (int $postId): ?array {
                    // Direct DB read — no soft-delete filter here because
                    // ownership resolution should succeed even on deleted
                    // posts (moderators still need to act on comments
                    // from a since-deleted post).
                    $row = Database::getInstance()->fetchOne(
                        "SELECT user_id, group_id FROM social_posts WHERE id = ?",
                        [$postId]
                    );
                    if (!$row) return null;
                    return [
                        'user_id'  => (int) $row['user_id'] ?: null,
                        'group_id' => isset($row['group_id']) && $row['group_id'] !== null
                            ? (int) $row['group_id'] : null,
                    ];
                }
            );
        }
    }
};
