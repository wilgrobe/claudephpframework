<?php $pageTitle = '@' . $profile['username']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card" style="margin-bottom:1rem">
    <div class="card-body" style="display:flex;gap:1rem;align-items:center">
        <div style="flex:1">
            <h1 style="margin:0">@<?= e($profile['username']) ?></h1>
            <div style="color:#6b7280;font-size:13px;margin-top:.25rem">
                <strong><?= (int) $counts['followers'] ?></strong> followers · <strong><?= (int) $counts['following'] ?></strong> following
            </div>
        </div>
        <?php if (!$isSelf && !empty($me)): ?>
        <?php if ($isFollowing): ?>
        <form method="post" action="/users/<?= (int) $profile['id'] ?>/unfollow">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-secondary">Unfollow</button>
        </form>
        <?php else: ?>
        <form method="post" action="/users/<?= (int) $profile['id'] ?>/follow">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-primary">Follow</button>
        </form>
        <?php endif; ?>
        <?php endif; ?>
    </div>
</div>

<?php if (empty($posts)): ?>
<div class="card"><div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
    Nothing posted yet.
</div></div>
<?php else: ?>
    <?php foreach ($posts as $p): ?>
    <?php include __DIR__ . '/../partials/post_card.php'; ?>
    <?php endforeach; ?>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
