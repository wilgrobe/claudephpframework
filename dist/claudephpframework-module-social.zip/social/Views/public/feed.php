<?php $pageTitle = 'Feed'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:grid;gap:1.5rem;grid-template-columns:2fr 1fr">
<div>
    <h1 style="margin:0 0 1rem 0">Feed</h1>

    <?php include __DIR__ . '/../partials/composer.php'; ?>

    <?php if (empty($posts)): ?>
    <div class="card"><div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
        No posts yet. <a href="/people">Follow some people →</a>
    </div></div>
    <?php else: ?>
        <?php foreach ($posts as $p): ?>
        <?php include __DIR__ . '/../partials/post_card.php'; ?>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<aside>
    <div class="card">
        <div class="card-header"><strong>Who to follow</strong></div>
        <div class="card-body" style="padding:.5rem 0">
            <?php if (empty($suggestions)): ?>
            <div style="padding:.75rem 1rem;color:#9ca3af;font-size:13px"><a href="/people">Browse people →</a></div>
            <?php else: ?>
            <?php foreach ($suggestions as $s): ?>
            <div style="display:flex;align-items:center;justify-content:space-between;padding:.5rem 1rem;border-bottom:1px solid #f3f4f6">
                <a href="/users/<?= e($s['username']) ?>" style="color:inherit;text-decoration:none">
                    <strong>@<?= e($s['username']) ?></strong>
                    <div style="font-size:11px;color:#9ca3af">
                        <?= (int) ($s['mutual_count'] ?? 0) ?> mutual
                    </div>
                </a>
                <form method="post" action="/users/<?= (int) $s['id'] ?>/follow">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-primary">Follow</button>
                </form>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</aside>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
