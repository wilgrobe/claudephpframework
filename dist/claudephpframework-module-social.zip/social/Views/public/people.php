<?php $pageTitle = 'People'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">People</h1>

<form method="get" action="/people" style="margin-bottom:1rem">
    <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search username or email" style="width:100%;max-width:480px;padding:.5rem;border:1px solid #d1d5db;border-radius:4px">
    <button type="submit" class="btn btn-secondary">Search</button>
</form>

<?php if ($q !== ''): ?>
<div class="card" style="margin-bottom:1rem">
    <div class="card-header"><strong>Search results for "<?= e($q) ?>"</strong></div>
    <div class="card-body" style="padding:.5rem 0">
        <?php if (empty($results)): ?>
        <div style="padding:.75rem 1rem;color:#9ca3af">No users matched.</div>
        <?php else: ?>
        <?php foreach ($results as $r): ?>
        <div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem 1rem;border-bottom:1px solid #f3f4f6">
            <a href="/users/<?= e($r['username']) ?>" style="color:inherit;text-decoration:none"><strong>@<?= e($r['username']) ?></strong></a>
            <form method="post" action="/users/<?= (int) $r['id'] ?>/follow">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-sm btn-primary">Follow</button>
            </form>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<div style="display:grid;gap:1rem;grid-template-columns:1fr 1fr">
    <div class="card">
        <div class="card-header"><strong>Suggestions</strong></div>
        <div class="card-body" style="padding:.5rem 0">
            <?php if (empty($suggestions)): ?>
            <div style="padding:.75rem 1rem;color:#9ca3af;font-size:13px">No suggestions yet — follow a few people to bootstrap.</div>
            <?php else: ?>
            <?php foreach ($suggestions as $s): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem 1rem;border-bottom:1px solid #f3f4f6">
                <a href="/users/<?= e($s['username']) ?>" style="color:inherit;text-decoration:none">
                    <strong>@<?= e($s['username']) ?></strong>
                    <span style="font-size:11px;color:#9ca3af;margin-left:.25rem"><?= (int) ($s['mutual_count'] ?? 0) ?> mutual</span>
                </a>
                <form method="post" action="/users/<?= (int) $s['id'] ?>/follow">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-primary">Follow</button>
                </form>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="card">
        <div class="card-header"><strong>You follow</strong></div>
        <div class="card-body" style="padding:.5rem 0">
            <?php if (empty($following)): ?>
            <div style="padding:.75rem 1rem;color:#9ca3af;font-size:13px">You're not following anyone yet.</div>
            <?php else: ?>
            <?php foreach ($following as $f): ?>
            <div style="display:flex;justify-content:space-between;align-items:center;padding:.5rem 1rem;border-bottom:1px solid #f3f4f6">
                <a href="/users/<?= e($f['username']) ?>" style="color:inherit;text-decoration:none"><strong>@<?= e($f['username']) ?></strong></a>
                <form method="post" action="/users/<?= (int) $f['id'] ?>/unfollow">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-secondary">Unfollow</button>
                </form>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
