<?php $pageTitle = 'Post by @' . $post['username']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:720px;margin:0 auto">
<?php $p = $post; include __DIR__ . '/../partials/post_card.php'; ?>

<?php if (function_exists('comments')): ?>
<?= comments('social_post', (int) $post['id']) ?>
<?php else: ?>
<div class="card"><div class="card-body" style="color:#9ca3af;font-size:13px">
    Install the comments module to enable replies on posts.
</div></div>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
