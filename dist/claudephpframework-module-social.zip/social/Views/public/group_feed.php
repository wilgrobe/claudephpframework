<?php $pageTitle = $group['name'] . ' — feed'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <h1 style="margin:0;font-size:1.5rem"><?= e($group['name']) ?></h1>
    <a href="/groups/<?= e($group['slug']) ?>" class="btn btn-sm btn-secondary">Group page</a>
</div>

<?php include __DIR__ . '/../partials/composer.php'; ?>

<?php if (empty($posts)): ?>
<div class="card"><div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
    No posts in this group yet — be the first.
</div></div>
<?php else: ?>
    <?php foreach ($posts as $p): ?>
    <?php include __DIR__ . '/../partials/post_card.php'; ?>
    <?php endforeach; ?>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
