<?php
// modules/social/Views/partials/post_card.php
// Expects: $p (joined post+user row), $me (current user or null).
//
// Uses comments() + reactions() from the comments module. Those helpers
// are optional — guard with function_exists so this module degrades
// gracefully when the comments module isn't installed.
?>
<div class="card" style="margin-bottom:.75rem">
    <div class="card-body">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:1rem">
            <div>
                <a href="/users/<?= e($p['username']) ?>" style="color:inherit;text-decoration:none;font-weight:600">
                    @<?= e($p['username']) ?>
                </a>
                <span style="color:#9ca3af;font-size:12px;margin-left:.5rem">
                    <?= e(date('M j, Y H:i', strtotime((string) $p['created_at']))) ?>
                </span>
                <?php if ($p['visibility'] === 'group'): ?>
                    <span class="badge badge-info" style="margin-left:.5rem">group</span>
                <?php endif; ?>
            </div>
            <?php if (!empty($me) && (int) $me['id'] === (int) $p['user_id']): ?>
            <form method="post" action="/posts/<?= (int) $p['id'] ?>/delete" onsubmit="return confirm('Delete post?')">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-sm btn-danger" title="Delete">×</button>
            </form>
            <?php endif; ?>
        </div>
        <div style="margin-top:.5rem;white-space:pre-wrap;line-height:1.5">
            <?= nl2br(e((string) $p['body'])) ?>
        </div>
        <div style="margin-top:.75rem;display:flex;gap:.5rem;align-items:center">
            <a href="/post/<?= (int) $p['id'] ?>" style="font-size:13px;color:#6b7280;text-decoration:none">Open →</a>
            <?php if (function_exists('reactions')): ?>
            <div style="margin-left:auto">
                <?= reactions('social_post', (int) $p['id']) ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>
