<?php
// modules/social/Views/partials/composer.php
// Expects: $me (current user), $group (array|null — if set, composes into that group)
?>
<div class="card" style="margin-bottom:1rem">
    <form method="post" action="/posts">
        <?= csrf_field() ?>
        <?php if (!empty($group)): ?>
        <input type="hidden" name="visibility" value="group">
        <input type="hidden" name="group_id" value="<?= (int) $group['id'] ?>">
        <?php else: ?>
        <input type="hidden" name="visibility" value="public">
        <?php endif; ?>
        <div class="card-body">
            <textarea name="body" rows="3" style="width:100%;padding:.5rem;border:1px solid #d1d5db;border-radius:4px"
                placeholder="<?= !empty($group) ? 'Post to ' . e($group['name']) : "What's new, @" . e($me['username'] ?? '') . '?' ?>"></textarea>
        </div>
        <div class="card-footer" style="padding:.5rem 1rem;background:#f9fafb;text-align:right">
            <button type="submit" class="btn btn-sm btn-primary">Post</button>
        </div>
    </form>
</div>
