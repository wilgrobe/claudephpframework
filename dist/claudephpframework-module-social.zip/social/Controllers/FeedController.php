<?php
// modules/social/Controllers/FeedController.php
namespace Modules\Social\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Modules\Social\Services\FeedService;
use Modules\Social\Services\FollowService;

/**
 * Feed surfaces:
 *   GET /feed                — home feed (own + followed users, public only)
 *   GET /feed/groups/{slug}  — group feed (visibility='group' for this group)
 *   GET /people              — suggestions + search
 *
 * Requires login. Anonymous browsing is deliberate non-goal: the social
 * graph isn't a public broadcast surface here.
 */
class FeedController
{
    private Auth          $auth;
    private FeedService   $feed;
    private FollowService $follows;
    private Database      $db;

    public function __construct()
    {
        $this->auth    = Auth::getInstance();
        $this->feed    = new FeedService();
        $this->follows = new FollowService();
        $this->db      = Database::getInstance();
    }

    public function home(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $uid = (int) $this->auth->id();

        return Response::view('social::public.feed', [
            'posts'       => $this->feed->homeFeed($uid),
            'suggestions' => $this->feed->suggestions($uid),
            'me'          => $this->auth->user(),
        ]);
    }

    public function group(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $slug  = (string) $request->param(0);
        $group = $this->db->fetchOne(
            "SELECT * FROM `groups` WHERE slug = ?", [$slug]
        );
        if (!$group) return new Response('Group not found', 404);

        // Group feed is private to members. SA-mode crosses the scope
        // via groupAccessCheck, which audits each bypass once.
        if ($this->auth->groupAccessCheck((int) $group['id'], 'social.group_feed') === 'denied') {
            return Response::redirect('/groups/' . $slug);
        }

        return Response::view('social::public.group_feed', [
            'group' => $group,
            'posts' => $this->feed->groupFeed((int) $group['id']),
            'me'    => $this->auth->user(),
        ]);
    }

    public function people(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $uid = (int) $this->auth->id();

        $q = trim((string) $request->query('q', ''));
        $results = [];
        if ($q !== '') {
            $like = '%' . $q . '%';
            $results = $this->db->fetchAll(
                "SELECT id, username, email FROM users
                  WHERE (username LIKE ? OR email LIKE ?)
                    AND id <> ?
                  ORDER BY username ASC
                  LIMIT 30",
                [$like, $like, $uid]
            );
        }

        return Response::view('social::public.people', [
            'suggestions' => $this->feed->suggestions($uid, 20),
            'following'   => $this->follows->followingUsers($uid, 100),
            'results'     => $results,
            'q'           => $q,
            'me'          => $this->auth->user(),
        ]);
    }
}
