<?php
// modules/social/Controllers/ProfileController.php
namespace Modules\Social\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Modules\Social\Services\FeedService;
use Modules\Social\Services\FollowService;

/**
 *   GET  /users/{username}           — profile + their public posts
 *   POST /users/{id}/follow          — current user follows target
 *   POST /users/{id}/unfollow        — current user unfollows target
 */
class ProfileController
{
    private Auth          $auth;
    private Database      $db;
    private FeedService   $feed;
    private FollowService $follows;

    public function __construct()
    {
        $this->auth    = Auth::getInstance();
        $this->db      = Database::getInstance();
        $this->feed    = new FeedService();
        $this->follows = new FollowService();
    }

    public function show(Request $request): Response
    {
        $username = (string) $request->param(0);
        $user = $this->db->fetchOne(
            "SELECT id, username, email FROM users WHERE username = ?",
            [$username]
        );
        if (!$user) return new Response('User not found', 404);

        $isFollowing = false;
        if (!$this->auth->guest()) {
            $isFollowing = $this->follows->isFollowing(
                (int) $this->auth->id(),
                (int) $user['id']
            );
        }

        return Response::view('social::public.profile', [
            'profile'    => $user,
            'posts'      => $this->feed->profileFeed((int) $user['id']),
            'counts'     => $this->follows->counts((int) $user['id']),
            'isFollowing'=> $isFollowing,
            'isSelf'     => !$this->auth->guest() && (int) $this->auth->id() === (int) $user['id'],
            'me'         => $this->auth->user(),
        ]);
    }

    public function follow(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $targetId = (int) $request->param(0);

        $target = $this->db->fetchOne("SELECT username FROM users WHERE id = ?", [$targetId]);
        if (!$target) return Response::redirect('/people');

        $this->follows->follow((int) $this->auth->id(), $targetId);
        return Response::redirect('/users/' . $target['username']);
    }

    public function unfollow(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $targetId = (int) $request->param(0);

        $target = $this->db->fetchOne("SELECT username FROM users WHERE id = ?", [$targetId]);
        if (!$target) return Response::redirect('/people');

        $this->follows->unfollow((int) $this->auth->id(), $targetId);
        return Response::redirect('/users/' . $target['username']);
    }
}
