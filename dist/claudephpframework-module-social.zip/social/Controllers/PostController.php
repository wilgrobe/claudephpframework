<?php
// modules/social/Controllers/PostController.php
namespace Modules\Social\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Modules\Social\Services\PostService;

/**
 *   POST /posts                — create a post
 *   POST /posts/{id}/delete    — author (or admin) soft-deletes
 *   GET  /post/{id}            — single post detail page (comments via
 *                                the comments module's helper)
 */
class PostController
{
    private Auth        $auth;
    private PostService $posts;
    private Database    $db;

    public function __construct()
    {
        $this->auth  = Auth::getInstance();
        $this->posts = new PostService();
        $this->db    = Database::getInstance();
    }

    public function show(Request $request): Response
    {
        $id   = (int) $request->param(0);
        $post = $this->posts->findWithAuthor($id);
        if (!$post) return new Response('Post not found', 404);

        // Group posts are only visible to group members (same as the feed).
        // SA-mode crosses the scope via groupAccessCheck.
        if ($post['visibility'] === 'group' && $post['group_id']) {
            if ($this->auth->guest()) return Response::redirect('/login');
            if ($this->auth->groupAccessCheck((int) $post['group_id'], 'social.post_view') === 'denied') {
                return new Response('Post not found', 404);
            }
        }

        return Response::view('social::public.post', [
            'post' => $post,
            'me'   => $this->auth->user(),
        ]);
    }

    public function store(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $uid = (int) $this->auth->id();

        $body       = trim((string) $request->post('body', ''));
        $visibility = (string) $request->post('visibility', 'public');
        $groupId    = (int) $request->post('group_id', 0) ?: null;

        if ($body === '') {
            return Response::redirect('/feed')->withFlash('error', 'Post body is empty.');
        }

        if ($visibility === 'group' && $groupId) {
            // SA-mode can post into any group (read-and-write parity
            // under the universal-visibility toggle). Bypass is audited.
            if ($this->auth->groupAccessCheck($groupId, 'social.post_create') === 'denied') {
                return Response::redirect('/feed')->withFlash('error', 'Not a member of that group.');
            }
        } else {
            $visibility = 'public';
            $groupId    = null;
        }

        $id = $this->posts->create($uid, $body, $visibility, $groupId);
        if (!$id) return Response::redirect('/feed')->withFlash('error', 'Could not create post.');

        // Redirect to where the post lives, not generically to /feed.
        if ($visibility === 'group' && $groupId) {
            $group = $this->db->fetchOne("SELECT slug FROM `groups` WHERE id = ?", [$groupId]);
            return Response::redirect('/feed/groups/' . ($group['slug'] ?? ''));
        }
        return Response::redirect('/feed')->withFlash('success', 'Posted.');
    }

    public function delete(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $id   = (int) $request->param(0);
        $post = $this->posts->find($id);
        if (!$post) return Response::redirect('/feed');

        $isOwner = (int) $post['user_id'] === (int) $this->auth->id();
        $isAdmin = method_exists($this->auth, 'isAdmin') ? $this->auth->isAdmin() : false;
        if (!$isOwner && !$isAdmin) {
            return Response::redirect('/feed')->withFlash('error', 'Not your post.');
        }

        $this->posts->softDelete($id);
        return Response::redirect('/feed')->withFlash('success', 'Post deleted.');
    }
}
