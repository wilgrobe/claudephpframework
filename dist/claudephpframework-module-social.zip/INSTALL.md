# Installation — Social module

## Prerequisites

- `claudephpframework-core` installed.
- `claudephpframework-module-groups` installed (the group-feed surface
  queries `groups` and `user_groups` tables directly).
- **Recommended:** `claudephpframework-module-comments` for replies +
  reactions on posts. The module functions without comments — post
  cards and detail pages just skip the comments section.

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-social.zip
   cp -r claudephpframework-module-social/social /path/to/project/modules/
   ```

2. Run the migration (creates 2 tables):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if you use production caching:
   ```bash
   php artisan module:cache
   ```

## First-use walkthrough

1. Log in as a user, visit `/feed` — it's empty but the composer is
   there.
2. Post something. It appears on your profile and on the feed.
3. Create (or join) a few more users. Follow each other via
   `/users/{username}` → **Follow**, or via the `/people` page.
4. Visit `/feed` again — posts from followed users show up
   reverse-chronologically.
5. Go to `/groups`, open one of your groups, then visit
   `/feed/groups/{slug}` — post into the group. Only members see it
   (confirmed by logging in as a non-member and hitting the URL: you
   get redirected to the group's about page).

## Environment variables

None specific to this module.

## Deferred features (v2)

- **Visibility='followers_only'** — kept out of the enum intentionally
  so existing rows don't break on the schema change. Add to the
  enum and teach `FeedService::homeFeed` that `followers_only` posts
  from a user only appear in feeds of users who follow them.
- **Quote / repost** — would need a `repost_of_post_id` column on
  `social_posts` + a detail surface showing the quoted post inline.
- **Mentions (`@username`)** — parse at save time, store a
  `social_mentions` table, and notify each mentioned user via the
  notifications module.
- **Hashtags** — either a parsed `social_post_tags` table or attach
  taxonomy terms from a 'hashtags' vocabulary via
  `attach_term('social_post', postId, 'hashtags', 'foo')`.
- **Attachments** — schema has `attachments_json` but there's no upload
  UI or rendering. Wire `FileUploadService` into the composer and
  render attachment thumbs in `post_card.php`.
- **Block / mute** — block list at follow-time would filter posts from
  blocked users in `homeFeed`; mute is a softer variant that keeps the
  follow but hides posts.
- **Ranked feeds** — trivial to bolt on — replace the
  `ORDER BY created_at DESC` in `homeFeed` with a score column maintained
  by a background job.
- **Notification fan-out on new followers** — currently silent. Add a
  `FollowController::follow` hook that creates a notification.

## Verification

- `php -l modules/social/**/*.php` — lint-check.
- Create two users, have A follow B, post as B, see the post on A's
  `/feed`. Unfollow. Post another as B. Refresh A's `/feed`: only the
  first post remains.
- Post as visibility='public' from `/feed`, confirm it shows on
  `/users/{you}`. Post visibility='group' from `/feed/groups/{slug}`,
  confirm it does NOT show on `/users/{you}` and DOES show on
  `/feed/groups/{slug}`.

## Troubleshooting

- **Post detail page says "Install the comments module"** — that
  string appears only when `comments()` helper isn't defined. Install
  `claudephpframework-module-comments` and reload.
- **Group feed shows "not a member"** — you aren't a member of that
  group, or `user_groups` doesn't have your row. Accept the group
  invite or rejoin via `/groups/{slug}`.
- **"People you might follow" is empty** — the suggestion query is
  friend-of-friend via follows. Follow at least one person first; the
  algorithm needs a seed.
