# Architecture — Groups + Roles module

## Files

```
groups/
├── module.php
├── routes.php                          # 24 route registrations
├── Controllers/
│   ├── GroupController.php             # User-facing + owner removal flow
│   └── RoleController.php              # System-wide roles admin
└── Views/
    ├── index.php                       # My groups
    ├── create.php                      # Create group form
    ├── show.php                        # Group detail / members
    ├── invite.php                      # Invite form
    ├── join.php                        # Public join page (token)
    ├── roles.php                       # Per-group custom roles
    ├── owner_removal_confirm.php       # Approval page
    ├── admin/groups_index.php          # Admin: all groups
    ├── admin/roles_index.php           # Admin: system roles
    ├── admin/roles_create.php
    └── admin/roles_edit.php
```

## Tables

- `groups` — id, name, slug, description, created_by, created_at
- `user_groups` — user_id, group_id, role (owner/admin/member), joined_at
- `roles` — id, name, slug, description (system-level roles)
- `permissions` — id, name, key
- `role_permissions` — role_id, permission_id
- `user_roles` — user_id, role_id (global assignments)
- `group_roles` — group_id, name, permissions_json (per-group custom roles)
- `group_invites` — id, group_id, email, token, invited_by, expires_at
- `group_owner_removal_requests` — id, group_id, target_user_id,
  requester_id, outcome (role_change / full_removal), status, resolved_by

All from `install.sql`.

## Owner-removal workflow

Removing an owner — either to change their role or to kick them — requires
two-party action:

1. A group admin POSTs to `/groups/{id}/request-owner-removal` specifying
   the target user and the outcome (`role_change` or `full_removal`).
2. A row lands in `group_owner_removal_requests` with status `pending`.
3. Other owners (and sometimes the target) see the approval in their
   dashboard. GET `/groups/{groupId}/owner-removal/{reqId}/{action}`
   renders the confirmation page.
4. POST to the same URL applies the action.

**Invariant:** a group can never have zero owners. Code enforces this
inside `resolveOwnerRemoval()` by counting remaining owners before
committing.

## Per-group custom roles

System-wide `roles` define defaults; `group_roles` lets each group layer
its own role definitions using the same permission vocabulary. When
resolving permissions for a user in a group, the framework checks group
roles first, then falls back to system roles.

## Authorization patterns

- User-facing routes: `AuthMiddleware`. Controllers then check
  `isGroupAdmin($groupId)` / `isGroupOwner($groupId)` before writes.
- Admin routes: `AuthMiddleware + RequireAdmin`.
- Owner-only destructive actions (delete group, change ownership) require
  both `isGroupOwner` AND `$this->auth->cannot('groups.manage')` as a
  secondary gate for defense-in-depth.

## Dependencies

- `claudephpframework-core` — Auth, Database, MailService (invites), View
- `App\Models\Group`, `App\Models\User`, `App\Models\Role` — available in
  core
- Tables from `install.sql` (not migration-based as of current release)

## Extension points

- **New permission** — add to core's `install.sql` seeder (or write a
  migration under `modules/groups/migrations/`), then grant it to roles
  via `/admin/roles/{id}/edit`.
- **New membership role** — add via `/groups/{id}/roles` for a specific
  group, or via `/admin/roles/create` for a system-wide default.
- **Custom invite email** — override the view at
  `modules/groups/Views/invite_email.php` (currently inlined in the
  controller; extract when you need customization).
