<?php $pageTitle = 'My Groups'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card-header" style="margin-bottom:1.5rem;border:1px solid var(--color-gray-200);border-radius:8px">
    <h2 style="margin:0">My Groups</h2>
    <?php if (can_create_group()): ?>
    <a href="/groups/create" class="btn btn-primary">+ Create Group</a>
    <?php endif; ?>
</div>

<?php if (empty($groups)): ?>
<div class="card">
    <div class="card-body" style="text-align:center;padding:3rem">
        <div style="font-size:3rem;margin-bottom:1rem">👥</div>
        <h3 style="margin:0 0 .5rem">No groups yet</h3>
        <?php if (can_create_group()): ?>
        <p style="color:#6b7280">Create your first group or wait for an invitation.</p>
        <a href="/groups/create" class="btn btn-primary" style="display:inline-flex;margin-top:1rem">Create a Group</a>
        <?php else: ?>
        <p style="color:#6b7280">Group creation is disabled on this site. Wait for an invitation from an existing group owner.</p>
        <?php endif; ?>
    </div>
</div>
<?php else: ?>
<div class="grid grid-3">
<?php foreach ($groups as $g): ?>
<div class="card" style="padding:1.25rem">
    <div style="display:flex;align-items:center;gap:.75rem;margin-bottom:.75rem">
        <?php if (!empty($g['avatar'])): ?>
        <img src="<?= e($g['avatar']) ?>" alt="<?= e($g['name']) ?>"
             style="width:44px;height:44px;border-radius:10px;object-fit:cover;flex-shrink:0">
        <?php else: ?>
        <div style="width:44px;height:44px;border-radius:10px;background:#4f46e5;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.1rem">
            <?= e(strtoupper(substr($g['name'], 0, 1))) ?>
        </div>
        <?php endif; ?>
        <div>
            <div style="font-weight:600;font-size:.95rem"><?= e($g['name']) ?></div>
            <span class="badge badge-primary"><?= e($g['role_name'] ?? 'Member') ?></span>
        </div>
    </div>
    <?php if ($g['description']): ?>
    <p style="color:#6b7280;font-size:13px;margin:0 0 .75rem"><?= e($g['description']) ?></p>
    <?php endif; ?>
    <a href="/groups/<?= e($g['slug']) ?>" class="btn btn-secondary btn-sm" style="width:100%;justify-content:center">View Group</a>
</div>
<?php endforeach; ?>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
