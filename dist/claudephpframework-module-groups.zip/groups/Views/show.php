<?php $pageTitle = e($group['name']); ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;gap:1.5rem;align-items:flex-start">

    <div style="flex:1;min-width:0">
        <div class="card" style="margin-bottom:1rem">
            <div class="card-header">
                <div style="display:flex;align-items:center;gap:.75rem">
                    <?php if (!empty($group['avatar'])): ?>
                    <img src="<?= e($group['avatar']) ?>" alt="<?= e($group['name']) ?>"
                         style="width:48px;height:48px;border-radius:10px;object-fit:cover">
                    <?php else: ?>
                    <div style="width:48px;height:48px;border-radius:10px;background:#4f46e5;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:1.2rem">
                        <?= e(strtoupper(substr($group['name'],0,1))) ?>
                    </div>
                    <?php endif; ?>
                    <div>
                        <h2 style="margin:0"><?= e($group['name']) ?></h2>
                        <?php if ($group['is_public']): ?>
                        <span class="badge badge-success">Public</span>
                        <?php else: ?>
                        <span class="badge badge-gray">Private</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php if ($isAdmin): ?>
                <div style="display:flex;gap:.5rem">
                    <a href="/groups/<?= $group['id'] ?>/invite" class="btn btn-sm btn-primary">Invite</a>
                    <a href="/groups/<?= $group['id'] ?>/roles" class="btn btn-sm btn-secondary">Manage Roles</a>
                </div>
                <?php endif; ?>
            </div>
            <?php if ($group['description']): ?>
            <div class="card-body">
                <p style="margin:0;color:#374151"><?= e($group['description']) ?></p>
            </div>
            <?php endif; ?>
        </div>

        <div class="card">
            <div class="card-header"><h2>Members (<?= count($members) ?>)</h2></div>
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Member</th>
                            <th>Role</th>
                            <th>Joined</th>
                            <?php if ($isAdmin): ?><th>Actions</th><?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($members as $m): ?>
                    <tr>
                        <td>
                            <div style="display:flex;align-items:center;gap:.6rem">
                                <span class="avatar"><?= e(strtoupper(substr($m['first_name']??'?',0,1))) ?></span>
                                <div>
                                    <div style="font-weight:500"><?= e(($m['first_name']??'').' '.($m['last_name']??'')) ?></div>
                                    <div style="font-size:12px;color:#6b7280"><?= e($m['email']) ?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <?php
                            $roleClass = match($m['base_role']??'member'){
                                'group_owner'=>'badge-danger','group_admin'=>'badge-warning',
                                'manager'=>'badge-info','editor'=>'badge-primary',default=>'badge-gray'
                            };
                            $rowIsOwner    = (($m['base_role'] ?? '') === 'group_owner');
                            $viewerIsOwner = auth()->isGroupOwner($group['id']);
                            $canChangeRole = $isAdmin && $m['id'] !== auth()->id() && !$rowIsOwner;
                            ?>
                            <?php if ($canChangeRole && !empty($roles)): ?>
                                <form method="POST"
                                      action="/groups/<?= (int)$group['id'] ?>/members/<?= (int)$m['id'] ?>/role"
                                      style="margin:0">
                                    <?= csrf_field() ?>
                                    <select name="group_role_id"
                                            onchange="confirmRolePromotion(this)"
                                            class="form-control"
                                            style="padding:.15rem .3rem;font-size:12px;width:auto;display:inline-block">
                                        <?php foreach ($roles as $r): ?>
                                            <?php if ($r['base_role'] === 'group_owner' && !$viewerIsOwner) continue; ?>
                                            <option value="<?= (int)$r['id'] ?>"
                                                    data-base-role="<?= e($r['base_role']) ?>"
                                                    <?= ((int)($m['group_role_id'] ?? 0) === (int)$r['id']) ? 'selected' : '' ?>>
                                                <?= e($r['name']) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </form>
                            <?php else: ?>
                                <span class="badge <?= $roleClass ?>"><?= e($m['role_name']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td style="color:#6b7280;font-size:13px"><?= date('M j, Y', strtotime($m['joined_at'])) ?></td>
                        <?php if ($isAdmin && $m['id'] !== auth()->id()): ?>
                        <td>
                            <?php
                            $rowIsOwner    = ($m['base_role'] === 'group_owner');
                            $viewerIsOwner = auth()->isGroupOwner($group['id']);
                            ?>
                            <?php if ($rowIsOwner && $viewerIsOwner): ?>
                                <form method="POST" action="/groups/<?= $group['id'] ?>/request-owner-removal"
                                      style="display:flex;gap:.25rem;align-items:center;margin:0"
                                      data-confirm="Send the removal request? They must approve it before anything happens.">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="user_id" value="<?= $m['id'] ?>">
                                    <select name="new_role_id" class="form-control"
                                            style="padding:.15rem .3rem;font-size:11.5px;width:auto;display:inline-block"
                                            title="What happens on approval">
                                        <option value="">Remove from group</option>
                                        <?php foreach ($roles as $r): ?>
                                            <?php if ($r['base_role'] === 'group_owner') continue; ?>
                                            <option value="<?= (int)$r['id'] ?>">Demote to <?= e($r['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button class="btn btn-xs btn-danger">Request Removal</button>
                                </form>
                            <?php elseif ($rowIsOwner): ?>
                                <span style="color:#9ca3af;font-size:12px">—</span>
                            <?php else: ?>
                                <form method="POST" action="/groups/<?= $group['id'] ?>/members/<?= $m['id'] ?>/remove" data-confirm="Remove this member?" style="display:inline">
                                    <?= csrf_field() ?><button class="btn btn-xs btn-danger">Remove</button>
                                </form>
                            <?php endif; ?>
                        </td>
                        <?php elseif ($isAdmin && $m['id'] === auth()->id()): ?>
                        <td><span style="color:#6b7280;font-size:12px">You</span></td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div style="width:280px;flex-shrink:0">
        <div class="card" style="padding:1.25rem">
            <div style="font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:#6b7280;margin-bottom:.75rem">Group Info</div>
            <div style="font-size:13.5px;display:flex;flex-direction:column;gap:.5rem">
                <div><strong>Members:</strong> <?= count($members) ?></div>
                <div><strong>Your Role:</strong> <?= e($isMember ? (auth()->groups()[array_search($group['id'], array_column(auth()->groups(),'id'))]['group_role_name'] ?? 'Member') : 'Not a member') ?></div>
            </div>

            <?php $isOwner = $isMember && auth()->isGroupOwner($group['id']); ?>
            <?php if ($isMember && !$isOwner): ?>
            <form method="POST" action="/groups/<?= (int)$group['id'] ?>/leave"
                  data-confirm="Leave <?= e($group['name']) ?>? You'll need a new invitation to rejoin."
                  style="margin-top:1rem">
                <?= csrf_field() ?>
                <button class="btn btn-sm btn-secondary" style="width:100%">Leave Group</button>
            </form>
            <?php elseif ($isOwner): ?>
            <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid #e5e7eb;font-size:12px;color:#6b7280;line-height:1.5">
                As a group owner you cannot leave directly. Another owner must initiate an owner-removal request, or you can transfer ownership first.
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function confirmRolePromotion(sel) {
    const opt = sel.selectedOptions[0];
    if (opt?.dataset.baseRole === 'group_owner') {
        const ok = confirm(
            'Share ownership of this group?\n\n' +
            'They will have full owner privileges — invite/remove members, ' +
            'change roles, manage content, and file their own owner-removal ' +
            'requests (including against you, subject to approval).\n\n' +
            'Continue?'
        );
        if (!ok) {
            const original = sel.querySelector('option[selected]');
            if (original) sel.value = original.value;
            return;
        }
    }
    sel.form.submit();
}
</script>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
