<?php $pageTitle = $role ? 'Edit Role' : 'Create Role'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:700px;margin:0 auto">
<div class="card">
    <div class="card-header">
        <h2><?= $role ? 'Edit Role: '.e($role['name']) : 'Create New Role' ?></h2>
        <a href="/admin/roles" class="btn btn-secondary btn-sm">← Back</a>
    </div>
    <div class="card-body">
        <?php $errors = \Core\Session::flash('errors') ?? []; ?>
        <form method="POST" action="<?= $role ? '/admin/roles/'.$role['id'].'/edit' : '/admin/roles/create' ?>">
            <?= csrf_field() ?>

            <div class="grid grid-2">
                <div class="form-group">
                    <label>Role Name *</label>
                    <input type="text" name="name" class="form-control <?= !empty($errors['name'])?'is-invalid':'' ?>"
                           value="<?= e($role['name'] ?? old('name')) ?>" required oninput="autoSlugRole(this)">
                    <?php if (!empty($errors['name'])): ?><span class="form-error"><?= e($errors['name'][0]) ?></span><?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Slug *</label>
                    <input type="text" id="role-slug" name="slug" class="form-control <?= !empty($errors['slug'])?'is-invalid':'' ?>"
                           value="<?= e($role['slug'] ?? old('slug')) ?>" required
                           <?= ($role['is_system'] ?? 0) ? 'readonly' : '' ?>>
                    <?php if (!empty($errors['slug'])): ?><span class="form-error"><?= e($errors['slug'][0]) ?></span><?php endif; ?>
                </div>
            </div>

            <div class="form-group">
                <label>Description</label>
                <textarea name="description" class="form-control" rows="2"><?= e($role['description'] ?? '') ?></textarea>
            </div>

            <div class="form-group">
                <label>Permissions</label>
                <?php
                $grouped = [];
                foreach ($permissions as $p) {
                    $grouped[$p['module']][] = $p;
                }
                ?>
                <?php foreach ($grouped as $module => $perms): ?>
                <div style="border:1px solid #e5e7eb;border-radius:6px;margin-bottom:.75rem;overflow:hidden">
                    <div style="background:#f9fafb;padding:.5rem .85rem;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;justify-content:space-between">
                        <strong style="font-size:13px;text-transform:capitalize"><?= e($module) ?></strong>
                        <label style="font-size:12px;cursor:pointer;display:flex;align-items:center;gap:.35rem;font-weight:400">
                            <input type="checkbox" onchange="toggleModule('<?= e($module) ?>', this.checked)"> All
                        </label>
                    </div>
                    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:.1rem;padding:.5rem .85rem">
                        <?php foreach ($perms as $p): ?>
                        <label style="display:flex;align-items:center;gap:.45rem;cursor:pointer;font-weight:400;font-size:13.5px;padding:.2rem 0">
                            <input type="checkbox" name="permissions[]" value="<?= $p['id'] ?>"
                                   data-module="<?= e($module) ?>"
                                   <?= in_array($p['id'], $assigned) ? 'checked' : '' ?>>
                            <?= e($p['name']) ?>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="display:flex;gap:.75rem">
                <button type="submit" class="btn btn-primary"><?= $role ? 'Save Changes' : 'Create Role' ?></button>
                <a href="/admin/roles" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</div>

<script>
function autoSlugRole(input) {
    const s = document.getElementById('role-slug');
    if (!s.readOnly) {
        s.value = input.value.toLowerCase().replace(/[^a-z0-9\s\-]/g,'').replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
    }
}
function toggleModule(module, checked) {
    document.querySelectorAll('[data-module="'+module+'"]').forEach(cb => cb.checked = checked);
}
</script>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
