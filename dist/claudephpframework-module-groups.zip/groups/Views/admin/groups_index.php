<?php $pageTitle = 'Groups (Admin)'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header"><h2>All Groups</h2></div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Group</th><th>Members</th><th>Public</th><th>Created</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($groups as $g): ?>
            <tr>
                <td>
                    <div style="font-weight:500"><?= e($g['name']) ?></div>
                    <div style="font-size:12px;color:#6b7280">/groups/<?= e($g['slug']) ?></div>
                </td>
                <td><?= $g['member_count'] ?? 0 ?></td>
                <td><?= $g['is_public'] ? '<span class="badge badge-success">Public</span>' : '<span class="badge badge-gray">Private</span>' ?></td>
                <td style="font-size:13px;color:#6b7280"><?= date('M j, Y', strtotime($g['created_at'])) ?></td>
                <td>
                    <div style="display:flex;gap:.35rem">
                        <a href="/groups/<?= e($g['slug']) ?>" class="btn btn-xs btn-secondary">View</a>
                        <form method="POST" action="/admin/groups/<?= $g['id'] ?>/delete"
                              data-confirm="Delete group '<?= e($g['name']) ?>'? This cannot be undone.">
                            <?= csrf_field() ?><button class="btn btn-xs btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
