<?php $pageTitle = 'Roles'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h2>System Roles</h2>
        <a href="/admin/roles/create" class="btn btn-primary btn-sm">+ New Role</a>
    </div>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Role</th><th>Slug</th><th>Type</th><th>Permissions</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($roles as $r): ?>
            <tr>
                <td>
                    <div style="font-weight:500"><?= e($r['name']) ?></div>
                    <?php if ($r['description']): ?><div style="font-size:12px;color:#6b7280"><?= e($r['description']) ?></div><?php endif; ?>
                </td>
                <td><code style="font-size:12px;background:#f3f4f6;padding:.1rem .4rem;border-radius:4px"><?= e($r['slug']) ?></code></td>
                <td><?= $r['is_system'] ? '<span class="badge badge-danger">System</span>' : '<span class="badge badge-gray">Custom</span>' ?></td>
                <td style="font-size:13px;color:#6b7280"><?= count($r['permissions']) ?> permissions</td>
                <td>
                    <div style="display:flex;gap:.35rem">
                        <a href="/admin/roles/<?= $r['id'] ?>/edit" class="btn btn-xs btn-secondary">Edit</a>
                        <?php if (!$r['is_system']): ?>
                        <form method="POST" action="/admin/roles/<?= $r['id'] ?>/delete" data-confirm="Delete role '<?= e($r['name']) ?>'?">
                            <?= csrf_field() ?><button class="btn btn-xs btn-danger">Delete</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
