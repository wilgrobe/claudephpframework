<?php $pageTitle = 'Invite to ' . e($group['name']); ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:580px;margin:0 auto">
<div class="card">
    <div class="card-header"><h2>Invite Members to <?= e($group['name']) ?></h2></div>
    <div class="card-body">
        <?php $errors = \Core\Session::flash('errors') ?? []; ?>
        <form method="POST" action="/groups/<?= $group['id'] ?>/invite">
            <?= csrf_field() ?>

            <div class="form-group">
                <label>Role to Assign</label>
                <select name="role_id" id="invite-role" class="form-control" required>
                    <?php foreach ($roles as $r): ?>
                    <?php if ($r['base_role'] !== 'group_owner' || auth()->isGroupOwner($group['id'])): ?>
                    <option value="<?= $r['id'] ?>" data-base-role="<?= e($r['base_role']) ?>"><?= e($r['name']) ?></option>
                    <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label>Invite Method</label>
                <div style="display:flex;flex-direction:column;gap:.5rem">
                    <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer">
                        <input type="radio" name="invite_type" value="email" checked onchange="toggleInviteType(this.value)">
                        By Email
                    </label>
                    <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer">
                        <input type="radio" name="invite_type" value="phone" onchange="toggleInviteType(this.value)">
                        By SMS / Phone
                    </label>
                    <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer">
                        <input type="radio" name="invite_type" value="user" onchange="toggleInviteType(this.value)">
                        Existing Platform User
                    </label>
                </div>
            </div>

            <div id="field-email" class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" class="form-control" placeholder="user@example.com">
            </div>
            <div id="field-phone" class="form-group" style="display:none">
                <label>Phone Number</label>
                <input type="tel" name="phone" class="form-control" placeholder="+1 555 000 0000">
            </div>
            <div id="field-user" class="form-group" style="display:none">
                <label>Search for User</label>
                <input type="text" id="user-search-input" class="form-control" placeholder="Type name or email…"
                       autocomplete="off" oninput="searchUsers(this.value)">
                <input type="hidden" name="user_id" id="user-search-id">
                <div id="user-search-results" style="border:1px solid #e5e7eb;border-radius:6px;margin-top:.25rem;display:none;background:#fff;box-shadow:0 4px 8px rgba(0,0,0,.08);max-height:220px;overflow-y:auto;position:relative;z-index:10"></div>
                <div id="user-search-selected" style="display:none;margin-top:.4rem;font-size:13px;color:#4f46e5;font-weight:500"></div>
            </div>

            <div style="display:flex;gap:.75rem">
                <button type="submit" class="btn btn-primary">Send Invitation</button>
                <a href="/groups/<?= e($group['slug']) ?>" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</div>

<script>
function toggleInviteType(type) {
    ['email','phone','user'].forEach(t => {
        document.getElementById('field-'+t).style.display = t === type ? '' : 'none';
    });
}

let searchTimer;
async function searchUsers(q) {
    const results = document.getElementById('user-search-results');
    const idInput = document.getElementById('user-search-id');
    idInput.value = '';
    document.getElementById('user-search-selected').style.display = 'none';

    if (q.length < 2) { results.style.display = 'none'; return; }
    clearTimeout(searchTimer);
    searchTimer = setTimeout(async () => {
        const data = await safeJson('/api/users/search?q=' + encodeURIComponent(q));
        if (!data.length) { results.innerHTML = '<div style="padding:.75rem 1rem;font-size:13px;color:#6b7280">No users found</div>'; results.style.display = ''; return; }
        results.innerHTML = data.map(u =>
            `<div onclick="selectUser(${u.id}, '${u.name.replace(/'/g,"\\'")} &lt;${u.email}&gt;')"
                  style="padding:.65rem 1rem;cursor:pointer;font-size:13.5px;border-bottom:1px solid #f3f4f6"
                  onmouseover="this.style.background='#f9fafb'" onmouseout="this.style.background=''"
             ><strong>${u.name}</strong> <span style="color:#6b7280">${u.email}</span></div>`
        ).join('');
        results.style.display = '';
    }, 250);
}

function selectUser(id, label) {
    document.getElementById('user-search-id').value = id;
    document.getElementById('user-search-input').value = label.replace(/&lt;/g,'<').replace(/&gt;/g,'>');
    document.getElementById('user-search-results').style.display = 'none';
    const sel = document.getElementById('user-search-selected');
    sel.textContent = '✓ Selected: ' + label.replace(/&lt;/g,'<').replace(/&gt;/g,'>');
    sel.style.display = '';
}

document.addEventListener('click', e => {
    if (!e.target.closest('#field-user')) {
        document.getElementById('user-search-results').style.display = 'none';
    }
});

document.querySelector('form[action$="/invite"]')?.addEventListener('submit', (e) => {
    const sel = document.getElementById('invite-role');
    const opt = sel?.selectedOptions?.[0];
    if (opt?.dataset.baseRole === 'group_owner') {
        const ok = confirm(
            'Share ownership of this group?\n\n' +
            'The invited person will have full owner privileges — they can ' +
            'invite, remove members (including you, via the approval ' +
            'workflow), change roles, and manage all group content.\n\n' +
            'Continue?'
        );
        if (!ok) e.preventDefault();
    }
});
</script>
<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
