<?php $pageTitle = 'Roles — ' . e($group['name']); ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="margin-bottom:1rem;display:flex;align-items:center;gap:.75rem">
    <a href="/groups/<?= e($group['slug']) ?>" class="btn btn-secondary btn-sm">← Back to Group</a>
    <h2 style="margin:0"><?= e($group['name']) ?> — Role Management</h2>
</div>

<div class="grid grid-2" style="align-items:flex-start">

    <div class="card">
        <div class="card-header"><h2>Group Roles</h2></div>
        <div class="table-responsive">
            <table class="table">
                <thead><tr><th>Role</th><th>Base</th><th>Type</th><th></th></tr></thead>
                <tbody>
                <?php foreach ($roles as $r): ?>
                <tr>
                    <td>
                        <div style="font-weight:500"><?= e($r['name']) ?></div>
                        <?php if ($r['description']): ?><div style="font-size:12px;color:#6b7280"><?= e($r['description']) ?></div><?php endif; ?>
                    </td>
                    <td><span class="badge badge-gray"><?= e($r['base_role']) ?></span></td>
                    <td>
                        <?php if ($r['is_system']): ?>
                        <span class="badge badge-primary">System</span>
                        <?php else: ?>
                        <span class="badge badge-success">Custom</span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if (!$r['is_system']): ?>
                        <form method="POST" action="/groups/<?= $group['id'] ?>/roles/<?= $r['id'] ?>/delete"
                              data-confirm="Delete this custom role? Members will need reassignment.">
                            <?= csrf_field() ?>
                            <button class="btn btn-xs btn-danger">Delete</button>
                        </form>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <div class="card-header"><h2>Create Custom Role</h2></div>
        <div class="card-body">
            <?php $errors = \Core\Session::flash('errors') ?? []; ?>
            <form method="POST" action="/groups/<?= $group['id'] ?>/roles">
                <?= csrf_field() ?>
                <div class="form-group">
                    <label>Role Name *</label>
                    <input type="text" name="name" class="form-control <?= !empty($errors['name'])?'is-invalid':'' ?>"
                           value="<?= old('name') ?>" required oninput="autoSlugRole(this)">
                    <?php if (!empty($errors['name'])): ?><span class="form-error"><?= e($errors['name'][0]) ?></span><?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Slug *</label>
                    <input type="text" id="role-slug" name="slug" class="form-control" value="<?= old('slug') ?>" required>
                </div>
                <div class="form-group">
                    <label>Base Role *
                        <span style="font-size:11px;color:#6b7280;font-weight:400">(custom roles inherit from manager, editor, or member)</span>
                    </label>
                    <select name="base_role" class="form-control" required>
                        <option value="manager">Manager</option>
                        <option value="editor">Editor</option>
                        <option value="member" selected>Member</option>
                    </select>
                    <?php if (!empty($errors['base_role'])): ?><span class="form-error"><?= e($errors['base_role'][0]) ?></span><?php endif; ?>
                </div>
                <div class="form-group">
                    <label>Description</label>
                    <textarea name="description" class="form-control" rows="2"><?= old('description') ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Create Role</button>
            </form>
        </div>
    </div>
</div>

<script>
function autoSlugRole(input) {
    document.getElementById('role-slug').value = input.value.toLowerCase()
        .replace(/[^a-z0-9\s\-]/g,'').replace(/\s+/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
}
</script>
<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
