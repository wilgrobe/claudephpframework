<?php $pageTitle = 'Create Group'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:600px;margin:0 auto">
<div class="card">
    <div class="card-header"><h2>Create a New Group</h2></div>
    <div class="card-body">
        <?php $errors = \Core\Session::flash('errors') ?? []; ?>
        <form method="POST" action="/groups/create" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <div class="form-group">
                <label>Group Name *</label>
                <input type="text" name="name" class="form-control <?= !empty($errors['name'])?'is-invalid':'' ?>"
                       value="<?= old('name') ?>" required oninput="autoSlug(this)">
                <?php if (!empty($errors['name'])): ?><span class="form-error"><?= e($errors['name'][0]) ?></span><?php endif; ?>
            </div>
            <div class="form-group">
                <label>URL Slug *</label>
                <input type="text" id="slug" name="slug" class="form-control <?= !empty($errors['slug'])?'is-invalid':'' ?>"
                       value="<?= old('slug') ?>" required pattern="[a-z0-9\-]+">
                <span style="font-size:12px;color:#6b7280">Lowercase letters, numbers, hyphens only. This becomes your group's URL.</span>
                <?php if (!empty($errors['slug'])): ?><span class="form-error"><?= e($errors['slug'][0]) ?></span><?php endif; ?>
            </div>
            <div class="form-group">
                <label>Description</label>
                <textarea name="description" class="form-control" rows="3"><?= old('description') ?></textarea>
            </div>
            <div class="form-group">
                <label>Group Icon <span style="color:#6b7280;font-weight:400;font-size:12px">(optional · JPEG, PNG, WebP · max 2 MB)</span></label>
                <input type="file" name="avatar" accept="image/jpeg,image/png,image/gif,image/webp" style="font-size:13px">
            </div>
            <div class="form-group">
                <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer">
                    <input type="checkbox" name="is_public" value="1" <?= old('is_public') ? 'checked' : '' ?>>
                    Make this group public (anyone can join without an invite)
                </label>
            </div>
            <div style="display:flex;gap:.75rem">
                <button type="submit" class="btn btn-primary">Create Group</button>
                <a href="/groups" class="btn btn-secondary">Cancel</a>
            </div>
        </form>
    </div>
</div>
</div>

<script>
function autoSlug(input) {
    document.getElementById('slug').value = input.value.toLowerCase()
        .replace(/[^a-z0-9\s\-]/g,'').replace(/[\s]+/g,'-').replace(/\-+/g,'-').replace(/^-|-$/g,'');
}
</script>
<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
