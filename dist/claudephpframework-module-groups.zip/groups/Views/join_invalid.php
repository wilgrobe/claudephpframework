<?php $pageTitle = 'Invalid Invitation'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>
<div style="max-width:480px;margin:2rem auto;text-align:center">
    <div class="card" style="padding:2.5rem">
        <div style="font-size:3rem;margin-bottom:1rem">⚠️</div>
        <h2>Invitation Not Found</h2>
        <p style="color:#6b7280">This invitation link is invalid, has already been used, or has expired.</p>
        <a href="/dashboard" class="btn btn-primary" style="display:inline-flex;margin-top:1rem">Go to Dashboard</a>
    </div>
</div>
<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
