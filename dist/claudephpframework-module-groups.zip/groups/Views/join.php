<?php $pageTitle = 'Accept Invitation'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:480px;margin:2rem auto">
<div class="card" style="text-align:center;padding:2.5rem">
    <div style="font-size:3rem;margin-bottom:1rem">🎉</div>
    <h2 style="margin:0 0 .5rem">You've been invited!</h2>
    <p style="color:#6b7280;margin:0 0 1.5rem">
        You have been invited to join <strong><?= e($invitation['group_name']) ?></strong>
        as a <strong><?= e($invitation['role_name'] ?? 'Member') ?></strong>.
    </p>

    <?php if (auth()->guest()): ?>
    <p style="font-size:13.5px;color:#6b7280;margin-bottom:1.5rem">You need to sign in or create an account to accept this invitation.</p>
    <div style="display:flex;gap:.75rem;justify-content:center">
        <a href="/login" class="btn btn-primary">Sign In</a>
        <a href="/register" class="btn btn-secondary">Create Account</a>
    </div>
    <?php else: ?>
    <form method="POST" action="/join/<?= e($invitation['token']) ?>">
        <?= csrf_field() ?>
        <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center">Accept Invitation</button>
    </form>
    <a href="/dashboard" style="display:block;margin-top:.75rem;font-size:13.5px;color:#6b7280">Decline</a>
    <?php endif; ?>
</div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
