<?php $pageTitle = 'Owner Removal Request'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:520px;margin:2rem auto">
<div class="card">
    <div class="card-header">
        <h2>Owner Removal Request</h2>
    </div>
    <div class="card-body">

        <?php
        $outcomeLabel = isset($outcomeRole) && $outcomeRole
            ? 'your role will change to <strong>' . e($outcomeRole['name']) . '</strong>'
            : 'you will be <strong>removed from the group entirely</strong>';
        ?>
        <div style="background:#fef3c7;border:1px solid #fcd34d;border-radius:8px;padding:1rem 1.25rem;margin-bottom:1.25rem;display:flex;gap:.75rem;align-items:flex-start">
            <span style="font-size:1.3rem;flex-shrink:0">⚠️</span>
            <div>
                <strong style="display:block;font-size:14px;color:#92400e;margin-bottom:.3rem">
                    Another owner of <?= e($group['name']) ?> has requested your removal as group owner.
                </strong>
                <p style="font-size:13px;color:#78350f;margin:0;line-height:1.5">
                    If you approve, <?= $outcomeLabel ?>.
                    Reversing this requires another group owner to reassign your previous permissions.
                </p>
            </div>
        </div>

        <p style="font-size:13.5px;color:#374151;margin:0 0 1.5rem">
            Please choose an action. You must submit the form below — the email link alone does not complete the action.
        </p>

        <div style="display:flex;gap:.75rem">
            <?php if ($action === 'approve'): ?>
            <form method="POST" action="/groups/<?= $group['id'] ?>/owner-removal/<?= $req['id'] ?>/approve"
                  data-confirm="Are you sure? You will be removed as group owner.">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-danger" style="background:#dc2626;color:#fff;border-color:#dc2626">
                    Confirm Removal
                </button>
            </form>
            <a href="/groups/<?= e($group['slug']) ?>" class="btn btn-secondary">Cancel (keep ownership)</a>
            <?php else: ?>
            <form method="POST" action="/groups/<?= $group['id'] ?>/owner-removal/<?= $req['id'] ?>/reject">
                <?= csrf_field() ?>
                <button type="submit" class="btn btn-primary">Reject Removal Request</button>
            </form>
            <a href="/groups/<?= e($group['slug']) ?>" class="btn btn-secondary">Cancel</a>
            <?php endif; ?>
        </div>

    </div>
</div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
