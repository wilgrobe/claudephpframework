<?php
// modules/groups/module.php
use Core\Module\ModuleProvider;

/**
 * Groups + Roles module. Combined because RoleController (global app roles)
 * is tightly coupled to GroupController (per-group roles use the same
 * permissions schema, and the admin UI for both lives under the same
 * superadmin surface).
 *
 * Includes the complex multi-owner workflow:
 *   - ownership must have at least one owner at all times
 *   - owners can only be removed via a request → target approves flow
 *   - outcome (role-change vs full removal) is decided at request time
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'groups'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
