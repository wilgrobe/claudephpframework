<?php
// modules/groups/Controllers/GroupController.php
namespace Modules\Groups\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Validation\Validator;
use Core\Services\{MailService, SmsService, NotificationService, FileUploadService};
use Core\SEO\SeoManager;
use App\Models\{Group, User};

/**
 * Ported from App\Controllers\GroupController. Behavior identical. Only
 * namespace moved and Response::view() calls use the 'groups::' prefix.
 */
class GroupController
{
    private Group               $groupModel;
    private MailService         $mail;
    private SmsService          $sms;
    private NotificationService $notifications;
    private Auth                $auth;

    public function __construct()
    {
        $this->groupModel    = new Group();
        $this->mail          = new MailService();
        $this->sms           = new SmsService();
        $this->notifications = new NotificationService();
        $this->auth          = Auth::getInstance();
    }

    public function myGroups(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $groups = $this->groupModel->getUserGroups($this->auth->id());
        return Response::view('groups::my_groups', ['groups' => $groups, 'user' => $this->auth->user()]);
    }

    public function show(Request $request): Response
    {
        $slug = $request->param(0);
        $group = $this->groupModel->findBySlug($slug);
        if (!$group) return new Response('Group not found', 404);

        $isMember = $this->auth->inGroup($slug);
        $isAdmin  = $this->auth->isGroupAdmin($group['id']);

        $members = $isMember ? $this->groupModel->getMembers($group['id']) : [];
        $roles   = $isAdmin ? $this->groupModel->getRoles($group['id']) : [];

        return Response::view('groups::show', [
            'group'    => $group,
            'members'  => $members,
            'roles'    => $roles,
            'isMember' => $isMember,
            'isAdmin'  => $isAdmin,
            'user'     => $this->auth->user(),
        ]);
    }

    public function createForm(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->canCreateGroup()) {
            return Response::redirect('/groups')
                ->withFlash('error', 'Group creation has been disabled by a site administrator.');
        }
        if ($this->singleGroupOnlyActive() && $this->userBelongsToAnyGroup()) {
            return Response::redirect('/groups')
                ->withFlash('error', 'This site limits users to a single group. Leave your current group before creating a new one.');
        }
        return Response::view('groups::create', ['user' => $this->auth->user()]);
    }

    public function store(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->canCreateGroup()) {
            return Response::redirect('/groups')
                ->withFlash('error', 'Group creation has been disabled by a site administrator.');
        }
        if ($this->singleGroupOnlyActive() && $this->userBelongsToAnyGroup()) {
            return Response::redirect('/groups')
                ->withFlash('error', 'This site limits users to a single group. Leave your current group before creating a new one.');
        }

        $v = new Validator($request->post());
        $v->validate([
            'name'        => 'required|min:2|max:150',
            'slug'        => 'required|min:2|max:150',
            'description' => 'nullable|max:1000',
        ]);

        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            Session::flash('old', $v->all());
            return Response::redirect('/groups/create');
        }

        $groupId = $this->groupModel->create([
            'name'        => $v->get('name'),
            'slug'        => $v->get('slug'),
            'description' => $v->get('description'),
            'is_public'   => (int) $request->post('is_public', 0),
            'created_by'  => $this->auth->id(),
        ]);

        if ($request->hasFile('avatar')) {
            try {
                $uploader = new FileUploadService();
                $rel      = $uploader->uploadImage($request->file('avatar'), 'group_images', 2_097_152);
                $this->groupModel->update($groupId, ['avatar' => $uploader->url($rel)]);
            } catch (\Throwable $e) {
                Session::flash('warning', 'Group created but avatar upload failed: ' . $e->getMessage());
            }
        }

        $this->groupModel->createDefaultRoles($groupId, $this->auth->id());
        $ownerRoleId = $this->groupModel->getOwnerRoleId($groupId);
        $this->groupModel->addMember($groupId, $this->auth->id(), $ownerRoleId);

        $seo = new SeoManager();
        $seo->register("groups/{$v->get('slug')}", "/groups/{$v->get('slug')}", 'group', $groupId);

        $this->auth->auditLog('group.create', 'groups', $groupId, null, ['name' => $v->get('name')]);
        $this->auth->refreshUser();

        return Response::redirect("/groups/{$v->get('slug')}")->withFlash('success', 'Group created! You are now the group owner.');
    }

    public function inviteForm(Request $request): Response
    {
        $groupId = (int) $request->param(0);
        $group   = $this->groupModel->findById($groupId);
        if (!$group) return new Response('Not found', 404);

        if (!$this->auth->isGroupAdmin($groupId)) {
            return Response::redirect("/groups/{$group['slug']}")->withFlash('error', 'Access denied.');
        }

        $roles = $this->groupModel->getRoles($groupId);
        return Response::view('groups::invite', ['group' => $group, 'roles' => $roles, 'user' => $this->auth->user()]);
    }

    public function sendInvite(Request $request): Response
    {
        $groupId = (int) $request->param(0);
        $group   = $this->groupModel->findById($groupId);
        if (!$group) return new Response('Not found', 404);

        if (!$this->auth->isGroupAdmin($groupId)) {
            return Response::redirect('/groups')->withFlash('error', 'Access denied.');
        }

        $v = new Validator($request->post());
        $v->validate([
            'invite_type' => 'required|in:email,phone,user',
            'role_id'     => 'required|integer',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect("/groups/$groupId/invite");
        }

        $inviteData = [
            'group_id'     => $groupId,
            'invited_by'   => $this->auth->id(),
            'group_role_id'=> (int) $request->post('role_id'),
        ];

        $type = $request->post('invite_type');

        if ($type === 'email') {
            $email = filter_var(trim($request->post('email', '')), FILTER_VALIDATE_EMAIL);
            if (!$email) {
                Session::flash('error', 'Invalid email address.');
                return Response::redirect("/groups/$groupId/invite");
            }
            $inviteData['email'] = $email;
            $invId = $this->groupModel->createInvitation($inviteData);
            $inv   = $this->groupModel->findInvitationByToken($this->getInvitationToken($invId));
            $joinUrl = config('app.url') . "/join/{$inv['token']}";

            $this->mail->sendTemplate($email, "You're invited to join {$group['name']}", 'group_invite', [
                'group'   => $group,
                'joinUrl' => $joinUrl,
                'inviter' => $this->auth->user(),
            ]);

        } elseif ($type === 'phone') {
            $phone = trim($request->post('phone', ''));
            if (!$phone) {
                Session::flash('error', 'Invalid phone number.');
                return Response::redirect("/groups/$groupId/invite");
            }
            $inviteData['phone'] = $phone;
            $invId = $this->groupModel->createInvitation($inviteData);
            $inv   = $this->groupModel->findInvitationByToken($this->getInvitationToken($invId));
            $joinUrl = config('app.url') . "/join/{$inv['token']}";

            $this->sms->send($phone, "You're invited to join {$group['name']}! Join here: $joinUrl");

        } elseif ($type === 'user') {
            $userId = (int) $request->post('user_id', 0);
            $userModel = new User();
            $targetUser = $userModel->findById($userId);
            if (!$targetUser) {
                Session::flash('error', 'User not found.');
                return Response::redirect("/groups/$groupId/invite");
            }
            $inviteData['user_id'] = $userId;
            $inviteData['email']   = $targetUser['email'];
            $invId = $this->groupModel->createInvitation($inviteData);
            $inv   = $this->groupModel->findInvitationByToken($this->getInvitationToken($invId));
            $joinUrl = config('app.url') . "/join/{$inv['token']}";

            $this->notifications->send(
                $userId,
                'group.invitation',
                "Invitation to join {$group['name']}",
                "{$this->auth->user()['first_name']} invited you to join {$group['name']}.",
                ['group_id' => $groupId, 'join_url' => $joinUrl],
                'in_app,email'
            );
            $this->mail->sendTemplate($targetUser['email'], "You're invited to join {$group['name']}", 'group_invite', [
                'group' => $group, 'joinUrl' => $joinUrl, 'inviter' => $this->auth->user(),
            ]);
        }

        $this->auth->auditLog('group.invite', 'groups', $groupId);
        return Response::redirect("/groups/{$group['slug']}")->withFlash('success', 'Invitation sent!');
    }

    public function joinForm(Request $request): Response
    {
        $token = $request->param(0);
        $inv   = $this->groupModel->findInvitationByToken($token);

        if (!$inv) {
            if ($this->auth->check()) {
                $used = $this->groupModel->findConsumedInvitationByToken($token, $this->auth->id());
                if ($used) {
                    return Response::redirect("/groups/{$used['group_slug']}")
                        ->withFlash('info', "You are already a member of {$used['group_name']}.");
                }
            }
            return Response::view('groups::join_invalid', ['user' => $this->auth->user()]);
        }

        if ($this->auth->guest()) {
            Session::set('invite_token', $token);
        }

        return Response::view('groups::join', ['invitation' => $inv, 'user' => $this->auth->user()]);
    }

    public function acceptJoin(Request $request): Response
    {
        $token = $request->param(0);
        $inv   = $this->groupModel->findInvitationByToken($token);

        if (!$inv) {
            if ($this->auth->check()) {
                $used = $this->groupModel->findConsumedInvitationByToken($token, $this->auth->id());
                if ($used) {
                    return Response::redirect("/groups/{$used['group_slug']}")
                        ->withFlash('info', "You are already a member of {$used['group_name']}.");
                }
            }
            return Response::redirect('/')->withFlash('error', 'Invitation not found or expired.');
        }

        if ($this->auth->guest()) {
            Session::set('invite_token', $token);
            return Response::redirect('/login')
                ->withFlash('info', 'Please sign in (or register) to accept this invitation.');
        }

        if ($this->singleGroupOnlyActive()
            && $this->userBelongsToGroupOtherThan((int) $inv['group_id'])) {
            return Response::redirect('/dashboard')->withFlash(
                'error',
                "This site limits users to a single group. Leave your current group before joining {$inv['group_name']}."
            );
        }

        $this->groupModel->acceptInvitation($inv['id'], $this->auth->id());
        $this->auth->refreshUser();
        Session::forget('invite_token');

        $this->auth->auditLog('group.join', 'groups', $inv['group_id'], null, ['via' => 'invitation']);
        return Response::redirect("/groups/{$inv['group_slug']}")->withFlash('success', "You joined {$inv['group_name']}!");
    }

    public function leave(Request $request): Response
    {
        $groupId = (int) $request->param(0);
        $group   = $this->groupModel->findById($groupId);
        if (!$group) return new Response('Not found', 404);

        if ($this->auth->guest()) {
            return Response::redirect('/login');
        }

        $userId     = $this->auth->id();
        $membership = $this->groupModel->getMembership($groupId, $userId);

        if (!$membership) {
            return Response::redirect("/groups/{$group['slug']}")
                ->withFlash('error', "You are not a member of {$group['name']}.");
        }

        if (($membership['base_role'] ?? '') === 'group_owner') {
            return Response::redirect("/groups/{$group['slug']}")->withFlash(
                'error',
                'Group owners cannot leave directly. Ask another owner to initiate an owner-removal request, or transfer ownership first.'
            );
        }

        $this->groupModel->removeMember($groupId, $userId);
        $this->auth->refreshUser();
        $this->auth->auditLog('group.leave', 'user_groups', $userId, null, ['group_id' => $groupId]);

        return Response::redirect('/groups')->withFlash('success', "You left {$group['name']}.");
    }

    public function updateMemberRole(Request $request): Response
    {
        $groupId = (int) $request->param(0);
        $userId  = (int) $request->param(1);
        $isAjax  = $request->isAjax();

        $group = $this->groupModel->findById($groupId);
        $back  = $group ? "/groups/{$group['slug']}" : '/groups';

        $respondError = function (string $msg, int $code) use ($isAjax, $back) {
            return $isAjax
                ? Response::json(['error' => $msg], $code)
                : Response::redirect($back)->withFlash('error', $msg);
        };

        if (!$this->auth->isGroupAdmin($groupId)) {
            return $respondError('Access denied', 403);
        }

        if ($userId === $this->auth->id()) {
            return $respondError('You cannot change your own role.', 422);
        }

        $newRoleId = (int) $request->post('group_role_id', 0);
        $role = $this->groupModel->findRole($newRoleId);
        if (!$role || (int) $role['group_id'] !== $groupId) {
            return $respondError('Invalid role', 422);
        }

        if ($role['base_role'] === 'group_owner' && !$this->auth->isGroupOwner($groupId)) {
            return $respondError('Only a group owner can assign the owner role.', 403);
        }

        $targetMembership = $this->groupModel->getMembership($groupId, $userId);
        if ($targetMembership && $targetMembership['base_role'] === 'group_owner') {
            return $respondError('Owners cannot be demoted directly. Use the owner-removal workflow (target must approve).', 403);
        }

        $old = $this->groupModel->getMembership($groupId, $userId);
        $this->groupModel->updateMemberRole($groupId, $userId, $newRoleId);
        $this->auth->auditLog('group.member_role_changed', 'user_groups', $userId,
            ['role' => $old['role_name'] ?? ''],
            ['role' => $role['name']]
        );

        return $isAjax
            ? Response::json(['success' => true])
            : Response::redirect($back)->withFlash('success', "Role updated to {$role['name']}.");
    }

    public function removeMember(Request $request): Response
    {
        $groupId = (int) $request->param(0);
        $userId  = (int) $request->param(1);

        $group = $this->groupModel->findById($groupId);
        $back  = $group ? "/groups/{$group['slug']}" : '/groups';

        if (!$this->auth->isGroupAdmin($groupId)) {
            return Response::redirect($back)->withFlash('error', 'Access denied.');
        }

        $membership = $this->groupModel->getMembership($groupId, $userId);
        if ($membership && $membership['base_role'] === 'group_owner') {
            return Response::redirect($back)->withFlash('error', 'Use the owner removal request workflow — only another owner can initiate that.');
        }

        $this->groupModel->removeMember($groupId, $userId);
        $this->auth->auditLog('group.member_removed', 'user_groups', $userId, null, ['group_id' => $groupId]);

        return Response::redirect($back)->withFlash('success', 'Member removed.');
    }

    // ── Owner Removal Workflow ────────────────────────────────────────────────

    public function requestOwnerRemoval(Request $request): Response
    {
        $groupId       = (int) $request->param(0);
        $targetUserId  = (int) $request->post('user_id', 0);

        $group = $this->groupModel->findById($groupId);
        $back  = $group ? "/groups/{$group['slug']}" : '/groups';

        if (!$this->auth->isGroupOwner($groupId)) {
            return Response::redirect($back)->withFlash('error', 'Only a group owner can request another owner\'s removal.');
        }

        $targetMembership = $this->groupModel->getMembership($groupId, $targetUserId);
        if (!$targetMembership || $targetMembership['base_role'] !== 'group_owner') {
            return Response::redirect($back)->withFlash('error', 'Target is not a group owner.');
        }

        $newRoleIdRaw = (string) $request->post('new_role_id', '');
        $newRoleId    = null;
        if ($newRoleIdRaw !== '' && $newRoleIdRaw !== '0') {
            $role = $this->groupModel->findRole((int) $newRoleIdRaw);
            if (!$role
                || (int) $role['group_id'] !== $groupId
                || $role['base_role'] === 'group_owner') {
                return Response::redirect($back)->withFlash(
                    'error',
                    'Invalid role selected for removal outcome.'
                );
            }
            $newRoleId = (int) $role['id'];
        }

        $outcomeRole = $newRoleId ? $this->groupModel->findRole($newRoleId) : null;
        $outcomeDescription = $outcomeRole
            ? "your role will change to {$outcomeRole['name']}"
            : 'you will be removed from the group entirely';

        $reqId = $this->groupModel->requestOwnerRemoval($groupId, $this->auth->id(), $targetUserId, $newRoleId);

        $this->notifications->send(
            $targetUserId,
            'group.owner_removal_request',
            'Owner Removal Request',
            "Another owner has requested your removal. If you approve, $outcomeDescription.",
            ['group_id' => $groupId, 'request_id' => $reqId, 'new_role_id' => $newRoleId],
            'in_app,email'
        );

        $userModel   = new User();
        $targetUser  = $userModel->findById($targetUserId);
        $group       = $this->groupModel->findById($groupId);
        $approveUrl  = config('app.url') . "/groups/$groupId/owner-removal/$reqId/approve";
        $rejectUrl   = config('app.url') . "/groups/$groupId/owner-removal/$reqId/reject";

        $this->mail->sendTemplate($targetUser['email'], 'Owner Removal Request', 'owner_removal', [
            'group'       => $group,
            'approveUrl'  => $approveUrl,
            'rejectUrl'   => $rejectUrl,
            'requester'   => $this->auth->user(),
            'outcomeRole' => $outcomeRole,
        ]);

        $this->auth->auditLog('group.owner_removal_requested', 'groups', $groupId, null, ['target' => $targetUserId]);
        return Response::redirect($back)->withFlash('success', 'Removal request sent. Target owner must approve.');
    }

    public function showOwnerRemovalPage(Request $request): Response
    {
        $groupId   = (int) $request->param(0);
        $requestId = (int) $request->param(1);
        $action    = $request->param(2);

        $req   = $this->groupModel->findOwnerRemovalRequest($requestId);
        $group = $this->groupModel->findById($groupId);

        if (!$req || (int) $req['group_id'] !== $groupId || !in_array($action, ['approve','reject'], true)) {
            return Response::redirect('/groups')->withFlash('error', 'Request not found.');
        }
        if ((int) $req['target_user_id'] !== $this->auth->id()) {
            return Response::redirect('/groups')->withFlash('error', 'Access denied.');
        }
        if ($req['status'] !== 'pending') {
            return Response::redirect("/groups/{$group['slug']}")->withFlash('info', 'This request has already been resolved.');
        }

        $outcomeRole = null;
        if (!empty($req['new_role_id'])) {
            $outcomeRole = $this->groupModel->findRole((int) $req['new_role_id']);
        }

        return Response::view('groups::owner_removal_confirm', [
            'req'         => $req,
            'group'       => $group,
            'action'      => $action,
            'outcomeRole' => $outcomeRole,
            'user'        => $this->auth->user(),
        ]);
    }

    public function resolveOwnerRemoval(Request $request): Response
    {
        $groupId   = (int) $request->param(0);
        $requestId = (int) $request->param(1);
        $action    = $request->param(2);

        $req = $this->groupModel->findOwnerRemovalRequest($requestId);
        if (!$req || (int) $req['group_id'] !== $groupId || !in_array($action, ['approve','reject'], true)) {
            return Response::redirect('/groups')->withFlash('error', 'Request not found.');
        }

        if ((int) $req['target_user_id'] !== $this->auth->id()) {
            return Response::redirect('/groups')->withFlash('error', 'Access denied.');
        }

        $status = $action === 'approve' ? 'approved' : 'rejected';
        $this->groupModel->resolveOwnerRemoval($requestId, $status);
        $this->auth->auditLog("group.owner_removal_$status", 'groups', $groupId);

        $group = $this->groupModel->findById($groupId);

        if ($status === 'approved') {
            $this->auth->refreshUser();
            return Response::redirect("/groups/{$group['slug']}")->withFlash('info', 'You have been removed as group owner and are now a standard member.');
        }
        return Response::redirect("/groups/{$group['slug']}")->withFlash('info', 'You rejected the owner removal request.');
    }

    // ── Custom Group Roles ────────────────────────────────────────────────────

    public function rolesIndex(Request $request): Response
    {
        $groupId = (int) $request->param(0);
        $group   = $this->groupModel->findById($groupId);
        if (!$group) return new Response('Not found', 404);

        if (!$this->auth->isGroupAdmin($groupId)) {
            return Response::redirect("/groups/{$group['slug']}")->withFlash('error', 'Access denied.');
        }

        $roles = $this->groupModel->getRoles($groupId);
        return Response::view('groups::roles', ['group' => $group, 'roles' => $roles, 'user' => $this->auth->user()]);
    }

    public function storeCustomRole(Request $request): Response
    {
        $groupId = (int) $request->param(0);
        $group   = $this->groupModel->findById($groupId);
        if (!$group) return new Response('Not found', 404);

        if (!$this->auth->isGroupAdmin($groupId)) {
            return Response::redirect("/groups/{$group['slug']}/roles")->withFlash('error', 'Access denied.');
        }

        $v = new Validator($request->post());
        $v->validate([
            'name'      => 'required|min:2|max:100',
            'slug'      => 'required|min:2|max:100',
            'base_role' => 'required|in:manager,editor,member',
        ]);

        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect("/groups/$groupId/roles");
        }

        $roleId = $this->groupModel->createCustomRole($groupId, [
            'name'        => $v->get('name'),
            'slug'        => $v->get('slug'),
            'description' => $v->get('description'),
            'base_role'   => $v->get('base_role'),
            'created_by'  => $this->auth->id(),
        ]);

        $permIds = array_filter((array) $request->post('permissions', []));
        if ($permIds) {
            $this->groupModel->syncRolePermissions($roleId, $permIds);
        }

        $this->auth->auditLog('group.role_created', 'group_roles', $roleId);
        return Response::redirect("/groups/$groupId/roles")->withFlash('success', 'Custom role created.');
    }

    // ── Admin Panel ───────────────────────────────────────────────────────────

    public function adminIndex(Request $request): Response
    {
        if ($this->auth->cannot('groups.view')) {
            return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');
        }
        $groups = $this->groupModel->all();
        return Response::view('groups::admin.groups_index', ['groups' => $groups, 'user' => $this->auth->user()]);
    }

    public function adminDelete(Request $request): Response
    {
        if ($this->auth->cannot('groups.delete')) {
            return Response::redirect('/admin/groups')->withFlash('error', 'Access denied.');
        }
        $id = (int) $request->param(0);
        $this->groupModel->delete($id);
        $this->auth->auditLog('group.admin_delete', 'groups', $id);
        return Response::redirect('/admin/groups')->withFlash('success', 'Group deleted.');
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function getInvitationToken(int $invId): string
    {
        $inv = \Core\Database\Database::getInstance()
            ->fetchOne("SELECT token FROM group_invitations WHERE id = ?", [$invId]);
        return $inv['token'] ?? '';
    }

    private function canCreateGroup(): bool
    {
        if ($this->auth->isSuperadminModeOn()) return true;
        if ($this->auth->hasRole(['super-admin', 'admin'])) return true;
        return (bool) setting('allow_group_creation', true);
    }

    private function singleGroupOnlyActive(): bool
    {
        if ($this->auth->isSuperadminModeOn()) return false;
        return (bool) setting('single_group_only', false);
    }

    private function userBelongsToAnyGroup(): bool
    {
        $count = (int) \Core\Database\Database::getInstance()->fetchColumn(
            "SELECT COUNT(*) FROM user_groups WHERE user_id = ?",
            [$this->auth->id()]
        );
        return $count > 0;
    }

    private function userBelongsToGroupOtherThan(int $excludeGroupId): bool
    {
        $count = (int) \Core\Database\Database::getInstance()->fetchColumn(
            "SELECT COUNT(*) FROM user_groups WHERE user_id = ? AND group_id <> ?",
            [$this->auth->id(), $excludeGroupId]
        );
        return $count > 0;
    }
}
