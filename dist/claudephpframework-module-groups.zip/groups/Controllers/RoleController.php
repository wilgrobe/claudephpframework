<?php
// modules/groups/Controllers/RoleController.php
namespace Modules\Groups\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Validation\Validator;
use App\Models\Role;

/**
 * Manages system-level roles (super-admin, admin, editor, etc.) that apply
 * across the whole app. Distinct from the per-group roles managed by
 * GroupController — those live in group_roles, these live in roles.
 *
 * Ported from App\Controllers\RoleController. Views moved to
 * modules/groups/Views/admin/roles_*.php.
 */
class RoleController
{
    private Role $roleModel;
    private Auth $auth;

    public function __construct()
    {
        $this->roleModel = new Role();
        $this->auth      = Auth::getInstance();
    }

    public function index(Request $request): Response
    {
        if ($this->auth->cannot('roles.view')) return $this->denied();
        $roles = $this->roleModel->all();
        foreach ($roles as &$r) {
            $r['permissions'] = $this->roleModel->getPermissions($r['id']);
        }
        return Response::view('groups::admin.roles_index', [
            'roles' => $roles,
            'user'  => $this->auth->user(),
        ]);
    }

    public function create(Request $request): Response
    {
        if ($this->auth->cannot('roles.create')) return $this->denied();
        return Response::view('groups::admin.roles_form', [
            'role'        => null,
            'permissions' => $this->roleModel->getAllPermissions(),
            'assigned'    => [],
            'user'        => $this->auth->user(),
        ]);
    }

    public function store(Request $request): Response
    {
        if ($this->auth->cannot('roles.create')) return $this->denied();

        $v = new Validator($request->post());
        $v->validate([
            'name' => 'required|min:2|max:100',
            'slug' => 'required|min:2|max:100',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect('/admin/roles/create');
        }

        $id = $this->roleModel->create([
            'name'        => $v->get('name'),
            'slug'        => $v->get('slug'),
            'description' => $v->get('description'),
            'is_system'   => 0,
        ]);

        $permIds = array_filter((array) $request->post('permissions', []));
        if ($permIds) $this->roleModel->syncPermissions($id, $permIds);

        $this->auth->auditLog('role.create', 'roles', $id);
        return Response::redirect('/admin/roles')->withFlash('success', 'Role created.');
    }

    public function edit(Request $request): Response
    {
        if ($this->auth->cannot('roles.edit')) return $this->denied();
        $id   = (int) $request->param(0);
        $role = $this->roleModel->findById($id);
        if (!$role) return new Response('Role not found', 404);

        return Response::view('groups::admin.roles_form', [
            'role'        => $role,
            'permissions' => $this->roleModel->getAllPermissions(),
            'assigned'    => array_column($this->roleModel->getPermissions($id), 'id'),
            'user'        => $this->auth->user(),
        ]);
    }

    public function update(Request $request): Response
    {
        if ($this->auth->cannot('roles.edit')) return $this->denied();
        $id = (int) $request->param(0);

        $v = new Validator($request->post());
        $v->validate(['name' => 'required|min:2', 'slug' => 'required|min:2']);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect("/admin/roles/$id/edit");
        }

        $this->roleModel->update($id, [
            'name'        => $v->get('name'),
            'slug'        => $v->get('slug'),
            'description' => $v->get('description'),
        ]);

        $permIds = array_filter((array) $request->post('permissions', []));
        $this->roleModel->syncPermissions($id, $permIds);

        $this->auth->auditLog('role.update', 'roles', $id);
        return Response::redirect('/admin/roles')->withFlash('success', 'Role updated.');
    }

    public function delete(Request $request): Response
    {
        if ($this->auth->cannot('roles.delete')) return $this->denied();
        $id = (int) $request->param(0);
        $rows = $this->roleModel->delete($id);
        if (!$rows) {
            return Response::redirect('/admin/roles')->withFlash('error', 'Cannot delete a system role.');
        }
        $this->auth->auditLog('role.delete', 'roles', $id);
        return Response::redirect('/admin/roles')->withFlash('success', 'Role deleted.');
    }

    private function denied(): Response
    {
        return Response::redirect('/dashboard')->withFlash('error', 'Access denied.');
    }
}
