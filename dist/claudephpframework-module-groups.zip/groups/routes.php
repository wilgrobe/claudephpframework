<?php
// modules/groups/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$G = 'Modules\Groups\Controllers\GroupController';
$R = 'Modules\Groups\Controllers\RoleController';

// ── User-facing group routes ──────────────────────────────────────────────
$router->get ('/groups',                                     "$G@myGroups",                [AuthMiddleware::class]);
$router->get ('/groups/create',                              "$G@createForm",              [AuthMiddleware::class]);
$router->post('/groups/create',                              "$G@store",                   [CsrfMiddleware::class, AuthMiddleware::class]);
$router->get ('/groups/{slug}',                              "$G@show",                    [AuthMiddleware::class]);
$router->post('/groups/{id}/leave',                          "$G@leave",                   [CsrfMiddleware::class, AuthMiddleware::class]);

$router->get ('/groups/{id}/invite',                         "$G@inviteForm",              [AuthMiddleware::class]);
$router->post('/groups/{id}/invite',                         "$G@sendInvite",              [CsrfMiddleware::class, AuthMiddleware::class]);
$router->get ('/join/{token}',                               "$G@joinForm");
$router->post('/join/{token}',                               "$G@acceptJoin",              [CsrfMiddleware::class]);

$router->post('/groups/{groupId}/members/{userId}/role',     "$G@updateMemberRole",        [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/groups/{groupId}/members/{userId}/remove',   "$G@removeMember",            [CsrfMiddleware::class, AuthMiddleware::class]);

// Owner-removal workflow (GET confirm page + POST actual action)
$router->post('/groups/{id}/request-owner-removal',             "$G@requestOwnerRemoval",    [CsrfMiddleware::class, AuthMiddleware::class]);
$router->get ('/groups/{groupId}/owner-removal/{reqId}/{action}',"$G@showOwnerRemovalPage",  [AuthMiddleware::class]);
$router->post('/groups/{groupId}/owner-removal/{reqId}/{action}',"$G@resolveOwnerRemoval",   [CsrfMiddleware::class, AuthMiddleware::class]);

// Per-group custom roles
$router->get ('/groups/{id}/roles',                          "$G@rolesIndex",              [AuthMiddleware::class]);
$router->post('/groups/{id}/roles',                          "$G@storeCustomRole",         [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Admin routes ──────────────────────────────────────────────────────────

// System-level roles (admin/roles/*)
$router->get ('/admin/roles',               "$R@index",  [AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/roles/create',        "$R@create", [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/roles/create',        "$R@store",  [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/roles/{id}/edit',     "$R@edit",   [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/roles/{id}/edit',     "$R@update", [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/roles/{id}/delete',   "$R@delete", [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);

// Admin view of all groups
$router->get ('/admin/groups',              "$G@adminIndex",  [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/groups/{id}/delete',  "$G@adminDelete", [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
