# Installation — Groups + Roles module

## Prerequisites

- `claudephpframework-core` installed.
- Core tables present: `groups`, `user_groups`, `roles`, `permissions`,
  `role_permissions`, `user_roles`, `group_roles`, `group_invites`,
  `group_owner_removal_requests` — all shipped in `database/install.sql`.

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-groups.zip
   cp -r claudephpframework-module-groups/groups /path/to/project/modules/
   ```

2. Run migrations:
   ```bash
   php artisan migrate
   ```

3. Module cache (production):
   ```bash
   php artisan module:cache
   ```

## Seeding default roles

The roles admin at `/admin/roles` requires at least one admin user to be
able to manage role definitions. If this is a fresh install, make sure the
seeded admin role has `roles.manage`, `groups.manage`, and friends. See
the core `database/install.sql` for the exact permission keys.

## Environment variables

None specific to this module. Invite emails use core's `MailService`;
configure `MAIL_*` vars in core's `.env`.

## Verification

1. As a logged-in user, visit `/groups/create` → create a test group.
2. Visit `/groups/{slug}` → you should be listed as group_owner.
3. Invite another user via `/groups/{id}/invite` → check the recipient's
   inbox for the join link (or `storage/logs` in dev mode with
   `MAIL_DRIVER=log`).
4. Try `/admin/roles` as an admin → the system roles list should render.
