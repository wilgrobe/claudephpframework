# Groups + Roles module

Groups with multi-owner support, per-group custom roles, invite/join flows,
and a safe owner-removal workflow. Also ships the system-wide Roles admin
because role permissions are shared between app-level and per-group roles.

## Features

- Create, invite members, manage roles within groups
- **Multi-owner with safe removal**: a group must always have at least one
  owner. Owners can only be removed via a request → target approves flow,
  preventing accidental lock-out.
- Role-change-vs-full-removal: request time picks the outcome
- Per-group custom roles: each group can define its own permission set
  atop the system-wide role library
- System-wide roles admin (`/admin/roles/*`) for defining default roles
- Invite via email with tokenized join links
- Admin view of all groups with delete + audit

## Routes (selected)

### User-facing
- `GET/POST /groups` — list + create form
- `GET/POST /groups/{slug}` — group detail + membership
- `POST /groups/{id}/leave`
- `GET/POST /groups/{id}/invite`
- `GET/POST /join/{token}` — accept an invite
- `POST /groups/{groupId}/members/{userId}/{role|remove}`
- `POST /groups/{id}/request-owner-removal`
- `GET/POST /groups/{groupId}/owner-removal/{reqId}/{action}`
- `GET/POST /groups/{id}/roles` — per-group custom roles

### Admin (`RequireAdmin`)
- `GET/POST /admin/roles`, `.../create`, `/{id}/edit`, `/{id}/delete` — system roles
- `GET /admin/groups` — cross-group admin view
- `POST /admin/groups/{id}/delete`

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
