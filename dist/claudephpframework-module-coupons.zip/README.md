# Coupons module

Discount codes that layer over the store's cart + checkout. Three
discount types, three scope-of-applicability modes, plus usage limits
and a date window. Enforcement lives in `CouponService::validate` so
the store just calls through at checkout time — nothing in the store
module needs to learn about coupons beyond the thin bridge in
`CartService::totals`.

## Features

- **Discount types**
  - `percent` — percentage off (basis points, so 1000 = 10%).
    Optional `max_discount_cents` cap.
  - `fixed` — flat-cents amount off.
  - `free_shipping` — zeroes the cart's shipping line.
- **Scope of applicability**
  - `cart` — whole cart (default).
  - `products` — only matching product_ids contribute to the
    eligible subtotal.
  - `categories` — only items attached (via `entity_terms`) to any of
    the linked taxonomy term_ids.
- **Limits**
  - `min_subtotal_cents` — won't apply unless cart subtotal meets it.
  - `usage_limit` — total redemptions cap (site-wide).
  - `per_user_limit` — per-user cap (requires a logged-in user).
  - `starts_at` / `ends_at` — optional date window.
- **Redemption ledger** — every applied coupon logs a row in
  `coupon_redemptions` tying it to the order, user, and discount
  amount. Used for the total + per-user limit checks and the
  per-coupon redemption view.
- **Session-based application** — the public `/coupon/apply` stashes
  the code on the PHP session; the cart + checkout read it and
  re-validate on every render.

## Routes

| Method | Path                                        | Purpose             |
|--------|---------------------------------------------|---------------------|
| POST   | `/coupon/apply`                             | Stash code in session |
| POST   | `/coupon/remove`                            | Clear session code    |
| GET    | `/admin/coupons`                            | List                  |
| GET/POST | `/admin/coupons/create`                   | New                   |
| GET/POST | `/admin/coupons/{id}/edit`                | Edit                  |
| POST   | `/admin/coupons/{id}/delete`                | Delete                |
| GET    | `/admin/coupons/{id}/redemptions`           | Redemption log        |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
