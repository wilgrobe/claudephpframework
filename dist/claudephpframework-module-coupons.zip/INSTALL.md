# Installation — Coupons module

## Prerequisites

- `claudephpframework-core`.
- `claudephpframework-module-store` for the checkout integration
  (the core coupon logic works standalone, but you need a cart + order
  consumer for it to matter).
- `claudephpframework-module-taxonomy` if you want category-scope
  coupons (the `coupon_categories` table references term ids).
- `coupons.manage` permission granted to an admin role (seeded by
  the second migration).

## Steps

1. Unzip into `modules/`:
   ```bash
   cp -r claudephpframework-module-coupons/coupons /path/to/project/modules/
   ```
2. Run migrations (creates 4 tables + seeds permission):
   ```bash
   php artisan migrate
   ```
3. The store module is already wired — `store/migrations/2026_04_23_120000`
   added `coupon_id`, `coupon_code`, `discount_cents` columns to
   `store_orders`. No store-side code change is needed.

## First-use walkthrough

1. Visit `/admin/coupons` → **New coupon**.
2. Create `SAVE10`:
   - Type: % off
   - Value (bps): 1000 (= 10%)
   - Min subtotal (cents): 0
   - Max discount (cents): leave blank
   - Applies to: cart
   - Usage limit: 100
   - Per-user limit: 1
   - Active: ✓
3. Log in as a customer, add items to cart, visit `/cart`. The cart
   page shows a coupon input box (only when the coupons module is
   detected). Enter `SAVE10`, hit Apply.
4. The cart re-renders with a green "Discount (SAVE10) −$X.XX" row
   and an updated total.
5. Proceed to checkout. The Stripe Checkout session carries the
   discount via Stripe's native coupons API (one-off, duration='once').
6. After payment, the webhook calls `OrderService::markPaid` which
   logs the redemption. View it under
   `/admin/coupons/{id}/redemptions`.

## Environment variables

None specific to this module. Relies on the store's `STRIPE_*` keys.

## Deferred features (v2)

- **First-purchase only** — a `first_purchase_only` flag + a check
  against the customer's order count at validate time.
- **Stackable / non-stackable** — today one coupon active per
  session. A `stackable` flag + array-in-session would allow multiple
  codes to combine.
- **Buy-X-get-Y** (BOGO) — needs a richer applies-to model; the
  current shape can't express "buy 2 of X, get 1 of Y free" cleanly.
- **Per-customer coupon assignment** — a `customer_coupons` table
  (coupon_id, user_id) that gates redemption to specific users.
- **Email delivery on create** — nice for PR campaigns; hook into
  `MailService` from a scheduled or event-driven job.

## Verification

- `php -l modules/coupons/**/*.php`.
- Create `SAVE10` with the 10% percent type; cart subtotal of $40
  should produce a $4 discount in the totals.
- Create `FREESHIP`, type free_shipping; cart with physical items
  should drop shipping to $0 at cart render.
- Hit `per_user_limit=1` twice — second apply should fail with
  "already used this coupon".
- Set `ends_at` in the past; apply should fail with "expired".
