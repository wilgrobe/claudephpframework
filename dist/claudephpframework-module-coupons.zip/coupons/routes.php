<?php
// modules/coupons/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$C = 'Modules\Coupons\Controllers\CouponController';
$A = 'Modules\Coupons\Controllers\CouponAdminController';

// ── Public ────────────────────────────────────────────────────────────────
$router->post('/coupon/apply',  "$C@apply",  [CsrfMiddleware::class]);
$router->post('/coupon/remove', "$C@remove", [CsrfMiddleware::class]);

// ── Admin ─────────────────────────────────────────────────────────────────
$admin     = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];

$router->get ('/admin/coupons',                    "$A@index",       $admin);
$router->get ('/admin/coupons/create',             "$A@createForm",  $admin);
$router->post('/admin/coupons/create',             "$A@store",       $adminCsrf);
$router->get ('/admin/coupons/{id}/edit',          "$A@edit",        $admin);
$router->post('/admin/coupons/{id}/edit',          "$A@update",      $adminCsrf);
$router->post('/admin/coupons/{id}/delete',        "$A@delete",      $adminCsrf);
$router->get ('/admin/coupons/{id}/redemptions',   "$A@redemptions", $admin);
