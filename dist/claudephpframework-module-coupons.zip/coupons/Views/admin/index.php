<?php $pageTitle = 'Coupons'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Coupons</h2>
        <a href="/admin/coupons/create" class="btn btn-sm btn-primary">New coupon</a>
    </div>
    <?php if (empty($coupons)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No coupons yet.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Code</th><th>Type</th><th>Value</th><th>Scope</th><th>Uses</th><th>Expires</th><th>Active</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($coupons as $c): ?>
        <tr>
            <td><strong><code><?= e($c['code']) ?></code></strong>
                <?php if (!empty($c['description'])): ?><div style="color:#9ca3af;font-size:12px"><?= e($c['description']) ?></div><?php endif; ?>
            </td>
            <td><?= e($c['type']) ?></td>
            <td>
                <?php if ($c['type'] === 'percent'): ?>
                <?= number_format((int) ($c['value_bps'] ?? 0) / 100, 2) ?>%
                <?= $c['max_discount_cents'] !== null ? ' · max ' . number_format((int) $c['max_discount_cents'] / 100, 2) : '' ?>
                <?php elseif ($c['type'] === 'fixed'): ?>
                $<?= number_format((int) ($c['value_cents'] ?? 0) / 100, 2) ?>
                <?php else: ?>
                free shipping
                <?php endif; ?>
            </td>
            <td><?= e($c['applies_to']) ?></td>
            <td>
                <?= (int) $c['uses'] ?><?= $c['usage_limit'] !== null ? ' / ' . (int) $c['usage_limit'] : '' ?>
                <?php if ($c['per_user_limit'] !== null): ?>
                <div style="color:#9ca3af;font-size:11px"><?= (int) $c['per_user_limit'] ?> per user</div>
                <?php endif; ?>
            </td>
            <td style="font-size:12px">
                <?= $c['ends_at'] ? e(date('M j, Y', strtotime((string) $c['ends_at']))) : '—' ?>
            </td>
            <td><?= (int) $c['active'] ? '✓' : '—' ?></td>
            <td>
                <a href="/admin/coupons/<?= (int) $c['id'] ?>/edit" class="btn btn-sm btn-secondary">Edit</a>
                <a href="/admin/coupons/<?= (int) $c['id'] ?>/redemptions" class="btn btn-sm btn-secondary">Redemptions</a>
                <form method="post" action="/admin/coupons/<?= (int) $c['id'] ?>/delete" style="display:inline" onsubmit="return confirm('Delete coupon?')">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
