<?php $pageTitle = 'Redemptions — ' . $coupon['code']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/coupons" style="color:#6b7280;font-size:13px;text-decoration:none">← All coupons</a>
    <h1 style="margin:0;font-size:1.5rem">Redemptions of <code><?= e($coupon['code']) ?></code></h1>
</div>

<div class="card">
<?php if (empty($rows)): ?>
<div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No redemptions yet.</div>
<?php else: ?>
<table class="table">
    <thead><tr><th>When</th><th>User</th><th>Order</th><th>Discount</th></tr></thead>
    <tbody>
    <?php foreach ($rows as $r): ?>
    <tr>
        <td style="font-size:13px"><?= e(date('M j, Y H:i', strtotime((string) $r['created_at']))) ?></td>
        <td><?= e((string) ($r['username'] ?? 'guest')) ?><?= !empty($r['email']) ? ' <span style="color:#9ca3af">(' . e($r['email']) . ')</span>' : '' ?></td>
        <td><?= !empty($r['order_id']) ? '<a href="/admin/store/orders/' . (int) $r['order_id'] . '">#' . (int) $r['order_id'] . '</a>' : '—' ?></td>
        <td>$<?= number_format((int) $r['discount_cents'] / 100, 2) ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
