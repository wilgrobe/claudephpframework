<?php $pageTitle = $coupon ? 'Edit coupon' : 'New coupon'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>
<?php
$c = $coupon ?: [];
$action = $coupon ? '/admin/coupons/' . (int) $c['id'] . '/edit' : '/admin/coupons/create';
?>

<div class="card">
    <div class="card-header"><h2 style="margin:0"><?= $coupon ? 'Edit coupon ' . e($c['code']) : 'New coupon' ?></h2></div>
    <form method="post" action="<?= e($action) ?>">
        <?= csrf_field() ?>

        <div class="card-body">
            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 2fr">
                <label>Code
                    <input name="code" required style="text-transform:uppercase" value="<?= e($c['code'] ?? '') ?>">
                </label>
                <label>Description
                    <input name="description" value="<?= e((string) ($c['description'] ?? '')) ?>">
                </label>
            </div>

            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr 1fr;margin-top:.75rem">
                <label>Type
                    <select name="type">
                        <option value="percent"        <?= ($c['type'] ?? '') === 'percent'        ? 'selected' : '' ?>>% off</option>
                        <option value="fixed"          <?= ($c['type'] ?? '') === 'fixed'          ? 'selected' : '' ?>>Fixed $ off</option>
                        <option value="free_shipping"  <?= ($c['type'] ?? '') === 'free_shipping'  ? 'selected' : '' ?>>Free shipping</option>
                    </select>
                </label>
                <label>Value (bps if %, cents if fixed)
                    <input type="number" name="value_bps"   placeholder="e.g. 1000 = 10%" value="<?= e((string) ($c['value_bps'] ?? '')) ?>">
                </label>
                <label>Or fixed value (cents)
                    <input type="number" name="value_cents" placeholder="e.g. 500 = $5"   value="<?= e((string) ($c['value_cents'] ?? '')) ?>">
                </label>
            </div>
            <p style="color:#9ca3af;font-size:12px">
                Fill <code>value_bps</code> for % coupons (10000 = 100%), <code>value_cents</code> for fixed-$ coupons. Free shipping ignores both.
            </p>

            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr 1fr;margin-top:.75rem">
                <label>Min subtotal (cents)
                    <input type="number" name="min_subtotal_cents" value="<?= (int) ($c['min_subtotal_cents'] ?? 0) ?>">
                </label>
                <label>Max discount (cents, % only)
                    <input type="number" name="max_discount_cents" value="<?= e((string) ($c['max_discount_cents'] ?? '')) ?>" placeholder="unlimited">
                </label>
                <label>Applies to
                    <select name="applies_to">
                        <?php foreach (['cart','products','categories'] as $scope): ?>
                        <option value="<?= e($scope) ?>" <?= ($c['applies_to'] ?? 'cart') === $scope ? 'selected' : '' ?>><?= ucfirst($scope) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>

            <label style="display:block;margin-top:.75rem">Product ids (comma-separated, for applies_to=products)
                <input name="product_ids" value="<?= e(implode(',', $productIds ?? [])) ?>" placeholder="12, 15, 22">
            </label>
            <label style="display:block;margin-top:.5rem">Taxonomy term ids (comma-separated, for applies_to=categories)
                <input name="term_ids" value="<?= e(implode(',', $termIds ?? [])) ?>" placeholder="3, 7">
            </label>

            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr;margin-top:.75rem">
                <label>Starts at
                    <input type="datetime-local" name="starts_at" value="<?= e($c['starts_at'] ? date('Y-m-d\TH:i', strtotime((string) $c['starts_at'])) : '') ?>">
                </label>
                <label>Ends at
                    <input type="datetime-local" name="ends_at"   value="<?= e($c['ends_at']   ? date('Y-m-d\TH:i', strtotime((string) $c['ends_at']))   : '') ?>">
                </label>
            </div>

            <div style="display:grid;gap:.75rem;grid-template-columns:1fr 1fr;margin-top:.75rem">
                <label>Total usage limit (blank = unlimited)
                    <input type="number" name="usage_limit"    value="<?= e((string) ($c['usage_limit']    ?? '')) ?>">
                </label>
                <label>Per-user limit (blank = unlimited)
                    <input type="number" name="per_user_limit" value="<?= e((string) ($c['per_user_limit'] ?? '')) ?>">
                </label>
            </div>

            <label style="display:block;margin-top:.75rem">
                <input type="checkbox" name="active" value="1" <?= !isset($c['active']) || (int) $c['active'] === 1 ? 'checked' : '' ?>> Active
            </label>
        </div>
        <div class="card-footer" style="padding:.75rem 1.25rem;background:#f9fafb">
            <a href="/admin/coupons" class="btn btn-secondary">Cancel</a>
            <button type="submit" class="btn btn-primary"><?= $coupon ? 'Save' : 'Create' ?></button>
        </div>
    </form>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
