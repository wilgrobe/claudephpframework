<?php
// modules/coupons/Services/CouponService.php
namespace Modules\Coupons\Services;

use Core\Database\Database;

/**
 * Coupon validation + application + redemption logging.
 *
 * Applied to cart totals at checkout. The cart layer calls
 * `apply($code, $totals, $userId)` and receives a decorated totals
 * array with `discount_cents` subtracted from the `total_cents`, plus
 * the coupon row for display. Checkout then passes that discount to
 * the gateway as a negative line item (see coupons/README.md
 * integration section).
 *
 * Validation:
 *   - coupon exists, active, within date window
 *   - total usage < usage_limit (if set)
 *   - per-user usage < per_user_limit (if set, when userId known)
 *   - cart subtotal >= min_subtotal_cents
 *   - applies_to eligibility:
 *       * cart        — always eligible
 *       * products    — at least one cart item's product_id is linked
 *       * categories  — at least one cart item's product is attached to
 *                       one of the coupon's terms via taxonomy_entity_terms
 *
 * Discount computation:
 *   - percent        — percent_bps × subtotal / 10000, capped by
 *                      max_discount_cents when set, capped by
 *                      subtotal so we don't owe the customer money.
 *                      For products/categories scope, only the
 *                      eligible line-items' subtotal is discounted.
 *   - fixed          — value_cents, capped by the eligible subtotal.
 *   - free_shipping  — returns {shipping_cents: 0, discount_cents:
 *                      shipping} so the caller can zero the shipping
 *                      line and show the discount clearly.
 */
class CouponService
{
    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Reads ─────────────────────────────────────────────────────────────

    public function findByCode(string $code): ?array
    {
        $code = strtoupper(trim($code));
        if ($code === '') return null;
        return $this->db->fetchOne("SELECT * FROM coupons WHERE code = ?", [$code]);
    }

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM coupons WHERE id = ?", [$id]);
    }

    /** @return array<int,array<string,mixed>> */
    public function all(): array
    {
        return $this->db->fetchAll("SELECT * FROM coupons ORDER BY active DESC, created_at DESC");
    }

    public function productIds(int $couponId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT product_id FROM coupon_products WHERE coupon_id = ?", [$couponId]
        );
        return array_map(static fn($r) => (int) $r['product_id'], $rows);
    }

    public function termIds(int $couponId): array
    {
        $rows = $this->db->fetchAll(
            "SELECT term_id FROM coupon_categories WHERE coupon_id = ?", [$couponId]
        );
        return array_map(static fn($r) => (int) $r['term_id'], $rows);
    }

    public function redemptionsForUser(int $couponId, int $userId): int
    {
        return (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM coupon_redemptions WHERE coupon_id = ? AND user_id = ?",
            [$couponId, $userId]
        );
    }

    // ── Writes ────────────────────────────────────────────────────────────

    public function create(array $data): int
    {
        return (int) $this->db->insert('coupons', $this->prepare($data));
    }

    public function update(int $id, array $data): void
    {
        $this->db->update('coupons', $this->prepare($data), 'id = ?', [$id]);
    }

    public function delete(int $id): void
    {
        $this->db->delete('coupons', 'id = ?', [$id]);
    }

    public function setProductIds(int $couponId, array $productIds): void
    {
        $this->db->delete('coupon_products', 'coupon_id = ?', [$couponId]);
        foreach (array_unique(array_map('intval', $productIds)) as $pid) {
            if ($pid > 0) {
                $this->db->insert('coupon_products', ['coupon_id' => $couponId, 'product_id' => $pid]);
            }
        }
    }

    public function setTermIds(int $couponId, array $termIds): void
    {
        $this->db->delete('coupon_categories', 'coupon_id = ?', [$couponId]);
        foreach (array_unique(array_map('intval', $termIds)) as $tid) {
            if ($tid > 0) {
                $this->db->insert('coupon_categories', ['coupon_id' => $couponId, 'term_id' => $tid]);
            }
        }
    }

    /**
     * Record a redemption and increment usage. Callers pass the
     * pre-computed discount so the ledger reflects what the customer
     * actually got.
     */
    public function recordRedemption(int $couponId, ?int $userId, ?int $orderId, int $discountCents): void
    {
        $this->db->insert('coupon_redemptions', [
            'coupon_id'      => $couponId,
            'user_id'        => $userId,
            'order_id'       => $orderId,
            'discount_cents' => $discountCents,
        ]);
        $this->db->query("UPDATE coupons SET uses = uses + 1 WHERE id = ?", [$couponId]);
    }

    private function prepare(array $data): array
    {
        $out = [];
        foreach ([
            'code','description','type','value_bps','value_cents',
            'min_subtotal_cents','max_discount_cents','applies_to',
            'starts_at','ends_at','usage_limit','per_user_limit','active',
        ] as $k) {
            if (array_key_exists($k, $data)) $out[$k] = $data[$k];
        }
        if (isset($out['code'])) $out['code'] = strtoupper(preg_replace('~\s+~', '', (string) $out['code']));
        // Nullable numeric fields — empty string → NULL so unlimited
        // stays unlimited even when the form posts empties.
        foreach (['value_bps','value_cents','max_discount_cents',
                 'usage_limit','per_user_limit','starts_at','ends_at'] as $k) {
            if (array_key_exists($k, $out) && ($out[$k] === '' || $out[$k] === 0)) {
                // 0 is a legit value for value_bps / value_cents, don't null those
                if (in_array($k, ['value_bps','value_cents'], true) && $out[$k] === 0) continue;
                if ($out[$k] === '') $out[$k] = null;
            }
        }
        return $out;
    }

    // ── Validation + application ──────────────────────────────────────────

    /**
     * Validate a coupon against a cart. Returns a structured result;
     * callers check `ok` before using the `discount_cents` / `notes`.
     *
     * $totals shape is the one CartService::totals produces — items,
     * subtotal_cents, shipping_cents, tax_cents, total_cents, currency.
     *
     * @return array{ok: bool, error: ?string, coupon: ?array,
     *               discount_cents: int, free_shipping: bool,
     *               eligible_subtotal_cents: int}
     */
    public function validate(string $code, array $totals, ?int $userId): array
    {
        $fail = static fn(string $err): array => [
            'ok' => false, 'error' => $err, 'coupon' => null,
            'discount_cents' => 0, 'free_shipping' => false,
            'eligible_subtotal_cents' => 0,
        ];

        $coupon = $this->findByCode($code);
        if (!$coupon || (int) $coupon['active'] !== 1) return $fail('Coupon not found.');

        $now = time();
        if (!empty($coupon['starts_at']) && strtotime((string) $coupon['starts_at']) > $now) {
            return $fail('Coupon not active yet.');
        }
        if (!empty($coupon['ends_at']) && strtotime((string) $coupon['ends_at']) < $now) {
            return $fail('Coupon has expired.');
        }
        if ($coupon['usage_limit'] !== null && (int) $coupon['uses'] >= (int) $coupon['usage_limit']) {
            return $fail('Coupon usage limit reached.');
        }
        if ($coupon['per_user_limit'] !== null && $userId !== null) {
            $used = $this->redemptionsForUser((int) $coupon['id'], $userId);
            if ($used >= (int) $coupon['per_user_limit']) {
                return $fail('You have already used this coupon the maximum number of times.');
            }
        }

        $subtotal = (int) ($totals['subtotal_cents'] ?? 0);
        if ($subtotal < (int) $coupon['min_subtotal_cents']) {
            $min = number_format($coupon['min_subtotal_cents'] / 100, 2);
            return $fail("Minimum subtotal of $min not met.");
        }

        // Eligibility check — which portion of the subtotal does the
        // coupon apply to? For cart-scope, the whole subtotal. For
        // products/categories, sum line totals that match.
        [$eligibleCents, $matchedItem] = $this->eligibleSubtotal($coupon, $totals);
        if ($coupon['applies_to'] !== 'cart' && $eligibleCents === 0) {
            return $fail('No eligible items in cart for this coupon.');
        }

        // Compute discount.
        $discount     = 0;
        $freeShipping = false;
        switch ($coupon['type']) {
            case 'percent':
                $bps = (int) ($coupon['value_bps'] ?? 0);
                $discount = (int) floor($eligibleCents * $bps / 10000);
                if ($coupon['max_discount_cents'] !== null) {
                    $discount = min($discount, (int) $coupon['max_discount_cents']);
                }
                $discount = min($discount, $eligibleCents);
                break;

            case 'fixed':
                $discount = min((int) ($coupon['value_cents'] ?? 0), $eligibleCents);
                break;

            case 'free_shipping':
                $discount     = (int) ($totals['shipping_cents'] ?? 0);
                $freeShipping = true;
                break;
        }

        return [
            'ok' => true, 'error' => null,
            'coupon' => $coupon,
            'discount_cents' => $discount,
            'free_shipping'  => $freeShipping,
            'eligible_subtotal_cents' => $eligibleCents,
        ];
    }

    /**
     * Return [eligibleSubtotal, matched] — subtotal of cart line items
     * that match the coupon's scope, and whether any matched.
     *
     * @return array{0: int, 1: bool}
     */
    public function eligibleSubtotal(array $coupon, array $totals): array
    {
        if ($coupon['applies_to'] === 'cart') {
            return [(int) $totals['subtotal_cents'], !empty($totals['items'])];
        }

        $items = $totals['items'] ?? [];
        if (empty($items)) return [0, false];

        if ($coupon['applies_to'] === 'products') {
            $ids   = array_flip($this->productIds((int) $coupon['id']));
            $sum   = 0;
            $match = false;
            foreach ($items as $it) {
                if (isset($ids[(int) $it['product_id']])) {
                    $sum += (int) $it['price_cents'] * (int) $it['qty'];
                    $match = true;
                }
            }
            return [$sum, $match];
        }

        if ($coupon['applies_to'] === 'categories') {
            $termIds = $this->termIds((int) $coupon['id']);
            if (empty($termIds)) return [0, false];

            // Resolve: which of the cart's product_ids are attached to
            // any of the coupon's term_ids. One query against the
            // taxonomy module's polymorphic attach table.
            $productIds = array_unique(array_map(static fn($i) => (int) $i['product_id'], $items));
            if (empty($productIds)) return [0, false];

            $ph1 = implode(',', array_fill(0, count($productIds), '?'));
            $ph2 = implode(',', array_fill(0, count($termIds),    '?'));
            $rows = $this->db->fetchAll(
                "SELECT DISTINCT entity_id AS product_id
                   FROM taxonomy_entity_terms
                  WHERE entity_type = 'store_product'
                    AND entity_id IN ($ph1)
                    AND term_id   IN ($ph2)",
                [...$productIds, ...$termIds]
            );
            $matchedPids = array_flip(array_map(static fn($r) => (int) $r['product_id'], $rows));

            $sum   = 0;
            $match = false;
            foreach ($items as $it) {
                if (isset($matchedPids[(int) $it['product_id']])) {
                    $sum += (int) $it['price_cents'] * (int) $it['qty'];
                    $match = true;
                }
            }
            return [$sum, $match];
        }

        return [0, false];
    }

    /**
     * Decorate a totals array with the coupon's effect. Non-destructive:
     * returns a new array; original $totals is untouched. Caller should
     * use this for display and pass `discount_cents` to the gateway as
     * a negative line item.
     */
    public function apply(string $code, array $totals, ?int $userId): array
    {
        $result = $this->validate($code, $totals, $userId);
        if (!$result['ok']) return ['ok' => false, 'error' => $result['error'], 'totals' => $totals];

        $out = $totals;
        if ($result['free_shipping']) {
            $out['shipping_cents'] = 0;
        }
        $out['coupon_code']    = $result['coupon']['code'];
        $out['coupon_id']      = (int) $result['coupon']['id'];
        $out['discount_cents'] = (int) $result['discount_cents'];

        $out['total_cents'] = max(
            0,
            (int) $out['subtotal_cents']
          + (int) $out['shipping_cents']
          + (int) ($out['tax_cents'] ?? 0)
          - (int) $out['discount_cents']
        );

        return ['ok' => true, 'error' => null, 'totals' => $out, 'coupon' => $result['coupon']];
    }
}
