<?php
// modules/coupons/migrations/2026_04_23_110010_seed_coupons_permission.php
use Core\Database\Migration;

return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage coupons',
            'coupons.manage',
            'coupons',
            'Create, edit, and deactivate discount coupons; review redemptions.',
        ]);
    }

    public function down(): void {}
};
