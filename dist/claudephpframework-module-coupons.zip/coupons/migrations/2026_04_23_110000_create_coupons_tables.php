<?php
// modules/coupons/migrations/2026_04_23_110000_create_coupons_tables.php
use Core\Database\Migration;

/**
 * Schema for the coupons module.
 *
 *   coupons             — the coupon definitions. `type` picks the
 *                         discount mechanic; `applies_to` picks the
 *                         eligibility scope. Usage limits + date
 *                         windows are nullable for "no limit".
 *                         `uses` is a denormalized counter updated
 *                         inside the redemption transaction so the
 *                         total cap can be enforced with a single
 *                         row-level check.
 *
 *   coupon_products     — link table when applies_to='products'.
 *                         Eligibility requires at least one cart item
 *                         matching an entry here.
 *
 *   coupon_categories   — link table when applies_to='categories'.
 *                         Categories are taxonomy terms; eligibility
 *                         walks `taxonomy_entity_terms` to match cart items
 *                         against the attached term set.
 *
 *   coupon_redemptions  — audit log of applied coupons. Used for the
 *                         per-user limit check + reports. One row per
 *                         (coupon, order). Grows with orders; not
 *                         expected to need pruning at any realistic
 *                         scale.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE coupons (
                id                  INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                code                VARCHAR(64)  NOT NULL,
                description         VARCHAR(255) NULL,
                type                ENUM('percent','fixed','free_shipping') NOT NULL DEFAULT 'percent',
                value_bps           INT UNSIGNED NULL,
                value_cents         INT UNSIGNED NULL,
                min_subtotal_cents  INT UNSIGNED NOT NULL DEFAULT 0,
                max_discount_cents  INT UNSIGNED NULL,
                applies_to          ENUM('cart','products','categories') NOT NULL DEFAULT 'cart',
                starts_at           DATETIME     NULL,
                ends_at             DATETIME     NULL,
                usage_limit         INT UNSIGNED NULL,
                per_user_limit      INT UNSIGNED NULL,
                uses                INT UNSIGNED NOT NULL DEFAULT 0,
                active              TINYINT(1)   NOT NULL DEFAULT 1,
                created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_code (code),
                KEY idx_active (active, ends_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE coupon_products (
                coupon_id  INT UNSIGNED NOT NULL,
                product_id INT UNSIGNED NOT NULL,
                PRIMARY KEY (coupon_id, product_id),
                KEY idx_product (product_id),
                CONSTRAINT fk_cp_coupon
                    FOREIGN KEY (coupon_id) REFERENCES coupons (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE coupon_categories (
                coupon_id INT UNSIGNED NOT NULL,
                term_id   INT UNSIGNED NOT NULL,
                PRIMARY KEY (coupon_id, term_id),
                KEY idx_term (term_id),
                CONSTRAINT fk_cc_coupon
                    FOREIGN KEY (coupon_id) REFERENCES coupons (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE coupon_redemptions (
                id              INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                coupon_id       INT UNSIGNED NOT NULL,
                user_id         INT UNSIGNED NULL,
                order_id        INT UNSIGNED NULL,
                subscription_id INT UNSIGNED NULL,
                discount_cents  INT UNSIGNED NOT NULL DEFAULT 0,
                created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                KEY idx_coupon_user (coupon_id, user_id),
                KEY idx_order       (order_id),
                CONSTRAINT fk_cr_coupon
                    FOREIGN KEY (coupon_id) REFERENCES coupons (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS coupon_redemptions");
        $this->db->query("DROP TABLE IF EXISTS coupon_categories");
        $this->db->query("DROP TABLE IF EXISTS coupon_products");
        $this->db->query("DROP TABLE IF EXISTS coupons");
    }
};
