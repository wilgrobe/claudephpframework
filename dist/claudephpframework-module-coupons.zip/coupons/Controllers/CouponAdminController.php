<?php
// modules/coupons/Controllers/CouponAdminController.php
namespace Modules\Coupons\Controllers;

use Core\Database\Database;
use Core\Request;
use Core\Response;
use Modules\Coupons\Services\CouponService;

/**
 * Admin CRUD for coupons at /admin/coupons.
 *
 * Product + term pickers are free-text comma-separated id lists — the
 * admin is expected to know which product_ids or taxonomy term_ids
 * they're targeting. A proper search-and-pick UI is deferred.
 */
class CouponAdminController
{
    private CouponService $svc;
    private Database      $db;

    public function __construct()
    {
        $this->svc = new CouponService();
        $this->db  = Database::getInstance();
    }

    public function index(Request $request): Response
    {
        return Response::view('coupons::admin.index', [
            'coupons' => $this->svc->all(),
        ]);
    }

    public function createForm(Request $request): Response
    {
        return Response::view('coupons::admin.form', ['coupon' => null, 'productIds' => [], 'termIds' => []]);
    }

    public function store(Request $request): Response
    {
        $data = $this->readForm($request);
        if ($data['code'] === '') {
            return Response::redirect('/admin/coupons/create')->withFlash('error', 'Code required.');
        }
        try {
            $id = $this->svc->create($data);
        } catch (\Throwable $e) {
            return Response::redirect('/admin/coupons/create')->withFlash('error', 'Could not create — code likely in use.');
        }
        $this->syncScope($id, $data['applies_to'], $request);
        return Response::redirect('/admin/coupons')->withFlash('success', 'Coupon created.');
    }

    public function edit(Request $request): Response
    {
        $id = (int) $request->param(0);
        $c  = $this->svc->find($id);
        if (!$c) return new Response('Not found', 404);
        return Response::view('coupons::admin.form', [
            'coupon'     => $c,
            'productIds' => $this->svc->productIds($id),
            'termIds'    => $this->svc->termIds($id),
        ]);
    }

    public function update(Request $request): Response
    {
        $id   = (int) $request->param(0);
        $data = $this->readForm($request);
        $this->svc->update($id, $data);
        $this->syncScope($id, $data['applies_to'], $request);
        return Response::redirect('/admin/coupons')->withFlash('success', 'Coupon updated.');
    }

    public function delete(Request $request): Response
    {
        $this->svc->delete((int) $request->param(0));
        return Response::redirect('/admin/coupons')->withFlash('success', 'Coupon deleted.');
    }

    public function redemptions(Request $request): Response
    {
        $id = (int) $request->param(0);
        $c  = $this->svc->find($id);
        if (!$c) return new Response('Not found', 404);
        $rows = $this->db->fetchAll(
            "SELECT cr.*, u.username, u.email
               FROM coupon_redemptions cr
          LEFT JOIN users u ON u.id = cr.user_id
              WHERE cr.coupon_id = ?
           ORDER BY cr.created_at DESC
              LIMIT 200",
            [$id]
        );
        return Response::view('coupons::admin.redemptions', [
            'coupon' => $c, 'rows' => $rows,
        ]);
    }

    // ── Helpers ──────────────────────────────────────────────────────────

    private function readForm(Request $request): array
    {
        return [
            'code'               => strtoupper((string) $request->post('code')),
            'description'        => (string) $request->post('description'),
            'type'               => (string) $request->post('type', 'percent'),
            'value_bps'          => $request->post('value_bps')   !== '' ? (int) $request->post('value_bps')   : null,
            'value_cents'        => $request->post('value_cents') !== '' ? (int) $request->post('value_cents') : null,
            'min_subtotal_cents' => (int) $request->post('min_subtotal_cents', 0),
            'max_discount_cents' => $request->post('max_discount_cents') !== '' ? (int) $request->post('max_discount_cents') : null,
            'applies_to'         => (string) $request->post('applies_to', 'cart'),
            'starts_at'          => (string) $request->post('starts_at') ?: null,
            'ends_at'            => (string) $request->post('ends_at')   ?: null,
            'usage_limit'        => $request->post('usage_limit')    !== '' ? (int) $request->post('usage_limit')    : null,
            'per_user_limit'     => $request->post('per_user_limit') !== '' ? (int) $request->post('per_user_limit') : null,
            'active'             => $request->post('active') ? 1 : 0,
        ];
    }

    private function syncScope(int $couponId, string $appliesTo, Request $request): void
    {
        $pids = array_filter(array_map('intval', explode(',', (string) $request->post('product_ids'))));
        $tids = array_filter(array_map('intval', explode(',', (string) $request->post('term_ids'))));

        if ($appliesTo === 'products') {
            $this->svc->setProductIds($couponId, $pids);
            $this->svc->setTermIds($couponId, []);
        } elseif ($appliesTo === 'categories') {
            $this->svc->setProductIds($couponId, []);
            $this->svc->setTermIds($couponId, $tids);
        } else {
            $this->svc->setProductIds($couponId, []);
            $this->svc->setTermIds($couponId, []);
        }
    }
}
