<?php
// modules/coupons/Controllers/CouponController.php
namespace Modules\Coupons\Controllers;

use Core\Request;
use Core\Response;
use Core\Session;

/**
 * Public surface: apply / remove a coupon code on the shopper side.
 * The code is stored in the session; any checkout integration reads
 * it and passes through validate() + apply() on the cart totals.
 *
 *   POST /coupon/apply     — body: code, return_url
 *   POST /coupon/remove    — body: return_url
 */
class CouponController
{
    public const SESSION_KEY = 'coupons_active_code';

    public function apply(Request $request): Response
    {
        $code   = strtoupper(trim((string) $request->post('code', '')));
        $return = (string) $request->post('return_url', '/cart');

        if ($code === '') {
            return Response::redirect($return)->withFlash('error', 'Enter a code.');
        }

        Session::start();
        $_SESSION[self::SESSION_KEY] = $code;

        // The cart view will surface success/failure on the next render
        // by calling validate(); no need to prefetch the coupon here.
        return Response::redirect($return)->withFlash('success', "Coupon $code applied.");
    }

    public function remove(Request $request): Response
    {
        Session::start();
        unset($_SESSION[self::SESSION_KEY]);
        $return = (string) $request->post('return_url', '/cart');
        return Response::redirect($return)->withFlash('success', 'Coupon removed.');
    }
}
