<?php
// modules/coupons/module.php
use Core\Module\ModuleProvider;

/**
 * Coupons module — discount codes that layer over the store's cart +
 * checkout. Three discount types (percent, fixed $, free shipping),
 * three eligibility scopes (cart, specific products, specific
 * taxonomy categories), usage limits (total + per-user), and a date
 * window. All enforcement lives in CouponService::validate so the
 * store module just calls into it from its checkout flow.
 *
 * Session integration: the public /coupon/apply route stashes the
 * code under SESSION[coupons_active_code] so the store (or any other
 * consumer) can read it on every request without maintaining its
 * own cart-side column.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'coupons'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
