# Architecture — Coupons module

## Files

```
coupons/
├── module.php
├── routes.php                                          # 7 routes
├── Controllers/
│   ├── CouponController.php                            # /coupon/apply, /coupon/remove
│   └── CouponAdminController.php                       # /admin/coupons CRUD + redemption log
├── Services/
│   └── CouponService.php                               # validate, apply, record redemption
├── Views/
│   └── admin/
│       ├── index.php
│       ├── form.php
│       └── redemptions.php
└── migrations/
    ├── 2026_04_23_110000_create_coupons_tables.php     # 4 tables
    └── 2026_04_23_110010_seed_coupons_permission.php
```

## Data model

### `coupons`

```
id, code (unique), description,
type ENUM('percent','fixed','free_shipping'),
value_bps NULL, value_cents NULL,
min_subtotal_cents,
max_discount_cents NULL,
applies_to ENUM('cart','products','categories'),
starts_at NULL, ends_at NULL,
usage_limit NULL, per_user_limit NULL, uses,
active, timestamps
```

`value_bps` is basis points (10000 = 100%). `value_cents` is used only
for `type='fixed'`. `max_discount_cents` caps a `percent` coupon
("10% off, max $50").

### Link tables

```
coupon_products:    coupon_id, product_id  PK (both)
coupon_categories:  coupon_id, term_id     PK (both)
```

Populated via `CouponService::setProductIds` / `setTermIds` from the
admin form.

### `coupon_redemptions`

```
id, coupon_id, user_id NULL, order_id NULL, subscription_id NULL,
discount_cents, created_at
```

One row per successful redemption. Used for the per-user limit check
and the admin redemption view. The `subscription_id` column is there
so a future subscriptions integration doesn't need a schema change.

## Validation flow

`CouponService::validate($code, $totals, $userId)` runs through in
order, failing fast on the first missed check:

1. **Exists + active**
2. **Date window** (`starts_at`, `ends_at`)
3. **Total usage limit** (denormalized `uses` column)
4. **Per-user limit** (COUNT against `coupon_redemptions`)
5. **Min subtotal** against `totals.subtotal_cents`
6. **Scope eligibility** — for `products` / `categories`, computes
   the "eligible subtotal" from cart line items that match, fails
   if zero.
7. **Discount calculation** based on `type`:
   - `percent` → `eligible × bps / 10000`, capped by
     `max_discount_cents`, clamped to `eligible` so a customer can't
     end up owed money.
   - `fixed` → min(`value_cents`, `eligible`).
   - `free_shipping` → `totals.shipping_cents`.

`CouponService::apply($code, $totals, $userId)` wraps `validate` and
returns the *decorated totals* — `discount_cents` populated, `total_cents`
recomputed, `shipping_cents` zeroed for `free_shipping`. The store's
`CartService::totals` calls `apply` automatically when a session code
is stashed and the coupons class is loaded.

## Store integration

`store/Services/CartService::totals` short-circuits on
`class_exists(Modules\Coupons\Services\CouponService)` so the store
stays coupon-agnostic when the module isn't installed.

`store/Services/CheckoutService::startCheckout` passes the discount to
Stripe using Stripe's own coupons API — a one-off coupon created per
checkout with `amount_off` = discount cents, attached via
`discounts[0][coupon]`. The local order already carries the discounted
total; Stripe arrives at the same number by its own math.

`store/Services/OrderService::createPendingFromCart` snapshots
`coupon_id`, `coupon_code`, `discount_cents` on the order.
`markPaid` logs the redemption to `coupon_redemptions` (inside the
same transaction as stock decrement + token issuance) so replay-safe
idempotency extends to coupon usage counts.

## Testing notes

- Unit-level — `validate` has tests for every branch. See
  `/tmp/coupon_math_smoke.php` used during the Batch 3 build.
- Concurrency — the total usage cap uses the denormalized `uses`
  counter; a race between two simultaneous last-slot redemptions
  could over-redeem by one. Acceptable for all but the narrowest
  "exactly N" campaigns; for those, wrap `recordRedemption` in
  SELECT FOR UPDATE.

## Deferred features

See INSTALL.md.
