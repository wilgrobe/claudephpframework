# Installation — Scheduling module

## Prerequisites

- `claudephpframework-core` installed.
- `scheduling.manage` permission granted to at least one admin role
  (seeded by this module's second migration). Grant via `/admin/roles`.
- Mail driver configured in core's `.env` if you want booking
  confirmation emails (otherwise they fail quietly and are logged).

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-scheduling.zip
   cp -r claudephpframework-module-scheduling/scheduling /path/to/project/modules/
   ```

2. Run the migrations (creates 3 tables + seeds permission):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if you use production caching:
   ```bash
   php artisan module:cache
   ```

## First-use walkthrough

1. Log in as admin, visit `/admin/scheduling/resources`.
2. Click **New resource** and fill in:
   - Name: "30-minute consultation"
   - Slug: `consultation-30`
   - Duration: 30 minutes
   - Capacity: 1 (or higher for class-style resources)
   - Timezone: pick the tz the availability windows are in
   - Owner user id: optional — if set, that user gets in-app
     notifications on each booking
   - Active ✓, Public ✓
3. Under **Weekly availability**, add rows — e.g.:
   - Mon 09:00 → 12:00
   - Mon 13:00 → 17:00
   - Tue 09:00 → 17:00
   - etc.
4. Save. Visit `/book/consultation-30` — you should see slot buttons
   for today's date. Navigate to another day with the arrows or the
   date picker.
5. Book a slot. You'll land on `/book/my` with a confirmation code,
   and a confirmation email goes out (check `message_log` if mail
   driver is `log`).

## Environment variables

None specific to this module. It leans on the framework's existing
`MAIL_*` and notifications setup.

## Deferred features (v2)

- **Date-specific overrides / blackouts** — "closed Dec 25", "open extra
  Sunday for event". Data model supports extending; schema left clean.
- **Buffer minutes between bookings** — `scheduling_resources.buffer_minutes`
  column exists but not yet honored in slot math.
- **iCal / Google / Outlook calendar sync** — see ARCHITECTURE.md for
  the design sketch. iCal (read-only subscribe) covers all three major
  calendar apps from a single endpoint; Google Calendar API and
  Microsoft Graph would be needed for two-way sync.
- **Reminder emails** — easy to add: new scheduled_tasks row running a
  `BookingReminderJob` daily that emails bookings starting within 24h.
- **Rescheduling** — MVP workaround: cancel + rebook. Proper
  reschedule is one new service method.
- **Payment integration** — ties into the subscriptions/payments module
  when a booking requires prepay.

## Verification

- `./vendor/bin/phpunit` should add ~12 new `SchedulingServiceTest` tests
  covering slot generation math (duration sizing, capacity filtering,
  timezone conversion, multiple windows, partial tails).
- Create a resource, book a slot, then try booking the same slot in a
  second incognito window — should see "That slot is fully booked".

## Troubleshooting

- **"No slots" on a day you expect slots** — timezone mismatch. The
  date you're viewing is interpreted in the resource's timezone. Check
  that the day-of-week matches a configured availability window in
  that tz.
- **Duration/end mismatch** — slot computation drops partial tails. If
  you configured Mon 9:00–10:15 with duration=30, you'll see 9:00 and
  9:30 only — the 10:00 slot would end at 10:30, past 10:15.
- **Email didn't arrive** — check core's `MAIL_DRIVER`; in dev it
  defaults to `log` (captured to `message_log`, visible in the
  Superadmin message log viewer).
