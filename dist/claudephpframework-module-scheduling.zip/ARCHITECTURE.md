# Architecture — Scheduling module

## Files

```
scheduling/
├── module.php
├── routes.php                                              # 14 routes
├── Controllers/
│   ├── BookingController.php                               # User: /book, /book/my, cancel
│   └── SchedulingAdminController.php                       # Admin: resource + booking CRUD
├── Services/
│   └── SchedulingService.php                               # Resource fetch, slot math, transactional book()
├── Views/
│   ├── public/
│   │   ├── resources.php                                   # /book — resource list cards
│   │   ├── resource.php                                    # /book/{slug} — slot picker
│   │   └── my_bookings.php                                 # /book/my — own bookings
│   └── admin/
│       ├── resources/index.php                             # Resource list
│       ├── resources/form.php                              # Create/edit + availability editor
│       └── bookings.php                                    # Cross-resource booking list
└── migrations/
    ├── 2026_04_22_220000_create_scheduling_tables.php      # 3 tables
    └── 2026_04_22_220010_seed_scheduling_permission.php
```

## Data model

### `scheduling_resources`

```
id, name, slug (unique), description, owner_user_id (nullable),
duration_minutes, capacity, buffer_minutes, timezone, active, public,
timestamps
```

Polymorphic. `owner_user_id` is an optional link to a user (for
"consultant Alice"-style resources); leave null for rooms / equipment
where there isn't a human owner.

### `scheduling_availability`

```
id, resource_id (FK cascade), day_of_week (0=Sun..6=Sat),
start_time TIME, end_time TIME, created_at
```

Multiple rows per resource × day (split shifts — 9-12, 13-17). `start_time`
and `end_time` are HH:MM:SS in the resource's `timezone`. Constraint
`end_time > start_time` is enforced by a CHECK; cross-midnight windows
aren't supported (split them: 22:00-24:00 for the current day + 00:00-06:00
for the next).

### `scheduling_bookings`

```
id, resource_id (FK cascade), user_id, starts_at DATETIME UTC,
ends_at DATETIME UTC, status ENUM, notes, confirmation_code (unique),
timestamps
```

Status values:
- `pending`   — reserved for manual-approval workflows (MVP auto-confirms)
- `confirmed` — active booking, counts against capacity
- `cancelled` — user or admin cancelled; slot becomes available again
- `completed` — ends_at has passed (admin marks; no scheduled task yet)
- `no_show`   — admin marks; no effect on slot availability

`confirmation_code` is a random 8-char hex, unique across the table —
shown to users for reference.

## Slot generation

`availableSlots($resourceId, $date)` — the critical read path.

Given a resource with duration=30, capacity=1, and availability
Mon 9:00-17:00, the Monday slot list is: 9:00, 9:30, ..., 16:30.

```php
for each availability window on this day_of_week:
    slot_start = window.start  (in resource tz)
    while slot_start + duration <= window.end:
        slot_end = slot_start + duration
        utc_start = slot_start converted to UTC
        count = bookingCounts[utc_start] ?? 0
        if count < capacity:
            emit slot
        slot_start = slot_end
```

`bookingCountsForDay` pulls all confirmed bookings for the calendar day
(in UTC) in one SELECT + GROUP BY, so the slot loop is O(slots) without
per-slot queries.

**Partial tails are dropped.** A 9:00–10:15 window with duration=30
yields slots at 9:00 and 9:30 but not 10:00 — the slot would end at
10:30, past the window's 10:15 cap. Prevents overlapping or overflowing
bookings.

**Buffer minutes** exist in the schema but aren't applied yet. Adding
them is a minor change to the `slot_start = slot_end` line
(`slot_start = slot_end + buffer`) and a corresponding `+= duration` on
the window traversal.

## Double-booking prevention

`book()` wraps the capacity check + INSERT in a transaction with
`SELECT ... FOR UPDATE`:

```sql
BEGIN;
  SELECT COUNT(*) FROM scheduling_bookings
    WHERE resource_id = ? AND starts_at = ? AND status = 'confirmed'
    FOR UPDATE;
  -- acquires row-level lock on matching rows OR gap lock if none.
  -- Concurrent writers block until this txn commits/rolls back.
  IF count >= capacity:
    RETURN ok=false;
  INSERT INTO scheduling_bookings (...);
COMMIT;
```

MySQL's InnoDB gap locks mean even when no rows match, a concurrent
writer can't insert into the "empty" slot until our txn ends. Correct
under the default REPEATABLE READ isolation level.

A unique constraint approach (e.g., `UNIQUE (resource_id, starts_at)
WHERE status='confirmed'`) would be simpler but doesn't fit: partial
indexes aren't portable and the "WHERE status=confirmed" part isn't
easily expressible. The transactional approach works on any MySQL 5.7+
without extensions.

## Timezones

- **Bookings** — `starts_at`/`ends_at` are UTC, always.
- **Availability windows** — `start_time`/`end_time` are HH:MM:SS in the
  resource's `timezone`.
- **Slot computation** converts window hours → local datetime in the
  resource tz → UTC, for comparison against booking counts.
- **Display** — `my_bookings.php` formats bookings in the resource's
  timezone (not the user's browser tz). That keeps consistency with
  what the user saw when they booked. If an app wants to render in
  "user's local tz", add a `users.timezone` column and do the
  conversion at render time.

A single resource serves one timezone. Cross-timezone resources (global
hotline with staff across regions) would need a per-availability-window
timezone column. Deferred; not a typical need.

## Notifications

Controllers fire two side effects on book/cancel:

1. **Customer email** via `MailService::send()` — subject + plain-text
   + simple HTML body. Best-effort; a send failure is logged and
   doesn't fail the booking.
2. **Owner in-app notification** via `NotificationService::send()` —
   type `scheduling.booked` / `scheduling.cancelled`, includes
   `booking_id` + `resource_id` + `action_url` for the bell-badge click-
   through. Only fires when the resource has `owner_user_id` set.

No email-the-owner or SMS paths in MVP — owners see the bell, click
through, see the booking list. Straightforward extensions.

## Authorization

| Action                     | Who                                             |
|----------------------------|-------------------------------------------------|
| List + browse resources    | Authenticated user                              |
| View slots                 | Authenticated user                              |
| Book a slot                | Authenticated user (booking their own)          |
| Cancel own booking         | Authenticated user (IDOR check in controller)   |
| Resource CRUD + availability | `scheduling.manage` permission                |
| View all bookings + status transitions | `scheduling.manage` permission      |

IDOR guard on user cancel: `$booking['user_id'] === $auth->id()`.
Admin path bypasses.

## Calendar integration design (deferred)

**iCal feeds** — simplest win. Apple Calendar, Google Calendar, and
Outlook all consume the iCal (.ics) format from a subscription URL
with read-only refresh. To add:

1. New route: `GET /book/my.ics?token=...` and
   `GET /admin/scheduling/resources/{id}/feed.ics?token=...`
2. Render bookings as VEVENTs with UID = booking's confirmation_code,
   DTSTART/DTEND in UTC, SUMMARY = "{resource.name}".
3. Secure each feed URL with an opaque per-user token (not the user's
   session) so the feed keeps working across calendar app restarts.

**Two-way sync with Google / Microsoft** — much bigger. Requires:
- OAuth 2.0 app registration with each provider
- Per-user refresh token storage (encrypted)
- Sync jobs that create events in the user's personal calendar when a
  booking lands, and listen for deletions/updates from their side
- Reconciliation logic when states diverge

Would be a dedicated `calendar-sync` module rather than part of
scheduling. Build when demand warrants.

## Services used (from core)

- `Core\Database\Database` — all SQL, transactions
- `Core\Auth\Auth` — actor, audit log, authorization
- `Core\Services\MailService` — confirmation emails
- `Core\Services\NotificationService` — owner in-app notifications
- `Core\Validation\Validator` — admin form validation
- `Core\Session` — flash messages

## Dependencies

- `claudephpframework-core`
- Core's `users` table (via `user_id` FK on bookings)
- `notifications` module (optional, for owner in-app notifications —
  fails gracefully if not installed since core's NotificationService
  is in the framework)

No dependencies on other modules.
