<?php
// modules/scheduling/module.php
use Core\Module\ModuleProvider;

/**
 * Scheduling / bookings module.
 *
 * Generic "book a time slot on a resource" primitive. Resources are
 * polymorphic — the app decides whether they're people, rooms, services,
 * class seats, or equipment. Weekly recurring availability, per-resource
 * capacity, transactional double-book prevention, confirmation emails,
 * and in-app notifications for resource owners.
 *
 * Calendar sync (iCal feeds + Google/Microsoft OAuth integration) is
 * deferred to a follow-up. The module's data model supports it cleanly
 * when added.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'scheduling'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
