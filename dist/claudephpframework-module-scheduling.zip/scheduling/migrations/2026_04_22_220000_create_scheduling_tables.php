<?php
// modules/scheduling/migrations/2026_04_22_220000_create_scheduling_tables.php
use Core\Database\Migration;

/**
 * Schema for the scheduling module. Three tables:
 *
 *   scheduling_resources      — the bookable things. A resource has a name,
 *                               duration (how long each slot is), capacity
 *                               (how many bookings per slot), optional
 *                               owner user_id, and a timezone. Resources are
 *                               deliberately polymorphic — apps decide
 *                               whether a "resource" is a person, a room,
 *                               a service, or a class seat.
 *
 *   scheduling_availability   — weekly recurring windows when a resource is
 *                               bookable. Day-of-week (0=Sun..6=Sat) plus
 *                               HH:MM:SS start/end in the resource's tz.
 *                               Multiple rows per resource are allowed
 *                               (split shifts — 9-12 + 13-17 etc.).
 *
 *   scheduling_bookings       — the actual reservations. starts_at/ends_at
 *                               stored in UTC (normalized from resource tz
 *                               when booked). Status lifecycle:
 *                                 confirmed → cancelled
 *                                           → completed   (after ends_at)
 *                                           → no_show     (admin marks)
 *                               "pending" exists for future manual-approval
 *                               workflows but the MVP auto-confirms on book.
 *
 * Double-booking prevention:
 *   The service wraps booking creation in a transaction with SELECT FOR
 *   UPDATE on the per-slot count. That's sufficient for typical load; a
 *   UNIQUE constraint doesn't fit well because the conflict definition
 *   depends on both status and capacity.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE scheduling_resources (
                id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name             VARCHAR(191) NOT NULL,
                slug             VARCHAR(120) NOT NULL,
                description      TEXT         NULL,
                owner_user_id    INT UNSIGNED NULL,
                duration_minutes INT UNSIGNED NOT NULL DEFAULT 30,
                capacity         INT UNSIGNED NOT NULL DEFAULT 1,
                buffer_minutes   INT UNSIGNED NOT NULL DEFAULT 0,
                timezone         VARCHAR(64)  NOT NULL DEFAULT 'UTC',
                active           TINYINT(1)   NOT NULL DEFAULT 1,
                public           TINYINT(1)   NOT NULL DEFAULT 1,
                created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_slug (slug),
                KEY idx_active_public (active, public),
                KEY idx_owner (owner_user_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE scheduling_availability (
                id           INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                resource_id  INT UNSIGNED NOT NULL,
                day_of_week  TINYINT UNSIGNED NOT NULL,
                start_time   TIME NOT NULL,
                end_time     TIME NOT NULL,
                created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                KEY idx_resource_day (resource_id, day_of_week),
                CONSTRAINT fk_avail_resource
                    FOREIGN KEY (resource_id) REFERENCES scheduling_resources (id) ON DELETE CASCADE,
                CONSTRAINT chk_day_range    CHECK (day_of_week BETWEEN 0 AND 6),
                CONSTRAINT chk_time_order   CHECK (end_time > start_time)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE scheduling_bookings (
                id                 BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                resource_id        INT UNSIGNED NOT NULL,
                user_id            INT UNSIGNED NOT NULL,
                starts_at          DATETIME     NOT NULL,
                ends_at            DATETIME     NOT NULL,
                status             ENUM('pending','confirmed','cancelled','completed','no_show') NOT NULL DEFAULT 'confirmed',
                notes              TEXT         NULL,
                confirmation_code  VARCHAR(32)  NOT NULL,
                created_at         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at         DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_code (confirmation_code),
                KEY idx_resource_start (resource_id, starts_at, status),
                KEY idx_user_start     (user_id, starts_at),
                KEY idx_status_start   (status, starts_at),
                CONSTRAINT fk_book_resource
                    FOREIGN KEY (resource_id) REFERENCES scheduling_resources (id) ON DELETE CASCADE,
                CONSTRAINT chk_times CHECK (ends_at > starts_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS scheduling_bookings");
        $this->db->query("DROP TABLE IF EXISTS scheduling_availability");
        $this->db->query("DROP TABLE IF EXISTS scheduling_resources");
    }
};
