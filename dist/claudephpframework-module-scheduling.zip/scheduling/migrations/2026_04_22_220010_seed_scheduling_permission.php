<?php
// modules/scheduling/migrations/2026_04_22_220010_seed_scheduling_permission.php
use Core\Database\Migration;

/**
 * Seed the `scheduling.manage` permission so admin roles can be granted
 * access to create resources, configure availability, and manage bookings.
 * Idempotent via INSERT IGNORE on the slug unique key.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage scheduling',
            'scheduling.manage',
            'scheduling',
            'Create and edit bookable resources, configure availability, and manage bookings.',
        ]);
    }

    public function down(): void
    {
        // Keep permission rows intact — other roles may reference them.
    }
};
