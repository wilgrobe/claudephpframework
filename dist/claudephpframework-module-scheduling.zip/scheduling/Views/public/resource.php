<?php
$pageTitle = $resource['name'];
/** @var \DateTimeZone $timezone */
$today     = (new \DateTimeImmutable('now', $timezone))->format('Y-m-d');
$prevDate  = (new \DateTimeImmutable($date, $timezone))->modify('-1 day')->format('Y-m-d');
$nextDate  = (new \DateTimeImmutable($date, $timezone))->modify('+1 day')->format('Y-m-d');
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/book" class="btn btn-sm btn-secondary">← All resources</a>
    <h1 style="margin:0;font-size:1.5rem"><?= e($resource['name']) ?></h1>
    <span style="color:#6b7280;font-size:13px">
        <?= (int) $resource['duration_minutes'] ?>min · <?= e($resource['timezone']) ?>
    </span>
</div>

<?php if (!empty($resource['description'])): ?>
<div style="color:#4b5563;font-size:14px;margin-bottom:1.5rem;max-width:720px"><?= nl2br(e((string) $resource['description'])) ?></div>
<?php endif; ?>

<!-- Date navigator -->
<div class="card" style="margin-bottom:1rem">
    <div class="card-body" style="display:flex;align-items:center;gap:.5rem">
        <a href="?date=<?= e($prevDate) ?>" class="btn btn-sm btn-secondary">←</a>
        <form method="GET" style="flex:1">
            <input type="date" name="date" value="<?= e($date) ?>" onchange="this.form.submit()" style="width:auto">
        </form>
        <?php if ($date !== $today): ?>
        <a href="?date=<?= e($today) ?>" class="btn btn-sm btn-secondary">Today</a>
        <?php endif; ?>
        <a href="?date=<?= e($nextDate) ?>" class="btn btn-sm btn-secondary">→</a>
    </div>
</div>

<!-- Slot picker -->
<?php if (empty($slots)): ?>
<div class="card">
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
        No available slots on <strong><?= e((new \DateTimeImmutable($date))->format('l, F j, Y')) ?></strong>.
        Try another day using the navigator above.
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="card-header">
        <h2 style="font-size:1rem;margin:0">
            <?= e((new \DateTimeImmutable($date))->format('l, F j, Y')) ?>
            <span style="color:#9ca3af;font-weight:normal;font-size:13px;margin-left:.5rem"><?= count($slots) ?> slot<?= count($slots) === 1 ? '' : 's' ?></span>
        </h2>
    </div>
    <div class="card-body">
        <form method="POST" action="/book/<?= e($resource['slug']) ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="date" value="<?= e($date) ?>">

            <!-- Time slots as radio-style buttons -->
            <div style="display:grid;gap:.5rem;grid-template-columns:repeat(auto-fill, minmax(110px, 1fr));margin-bottom:1rem">
                <?php foreach ($slots as $s): ?>
                <?php $utcStr = $s['start']->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s'); ?>
                <label style="cursor:pointer;border:1px solid #e5e7eb;border-radius:6px;padding:.6rem;text-align:center;display:block">
                    <input type="radio" name="starts_at_utc" value="<?= e($utcStr) ?>" required style="margin-right:.25rem;vertical-align:middle">
                    <strong style="font-size:14px"><?= e($s['start']->format('H:i')) ?></strong>
                    <div style="font-size:11px;color:#9ca3af">
                        <?= e($s['start']->format('ga')) ?>
                        <?php if ((int) $resource['capacity'] > 1): ?>
                        · <?= (int) $s['available'] ?> left
                        <?php endif; ?>
                    </div>
                </label>
                <?php endforeach; ?>
            </div>

            <div class="form-row">
                <label>Notes (optional)</label>
                <textarea name="notes" rows="2" maxlength="1000" placeholder="Anything the host should know?"></textarea>
            </div>

            <button class="btn btn-primary">Book selected time</button>
        </form>
    </div>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
