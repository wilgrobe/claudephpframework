<?php $pageTitle = 'My bookings'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <h1 style="margin:0;font-size:1.5rem">My bookings</h1>
    <a href="/book" class="btn btn-sm btn-primary" style="margin-left:auto">+ New booking</a>
</div>

<?php if (empty($bookings)): ?>
<div class="card">
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
        You don't have any bookings yet.
        <div style="margin-top:1rem"><a href="/book" class="btn btn-primary">Browse resources</a></div>
    </div>
</div>
<?php else: ?>
<div class="card">
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Resource</th><th>When</th><th>Status</th><th>Code</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($bookings as $b): ?>
            <?php
            $tz    = new \DateTimeZone((string) $b['resource_timezone']);
            $start = new \DateTimeImmutable($b['starts_at'], new \DateTimeZone('UTC'));
            $local = $start->setTimezone($tz);
            $isPast = $start < new \DateTimeImmutable('now', new \DateTimeZone('UTC'));
            $badge = match ($b['status']) {
                'confirmed' => 'badge-success',
                'pending'   => 'badge-warning',
                'cancelled' => 'badge-gray',
                'completed' => 'badge-info',
                'no_show'   => 'badge-danger',
                default     => 'badge-gray',
            };
            ?>
            <tr>
                <td>
                    <strong><?= e($b['resource_name']) ?></strong>
                    <div style="font-size:11px;color:#9ca3af"><?= e($b['resource_timezone']) ?></div>
                </td>
                <td>
                    <div><?= e($local->format('D M j, Y H:i')) ?></div>
                    <div style="font-size:11px;color:#9ca3af"><?= e($local->format('T')) ?></div>
                </td>
                <td><span class="badge <?= $badge ?>"><?= e(str_replace('_', ' ', $b['status'])) ?></span></td>
                <td><code style="font-size:12px"><?= e($b['confirmation_code']) ?></code></td>
                <td>
                    <?php if (!$isPast && in_array($b['status'], ['pending', 'confirmed'], true)): ?>
                    <form method="POST" action="/book/<?= (int) $b['id'] ?>/cancel" data-confirm="Cancel this booking?">
                        <?= csrf_field() ?><button class="btn btn-xs btn-danger">Cancel</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
