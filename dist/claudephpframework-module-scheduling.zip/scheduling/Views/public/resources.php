<?php $pageTitle = 'Book a time'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <h1 style="margin:0;font-size:1.5rem">Book a time</h1>
    <a href="/book/my" class="btn btn-sm btn-secondary" style="margin-left:auto">My bookings</a>
</div>

<?php if (empty($resources)): ?>
<div class="card">
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
        No bookable resources are available right now. Check back later.
    </div>
</div>
<?php else: ?>
<div style="display:grid;gap:1rem;grid-template-columns:repeat(auto-fit, minmax(280px, 1fr))">
    <?php foreach ($resources as $r): ?>
    <a href="/book/<?= e($r['slug']) ?>" class="card" style="text-decoration:none;color:inherit;padding:1.25rem;display:block">
        <h3 style="margin:0 0 .5rem 0;font-size:1.1rem"><?= e($r['name']) ?></h3>
        <div style="color:#6b7280;font-size:13px;margin-bottom:.75rem">
            <?= (int) $r['duration_minutes'] ?> minutes
            <?php if ((int) $r['capacity'] > 1): ?> · <?= (int) $r['capacity'] ?> per slot<?php endif; ?>
            · <?= e($r['timezone']) ?>
        </div>
        <?php if (!empty($r['description'])): ?>
        <p style="color:#4b5563;font-size:14px;margin:0"><?= nl2br(e(mb_substr((string) $r['description'], 0, 160))) ?><?= mb_strlen((string) $r['description']) > 160 ? '…' : '' ?></p>
        <?php endif; ?>
    </a>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
