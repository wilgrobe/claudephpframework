<?php $pageTitle = 'Scheduling — Bookings'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h2>Bookings</h2>
        <a href="/admin/scheduling/resources" class="btn btn-sm btn-secondary">Resources →</a>
    </div>

    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem;flex-wrap:wrap">
        <a href="/admin/scheduling/bookings" class="btn btn-sm <?= empty($status) ? 'btn-primary' : 'btn-secondary' ?>">All</a>
        <?php foreach (['confirmed', 'pending', 'cancelled', 'completed', 'no_show'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= $status === $s ? 'btn-primary' : 'btn-secondary' ?>">
            <?= ucfirst(str_replace('_', ' ', $s)) ?>
            <span style="opacity:.7;margin-left:.25rem">(<?= (int) ($counts[$s] ?? 0) ?>)</span>
        </a>
        <?php endforeach; ?>
    </div>

    <?php if (empty($items)): ?>
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">No bookings in this status.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>When (UTC)</th><th>Resource</th><th>User</th><th>Status</th><th>Code</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($items as $b): ?>
            <?php
            $badge = match ($b['status']) {
                'confirmed' => 'badge-success',
                'pending'   => 'badge-warning',
                'cancelled' => 'badge-gray',
                'completed' => 'badge-info',
                'no_show'   => 'badge-danger',
                default     => 'badge-gray',
            };
            ?>
            <tr>
                <td style="font-size:13px;white-space:nowrap">
                    <div><?= e(date('M j, Y H:i', strtotime((string) $b['starts_at']))) ?></div>
                    <div style="color:#9ca3af;font-size:11px">to <?= e(date('H:i', strtotime((string) $b['ends_at']))) ?></div>
                </td>
                <td><?= e($b['resource_name']) ?></td>
                <td>
                    <?php if (!empty($b['username'])): ?>
                    <strong><?= e($b['username']) ?></strong>
                    <div style="font-size:12px;color:#9ca3af"><?= e((string) $b['email']) ?></div>
                    <?php else: ?>
                    <span style="color:#9ca3af">user #<?= (int) $b['user_id'] ?></span>
                    <?php endif; ?>
                </td>
                <td><span class="badge <?= $badge ?>"><?= e(str_replace('_', ' ', $b['status'])) ?></span></td>
                <td><code style="font-size:11px"><?= e($b['confirmation_code']) ?></code></td>
                <td>
                    <div style="display:flex;gap:.25rem;flex-wrap:wrap">
                        <?php
                        $avail = match ($b['status']) {
                            'confirmed' => ['completed' => ['Complete', 'btn-info'], 'no_show' => ['No-show', 'btn-warning'], 'cancelled' => ['Cancel', 'btn-danger']],
                            'pending'   => ['confirmed' => ['Confirm', 'btn-success'], 'cancelled' => ['Cancel', 'btn-danger']],
                            'cancelled' => ['confirmed' => ['Restore', 'btn-success']],
                            'completed' => [],
                            'no_show'   => [],
                            default     => [],
                        };
                        ?>
                        <?php foreach ($avail as $toStatus => [$label, $class]): ?>
                        <form method="POST" action="/admin/scheduling/bookings/<?= (int) $b['id'] ?>/status/<?= e($toStatus) ?>">
                            <?= csrf_field() ?><button class="btn btn-xs <?= $class ?>"><?= e($label) ?></button>
                        </form>
                        <?php endforeach; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
