<?php $pageTitle = 'Scheduling — Resources'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h2>Scheduling — Resources</h2>
        <div style="display:flex;gap:.35rem">
            <a href="/admin/scheduling/bookings" class="btn btn-sm btn-secondary">View bookings</a>
            <a href="/admin/scheduling/resources/create" class="btn btn-sm btn-primary">+ New resource</a>
        </div>
    </div>

    <?php if (empty($resources)): ?>
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
        No resources yet. Create one to start accepting bookings.
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>Name</th><th>Duration</th><th>Capacity</th><th>Timezone</th><th>Visibility</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($resources as $r): ?>
            <tr<?= (int) $r['active'] !== 1 ? ' style="opacity:.5"' : '' ?>>
                <td>
                    <strong><?= e($r['name']) ?></strong>
                    <div style="font-size:12px;color:#9ca3af"><code><?= e($r['slug']) ?></code></div>
                </td>
                <td><?= (int) $r['duration_minutes'] ?>min</td>
                <td><?= (int) $r['capacity'] ?></td>
                <td style="font-size:12px"><?= e($r['timezone']) ?></td>
                <td>
                    <?php if ((int) $r['active'] !== 1): ?><span class="badge badge-gray">Inactive</span>
                    <?php elseif ((int) $r['public'] === 1): ?><span class="badge badge-success">Public</span>
                    <?php else: ?><span class="badge badge-info">Private</span>
                    <?php endif; ?>
                </td>
                <td>
                    <div style="display:flex;gap:.35rem">
                        <?php if ((int) $r['active'] === 1 && (int) $r['public'] === 1): ?>
                        <a href="/book/<?= e($r['slug']) ?>" target="_blank" class="btn btn-xs btn-secondary">View</a>
                        <?php endif; ?>
                        <a href="/admin/scheduling/resources/<?= (int) $r['id'] ?>/edit" class="btn btn-xs btn-secondary">Edit</a>
                        <form method="POST" action="/admin/scheduling/resources/<?= (int) $r['id'] ?>/delete"
                              data-confirm="Delete '<?= e($r['name']) ?>' and ALL its bookings?">
                            <?= csrf_field() ?><button class="btn btn-xs btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
