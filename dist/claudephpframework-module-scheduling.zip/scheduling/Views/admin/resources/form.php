<?php
$isEdit    = !empty($resource);
$pageTitle = $isEdit ? 'Edit resource: ' . $resource['name'] : 'New resource';
$errors    = \Core\Session::get('errors', []);
$old       = \Core\Session::get('old', []);
$val       = fn(string $k, string $default = '') => e($old[$k] ?? ($resource[$k] ?? $default));

// Common timezones list — short subset for the dropdown; admin can edit
// directly to use any PHP DateTimeZone id.
$tzOptions = ['UTC', 'America/New_York', 'America/Chicago', 'America/Denver',
              'America/Los_Angeles', 'Europe/London', 'Europe/Paris', 'Europe/Berlin',
              'Asia/Tokyo', 'Asia/Singapore', 'Australia/Sydney'];
$dayNames  = [0 => 'Sun', 1 => 'Mon', 2 => 'Tue', 3 => 'Wed', 4 => 'Thu', 5 => 'Fri', 6 => 'Sat'];
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/scheduling/resources" class="btn btn-sm btn-secondary">← Back</a>
    <h1 style="margin:0;font-size:1.5rem"><?= $isEdit ? 'Edit resource' : 'New resource' ?></h1>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? '/admin/scheduling/resources/' . (int) $resource['id'] . '/edit' : '/admin/scheduling/resources/create' ?>">
            <?= csrf_field() ?>

            <div class="form-row">
                <label>Name *</label>
                <input type="text" name="name" value="<?= $val('name') ?>" required maxlength="191" placeholder="30-minute consultation">
            </div>

            <div class="form-row">
                <label>Slug *</label>
                <input type="text" name="slug" value="<?= $val('slug') ?>" required maxlength="120" pattern="[a-z0-9-]+" placeholder="consultation-30">
                <small>Used in <code>/book/{slug}</code>.</small>
            </div>

            <div class="form-row">
                <label>Description</label>
                <textarea name="description" rows="3"><?= $val('description') ?></textarea>
            </div>

            <div style="display:flex;gap:1rem">
                <div class="form-row" style="flex:1">
                    <label>Duration (minutes) *</label>
                    <input type="number" name="duration_minutes" value="<?= $val('duration_minutes', '30') ?>" required min="1">
                </div>
                <div class="form-row" style="flex:1">
                    <label>Capacity</label>
                    <input type="number" name="capacity" value="<?= $val('capacity', '1') ?>" min="1">
                    <small>Bookings per slot. Use >1 for class-style seats.</small>
                </div>
                <div class="form-row" style="flex:1">
                    <label>Buffer (minutes)</label>
                    <input type="number" name="buffer_minutes" value="<?= $val('buffer_minutes', '0') ?>" min="0">
                    <small>Not enforced yet (v2).</small>
                </div>
            </div>

            <div class="form-row">
                <label>Timezone</label>
                <select name="timezone">
                    <?php foreach ($tzOptions as $tz): ?>
                    <option value="<?= e($tz) ?>" <?= ($old['timezone'] ?? $resource['timezone'] ?? 'UTC') === $tz ? 'selected' : '' ?>><?= e($tz) ?></option>
                    <?php endforeach; ?>
                </select>
                <small>Availability windows below are in this timezone. Bookings stored in UTC.</small>
            </div>

            <div class="form-row">
                <label>Owner user ID (optional)</label>
                <input type="number" name="owner_user_id" value="<?= $val('owner_user_id') ?>" min="1">
                <small>Resource owner receives an in-app notification on each booking.</small>
            </div>

            <div style="display:flex;gap:1.5rem">
                <label><input type="checkbox" name="active" value="1" <?= (!$isEdit || (int) ($resource['active'] ?? 1) === 1) ? 'checked' : '' ?>> Active</label>
                <label><input type="checkbox" name="public" value="1" <?= (!$isEdit || (int) ($resource['public'] ?? 1) === 1) ? 'checked' : '' ?>> Public (listed at /book)</label>
            </div>

            <!-- ── Weekly availability ─────────────────────────────────── -->
            <fieldset style="margin-top:1.5rem;padding:1rem;border:1px solid #e5e7eb;border-radius:6px">
                <legend style="font-weight:600;padding:0 .5rem">Weekly availability</legend>
                <p style="color:#6b7280;font-size:13px;margin-top:0">
                    Add one row per availability window. Times are in the resource's timezone.
                    Leave a row blank to remove it on save.
                </p>

                <div id="avail-rows">
                    <?php
                    // Show existing rows + 3 blank ones for new additions.
                    $rows = array_merge(
                        $availability ?? [],
                        array_fill(0, 3, ['day_of_week' => 1, 'start_time' => '', 'end_time' => ''])
                    );
                    foreach ($rows as $i => $row):
                    ?>
                    <div style="display:flex;gap:.5rem;align-items:center;margin-bottom:.5rem">
                        <select name="avail_day[]" style="flex:0 0 100px">
                            <?php foreach ($dayNames as $d => $n): ?>
                            <option value="<?= $d ?>" <?= (int) $row['day_of_week'] === $d ? 'selected' : '' ?>><?= $n ?></option>
                            <?php endforeach; ?>
                        </select>
                        <input type="time" name="avail_start[]" value="<?= e(substr((string) $row['start_time'], 0, 5)) ?>" style="flex:0 0 120px">
                        <span style="color:#9ca3af">to</span>
                        <input type="time" name="avail_end[]" value="<?= e(substr((string) $row['end_time'], 0, 5)) ?>" style="flex:0 0 120px">
                    </div>
                    <?php endforeach; ?>
                </div>
                <button type="button" class="btn btn-xs btn-secondary" onclick="
                    const container = document.getElementById('avail-rows');
                    const row = container.firstElementChild.cloneNode(true);
                    row.querySelectorAll('input').forEach(i => i.value = '');
                    container.appendChild(row);
                ">+ Add row</button>
            </fieldset>

            <div style="margin-top:1rem">
                <button class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
