<?php
// modules/scheduling/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$B = 'Modules\Scheduling\Controllers\BookingController';
$A = 'Modules\Scheduling\Controllers\SchedulingAdminController';

// ── User-facing /book ─────────────────────────────────────────────────────
$router->get ('/book',                     "$B@index",  [AuthMiddleware::class]);
$router->get ('/book/my',                  "$B@my",     [AuthMiddleware::class]);
$router->get ('/book/{slug}',              "$B@show",   [AuthMiddleware::class]);
$router->post('/book/{slug}',              "$B@book",   [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/book/{id}/cancel',         "$B@cancel", [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Admin ─────────────────────────────────────────────────────────────────
$router->get ('/admin/scheduling/resources',                "$A@resourcesIndex",   [AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/scheduling/resources/create',         "$A@resourceCreate",   [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/scheduling/resources/create',         "$A@resourceStore",    [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/scheduling/resources/{id}/edit',      "$A@resourceEdit",     [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/scheduling/resources/{id}/edit',      "$A@resourceUpdate",   [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/scheduling/resources/{id}/delete',    "$A@resourceDelete",   [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/scheduling/bookings',                 "$A@bookingsIndex",    [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/scheduling/bookings/{id}/status/{st}',"$A@bookingSetStatus", [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
