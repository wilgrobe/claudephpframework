<?php
// modules/scheduling/Services/SchedulingService.php
namespace Modules\Scheduling\Services;

use Core\Database\Database;
use DateTimeImmutable;
use DateTimeZone;

/**
 * Scheduling domain logic: resources, availability windows, slot
 * generation, transactional booking.
 *
 * Key pieces:
 *   - availableSlots($resourceId, $date): computes concrete (start, end)
 *     UTC ranges from the resource's weekly availability, minus already-
 *     booked slots that have hit capacity. Date is the local calendar
 *     day in the resource's timezone.
 *   - book(): transactional SELECT FOR UPDATE + INSERT, capacity-aware.
 *     A concurrent booking for the same slot is blocked until our txn
 *     commits/rolls back.
 *   - cancel(): simple status update; the freed slot becomes available
 *     again on the next slot query.
 *
 * Timezones: booking starts_at/ends_at are stored in UTC. Availability
 * windows (HH:MM:SS) are interpreted in the resource's `timezone`. Slot
 * computation does the HH:MM→UTC conversion using PHP's DateTimeZone.
 */
class SchedulingService
{
    public const STATUSES = ['pending', 'confirmed', 'cancelled', 'completed', 'no_show'];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Resource fetches ──────────────────────────────────────────────────

    /** @return array<int, array<string, mixed>> */
    public function activeResources(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM scheduling_resources
              WHERE active = 1 AND public = 1
           ORDER BY name ASC"
        );
    }

    /** All resources, including inactive/private — for admin. */
    public function allResources(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM scheduling_resources ORDER BY active DESC, name ASC"
        );
    }

    public function findResource(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM scheduling_resources WHERE id = ?", [$id]);
    }

    public function findResourceBySlug(string $slug): ?array
    {
        return $this->db->fetchOne("SELECT * FROM scheduling_resources WHERE slug = ?", [$slug]);
    }

    /** @return array<int, array<string, mixed>> ordered by day + start_time */
    public function availabilityFor(int $resourceId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM scheduling_availability
              WHERE resource_id = ?
           ORDER BY day_of_week ASC, start_time ASC",
            [$resourceId]
        );
    }

    // ── Resource CRUD (admin) ─────────────────────────────────────────────

    public function createResource(array $data): int
    {
        return $this->db->insert('scheduling_resources', [
            'name'             => (string) $data['name'],
            'slug'             => (string) $data['slug'],
            'description'      => $data['description'] ?? null,
            'owner_user_id'    => !empty($data['owner_user_id']) ? (int) $data['owner_user_id'] : null,
            'duration_minutes' => max(1, (int) ($data['duration_minutes'] ?? 30)),
            'capacity'         => max(1, (int) ($data['capacity'] ?? 1)),
            'buffer_minutes'   => max(0, (int) ($data['buffer_minutes'] ?? 0)),
            'timezone'         => (string) ($data['timezone'] ?? 'UTC'),
            'active'           => !empty($data['active']) ? 1 : 0,
            'public'           => !empty($data['public']) ? 1 : 0,
        ]);
    }

    public function updateResource(int $id, array $data): void
    {
        $this->db->update('scheduling_resources', [
            'name'             => (string) $data['name'],
            'slug'             => (string) $data['slug'],
            'description'      => $data['description'] ?? null,
            'owner_user_id'    => !empty($data['owner_user_id']) ? (int) $data['owner_user_id'] : null,
            'duration_minutes' => max(1, (int) ($data['duration_minutes'] ?? 30)),
            'capacity'         => max(1, (int) ($data['capacity'] ?? 1)),
            'buffer_minutes'   => max(0, (int) ($data['buffer_minutes'] ?? 0)),
            'timezone'         => (string) ($data['timezone'] ?? 'UTC'),
            'active'           => !empty($data['active']) ? 1 : 0,
            'public'           => !empty($data['public']) ? 1 : 0,
        ], 'id = ?', [$id]);
    }

    public function deleteResource(int $id): void
    {
        // Cascades wipe availability + bookings via FK.
        $this->db->delete('scheduling_resources', 'id = ?', [$id]);
    }

    /**
     * Replace the entire weekly availability for a resource. Expects an
     * array of rows like [['day_of_week' => 1, 'start_time' => '09:00:00',
     * 'end_time' => '17:00:00'], ...]. Transactional so a failed row
     * doesn't leave the resource half-configured.
     */
    public function setAvailability(int $resourceId, array $windows): void
    {
        $this->db->transaction(function () use ($resourceId, $windows) {
            $this->db->delete('scheduling_availability', 'resource_id = ?', [$resourceId]);
            foreach ($windows as $w) {
                $day   = (int) ($w['day_of_week'] ?? -1);
                $start = (string) ($w['start_time'] ?? '');
                $end   = (string) ($w['end_time']   ?? '');
                if ($day < 0 || $day > 6 || $start === '' || $end === '') continue;
                if (strtotime('1970-01-01 ' . $end) <= strtotime('1970-01-01 ' . $start)) continue;

                $this->db->insert('scheduling_availability', [
                    'resource_id' => $resourceId,
                    'day_of_week' => $day,
                    'start_time'  => $start,
                    'end_time'    => $end,
                ]);
            }
        });
    }

    // ── Slot generation ───────────────────────────────────────────────────

    /**
     * Compute available slots for $resourceId on a given local date.
     *
     * Walks the resource's availability windows for that day-of-week,
     * steps through them in duration-sized chunks, and filters out any
     * slot that already has `capacity` confirmed bookings.
     *
     * @param  int    $resourceId
     * @param  string $date       YYYY-MM-DD in the resource's timezone
     * @return array<int, array{start: DateTimeImmutable, end: DateTimeImmutable, available: int}>
     */
    public function availableSlots(int $resourceId, string $date): array
    {
        $resource = $this->findResource($resourceId);
        if (!$resource || (int) $resource['active'] !== 1) return [];

        $tz       = new DateTimeZone((string) $resource['timezone']);
        $duration = (int) $resource['duration_minutes'];
        $capacity = max(1, (int) $resource['capacity']);

        $dayStart = DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $date . ' 00:00:00', $tz);
        if (!$dayStart) return [];
        $dow = (int) $dayStart->format('w'); // 0..6

        $windows = $this->db->fetchAll(
            "SELECT start_time, end_time FROM scheduling_availability
              WHERE resource_id = ? AND day_of_week = ?
           ORDER BY start_time ASC",
            [$resourceId, $dow]
        );
        if (empty($windows)) return [];

        // Pull existing confirmed bookings for the calendar-day in UTC
        // so we can O(1) check per slot.
        $bookingCounts = $this->bookingCountsForDay($resourceId, $dayStart, $tz);

        $slots = [];
        foreach ($windows as $w) {
            $slot = DateTimeImmutable::createFromFormat(
                'Y-m-d H:i:s',
                $date . ' ' . $w['start_time'],
                $tz
            );
            $end  = DateTimeImmutable::createFromFormat(
                'Y-m-d H:i:s',
                $date . ' ' . $w['end_time'],
                $tz
            );
            if (!$slot || !$end) continue;

            while ($slot < $end) {
                $slotEnd = $slot->modify("+$duration minutes");
                if ($slotEnd > $end) break;

                $startUtc = $slot->setTimezone(new DateTimeZone('UTC'));
                $count = $bookingCounts[$startUtc->format('Y-m-d H:i:s')] ?? 0;
                if ($count < $capacity) {
                    $slots[] = [
                        'start'     => $slot,
                        'end'       => $slotEnd,
                        'available' => $capacity - $count,
                    ];
                }

                $slot = $slotEnd;
            }
        }
        return $slots;
    }

    /**
     * Map of booking counts keyed by UTC starts_at string for the given
     * local date. Used by availableSlots to avoid N queries.
     *
     * @return array<string, int>
     */
    private function bookingCountsForDay(int $resourceId, DateTimeImmutable $localMidnight, DateTimeZone $tz): array
    {
        $utcStart = $localMidnight->setTimezone(new DateTimeZone('UTC'));
        $utcEnd   = $localMidnight->modify('+1 day')->setTimezone(new DateTimeZone('UTC'));

        $rows = $this->db->fetchAll(
            "SELECT starts_at, COUNT(*) AS n
               FROM scheduling_bookings
              WHERE resource_id = ?
                AND status = 'confirmed'
                AND starts_at >= ? AND starts_at < ?
           GROUP BY starts_at",
            [$resourceId, $utcStart->format('Y-m-d H:i:s'), $utcEnd->format('Y-m-d H:i:s')]
        );

        $out = [];
        foreach ($rows as $r) {
            $out[(string) $r['starts_at']] = (int) $r['n'];
        }
        return $out;
    }

    // ── Booking lifecycle ────────────────────────────────────────────────

    /**
     * Reserve a slot. Transactional with SELECT FOR UPDATE on the per-slot
     * count so two concurrent bookings can't both win when capacity=1.
     *
     * $startsAtUtc: 'Y-m-d H:i:s' UTC. Must line up with a valid slot for
     * the resource; this function does NOT validate against availability
     * windows — callers should only pass values from availableSlots().
     * (Not re-validating saves a round-trip; it's a convention that the
     * service accepts slots the UI presented.)
     *
     * @return array{ok: bool, booking: ?array, error: ?string}
     */
    public function book(int $resourceId, int $userId, string $startsAtUtc, ?string $notes = null): array
    {
        $resource = $this->findResource($resourceId);
        if (!$resource || (int) $resource['active'] !== 1) {
            return ['ok' => false, 'booking' => null, 'error' => 'Resource is not bookable.'];
        }

        $duration = (int) $resource['duration_minutes'];
        $capacity = max(1, (int) $resource['capacity']);

        try {
            $start = new DateTimeImmutable($startsAtUtc, new DateTimeZone('UTC'));
        } catch (\Throwable) {
            return ['ok' => false, 'booking' => null, 'error' => 'Invalid start time.'];
        }
        $end = $start->modify("+$duration minutes");

        $result = $this->db->transaction(function () use ($resourceId, $userId, $start, $end, $capacity, $notes) {
            // SELECT FOR UPDATE locks the matching rows (or the gap if
            // none exist) for the duration of the transaction — concurrent
            // writers wait.
            $count = (int) $this->db->fetchColumn(
                "SELECT COUNT(*) FROM scheduling_bookings
                  WHERE resource_id = ? AND starts_at = ? AND status = 'confirmed'
                   FOR UPDATE",
                [$resourceId, $start->format('Y-m-d H:i:s')]
            );
            if ($count >= $capacity) {
                return ['ok' => false, 'booking' => null, 'error' => 'That slot is fully booked.'];
            }

            $code = strtoupper(bin2hex(random_bytes(4)));
            $id   = $this->db->insert('scheduling_bookings', [
                'resource_id'       => $resourceId,
                'user_id'           => $userId,
                'starts_at'         => $start->format('Y-m-d H:i:s'),
                'ends_at'           => $end->format('Y-m-d H:i:s'),
                'status'            => 'confirmed',
                'notes'             => $notes,
                'confirmation_code' => $code,
            ]);

            return [
                'ok'      => true,
                'booking' => $this->findBooking($id),
                'error'   => null,
            ];
        });

        return $result;
    }

    public function cancel(int $bookingId): bool
    {
        $affected = $this->db->update(
            'scheduling_bookings',
            ['status' => 'cancelled'],
            "id = ? AND status IN ('pending', 'confirmed')",
            [$bookingId]
        );
        return $affected === 1;
    }

    public function setStatus(int $bookingId, string $status): void
    {
        if (!in_array($status, self::STATUSES, true)) {
            throw new \InvalidArgumentException("Unknown status: $status");
        }
        $this->db->update('scheduling_bookings', ['status' => $status], 'id = ?', [$bookingId]);
    }

    public function findBooking(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM scheduling_bookings WHERE id = ?", [$id]);
    }

    // ── Booking queries ───────────────────────────────────────────────────

    /**
     * User's own bookings — most recent first, grouped by future/past in
     * the UI layer. Joins the resource for display.
     *
     * @return array<int, array<string, mixed>>
     */
    public function bookingsForUser(int $userId, int $limit = 100): array
    {
        return $this->db->fetchAll(
            "SELECT b.*, r.name AS resource_name, r.slug AS resource_slug, r.timezone AS resource_timezone
               FROM scheduling_bookings b
               JOIN scheduling_resources r ON r.id = b.resource_id
              WHERE b.user_id = ?
           ORDER BY b.starts_at DESC
              LIMIT ?",
            [$userId, $limit]
        );
    }

    /**
     * Admin listing with optional status filter.
     * @return array{items: array<int, array<string, mixed>>, total: int}
     */
    public function listBookings(?string $status = null, int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        $where  = '';
        $bind   = [];
        if ($status && in_array($status, self::STATUSES, true)) {
            $where = 'WHERE b.status = ?';
            $bind[] = $status;
        }
        $items = $this->db->fetchAll(
            "SELECT b.*, r.name AS resource_name, u.username, u.email
               FROM scheduling_bookings b
               JOIN scheduling_resources r ON r.id = b.resource_id
          LEFT JOIN users u                 ON u.id = b.user_id
               $where
           ORDER BY b.starts_at DESC
              LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM scheduling_bookings b $where",
            $bind
        );
        return ['items' => $items, 'total' => $total];
    }
}
