<?php
// modules/scheduling/Controllers/BookingController.php
namespace Modules\Scheduling\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Services\MailService;
use Core\Services\NotificationService;
use Core\Session;
use DateTimeImmutable;
use DateTimeZone;
use Modules\Scheduling\Services\SchedulingService;

/**
 * User-facing booking flow:
 *   GET  /book                       list of active public resources
 *   GET  /book/{slug}?date=YYYY-MM-DD show slots + book form for a date
 *   POST /book/{slug}                create a booking
 *   GET  /book/my                    the current user's bookings
 *   POST /book/{id}/cancel           user cancels their own booking
 *
 * Auth is required for all actions — anonymous browsing deferred.
 */
class BookingController
{
    private Auth              $auth;
    private SchedulingService $sched;

    public function __construct()
    {
        $this->auth  = Auth::getInstance();
        $this->sched = new SchedulingService();
    }

    public function index(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        return Response::view('scheduling::public.resources', [
            'resources' => $this->sched->activeResources(),
            'user'      => $this->auth->user(),
        ]);
    }

    public function show(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $slug     = (string) $request->param(0);
        $resource = $this->sched->findResourceBySlug($slug);
        if (!$resource || (int) $resource['public'] !== 1 || (int) $resource['active'] !== 1) {
            return new Response('Resource not found', 404);
        }

        // Default to today in the resource's timezone — users usually want
        // "the soonest available" rather than today-in-UTC.
        $tz   = new DateTimeZone((string) $resource['timezone']);
        $date = (string) $request->query('date', (new DateTimeImmutable('now', $tz))->format('Y-m-d'));

        // Guard against malformed input — parse + re-format so a query
        // like "invalid" doesn't propagate into slot computation.
        try {
            $parsed = DateTimeImmutable::createFromFormat('Y-m-d', $date, $tz);
            if (!$parsed) throw new \InvalidArgumentException('bad date');
            $date = $parsed->format('Y-m-d');
        } catch (\Throwable) {
            $date = (new DateTimeImmutable('now', $tz))->format('Y-m-d');
        }

        $slots = $this->sched->availableSlots((int) $resource['id'], $date);

        return Response::view('scheduling::public.resource', [
            'resource' => $resource,
            'date'     => $date,
            'slots'    => $slots,
            'timezone' => $tz,
            'user'     => $this->auth->user(),
        ]);
    }

    public function book(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $slug     = (string) $request->param(0);
        $resource = $this->sched->findResourceBySlug($slug);
        if (!$resource || (int) $resource['public'] !== 1 || (int) $resource['active'] !== 1) {
            return new Response('Resource not found', 404);
        }

        $startsUtc = (string) $request->post('starts_at_utc', '');
        $notes     = $request->post('notes');
        if ($startsUtc === '') {
            Session::flash('error', 'Please pick a time slot.');
            return Response::redirect("/book/$slug");
        }

        $res = $this->sched->book(
            (int) $resource['id'],
            (int) $this->auth->id(),
            $startsUtc,
            $notes ? substr((string) $notes, 0, 1000) : null
        );
        if (!$res['ok']) {
            Session::flash('error', $res['error'] ?? 'Booking failed.');
            return Response::redirect("/book/$slug?date=" . urlencode((string) $request->query('date', '')));
        }

        $this->auth->auditLog('booking.create', 'scheduling_bookings', (int) $res['booking']['id']);
        $this->notifyParties($resource, $res['booking'], 'booked');

        Session::flash('success', 'Booked! Confirmation code: ' . $res['booking']['confirmation_code']);
        return Response::redirect('/book/my');
    }

    public function my(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        return Response::view('scheduling::public.my_bookings', [
            'bookings' => $this->sched->bookingsForUser((int) $this->auth->id()),
            'user'     => $this->auth->user(),
        ]);
    }

    public function cancel(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $id      = (int) $request->param(0);
        $booking = $this->sched->findBooking($id);
        if (!$booking) return new Response('Booking not found', 404);

        // IDOR guard: only the booking owner can cancel via the public route.
        // Admins use the admin panel's cancel (which doesn't have this check).
        if ((int) $booking['user_id'] !== (int) $this->auth->id()) {
            return new Response('Forbidden', 403);
        }

        if (!$this->sched->cancel($id)) {
            Session::flash('error', 'Could not cancel — may already be completed or cancelled.');
            return Response::redirect('/book/my');
        }

        $this->auth->auditLog('booking.cancel', 'scheduling_bookings', $id);
        $resource = $this->sched->findResource((int) $booking['resource_id']);
        if ($resource) $this->notifyParties($resource, $booking, 'cancelled');

        Session::flash('success', 'Booking cancelled.');
        return Response::redirect('/book/my');
    }

    /**
     * Send confirmation + owner notification for a booking event. Best-
     * effort — never lets a mail or notification failure block the
     * user-visible flow.
     */
    private function notifyParties(array $resource, array $booking, string $eventType): void
    {
        $subject = $eventType === 'booked'
            ? "Booking confirmed: {$resource['name']}"
            : "Booking cancelled: {$resource['name']}";

        try {
            // Email the customer.
            $customer = \Core\Database\Database::getInstance()->fetchOne(
                "SELECT id, email, first_name FROM users WHERE id = ?",
                [(int) $booking['user_id']]
            );
            if ($customer && !empty($customer['email'])) {
                $name = $customer['first_name'] ?: 'there';
                $body = "Hi $name,\n\n"
                     . ($eventType === 'booked'
                         ? "Your booking for \"{$resource['name']}\" is confirmed.\n"
                         : "Your booking for \"{$resource['name']}\" has been cancelled.\n")
                     . "Time: " . $booking['starts_at'] . " UTC\n"
                     . "Confirmation: " . $booking['confirmation_code'] . "\n";
                (new MailService())->send(
                    (string) $customer['email'],
                    $subject,
                    nl2br(htmlspecialchars($body, ENT_QUOTES)),
                    $body
                );
            }
        } catch (\Throwable $e) {
            error_log('[scheduling] customer email failed: ' . $e->getMessage());
        }

        // In-app notification for the owner if the resource is owned by a user.
        if (!empty($resource['owner_user_id'])) {
            try {
                (new NotificationService())->send(
                    (int) $resource['owner_user_id'],
                    'scheduling.' . $eventType,
                    $subject,
                    "Booking " . $booking['confirmation_code'] . " at " . $booking['starts_at'] . " UTC",
                    [
                        'booking_id'   => (int) $booking['id'],
                        'resource_id'  => (int) $resource['id'],
                        'action_url'   => '/admin/scheduling/bookings',
                    ],
                    'in_app'
                );
            } catch (\Throwable $e) {
                error_log('[scheduling] owner notification failed: ' . $e->getMessage());
            }
        }
    }
}
