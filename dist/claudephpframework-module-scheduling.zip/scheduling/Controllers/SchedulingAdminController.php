<?php
// modules/scheduling/Controllers/SchedulingAdminController.php
namespace Modules\Scheduling\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Validation\Validator;
use Modules\Scheduling\Services\SchedulingService;

/**
 * Admin surface for scheduling: resource CRUD (including availability
 * window editing), booking oversight, manual status transitions.
 *
 * Gated by Auth + RequireAdmin at registration; per-method permission
 * checks for defense in depth.
 */
class SchedulingAdminController
{
    private Auth              $auth;
    private Database          $db;
    private SchedulingService $sched;

    public function __construct()
    {
        $this->auth  = Auth::getInstance();
        $this->db    = Database::getInstance();
        $this->sched = new SchedulingService();
    }

    // ── Resource CRUD ─────────────────────────────────────────────────────

    public function resourcesIndex(Request $request): Response
    {
        if ($this->auth->cannot('scheduling.manage')) return $this->denied();
        return Response::view('scheduling::admin.resources.index', [
            'resources' => $this->sched->allResources(),
            'user'      => $this->auth->user(),
        ]);
    }

    public function resourceCreate(Request $request): Response
    {
        if ($this->auth->cannot('scheduling.manage')) return $this->denied();
        return Response::view('scheduling::admin.resources.form', [
            'resource'     => null,
            'availability' => [],
            'user'         => $this->auth->user(),
        ]);
    }

    public function resourceStore(Request $request): Response
    {
        if ($this->auth->cannot('scheduling.manage')) return $this->denied();

        $v = new Validator($request->post());
        $v->validate([
            'name'             => 'required|min:2|max:191',
            'slug'             => 'required|min:2|max:120',
            'duration_minutes' => 'required',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            Session::flash('old', $v->all());
            return Response::redirect('/admin/scheduling/resources/create');
        }

        $slug = $this->sanitizeSlug((string) $v->get('slug'));
        if ($this->sched->findResourceBySlug($slug)) {
            Session::flash('errors', ['slug' => ['That slug is already in use.']]);
            Session::flash('old', $v->all());
            return Response::redirect('/admin/scheduling/resources/create');
        }

        $id = $this->sched->createResource($this->resourceDataFromPost($request, $slug, $v));
        $this->sched->setAvailability($id, $this->availabilityFromPost($request));
        $this->auth->auditLog('scheduling.resource.create', 'scheduling_resources', $id);
        return Response::redirect("/admin/scheduling/resources/$id/edit")
            ->withFlash('success', 'Resource created.');
    }

    public function resourceEdit(Request $request): Response
    {
        if ($this->auth->cannot('scheduling.manage')) return $this->denied();
        $id       = (int) $request->param(0);
        $resource = $this->sched->findResource($id);
        if (!$resource) return new Response('Resource not found', 404);

        return Response::view('scheduling::admin.resources.form', [
            'resource'     => $resource,
            'availability' => $this->sched->availabilityFor($id),
            'user'         => $this->auth->user(),
        ]);
    }

    public function resourceUpdate(Request $request): Response
    {
        if ($this->auth->cannot('scheduling.manage')) return $this->denied();
        $id       = (int) $request->param(0);
        $resource = $this->sched->findResource($id);
        if (!$resource) return new Response('Resource not found', 404);

        $v = new Validator($request->post());
        $v->validate([
            'name' => 'required|min:2|max:191',
            'slug' => 'required|min:2|max:120',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect("/admin/scheduling/resources/$id/edit");
        }

        $slug  = $this->sanitizeSlug((string) $v->get('slug'));
        $clash = $this->db->fetchOne("SELECT id FROM scheduling_resources WHERE slug = ? AND id <> ?", [$slug, $id]);
        if ($clash) {
            Session::flash('errors', ['slug' => ['That slug is already in use.']]);
            return Response::redirect("/admin/scheduling/resources/$id/edit");
        }

        $this->sched->updateResource($id, $this->resourceDataFromPost($request, $slug, $v));
        $this->sched->setAvailability($id, $this->availabilityFromPost($request));
        $this->auth->auditLog('scheduling.resource.update', 'scheduling_resources', $id);
        return Response::redirect("/admin/scheduling/resources/$id/edit")
            ->withFlash('success', 'Resource saved.');
    }

    public function resourceDelete(Request $request): Response
    {
        if ($this->auth->cannot('scheduling.manage')) return $this->denied();
        $id = (int) $request->param(0);
        if (!$this->sched->findResource($id)) return new Response('Resource not found', 404);

        $this->sched->deleteResource($id);
        $this->auth->auditLog('scheduling.resource.delete', 'scheduling_resources', $id);
        return Response::redirect('/admin/scheduling/resources')
            ->withFlash('success', 'Resource and all bookings deleted.');
    }

    // ── Booking oversight ────────────────────────────────────────────────

    public function bookingsIndex(Request $request): Response
    {
        if ($this->auth->cannot('scheduling.manage')) return $this->denied();
        $status = $request->query('status');
        $page   = max(1, (int) $request->query('page', 1));
        $data   = $this->sched->listBookings($status ?: null, $page);

        $counts = [];
        foreach (SchedulingService::STATUSES as $s) {
            $counts[$s] = $this->sched->listBookings($s, 1, 1)['total'];
        }

        return Response::view('scheduling::admin.bookings', [
            'items'   => $data['items'],
            'total'   => $data['total'],
            'status'  => $status,
            'page'    => $page,
            'counts'  => $counts,
            'user'    => $this->auth->user(),
        ]);
    }

    public function bookingSetStatus(Request $request): Response
    {
        if ($this->auth->cannot('scheduling.manage')) return $this->denied();
        $id     = (int) $request->param(0);
        $status = (string) $request->param(1);
        $booking = $this->sched->findBooking($id);
        if (!$booking) return new Response('Booking not found', 404);

        try {
            $this->sched->setStatus($id, $status);
        } catch (\InvalidArgumentException $e) {
            Session::flash('error', $e->getMessage());
            return Response::redirect('/admin/scheduling/bookings');
        }

        $this->auth->auditLog('scheduling.booking.status', 'scheduling_bookings', $id, null, [
            'from' => $booking['status'], 'to' => $status,
        ]);
        Session::flash('success', "Booking #$id moved to $status.");
        return Response::redirect('/admin/scheduling/bookings');
    }

    // ── internals ─────────────────────────────────────────────────────────

    private function denied(): Response
    {
        return Response::redirect('/dashboard')
            ->withFlash('error', 'You do not have permission to manage scheduling.');
    }

    private function sanitizeSlug(string $raw): string
    {
        $slug = strtolower(trim($raw));
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
        return trim((string) $slug, '-');
    }

    /** Collect resource-table fields from the POST into a data array. */
    private function resourceDataFromPost(Request $request, string $slug, Validator $v): array
    {
        return [
            'name'             => (string) $v->get('name'),
            'slug'             => $slug,
            'description'      => $request->post('description'),
            'owner_user_id'    => $request->post('owner_user_id'),
            'duration_minutes' => (int) ($request->post('duration_minutes') ?: 30),
            'capacity'         => (int) ($request->post('capacity') ?: 1),
            'buffer_minutes'   => (int) ($request->post('buffer_minutes') ?: 0),
            'timezone'         => (string) ($request->post('timezone') ?: 'UTC'),
            'active'           => !empty($request->post('active')),
            'public'           => !empty($request->post('public')),
        ];
    }

    /**
     * Form posts availability as parallel arrays (day_of_week[], start_time[],
     * end_time[]). Zip them and filter blanks.
     *
     * @return array<int, array{day_of_week: int, start_time: string, end_time: string}>
     */
    private function availabilityFromPost(Request $request): array
    {
        $days   = (array) $request->post('avail_day',   []);
        $starts = (array) $request->post('avail_start', []);
        $ends   = (array) $request->post('avail_end',   []);

        $out = [];
        $n   = min(count($days), count($starts), count($ends));
        for ($i = 0; $i < $n; $i++) {
            $s = (string) $starts[$i];
            $e = (string) $ends[$i];
            if ($s === '' || $e === '') continue;
            // Normalize 'HH:MM' → 'HH:MM:00' so the DB TIME column parses.
            if (strlen($s) === 5) $s .= ':00';
            if (strlen($e) === 5) $e .= ':00';
            $out[] = [
                'day_of_week' => (int) $days[$i],
                'start_time'  => $s,
                'end_time'    => $e,
            ];
        }
        return $out;
    }
}
