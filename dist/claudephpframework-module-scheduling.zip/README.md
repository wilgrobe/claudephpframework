# Scheduling module

Bookable-resource scheduling for the framework. Supports consultants (1:1
sessions), clinics (appointments), venues (rooms), and class-style sit-ins
(multi-capacity slots) — all via a single polymorphic "resource" concept.

## Features

- **Polymorphic resources** — a resource has a name, duration, capacity,
  timezone, and optional linked owner user. The app decides whether it
  represents a person, room, service, or class seat.
- **Weekly recurring availability** — multiple windows per day (split
  shifts). Hours are in the resource's timezone; bookings are stored in
  UTC.
- **Capacity >1** for class-style slots — 20 seats in a yoga class fall
  out of a single field.
- **Transactional double-book prevention** — SELECT FOR UPDATE + capacity
  check inside a transaction, so concurrent bookings can't oversell.
- **Auto-confirmation emails** to the customer and **in-app notifications**
  for the resource owner (via NotificationService).
- **User-facing flow** at `/book` — list, detail with slot picker,
  "my bookings" with cancel.
- **Admin surface** at `/admin/scheduling/resources` and
  `/admin/scheduling/bookings` — resource CRUD with inline availability
  editor, per-booking status transitions.
- **Status lifecycle**: `pending` → `confirmed` → `completed` |
  `cancelled` | `no_show`. The MVP auto-confirms on book; manual-approval
  workflows can flip to `pending` as the default.

## Routes

### User-facing (`Auth`)

| Method | Path                  | Purpose              |
|--------|-----------------------|----------------------|
| GET    | `/book`               | List of resources    |
| GET    | `/book/{slug}`        | Slot picker for date |
| POST   | `/book/{slug}`        | Create booking       |
| GET    | `/book/my`            | My bookings          |
| POST   | `/book/{id}/cancel`   | Cancel own booking   |

### Admin (`Auth + RequireAdmin`, `scheduling.manage` permission)

| Method | Path                                                          | Purpose                      |
|--------|---------------------------------------------------------------|------------------------------|
| GET    | `/admin/scheduling/resources`                                 | Resources list               |
| GET/POST | `/admin/scheduling/resources/create`                        | Create resource              |
| GET/POST | `/admin/scheduling/resources/{id}/edit`                     | Edit resource + availability |
| POST   | `/admin/scheduling/resources/{id}/delete`                     | Delete resource              |
| GET    | `/admin/scheduling/bookings`                                  | All bookings w/ status tabs  |
| POST   | `/admin/scheduling/bookings/{id}/status/{status}`             | Transition a booking         |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
