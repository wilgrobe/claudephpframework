# Architecture — Hierarchies module

## Files

```
hierarchies/
├── module.php
├── routes.php                                            # 10 routes
├── Controllers/
│   └── HierarchiesAdminController.php                    # Tree + node CRUD + move + reorder
├── Services/
│   └── HierarchyService.php                              # Closure-table maintenance
├── Helpers/
│   └── helpers.php                                       # hierarchy_tree(), render_hierarchy_nav()
├── Views/
│   └── admin/
│       ├── index.php                                     # /admin/hierarchies — list
│       ├── form.php                                      # /admin/hierarchies/create
│       └── show.php                                      # /admin/hierarchies/{slug} — tree editor
└── migrations/
    ├── 2026_04_22_232000_create_hierarchies_tables.php   # 3 tables
    └── 2026_04_22_232010_seed_hierarchies_permission.php
```

## Data model

### `hierarchies`

```
id, name, slug (unique), description, active, timestamps
```

One row per named tree. Slugs are the stable identifier views use when
calling `hierarchy_tree('main-nav')`.

### `hierarchy_nodes`

```
id, hierarchy_id FK CASCADE,
parent_id FK self CASCADE NULL,
label, slug, url, icon, color, metadata_json,
sort_order, timestamps
UNIQUE (hierarchy_id, slug)
KEY (parent_id, sort_order)
KEY (hierarchy_id)
```

`parent_id` = NULL is a root node. `sort_order` is a per-parent
integer — reorder is a bulk rewrite of this column within a sibling
group. The `(hierarchy_id, slug)` unique key means slugs are stable
per-tree but can be reused across trees.

### `hierarchy_node_closure`

```
ancestor_id, descendant_id, depth
PRIMARY KEY (ancestor_id, descendant_id)
KEY (descendant_id, depth)
```

Closure table with self-rows (depth=0). Subtree queries use
`WHERE ancestor_id = X` and get back X plus every descendant. Ancestor
lookups use the reverse index.

## Operations

### Add node

```
1. Insert the node with (hierarchy_id, parent_id, fields).
2. Insert closure self-row (id, id, 0).
3. INSERT ... SELECT from (ancestor, descendant=parent) with depth+1
   so every ancestor of the parent is now an ancestor of the new node
   at depth = parent_depth + 1.
```

O(depth) writes — a node at depth 5 generates 6 closure rows.

### Move subtree

Closure rewrite in two passes:

1. **Delete outbound closure** — drop every `(ancestor, descendant)`
   row where `descendant` is in `subtree(nodeId)` AND `ancestor` is
   NOT. The condition "ancestor is in subtree(nodeId)" uses a nested
   SELECT against the closure table itself.
2. **Re-insert inbound closure** — for every ancestor of the NEW parent
   (including the new parent itself) × every descendant of the node
   being moved, insert a row with `depth = super.depth + sub.depth + 1`.

This preserves the internal closure of the moving subtree (no rewrite
of (nodeId → descendant) rows) and only touches the "external" rows
that cross the old parent boundary.

Cycle prevention: before rewriting, check
`hierarchy_node_closure WHERE ancestor_id = nodeId AND descendant_id = newParentId`
— if that row exists, the move would point a subtree at itself.

### Reorder siblings

`reorderSiblings([id1, id2, id3])` rewrites `sort_order` to 1, 2, 3
for the ids in order. Ids missing from the DB are ignored; ids present
in the DB but absent from the array keep their existing sort_order
(useful for partial drags in a large group).

### Tree render

`HierarchyService::tree($id)` pulls all nodes for a hierarchy in one
query ordered by `(parent_id, sort_order)`, then builds the nested
array in PHP using a parent-id map. O(n) time, one query.

## View helpers

Registered in `module.php::register()`:

```php
$tree = hierarchy_tree('main-nav');
// nested array, each node has a 'children' array

echo render_hierarchy_nav('main-nav');
// cheap default <ul><li><a>...</a>...</ul> markup
```

Apps with specific markup (top-nav bars, accordion menus, breadcrumb
renderers) should consume `hierarchy_tree()` directly and render their
own HTML; the default renderer is just a "does it work?" helper.

## Comparison with taxonomy

Both back a tree primitive, both support CRUD + attach, but the data
models diverge:

| Concern                 | taxonomy                                 | hierarchies                          |
|-------------------------|------------------------------------------|--------------------------------------|
| Purpose                 | Classify entities (tag/filter)           | Structure navigable UI               |
| Entities get attached?  | Yes — polymorphic via `entity_terms`     | Not yet — nodes carry URL + metadata |
| Hierarchy required?     | Optional per vocabulary                  | Always                               |
| Sibling order?          | Implicit (name)                          | Explicit `sort_order`                |
| Move / re-parent?       | Deferred                                 | Supported                            |
| Rich per-node metadata? | Minimal (slug + name + description)      | URL + icon + color + metadata_json   |
| Admin UX                | Form-based CRUD                          | Tree editor with inline add          |

## Testing notes

- Unit — `HierarchyService::addNode` → query
  `hierarchy_node_closure` and count expected rows. Then `moveNode` →
  recount closure rows. `moveNode` cycle rejection gets a direct test.
- Integration — create "main-nav" with 3 levels, verify
  `hierarchy_tree('main-nav')` output shape, verify the closure table
  has correct row count `∑ (depth+1)` across nodes.
- Snapshot — `render_hierarchy_nav()` output is stable enough to be a
  golden-file test for small trees.
