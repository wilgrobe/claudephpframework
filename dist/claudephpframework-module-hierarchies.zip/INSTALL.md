# Installation — Hierarchies module

## Prerequisites

- `claudephpframework-core` installed.
- `hierarchies.manage` permission granted to at least one admin role
  (seeded by the second migration). Grant via `/admin/roles`.

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-hierarchies.zip
   cp -r claudephpframework-module-hierarchies/hierarchies /path/to/project/modules/
   ```

2. Run the migrations (creates 3 tables + seeds the permission):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if you use production caching:
   ```bash
   php artisan module:cache
   ```

## First-use walkthrough

1. Log in as admin, visit `/admin/hierarchies` → **New hierarchy**.
2. Create one called "Main nav" with slug `main-nav`.
3. On the tree editor, use **Add root** to add:
   - "Home" (url: `/`)
   - "Shop" (url: `/shop`)
   - "About" (url: `/about`)
4. Open **Add child** under "Shop" and add "Catalog" and "New arrivals".
5. In a layout view anywhere in the app, drop:
   ```php
   <?= render_hierarchy_nav('main-nav') ?>
   ```
   Or read the tree and render your own markup:
   ```php
   <?php $tree = hierarchy_tree('main-nav'); ?>
   <nav>
     <?php foreach ($tree as $n): ?>
     <a href="<?= e($n['url'] ?? '#') ?>"><?= e($n['label']) ?></a>
     <?php endforeach; ?>
   </nav>
   ```

## Environment variables

None specific to this module.

## Deferred features (v2)

- **Drag-and-drop reorder UI** — the backend `reorder` + `move`
  endpoints are already in place (they return JSON and accept `ids[]`
  or `new_parent_id`). What's missing is the client JS to wire a
  library like Sortable.js into the tree editor. Slot it into
  `Views/admin/show.php` — it won't touch the services.
- **Attach entities to nodes** — today a node has a URL. For catalog
  usage you might want a node to *be* a category that products attach
  to. Add a polymorphic `hierarchy_node_entities` table
  (hierarchy_node_id, entity_type, entity_id) plus helper methods.
- **Permissions per node** — a "private" flag, or group-gated
  visibility. Today the admin builds the whole tree and it's public on
  read.
- **Import/export** — nested JSON dumps would make rotating the
  entire menu between environments painless.
- **Inline edit modal** — currently "update" requires a POST to
  `/admin/hierarchies/nodes/{id}/update` with the new fields. A
  per-node edit modal in the tree editor would make this fluent.

## Verification

- `php -l modules/hierarchies/**/*.php` — lint check.
- Create a hierarchy with a root "A", child "B" under it, grandchild
  "C" under B. Then call `HierarchyService::tree($id)` — assert the
  returned array reflects the structure. Assert
  `hierarchy_node_closure` has entries: (A,A,0), (A,B,1), (A,C,2),
  (B,B,0), (B,C,1), (C,C,0).
- Move B under a fresh root "D" → closure should be rewritten so (A,B)
  and (A,C) disappear, (D,B,1) and (D,C,2) appear.
- Attempt to move A under C → must throw "cycle".

## Troubleshooting

- **"Parent not in hierarchy"** — you're trying to add a node whose
  `parent_id` belongs to a different hierarchy. Parents and children
  must share `hierarchy_id`.
- **"Cycle"** on move — the move would make the tree cyclic. Double-
  check the new parent isn't inside the subtree of the moving node.
- **Empty nav output** — check the hierarchy's slug matches the
  `hierarchy_tree('...')` call, and that the hierarchy has at least
  one node.
