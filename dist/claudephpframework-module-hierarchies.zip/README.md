# Hierarchies module

Navigable tree primitive for the framework — site nav, product catalog
sections, org charts, curated structures — anything where the shape of
the tree and the order of siblings matters.

Complementary to, not a replacement for, the taxonomy module:

- **taxonomy** — classification. Attach a term ("featured", "audio") to
  any entity so you can filter/query by it. Multiple vocabularies, used
  for tagging.
- **hierarchies** — structure. Each node has a label + slug + optional
  URL + icon + metadata. You render the tree as a menu or a section
  list; users navigate through it.

## Features

- **Multiple hierarchies** — a "main-nav" tree, a "footer-nav" tree, a
  "service-areas" tree, a "help-center-sections" tree — all separate
  trees in the same table, identified by slug.
- **Closure-table backed** — subtree queries are O(depth) instead of
  recursive, and cycle-safe by explicit rejection in `moveNode`.
- **Move + reorder** — both operations that the taxonomy module
  deferred. Nodes can be re-parented (with a subtree-preserving
  closure rewrite) and sibling order is a single `sort_order` integer
  you can reshuffle via the reorder endpoint.
- **Rich node metadata** — label, slug, URL, icon slug, color hex,
  and a free-form `metadata_json` blob. The same table serves nav
  menus (label+url), catalog categories (label+slug+metadata), org
  charts (label+metadata with person fields).
- **Admin at `/admin/hierarchies`** — list trees, drill into each for a
  nested editor with per-node Add child / Delete / inline URL display.
- **View helper** `hierarchy_tree($slug)` returns the nested tree as
  an array; `render_hierarchy_nav($slug)` gives a boring nested `<ul>`
  for quick wiring.

## Routes

All admin-only (`AuthMiddleware` + `RequireAdmin`), gated by the seeded
`hierarchies.manage` permission:

| Method | Path                                               | Purpose                    |
|--------|----------------------------------------------------|----------------------------|
| GET    | `/admin/hierarchies`                               | List hierarchies           |
| GET    | `/admin/hierarchies/create`                        | New hierarchy form         |
| POST   | `/admin/hierarchies/create`                        | Create hierarchy           |
| GET    | `/admin/hierarchies/{slug}`                        | Tree editor                |
| POST   | `/admin/hierarchies/{id}/delete`                   | Delete hierarchy + subtree |
| POST   | `/admin/hierarchies/{id}/nodes`                    | Add node                   |
| POST   | `/admin/hierarchies/nodes/{id}/update`             | Edit node fields           |
| POST   | `/admin/hierarchies/nodes/{id}/delete`             | Delete node + descendants  |
| POST   | `/admin/hierarchies/nodes/{id}/move`               | Re-parent (JSON response)  |
| POST   | `/admin/hierarchies/nodes/reorder`                 | Reorder siblings batch     |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
