# Installation — Activity-feed module

## Steps

1. Unzip into `modules/`.
2. `php artisan migrate` (creates 1 table).
3. From other modules, call `activity_emit(...)` wherever meaningful
   things happen. Register a renderer per verb in the module's
   `register(Container)` for nice display.

## Wiring recommendations

- **social module** — `PostService::create` → `activity_emit(userId,
  'post.created', 'social_post', $postId, groupId: $groupId,
  visibility: $visibility)`.
- **comments module** — on new comment, emit `comment.replied` with
  the comment target as the object.
- **store module** — on `markPaid`, emit `order.placed` with visibility
  private, summary "New order for $N.NN" so only the actor sees it on
  their own feed.

## Deferred features

- **Fan-out / per-user inbox** — materialize a per-follower row on emit
  for O(1) feed reads at very large scale.
- **Email digest** — scheduled task that bundles unread events into a
  daily email per follower.
- **Moderation** — actions on activity rows (hide/unhide). Currently
  append-only; admins can delete via raw DB.
