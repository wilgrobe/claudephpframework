# Architecture — Activity-feed module

## Files

```
activity-feed/
├── module.php
├── routes.php                      # 4 routes
├── Controllers/ActivityController.php
├── Services/ActivityService.php    # emit + 4 read queries + render
├── Helpers/helpers.php             # activity_emit, activity_register_renderer
├── Views/
│   ├── public/{home,profile,group}.php
│   ├── admin/index.php
│   └── partials/event_row.php
└── migrations/…_create_activity_feed_tables.php
```

## Data model

```
activity_events:
  id BIGINT, actor_user_id, verb, object_type NULL, object_id NULL,
  group_id NULL, visibility ENUM('public','group','private'),
  summary NULL, context_json NULL, created_at
  Indexes: (actor_user_id, created_at), (group_id, created_at),
           (verb, created_at), (visibility, created_at)
```

## Surfaces

- `/activity` — home feed. `actor_user_id = me OR group_id IN (user's groups)`.
- `/activity/user/{username}` — profile. Public by default; self-view
  includes private.
- `/activity/group/{slug}` — group feed. Membership check gates access.
- `/admin/activity` — filterable global log.

## Verb renderers

Static registry on `ActivityService`. Modules register at boot; falls
back to `summary` column, then a generic "@actor verb" string.
Renderers receive the event row with `context` pre-parsed from JSON.
