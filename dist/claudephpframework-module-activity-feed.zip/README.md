# Activity-feed module

Generic event bus for the framework, plus three read surfaces:
`/activity` (personal home), `/activity/user/{username}` (profile
timeline), `/activity/group/{slug}` (group members only), and
`/admin/activity` (global log).

Any module emits events with a single function call:

```php
activity_emit(
    $userId, 'post.created',
    'social_post', $postId,
    groupId: $post['group_id'] ?? null,
    visibility: 'public',
    summary: '@alice posted',
    context: ['excerpt' => mb_substr($body, 0, 200)]
);
```

And registers a per-verb renderer so events display with meaningful
text:

```php
activity_register_renderer('post.created', function($event) {
    return '<strong>@' . e($event['actor_username']) . '</strong> posted'
         . (!empty($event['context']['excerpt'])
             ? ': <em>' . e($event['context']['excerpt']) . '</em>'
             : '');
});
```

Storage is append-only into a single `activity_events` table — no
per-user fan-out materialization. Indexes cover the common queries
(actor, group, visibility). Scales fine into the low millions of rows;
bigger installs can add a materialized projection without changing the
emit side.

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
