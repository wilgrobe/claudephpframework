<?php
// modules/activity-feed/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\RequireAdmin;

$A = 'Modules\ActivityFeed\Controllers\ActivityController';

$router->get ('/activity',                     "$A@home",    [AuthMiddleware::class]);
$router->get ('/activity/user/{username}',     "$A@profile");
$router->get ('/activity/group/{slug}',        "$A@group",   [AuthMiddleware::class]);
$router->get ('/admin/activity',               "$A@admin",   [AuthMiddleware::class, RequireAdmin::class]);
