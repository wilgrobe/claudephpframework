<?php
// modules/activity-feed/Helpers/helpers.php
/**
 * Global helpers for activity-feed. Thin wrappers so other modules
 * can emit events without instantiating the service explicitly.
 *
 *   activity_emit(userId, 'post.created', 'social_post', $postId,
 *                 groupId: $post['group_id'] ?? null,
 *                 visibility: 'public',
 *                 summary: '@' . $user . ' posted',
 *                 context: ['excerpt' => mb_substr($body, 0, 200)]);
 *
 *   activity_register_renderer('post.created', function($event) {
 *       $user = htmlspecialchars($event['actor_username']);
 *       $exc  = htmlspecialchars($event['context']['excerpt'] ?? '');
 *       return "<strong>@$user</strong> posted: <em>$exc</em>";
 *   });
 */

if (!function_exists('activity_emit')) {
    function activity_emit(
        int $actorUserId,
        string $verb,
        ?string $objectType = null,
        ?int $objectId = null,
        ?int $groupId = null,
        string $visibility = 'public',
        ?string $summary = null,
        ?array $context = null
    ): int {
        return (new \Modules\ActivityFeed\Services\ActivityService())
            ->emit($actorUserId, $verb, $objectType, $objectId, $groupId, $visibility, $summary, $context);
    }
}

if (!function_exists('activity_register_renderer')) {
    function activity_register_renderer(string $verb, callable $renderer): void
    {
        \Modules\ActivityFeed\Services\ActivityService::registerRenderer($verb, $renderer);
    }
}
