<?php
// modules/activity-feed/Services/ActivityService.php
namespace Modules\ActivityFeed\Services;

use Core\Database\Database;

/**
 * Event-bus style service. Any module can call
 * `ActivityService::emit(...)` to record an event; the feeds surface
 * consumes `activity_events` on demand.
 *
 * Design choices:
 *   - Append-only. Events are never edited or deleted in normal
 *     operation; a superadmin tool to purge old rows is a future
 *     follow-up.
 *   - No per-user fan-out table. The query model scans indexed paths
 *     (actor_user_id / group_id / visibility), which scales fine into
 *     the low millions of rows. Big installs can add a materialized
 *     projection without changing the emit side.
 *   - Verb renderers are pluggable: modules register a closure that
 *     turns an event row into a human string. If no renderer exists
 *     for a verb, the row's `summary` column is rendered as-is.
 */
class ActivityService
{
    /** @var array<string, callable(array): string> verb => renderer */
    private static array $renderers = [];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Register a renderer for a verb. Renderer receives the event row
     * (with parsed context) and returns HTML. Registered once per
     * request by each module's `register(Container)` call.
     */
    public static function registerRenderer(string $verb, callable $renderer): void
    {
        self::$renderers[$verb] = $renderer;
    }

    public static function clearRenderers(): void
    {
        self::$renderers = [];
    }

    /**
     * Record an event. `context` is the free-form payload; avoid
     * stuffing large blobs here (keep under a few KB). `summary` is a
     * fallback string used when no renderer is registered for the verb.
     *
     * Returns the new event id, or 0 on failure (logged, not thrown —
     * emission should never block a calling path).
     */
    public function emit(
        int    $actorUserId,
        string $verb,
        ?string $objectType = null,
        ?int    $objectId   = null,
        ?int    $groupId    = null,
        string $visibility  = 'public',
        ?string $summary    = null,
        ?array  $context    = null
    ): int {
        if (!in_array($visibility, ['public','group','private'], true)) {
            $visibility = 'public';
        }
        try {
            return (int) $this->db->insert('activity_events', [
                'actor_user_id' => $actorUserId,
                'verb'          => substr($verb, 0, 80),
                'object_type'   => $objectType !== null ? substr($objectType, 0, 64) : null,
                'object_id'     => $objectId,
                'group_id'      => $groupId,
                'visibility'    => $visibility,
                'summary'       => $summary !== null ? substr($summary, 0, 500) : null,
                'context_json'  => $context !== null
                    ? json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)
                    : null,
            ]);
        } catch (\Throwable $e) {
            error_log('[activity] emit failed: ' . $e->getMessage());
            return 0;
        }
    }

    // ── Reads ─────────────────────────────────────────────────────────────

    /**
     * Profile timeline — events where $userId is the actor. Visibility
     * filter for non-self viewers: only `public` events are visible.
     *
     * @return array<int, array<string, mixed>>
     */
    public function profileFeed(int $userId, ?int $viewerId = null, int $limit = 50, int $offset = 0): array
    {
        $viewerIsSelf = $viewerId === $userId;
        if ($viewerIsSelf) {
            $where = 'actor_user_id = ?';
            $bind  = [$userId];
        } else {
            $where = "actor_user_id = ? AND visibility = 'public'";
            $bind  = [$userId];
        }
        return $this->fetchWithAuthor("$where ORDER BY e.created_at DESC LIMIT ? OFFSET ?",
            [...$bind, $limit, $offset]);
    }

    /**
     * Group feed — events where group_id matches. Caller is responsible
     * for confirming membership; this method doesn't gate by viewer.
     */
    public function groupFeed(int $groupId, int $limit = 50, int $offset = 0): array
    {
        return $this->fetchWithAuthor(
            "group_id = ? ORDER BY e.created_at DESC LIMIT ? OFFSET ?",
            [$groupId, $limit, $offset]
        );
    }

    /**
     * Admin-side global log — every event, no filtering. Used by the
     * admin surface for traffic awareness and debugging. Filterable
     * query string via $filters.
     */
    public function globalFeed(array $filters = [], int $limit = 100, int $offset = 0): array
    {
        $where = ['1=1'];
        $bind  = [];
        if (!empty($filters['verb'])) {
            $where[] = 'e.verb = ?';
            $bind[]  = (string) $filters['verb'];
        }
        if (!empty($filters['actor_user_id'])) {
            $where[] = 'e.actor_user_id = ?';
            $bind[]  = (int) $filters['actor_user_id'];
        }
        if (!empty($filters['group_id'])) {
            $where[] = 'e.group_id = ?';
            $bind[]  = (int) $filters['group_id'];
        }
        $whereSql = 'WHERE ' . implode(' AND ', $where);
        return $this->fetchWithAuthor(
            str_replace('WHERE ', '', $whereSql) . " ORDER BY e.created_at DESC LIMIT ? OFFSET ?",
            [...$bind, $limit, $offset]
        );
    }

    /**
     * Personalized "home" feed for a user — own public events plus
     * events from groups they're a member of. Useful as a dashboard
     * widget; nothing magical, just a union.
     */
    public function homeFeed(int $userId, int $limit = 50, int $offset = 0): array
    {
        return $this->fetchWithAuthor(
            "(e.actor_user_id = ?
              OR e.group_id IN (SELECT group_id FROM user_groups WHERE user_id = ?))
             ORDER BY e.created_at DESC LIMIT ? OFFSET ?",
            [$userId, $userId, $limit, $offset]
        );
    }

    /**
     * Common read path: join author username for display, parse
     * context_json, and run the row through a verb renderer when one
     * is registered.
     *
     * @return array<int, array<string, mixed>>
     */
    private function fetchWithAuthor(string $whereAndOrderWithLimit, array $bind): array
    {
        $rows = $this->db->fetchAll(
            "SELECT e.*, u.username AS actor_username
               FROM activity_events e
          LEFT JOIN users u ON u.id = e.actor_user_id
              WHERE $whereAndOrderWithLimit",
            $bind
        );
        foreach ($rows as &$r) {
            $r['context'] = !empty($r['context_json'])
                ? (json_decode((string) $r['context_json'], true) ?: [])
                : [];
            $r['rendered'] = self::render($r);
        }
        unset($r);
        return $rows;
    }

    /**
     * Render one event row as HTML. Uses the registered renderer if
     * one exists for the verb; otherwise falls back to the summary
     * column, or a generic "{username} {verb}" string.
     */
    public static function render(array $event): string
    {
        $verb = (string) ($event['verb'] ?? '');
        $renderer = self::$renderers[$verb] ?? null;
        if ($renderer !== null) {
            try { return (string) $renderer($event); }
            catch (\Throwable $e) {
                error_log("[activity] renderer for $verb threw: " . $e->getMessage());
            }
        }
        if (!empty($event['summary'])) {
            return htmlspecialchars((string) $event['summary'], ENT_QUOTES | ENT_HTML5, 'UTF-8');
        }
        $user = htmlspecialchars((string) ($event['actor_username'] ?? 'someone'), ENT_QUOTES | ENT_HTML5, 'UTF-8');
        $v    = htmlspecialchars($verb, ENT_QUOTES | ENT_HTML5, 'UTF-8');
        return "<span>@$user</span> <span style=\"color:#9ca3af\">$v</span>";
    }
}
