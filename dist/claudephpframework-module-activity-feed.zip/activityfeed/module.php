<?php
// modules/activity-feed/module.php
use Core\Container\Container;
use Core\Module\ModuleProvider;

/**
 * Activity-feed module — generic event bus + per-actor + per-group
 * timeline reads.
 *
 * Other modules call `activity_emit(...)` to record events; the
 * surfaces at `/activity`, `/activity/user/{username}`,
 * `/activity/group/{slug}`, and `/admin/activity` consume them.
 *
 * Verb renderers are registered per-verb so each emitter controls the
 * human-readable surface shape. Missing renderers fall back to the
 * event's `summary` column, or a generic "@actor verb".
 */
return new class extends ModuleProvider {
    // Namespace must match View::addNamespace's /^[a-zA-Z0-9_]+$/ regex —
    // underscores, not hyphens. Folder is still `activity-feed/` for tidy
    // dist naming; the view namespace is the module's identity here.
    public function name(): string            { return 'activity_feed'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }

    public function register(Container $container): void
    {
        require_once __DIR__ . '/Helpers/helpers.php';
    }
};
