<?php
// modules/activity-feed/Controllers/ActivityController.php
namespace Modules\ActivityFeed\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Modules\ActivityFeed\Services\ActivityService;

/**
 *   GET /activity                    — your home activity feed (logged-in)
 *   GET /activity/user/{username}    — public profile timeline
 *   GET /activity/group/{slug}       — group activity (members only)
 *   GET /admin/activity              — global log (requires admin)
 */
class ActivityController
{
    private Auth            $auth;
    private Database        $db;
    private ActivityService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->db   = Database::getInstance();
        $this->svc  = new ActivityService();
    }

    public function home(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        return Response::view('activity_feed::public.home', [
            'events' => $this->svc->homeFeed((int) $this->auth->id()),
            'me'     => $this->auth->user(),
        ]);
    }

    public function profile(Request $request): Response
    {
        $username = (string) $request->param(0);
        $user = $this->db->fetchOne("SELECT id, username FROM users WHERE username = ?", [$username]);
        if (!$user) return new Response('User not found', 404);

        $viewerId = $this->auth->guest() ? null : (int) $this->auth->id();
        return Response::view('activity_feed::public.profile', [
            'profile' => $user,
            'events'  => $this->svc->profileFeed((int) $user['id'], $viewerId),
        ]);
    }

    public function group(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $slug  = (string) $request->param(0);
        $group = $this->db->fetchOne("SELECT * FROM `groups` WHERE slug = ?", [$slug]);
        if (!$group) return new Response('Group not found', 404);

        // Membership gate; SA-mode crosses the scope via groupAccessCheck.
        if ($this->auth->groupAccessCheck((int) $group['id'], 'activity.group_feed') === 'denied') {
            return Response::redirect("/groups/$slug");
        }

        return Response::view('activity_feed::public.group', [
            'group'  => $group,
            'events' => $this->svc->groupFeed((int) $group['id']),
        ]);
    }

    public function admin(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->auth->can('admin.access') && !$this->auth->can('activity.view')) {
            return new Response('Forbidden', 403);
        }

        $filters = array_filter([
            'verb'          => (string) $request->query('verb'),
            'actor_user_id' => (int) $request->query('actor_user_id', 0),
            'group_id'      => (int) $request->query('group_id', 0),
        ]);
        return Response::view('activity_feed::admin.index', [
            'events'  => $this->svc->globalFeed($filters, 100),
            'filters' => $filters,
        ]);
    }
}
