<?php
// modules/activity-feed/migrations/2026_04_23_150000_create_activity_feed_tables.php
use Core\Database\Migration;

/**
 * Schema for the activity-feed module.
 *
 *   activity_events — append-only event log. Each row is a verb
 *                     (past-tense action like 'post.created',
 *                     'comment.replied', 'order.placed'), a subject
 *                     (the actor user), a polymorphic object, plus
 *                     optional context fields that drive surface
 *                     routing:
 *                       group_id   — when set, the event appears on
 *                                    that group's feed
 *                       visibility — 'public' / 'group' / 'private'
 *                                    controls who sees it outside the
 *                                    actor's own timeline
 *                       context_json — free-form payload the verb's
 *                                    renderer consumes
 *
 * Storage is intentionally simple: no materialized per-user fan-out
 * table. Reads pull (user_id in actor_user_id, OR group_id in user's
 * memberships, OR visibility='public' for the admin log) with
 * LIMIT+OFFSET. Small/medium installs don't need fan-out; large ones
 * add a `feed_entries` materialized projection later without touching
 * the emit side.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE activity_events (
                id             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                actor_user_id  INT UNSIGNED NOT NULL,
                verb           VARCHAR(80)  NOT NULL,
                object_type    VARCHAR(64)  NULL,
                object_id      BIGINT UNSIGNED NULL,
                group_id       INT UNSIGNED NULL,
                visibility     ENUM('public','group','private') NOT NULL DEFAULT 'public',
                summary        VARCHAR(500) NULL,
                context_json   TEXT NULL,
                created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                KEY idx_actor_created   (actor_user_id, created_at),
                KEY idx_group_created   (group_id, created_at),
                KEY idx_verb_created    (verb, created_at),
                KEY idx_public_created  (visibility, created_at)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS activity_events");
    }
};
