<?php
// modules/activity-feed/Views/partials/event_row.php
// Expects: $e (event row with 'rendered' HTML pre-rendered by ActivityService).
?>
<div style="padding:.75rem 1rem;border-bottom:1px solid #f3f4f6;display:flex;align-items:flex-start;gap:.75rem">
    <div style="flex:1;font-size:14px;line-height:1.45"><?= $e['rendered'] ?></div>
    <div style="color:#9ca3af;font-size:11px;white-space:nowrap">
        <?= e(date('M j H:i', strtotime((string) $e['created_at']))) ?>
    </div>
</div>
