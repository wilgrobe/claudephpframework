<?php $pageTitle = 'Activity log (admin)'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Activity log</h1>

<form method="get" style="display:flex;gap:.5rem;margin-bottom:1rem;flex-wrap:wrap">
    <input name="verb" value="<?= e((string) ($filters['verb'] ?? '')) ?>" placeholder="verb (e.g. post.created)" style="padding:.4rem">
    <input name="actor_user_id" value="<?= (int) ($filters['actor_user_id'] ?? 0) ?: '' ?>" placeholder="actor user id" style="padding:.4rem;width:140px">
    <input name="group_id" value="<?= (int) ($filters['group_id'] ?? 0) ?: '' ?>" placeholder="group id" style="padding:.4rem;width:120px">
    <button class="btn btn-secondary">Filter</button>
    <a href="/admin/activity" class="btn btn-secondary">Clear</a>
</form>

<div class="card">
<?php if (empty($events)): ?>
<div class="card-body" style="color:#9ca3af;text-align:center;padding:3rem 1rem">No events match.</div>
<?php else: ?>
<table class="table">
    <thead><tr><th>When</th><th>Actor</th><th>Verb</th><th>Object</th><th>Group</th><th>Visibility</th><th>Rendered</th></tr></thead>
    <tbody>
    <?php foreach ($events as $e): ?>
    <tr>
        <td style="font-size:12px;white-space:nowrap"><?= e(date('M j H:i', strtotime((string) $e['created_at']))) ?></td>
        <td>@<?= e((string) ($e['actor_username'] ?? '?')) ?></td>
        <td><code><?= e((string) $e['verb']) ?></code></td>
        <td style="font-family:monospace;font-size:12px"><?= $e['object_type'] ? e((string) $e['object_type']) . ' #' . (int) $e['object_id'] : '—' ?></td>
        <td><?= $e['group_id'] ? (int) $e['group_id'] : '—' ?></td>
        <td><?= e((string) $e['visibility']) ?></td>
        <td style="font-size:13px"><?= $e['rendered'] ?></td>
    </tr>
    <?php endforeach; ?>
    </tbody>
</table>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
