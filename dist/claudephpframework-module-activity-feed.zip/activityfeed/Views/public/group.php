<?php $pageTitle = $group['name'] . ' — activity'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <h1 style="margin:0;font-size:1.5rem"><?= e($group['name']) ?> activity</h1>
    <a href="/groups/<?= e($group['slug']) ?>" class="btn btn-sm btn-secondary" style="margin-left:auto">Group →</a>
</div>

<div class="card">
<?php if (empty($events)): ?>
<div class="card-body" style="color:#9ca3af;text-align:center;padding:3rem 1rem">No activity recorded in this group yet.</div>
<?php else: ?>
<?php foreach ($events as $e): include __DIR__ . '/../partials/event_row.php'; endforeach; ?>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
