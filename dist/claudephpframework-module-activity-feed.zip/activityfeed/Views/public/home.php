<?php $pageTitle = 'Activity'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Activity</h1>

<div class="card">
<?php if (empty($events)): ?>
<div class="card-body" style="color:#9ca3af;text-align:center;padding:3rem 1rem">
    Your feed is quiet. Activity from your own actions and the groups you're in shows up here.
</div>
<?php else: ?>
<?php foreach ($events as $e): include __DIR__ . '/../partials/event_row.php'; endforeach; ?>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
