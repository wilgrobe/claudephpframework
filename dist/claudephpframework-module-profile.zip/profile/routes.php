<?php
// modules/profile/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;

$router->get ('/profile',       'Modules\Profile\Controllers\ProfileController@show',
    [AuthMiddleware::class]);
$router->get ('/profile/edit',  'Modules\Profile\Controllers\ProfileController@editForm',
    [AuthMiddleware::class]);
$router->post('/profile/edit',  'Modules\Profile\Controllers\ProfileController@update',
    [CsrfMiddleware::class, AuthMiddleware::class]);

// /profile/2fa/* routes stay in routes/web.php — they belong to the core
// TwoFactorController and are framework-level primitives.
