<?php
// modules/profile/Controllers/ProfileController.php
namespace Modules\Profile\Controllers;

use Core\Auth\Auth;
use Core\Auth\TwoFactorService;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Validation\Validator;
use Core\Database\Database;
use Core\Services\FileUploadService;

/**
 * Ported from App\Controllers\ProfileController. Behavior unchanged. Only
 * namespace moved and view names use 'profile::' prefix. The show view
 * still links to /profile/2fa/* which stays in routes/web.php.
 */
class ProfileController
{
    private Auth             $auth;
    private Database         $db;
    private TwoFactorService $twoFactor;

    public function __construct()
    {
        $this->auth      = Auth::getInstance();
        $this->db        = Database::getInstance();
        $this->twoFactor = new TwoFactorService();
    }

    public function show(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $userId = $this->auth->id();
        $user   = $this->db->fetchOne(
            "SELECT id, username, email, first_name, last_name, avatar, bio, phone,
                    is_active, email_verified_at, last_login_at, created_at,
                    two_factor_enabled, two_factor_method, two_factor_confirmed
             FROM users WHERE id = ?",
            [$userId]
        );

        $oauthProviders = $this->db->fetchAll(
            "SELECT provider, created_at FROM user_oauth WHERE user_id = ?",
            [$userId]
        );

        $twofa = $this->twoFactor->getUserTwoFactorInfo($userId);

        return Response::view('profile::show', [
            'user'           => $user,
            'oauthProviders' => $oauthProviders,
            'twofa'          => $twofa,
        ]);
    }

    public function editForm(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        $user = $this->db->fetchOne(
            "SELECT id, username, email, first_name, last_name, avatar, bio, phone
               FROM users WHERE id = ?",
            [$this->auth->id()]
        );
        return Response::view('profile::edit', ['user' => $user]);
    }

    public function update(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $v = new Validator($request->post());
        $v->validate([
            'first_name' => 'required|min:1|max:100',
            'last_name'  => 'required|min:1|max:100',
            'phone'      => 'nullable|max:30',
            'bio'        => 'nullable|max:1000',
        ]);

        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect('/profile/edit');
        }

        $data = [
            'first_name' => $v->get('first_name'),
            'last_name'  => $v->get('last_name'),
            'phone'      => $v->get('phone') ?: null,
            'bio'        => $v->get('bio') ?: null,
        ];

        // Handle avatar upload
        if ($request->hasFile('avatar')) {
            try {
                $uploader = new FileUploadService();
                $existing = $this->db->fetchOne("SELECT avatar FROM users WHERE id = ?", [$this->auth->id()]);

                $relativePath = $uploader->uploadImage(
                    $request->file('avatar'),
                    'avatars',
                    2_097_152 // 2 MB limit for avatars
                );

                $data['avatar'] = $uploader->url($relativePath);

                // Delete the previous avatar. delete() tolerates either a bare
                // relative key or a full URL left over from the old URL-in-DB
                // convention — it resolves both back to a storage key before
                // issuing the delete.
                if (!empty($existing['avatar'])) {
                    $uploader->delete($existing['avatar']);
                }
            } catch (\Throwable $e) {
                error_log('[ProfileController] avatar upload failed: ' . $e::class . ': ' . $e->getMessage());
                Session::flash('errors', ['avatar' => [
                    'Upload failed: ' . $e->getMessage() . ' (' . $e::class . ')'
                ]]);
                return Response::redirect('/profile/edit');
            }
        }

        // Password change
        if ($newPass = $request->post('password')) {
            $v2 = new Validator($request->post());
            $v2->validate([
                'password'         => 'min:12|password_strength',
                'password_confirm' => 'same:password',
            ]);
            if ($v2->fails()) {
                Session::flash('errors', $v2->errors());
                return Response::redirect('/profile/edit');
            }
            $data['password'] = password_hash($newPass, PASSWORD_BCRYPT, ['cost' => 12]);
        }

        $this->db->update('users', $data, 'id = ?', [$this->auth->id()]);
        $this->auth->refreshUser();
        $this->auth->auditLog('profile.update', 'users', $this->auth->id());

        return Response::redirect('/profile')->withFlash('success', 'Profile updated.');
    }
}
