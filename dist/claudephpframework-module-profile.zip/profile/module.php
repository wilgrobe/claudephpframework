<?php
// modules/profile/module.php
use Core\Module\ModuleProvider;

/**
 * Profile module — user's own profile view + edit (name, avatar, bio, phone,
 * password). Does NOT include the 2FA settings routes: /profile/2fa/* routes
 * stay in core via TwoFactorController because 2FA is a framework primitive
 * that authentication flows depend on.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'profile'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
