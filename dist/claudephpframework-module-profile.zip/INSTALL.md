# Installation — Profile module

## Prerequisites

- `claudephpframework-core` installed.
- Core tables `users`, `user_oauth` present (from `install.sql`).
- For avatar uploads: either local-filesystem storage writable, or
  S3/MinIO configured via `FileUploadService` / Flysystem in core's
  `.env` (`STORAGE_DRIVER`, `STORAGE_S3_*` etc.).

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-profile.zip
   cp -r claudephpframework-module-profile/profile /path/to/project/modules/
   ```

2. Run migrations (none ship):
   ```bash
   php artisan migrate
   ```

3. Refresh module cache if enabled:
   ```bash
   php artisan module:cache
   ```

## Environment variables

None specific. Image re-encoding uses `ext-gd` or `ext-imagick` — install
one of these if avatar upload throws "No image driver available".

## Verification

1. Log in, visit `/profile` — your profile info renders.
2. Visit `/profile/edit`, change your bio, save — redirect back to
   `/profile` with the new bio.
3. Upload a test avatar — verify it appears on `/profile` and that the
   stored file has a random hex filename (check
   `storage/uploads/avatars/`).
