# Profile module

The user's own profile view + edit page. Name, avatar, bio, phone, password
change. Intentionally narrow — 2FA settings stay in core because they're a
framework primitive that authentication flows depend on.

## Features

- View own profile (name, avatar, email, phone, bio, OAuth providers
  linked, 2FA status)
- Edit name, email, phone, bio, avatar (image upload with re-encoding)
- Change password (with current-password confirmation)
- Links to core's `/profile/2fa/*` routes for 2FA management

## Routes

| Method | Path             | Middleware     | Purpose         |
|--------|------------------|----------------|-----------------|
| GET    | `/profile`       | Auth           | View own profile |
| GET    | `/profile/edit`  | Auth           | Edit form        |
| POST   | `/profile/edit`  | Csrf + Auth    | Save changes     |

The `/profile/2fa/*` routes are provided by core's `TwoFactorController`
and stay there; this module doesn't duplicate them.

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
