# Architecture — Profile module

## Files

```
profile/
├── module.php
├── routes.php                                 # 3 routes
├── Controllers/ProfileController.php          # show + edit + update
└── Views/
    ├── show.php                               # Profile read
    └── edit.php                               # Edit form
```

## Data model

All stored in the core `users` table — this module doesn't own any of its
own tables. Linked OAuth providers come from `user_oauth` (rendered
read-only as a list of "signed in via Google" rows).

## Authorization

All routes gated by `AuthMiddleware`. Inside the controller:

- Every action uses `$this->auth->id()` for the user id. The URL has no
  `{id}` parameter on any edit route — you can only edit *yourself*,
  structurally. No IDOR possible.

## Password change

Validates the current password via `password_verify` before accepting the
new one. New password runs through `password_hash(PASSWORD_BCRYPT,
['cost' => 12])`. Session is NOT regenerated on password change in this
module — that happens in core's auth flows; after a password change here
the existing session remains valid.

## Avatar upload

Delegated to `FileUploadService`:
- Accepted MIME types verified from file content (not client header)
- Image re-encoded through GD or Imagick → strips EXIF and any polyglot
  payloads
- Stored with a random hex filename under `storage/uploads/avatars/`
- The old avatar's file is deleted when a new one is uploaded

Size limit defaults to 5 MB — change via `FileUploadService` config.

## Why 2FA lives in core

2FA routes (`/profile/2fa/*`) stay in `routes/web.php` + core's
`TwoFactorController` because:

1. 2FA gates login before the user is fully authenticated — it's not
   purely a profile concern.
2. `TwoFactorService` is used by both login and the setup flow; splitting
   it across core + module would duplicate responsibilities.

This module links out to those routes from the edit/show views; the
profile module never touches 2FA state directly.

## Dependencies

- `claudephpframework-core` — Auth, Database, FileUploadService, Validator,
  View
- Core's `users` + `user_oauth` tables
