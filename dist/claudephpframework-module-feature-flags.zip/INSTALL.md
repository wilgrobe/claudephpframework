# Installation — Feature flags

## Steps

1. Unzip into `modules/` (folder: `featureflags/`).
2. `php artisan migrate` (creates 2 tables + seeds permission).
3. Grant `featureflags.manage` to admin roles.

## Walkthrough

1. `/admin/feature-flags/create` → key `new_checkout`, label "New
   checkout", enabled ✓, rollout_percent = 25.
2. In a view:
   ```php
   <?= feature('new_checkout') ? 'NEW' : 'OLD' ?>
   ```
3. ~25% of users see "NEW", rest see "OLD". Same user sees the same
   branch on every visit (deterministic hash).
4. Add user id 42 as override = on. User 42 sees "NEW" even at 0%
   rollout.
5. Set rollout to 100%. All users see "NEW" (except any override =
   off). Ready to delete the flag — just remove the `feature()` call
   and the `/admin/feature-flags/{key}/delete` button.

## Deferred

- **JS client** — a `/api/feature-flags` endpoint returning the
  resolved flag map for the current user, so client-side rendering
  can branch without a server roundtrip.
- **Analytics hooks** — fire an event on every `feature()` call so
  exposure counts show up in an analytics tool.
- **Audit log** — who flipped which flag when. Piggyback the
  `audit_log` table via `Auth::auditLog` on every admin write.
- **Flag scheduling** — "turn this on at noon Friday" via a
  scheduled task that flips `enabled`.
