# Architecture — Feature flags

## Files

```
featureflags/
├── module.php
├── routes.php
├── Controllers/FeatureFlagAdminController.php
├── Services/FeatureFlagService.php
├── Helpers/helpers.php                    # feature($key, $userId?)
├── Views/admin/{index,form,overrides}.php
└── migrations/{create_tables, seed_permission}.php
```

## Data model

```
feature_flags:
  key PK, label, description,
  enabled, rollout_percent (0-100),
  groups_json NULL (e.g. '[12, 34]'),
  timestamps
  CHECK (rollout_percent BETWEEN 0 AND 100)

feature_flag_overrides:
  user_id, flag_key (FK CASCADE), enabled, note, created_at
  PK (user_id, flag_key)
```

## Resolution logic

```php
public function isEnabled(string $key, ?int $userId = null): bool
{
  // 1. per-user override
  if ($userId) {
    $ov = lookup $userId + $key;
    if ($ov) return $ov->enabled;
  }

  $flag = lookup $key;
  if (!$flag) return false;
  // 2. global kill switch
  if (!$flag->enabled) return false;

  // 3. group membership
  $groups = json_decode($flag->groups_json);
  if ($userId && $groups && any_of_these_groups($userId, $groups))
    return true;

  // 4. percentage rollout
  $pct = $flag->rollout_percent;
  if ($pct >= 100) return true;
  if ($pct <= 0)   return false;
  return hashBucket($userId ?? 0, $key) < $pct;
}
```

### Hash bucket

```
hashBucket(int $userId, string $key): int
  = hexdec(substr(sha256("$userId:$key"), 0, 8)) % 100
```

- First 8 hex chars → 32-bit unsigned int → mod 100 → uniform bucket.
- Deterministic: same (user, key) always maps to the same bucket.
- Changing the key (e.g. rolling out a v2 under a new key)
  re-distributes buckets — a feature, not a bug. Users who were in
  at 10% of the old key aren't necessarily in at 10% of the new one.

## Caching

Per-request static array keyed by `"$key:$userId"`. One DB lookup per
unique (flag, user) per request. Cleared on any admin write via
`self::clearCache()`. The cache is per-process and per-request — no
shared cache server integration (yet).

## Why user_id=0 for guests in the hash bucket

Alternatives considered:
- Always exclude guests from partial rollouts — less surprising but
  less useful for anonymous-facing features you actually want to
  canary.
- Hash by IP — unstable (NAT, mobile networks), and the guest
  "session" is already ephemeral. Bucket-shift on every IP change
  defeats the point.

Choosing `0` means all guests share a bucket. It's a pragmatic
compromise: either the feature is on for all guests (percentage
bracket includes bucket-0) or off for all.
