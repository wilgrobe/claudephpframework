# Feature-flags module

Runtime flag evaluation for gradual rollouts. Four targeting modes,
combined deterministically.

## Resolution precedence

First match wins:

1. **Per-user override** — explicit enable/disable in
   `feature_flag_overrides`. QA accounts get it on regardless of
   global state; users reporting bugs get it off without rolling back.
2. **Global kill switch** — `flag.enabled=0` turns it off for everyone
   (except explicit overrides in #1).
3. **Group membership** — user is in any group listed in
   `flag.groups_json` → on. Useful for "internal dogfooding",
   "beta tester group", per-team rollouts.
4. **Percentage rollout** — deterministic SHA-256 hash of
   `user_id:flag_key` mod 100. Stable: a user either always sees
   the flag or always doesn't, for a given percentage + key. Moving
   the bar up adds users; moving down removes the highest-bucket ones.
5. **Otherwise** — off.

Guests (no `user_id`) are bucketed on `user_id=0` for percentage
rollouts, which means they're all in or all out for a given flag.

## Usage

```php
<?php if (feature('new_checkout')): ?>
  <!-- new UI -->
<?php else: ?>
  <!-- old UI -->
<?php endif; ?>
```

Resolves against the current user by default. Pass a user id as the
second arg to check for someone else (admin preview, server-to-server).

## Admin

- `/admin/feature-flags` — list all flags.
- `/admin/feature-flags/create` — new flag.
- `/admin/feature-flags/{key}/edit` — edit existing.
- `/admin/feature-flags/{key}/overrides` — per-user overrides.

Folder: `featureflags/`. View namespace: `feature_flags`. Permission:
`featureflags.manage`.

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
