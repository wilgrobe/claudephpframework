<?php
// modules/knowledgebase/Controllers/KnowledgeBaseController.php
namespace Modules\KnowledgeBase\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\KnowledgeBase\Services\KnowledgeBaseService;

/**
 *   GET /kb                     — index + search
 *   GET /kb/{slug}              — article view (published only)
 */
class KnowledgeBaseController
{
    private Auth                 $auth;
    private KnowledgeBaseService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new KnowledgeBaseService();
    }

    public function index(Request $request): Response
    {
        $q = trim((string) $request->query('q'));
        $results = $q !== '' ? $this->svc->search($q) : [];
        $recent  = $q === '' ? $this->svc->listPublished(20) : [];

        return Response::view('knowledge_base::public.index', [
            'q'       => $q,
            'results' => $results,
            'recent'  => $recent,
        ]);
    }

    public function show(Request $request): Response
    {
        $slug = (string) $request->param(0);
        $article = $this->svc->findPublishedBySlug($slug);
        if (!$article) return new Response('Article not found', 404);
        return Response::view('knowledge_base::public.show', ['article' => $article]);
    }
}
