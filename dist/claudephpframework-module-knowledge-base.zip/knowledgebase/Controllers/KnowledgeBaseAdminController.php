<?php
// modules/knowledgebase/Controllers/KnowledgeBaseAdminController.php
namespace Modules\KnowledgeBase\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Modules\KnowledgeBase\Services\KnowledgeBaseService;

/**
 *   GET  /admin/kb                             — article list (all statuses)
 *   GET  /admin/kb/create                      — new article form
 *   POST /admin/kb/create                      — save new
 *   GET  /admin/kb/{id}/edit                   — editor + revisions sidebar
 *   POST /admin/kb/{id}/edit                   — save revision
 *   POST /admin/kb/{id}/publish/{revId}        — publish a specific revision
 *   POST /admin/kb/{id}/archive                — archive
 *   POST /admin/kb/{id}/unarchive              — back to draft
 *   POST /admin/kb/{id}/delete                 — delete + cascade revisions
 *   POST /admin/kb/{id}/restore/{revId}        — create new revision from old
 *   GET  /admin/kb/{id}/revisions/{revId}      — view a specific revision
 */
class KnowledgeBaseAdminController
{
    private Auth                 $auth;
    private KnowledgeBaseService $svc;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->svc  = new KnowledgeBaseService();
    }

    private function gate(): ?Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        if (!$this->auth->can('knowledgebase.manage') && !$this->auth->can('admin.access')) {
            return new Response('Forbidden', 403);
        }
        return null;
    }

    public function index(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $status = (string) $request->query('status') ?: null;
        $page   = max(1, (int) $request->query('page', 1));
        $res = $this->svc->listAll($status, $page, 50);
        return Response::view('knowledge_base::admin.index', $res);
    }

    public function createForm(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        return Response::view('knowledge_base::admin.form', ['article' => null]);
    }

    public function store(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        try {
            $id = $this->svc->create(
                (string) $request->post('title'),
                (string) $request->post('slug'),
                (string) $request->post('body'),
                (string) $request->post('summary') ?: null,
                (int) $this->auth->id(),
                null,
                'initial'
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect('/admin/kb/create')->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/admin/kb/$id/edit");
    }

    public function edit(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id = (int) $request->param(0);
        $article = $this->svc->findWithCurrentRevision($id);
        if (!$article) return new Response('Not found', 404);
        return Response::view('knowledge_base::admin.form', [
            'article'   => $article,
            'revisions' => $this->svc->revisionsFor($id),
        ]);
    }

    public function update(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id = (int) $request->param(0);
        try {
            $this->svc->saveRevision(
                $id,
                (string) $request->post('title'),
                (string) $request->post('summary') ?: null,
                (string) $request->post('body'),
                (int) $this->auth->id(),
                (string) $request->post('note') ?: null
            );
        } catch (\InvalidArgumentException $e) {
            return Response::redirect("/admin/kb/$id/edit")->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/admin/kb/$id/edit")->withFlash('success', 'Saved.');
    }

    public function publish(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id    = (int) $request->param(0);
        $revId = (int) $request->param(1);
        $rev   = $this->svc->findRevision($revId);
        if (!$rev || (int) $rev['article_id'] !== $id) return new Response('Revision not found', 404);
        $this->svc->publish($id, $revId);
        return Response::redirect("/admin/kb/$id/edit")->withFlash('success', 'Published.');
    }

    public function archive(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $this->svc->archive((int) $request->param(0));
        return Response::redirect('/admin/kb');
    }

    public function unarchive(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $this->svc->unarchive((int) $request->param(0));
        return Response::redirect('/admin/kb');
    }

    public function delete(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $this->svc->delete((int) $request->param(0));
        return Response::redirect('/admin/kb');
    }

    public function restoreRevision(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id    = (int) $request->param(0);
        $revId = (int) $request->param(1);
        try {
            $this->svc->restoreRevision($id, $revId, (int) $this->auth->id());
        } catch (\InvalidArgumentException $e) {
            return Response::redirect("/admin/kb/$id/edit")->withFlash('error', $e->getMessage());
        }
        return Response::redirect("/admin/kb/$id/edit")->withFlash('success', 'Restored as new revision.');
    }

    public function showRevision(Request $request): Response
    {
        if ($g = $this->gate()) return $g;
        $id    = (int) $request->param(0);
        $revId = (int) $request->param(1);
        $rev = $this->svc->findRevision($revId);
        if (!$rev || (int) $rev['article_id'] !== $id) return new Response('Not found', 404);
        return Response::view('knowledge_base::admin.revision', [
            'article'  => $this->svc->find($id),
            'revision' => $rev,
        ]);
    }
}
