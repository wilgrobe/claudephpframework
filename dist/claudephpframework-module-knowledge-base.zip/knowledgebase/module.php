<?php
// modules/knowledgebase/module.php
use Core\Module\ModuleProvider;

/**
 * Knowledge-base module.
 *
 * Folder is `knowledgebase/` (flat lowercase to match the framework's
 * module autoloader, which maps Modules\KnowledgeBase\… to
 * modules/knowledgebase/…). View namespace is `knowledge_base`
 * (underscored to pass View::addNamespace's [a-zA-Z0-9_]+ regex and
 * read naturally in Response::view calls).
 *
 * Immutable-revision model: every save creates a kb_article_revisions
 * row, kb_articles.current_revision_id points at the published one,
 * "restore" copies old content into a new revision rather than
 * rewriting pointers.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'knowledge_base'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
