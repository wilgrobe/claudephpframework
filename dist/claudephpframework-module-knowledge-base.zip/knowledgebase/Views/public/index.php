<?php $pageTitle = 'Knowledge base'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<h1 style="margin:0 0 1rem 0">Knowledge base</h1>

<form method="get" action="/kb" style="margin-bottom:1rem">
    <input type="search" name="q" value="<?= e($q) ?>" placeholder="Search articles…"
           style="width:100%;max-width:480px;padding:.5rem;border:1px solid #d1d5db;border-radius:4px">
    <button class="btn btn-secondary">Search</button>
</form>

<?php if ($q !== ''): ?>
<h2 style="font-size:1.1rem">Results for "<?= e($q) ?>"</h2>
<?php if (empty($results)): ?>
<div class="card"><div class="card-body" style="color:#9ca3af;padding:2rem 1rem;text-align:center">No results.</div></div>
<?php else: ?>
<?php foreach ($results as $r): ?>
<div class="card" style="margin-bottom:.5rem">
    <div class="card-body">
        <a href="/kb/<?= e((string) $r['slug']) ?>" style="color:inherit;text-decoration:none">
            <strong><?= e((string) ($r['rev_title'] ?? $r['title'])) ?></strong>
        </a>
        <?php if (!empty($r['rev_summary']) || !empty($r['summary'])): ?>
        <div style="color:#6b7280;font-size:13px;margin-top:.25rem"><?= e((string) ($r['rev_summary'] ?? $r['summary'])) ?></div>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>
<?php else: ?>
<h2 style="font-size:1.1rem">Recent articles</h2>
<?php if (empty($recent)): ?>
<div class="card"><div class="card-body" style="color:#9ca3af;padding:2rem 1rem;text-align:center">No articles yet.</div></div>
<?php else: ?>
<?php foreach ($recent as $a): ?>
<div class="card" style="margin-bottom:.5rem">
    <div class="card-body">
        <a href="/kb/<?= e((string) $a['slug']) ?>" style="color:inherit;text-decoration:none">
            <strong><?= e((string) $a['title']) ?></strong>
        </a>
        <?php if (!empty($a['summary'])): ?>
        <div style="color:#6b7280;font-size:13px;margin-top:.25rem"><?= e((string) $a['summary']) ?></div>
        <?php endif; ?>
    </div>
</div>
<?php endforeach; ?>
<?php endif; ?>
<?php endif; ?>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
