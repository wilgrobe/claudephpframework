<?php $pageTitle = $article['title']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<?php $rev = $article['revision'] ?? null; ?>
<div style="max-width:820px;margin:0 auto">
<a href="/kb" style="color:#6b7280;font-size:13px;text-decoration:none">← Knowledge base</a>

<article style="margin-top:.5rem">
    <h1 style="margin:0 0 .25rem 0"><?= e((string) ($rev['title'] ?? $article['title'])) ?></h1>
    <?php if (!empty($article['published_at'])): ?>
    <div style="color:#9ca3af;font-size:12px;margin-bottom:1rem">
        Published <?= e(date('M j, Y', strtotime((string) $article['published_at']))) ?>
    </div>
    <?php endif; ?>

    <?php if (!empty($rev['summary'])): ?>
    <p style="color:#4b5563;font-size:15px;border-left:3px solid #e5e7eb;padding-left:.75rem">
        <?= e((string) $rev['summary']) ?>
    </p>
    <?php endif; ?>

    <div style="line-height:1.65;color:#111827"><?= nl2br(e((string) ($rev['body'] ?? ''))) ?></div>
</article>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
