<?php
$isNew = empty($article);
$rev   = $article['revision'] ?? null;
$pageTitle = $isNew ? 'New article' : 'Edit ' . $article['title'];
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<a href="/admin/kb" style="color:#6b7280;font-size:13px;text-decoration:none">← All articles</a>

<div style="display:grid;gap:1rem;grid-template-columns:2fr 1fr;margin-top:.5rem">
<div>
    <div class="card">
        <div class="card-header">
            <h2 style="margin:0"><?= $isNew ? 'New article' : e((string) $article['title']) ?>
                <?php if (!$isNew): ?><span class="badge" style="margin-left:.5rem"><?= e((string) $article['status']) ?></span><?php endif; ?>
            </h2>
        </div>
        <form method="post" action="<?= $isNew ? '/admin/kb/create' : '/admin/kb/' . (int) $article['id'] . '/edit' ?>">
            <?= csrf_field() ?>
            <div class="card-body">
                <label>Title
                    <input name="title" required value="<?= e((string) ($rev['title'] ?? $article['title'] ?? '')) ?>" style="width:100%">
                </label>
                <?php if ($isNew): ?>
                <label style="display:block;margin-top:.5rem">Slug
                    <input name="slug" required style="width:100%" placeholder="how-to-do-x">
                </label>
                <?php endif; ?>
                <label style="display:block;margin-top:.5rem">Summary (short blurb for the listing)
                    <textarea name="summary" rows="2" style="width:100%"><?= e((string) ($rev['summary'] ?? $article['summary'] ?? '')) ?></textarea>
                </label>
                <label style="display:block;margin-top:.5rem">Body
                    <textarea name="body" rows="14" style="width:100%;font-family:monospace"><?= e((string) ($rev['body'] ?? '')) ?></textarea>
                </label>
                <?php if (!$isNew): ?>
                <label style="display:block;margin-top:.5rem">Revision note
                    <input name="note" style="width:100%" placeholder="fixed typo in intro">
                </label>
                <?php endif; ?>
            </div>
            <div class="card-footer" style="padding:.75rem 1.25rem;background:#f9fafb;text-align:right">
                <button type="submit" class="btn btn-primary"><?= $isNew ? 'Create' : 'Save revision' ?></button>
            </div>
        </form>
    </div>

    <?php if (!$isNew): ?>
    <div style="display:flex;gap:.5rem;margin-top:1rem">
        <form method="post" action="/admin/kb/<?= (int) $article['id'] ?>/delete" onsubmit="return confirm('Delete article + all revisions?')">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-danger">Delete article</button>
        </form>
    </div>
    <?php endif; ?>
</div>

<?php if (!$isNew): ?>
<aside>
    <div class="card">
        <div class="card-header"><strong>Revisions</strong></div>
        <div class="card-body" style="padding:0">
            <?php foreach ($revisions as $r): $isCurrent = (int) ($article['current_revision_id'] ?? 0) === (int) $r['id']; ?>
            <div style="padding:.5rem .75rem;border-bottom:1px solid #f3f4f6;<?= $isCurrent ? 'background:#ecfdf5' : '' ?>">
                <div style="display:flex;justify-content:space-between;align-items:baseline">
                    <strong>#<?= (int) $r['id'] ?></strong>
                    <span style="color:#9ca3af;font-size:11px"><?= e(date('M j H:i', strtotime((string) $r['created_at']))) ?></span>
                </div>
                <div style="font-size:12px;color:#6b7280">
                    @<?= e((string) ($r['author_username'] ?? '?')) ?><?php if (!empty($r['note'])): ?> · <?= e((string) $r['note']) ?><?php endif; ?>
                </div>
                <div style="display:flex;gap:.25rem;margin-top:.25rem;flex-wrap:wrap">
                    <a href="/admin/kb/<?= (int) $article['id'] ?>/revisions/<?= (int) $r['id'] ?>" class="btn btn-sm btn-secondary">View</a>
                    <?php if (!$isCurrent): ?>
                    <form method="post" action="/admin/kb/<?= (int) $article['id'] ?>/publish/<?= (int) $r['id'] ?>" style="display:inline">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-success">Publish this</button>
                    </form>
                    <form method="post" action="/admin/kb/<?= (int) $article['id'] ?>/restore/<?= (int) $r['id'] ?>" style="display:inline">
                        <?= csrf_field() ?>
                        <button type="submit" class="btn btn-sm btn-secondary" title="Copy this revision's body into a new revision">Restore</button>
                    </form>
                    <?php else: ?>
                    <span class="badge badge-success">live</span>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</aside>
<?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
