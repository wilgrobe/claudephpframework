<?php $pageTitle = 'Knowledge base — admin'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:center">
        <h2 style="margin:0">Knowledge base <span style="color:#9ca3af;font-size:13px">(<?= (int) $total ?>)</span></h2>
        <a href="/admin/kb/create" class="btn btn-sm btn-primary">New article</a>
    </div>
    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem">
        <a href="/admin/kb" class="btn btn-sm <?= empty($status) ? 'btn-primary' : 'btn-secondary' ?>">All</a>
        <?php foreach (['draft','published','archived'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= ($status ?? '') === $s ? 'btn-primary' : 'btn-secondary' ?>"><?= ucfirst($s) ?></a>
        <?php endforeach; ?>
    </div>
    <?php if (empty($items)): ?>
    <div class="card-body" style="text-align:center;color:#6b7280;padding:3rem 1rem">No articles in this status.</div>
    <?php else: ?>
    <table class="table">
        <thead><tr><th>Title</th><th>Slug</th><th>Status</th><th>Updated</th><th></th></tr></thead>
        <tbody>
        <?php foreach ($items as $a): ?>
        <tr>
            <td><strong><?= e((string) $a['title']) ?></strong></td>
            <td><code style="font-size:12px"><?= e((string) $a['slug']) ?></code></td>
            <td><span class="badge"><?= e((string) $a['status']) ?></span></td>
            <td style="font-size:12px"><?= e(date('M j H:i', strtotime((string) $a['updated_at']))) ?></td>
            <td>
                <a href="/admin/kb/<?= (int) $a['id'] ?>/edit" class="btn btn-sm btn-secondary">Edit</a>
                <?php if ($a['status'] === 'archived'): ?>
                <form method="post" action="/admin/kb/<?= (int) $a['id'] ?>/unarchive" style="display:inline">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-secondary">Unarchive</button>
                </form>
                <?php else: ?>
                <form method="post" action="/admin/kb/<?= (int) $a['id'] ?>/archive" style="display:inline">
                    <?= csrf_field() ?>
                    <button type="submit" class="btn btn-sm btn-secondary">Archive</button>
                </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
