<?php $pageTitle = 'Revision #' . (int) $revision['id']; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<a href="/admin/kb/<?= (int) $article['id'] ?>/edit" style="color:#6b7280;font-size:13px;text-decoration:none">← Back to editor</a>

<div class="card" style="margin-top:.5rem">
    <div class="card-header">
        <h2 style="margin:0">Revision #<?= (int) $revision['id'] ?></h2>
        <div style="color:#9ca3af;font-size:12px;margin-top:.25rem">
            @<?= e((string) ($revision['author_username'] ?? '?')) ?> ·
            <?= e(date('M j, Y H:i', strtotime((string) $revision['created_at']))) ?>
            <?php if (!empty($revision['note'])): ?> · <?= e((string) $revision['note']) ?><?php endif; ?>
        </div>
    </div>
    <div class="card-body">
        <h3 style="margin-top:0"><?= e((string) $revision['title']) ?></h3>
        <?php if (!empty($revision['summary'])): ?>
        <p style="color:#4b5563"><?= e((string) $revision['summary']) ?></p>
        <?php endif; ?>
        <pre style="white-space:pre-wrap;background:#f9fafb;padding:.75rem;border-radius:4px;font-family:inherit"><?= e((string) $revision['body']) ?></pre>
    </div>
    <div class="card-footer" style="padding:.75rem;background:#f9fafb;display:flex;gap:.5rem">
        <?php if ((int) $article['current_revision_id'] !== (int) $revision['id']): ?>
        <form method="post" action="/admin/kb/<?= (int) $article['id'] ?>/publish/<?= (int) $revision['id'] ?>">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-success">Publish this revision</button>
        </form>
        <form method="post" action="/admin/kb/<?= (int) $article['id'] ?>/restore/<?= (int) $revision['id'] ?>">
            <?= csrf_field() ?>
            <button type="submit" class="btn btn-secondary">Restore (create new revision)</button>
        </form>
        <?php else: ?>
        <span class="badge badge-success">Currently published</span>
        <?php endif; ?>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
