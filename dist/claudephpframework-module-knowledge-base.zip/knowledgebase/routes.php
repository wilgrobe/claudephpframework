<?php
// modules/knowledgebase/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$K = 'Modules\KnowledgeBase\Controllers\KnowledgeBaseController';
$A = 'Modules\KnowledgeBase\Controllers\KnowledgeBaseAdminController';

// Public
$router->get('/kb',                   "$K@index");
$router->get('/kb/{slug}',            "$K@show");

// Admin
$admin     = [AuthMiddleware::class, RequireAdmin::class];
$adminCsrf = [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class];
$router->get ('/admin/kb',                                "$A@index",           $admin);
$router->get ('/admin/kb/create',                         "$A@createForm",      $admin);
$router->post('/admin/kb/create',                         "$A@store",           $adminCsrf);
$router->get ('/admin/kb/{id}/edit',                      "$A@edit",            $admin);
$router->post('/admin/kb/{id}/edit',                      "$A@update",          $adminCsrf);
$router->post('/admin/kb/{id}/publish/{revId}',           "$A@publish",         $adminCsrf);
$router->post('/admin/kb/{id}/archive',                   "$A@archive",         $adminCsrf);
$router->post('/admin/kb/{id}/unarchive',                 "$A@unarchive",       $adminCsrf);
$router->post('/admin/kb/{id}/delete',                    "$A@delete",          $adminCsrf);
$router->post('/admin/kb/{id}/restore/{revId}',           "$A@restoreRevision", $adminCsrf);
$router->get ('/admin/kb/{id}/revisions/{revId}',         "$A@showRevision",    $admin);
