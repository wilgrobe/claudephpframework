<?php
// modules/knowledgebase/Services/KnowledgeBaseService.php
namespace Modules\KnowledgeBase\Services;

use Core\Database\Database;

/**
 * Knowledge-base article CRUD + revision management + search.
 *
 * Revision model (immutable history):
 *   - Every save that changes content inserts a new kb_article_revisions row.
 *   - kb_articles.current_revision_id points at the currently-published
 *     revision; readers pull body/title through that pointer. Drafts
 *     in-progress write to revisions with article.status='draft' until the
 *     author publishes.
 *   - "Restore revision #N" creates a NEW revision whose body is copied
 *     from #N, not a pointer move — preserves linearity and makes the
 *     history read like a timeline.
 *
 * Search: simple LIKE across current-revision title + summary + body.
 * Good enough for a few thousand articles. Swap for SearchService/FTS
 * when the corpus grows.
 */
class KnowledgeBaseService
{
    public const STATUSES = ['draft','published','archived'];

    private Database $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    // ── Reads ─────────────────────────────────────────────────────────────

    public function find(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM kb_articles WHERE id = ?", [$id]);
    }

    public function findBySlug(string $slug): ?array
    {
        return $this->db->fetchOne("SELECT * FROM kb_articles WHERE slug = ?", [$slug]);
    }

    /**
     * Read the article + its current (or most-recent) revision body for
     * display. For published articles we read through current_revision_id;
     * for drafts with no published revision we read the latest revision.
     */
    public function findWithCurrentRevision(int $articleId): ?array
    {
        $a = $this->find($articleId);
        if (!$a) return null;
        $rev = null;
        if (!empty($a['current_revision_id'])) {
            $rev = $this->findRevision((int) $a['current_revision_id']);
        }
        if (!$rev) {
            $rev = $this->db->fetchOne(
                "SELECT * FROM kb_article_revisions
                  WHERE article_id = ?
               ORDER BY id DESC LIMIT 1",
                [$articleId]
            );
        }
        $a['revision'] = $rev;
        return $a;
    }

    public function findPublishedBySlug(string $slug): ?array
    {
        $a = $this->findBySlug($slug);
        if (!$a || $a['status'] !== 'published' || empty($a['current_revision_id'])) return null;
        return $this->findWithCurrentRevision((int) $a['id']);
    }

    /** @return array<int, array<string, mixed>> */
    public function listPublished(int $limit = 50, int $offset = 0): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM kb_articles
              WHERE status = 'published'
           ORDER BY published_at DESC, id DESC
              LIMIT ? OFFSET ?",
            [$limit, $offset]
        );
    }

    /** Admin listing — all statuses. */
    public function listAll(?string $status = null, int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        if ($status && in_array($status, self::STATUSES, true)) {
            $where = 'WHERE status = ?'; $bind = [$status];
        } else {
            $where = ''; $bind = [];
        }
        $items = $this->db->fetchAll(
            "SELECT * FROM kb_articles $where ORDER BY updated_at DESC LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM kb_articles $where", $bind
        );
        return ['items' => $items, 'total' => $total, 'status' => $status];
    }

    /**
     * @return array<int, array<string, mixed>>  revisions newest first
     */
    public function revisionsFor(int $articleId): array
    {
        return $this->db->fetchAll(
            "SELECT r.*, u.username AS author_username
               FROM kb_article_revisions r
          LEFT JOIN users u ON u.id = r.author_user_id
              WHERE r.article_id = ?
           ORDER BY r.id DESC",
            [$articleId]
        );
    }

    public function findRevision(int $revisionId): ?array
    {
        return $this->db->fetchOne(
            "SELECT r.*, u.username AS author_username
               FROM kb_article_revisions r
          LEFT JOIN users u ON u.id = r.author_user_id
              WHERE r.id = ?",
            [$revisionId]
        );
    }

    // ── Search ───────────────────────────────────────────────────────────

    /**
     * Naive LIKE search across current-revision content. Ranks by title
     * match first, then summary, then body — cheap SQL heuristic.
     *
     * @return array<int, array<string, mixed>>
     */
    public function search(string $query, int $limit = 30): array
    {
        $query = trim($query);
        if ($query === '') return [];
        $like = '%' . str_replace(['%','_'], ['\%','\_'], $query) . '%';

        return $this->db->fetchAll(
            "SELECT a.*,
                    r.title AS rev_title, r.summary AS rev_summary,
                    CASE
                      WHEN r.title   LIKE ? THEN 3
                      WHEN r.summary LIKE ? THEN 2
                      WHEN r.body    LIKE ? THEN 1
                      ELSE 0
                    END AS match_rank
               FROM kb_articles a
               JOIN kb_article_revisions r ON r.id = a.current_revision_id
              WHERE a.status = 'published'
                AND (r.title LIKE ? OR r.summary LIKE ? OR r.body LIKE ?)
           ORDER BY match_rank DESC, a.published_at DESC
              LIMIT ?",
            [$like, $like, $like, $like, $like, $like, $limit]
        );
    }

    // ── Writes ───────────────────────────────────────────────────────────

    /**
     * Create a new article with its initial revision. Returns the
     * article id. Status starts as 'draft'; call publish() to promote.
     */
    public function create(
        string $title, string $slug, string $body, ?string $summary,
        int $authorUserId, ?int $ownerGroupId = null, ?string $note = 'initial'
    ): int {
        $title = trim($title);
        $slug  = self::slugify($slug ?: $title);
        if ($title === '' || $slug === '') {
            throw new \InvalidArgumentException('Title and slug required.');
        }

        $articleId = (int) $this->db->insert('kb_articles', [
            'slug'            => $slug,
            'title'           => substr($title, 0, 191),
            'summary'         => $summary !== null ? substr($summary, 0, 500) : null,
            'owner_user_id'   => $authorUserId,
            'owner_group_id'  => $ownerGroupId,
            'status'          => 'draft',
        ]);

        $this->createRevision($articleId, $title, $summary, $body, $authorUserId, $note);
        return $articleId;
    }

    /**
     * Save a new revision. Article's title/summary are mirrored from the
     * revision on this path (they're display-level fields on the article
     * row; the revision is the source of truth).
     */
    public function saveRevision(
        int $articleId, string $title, ?string $summary, string $body,
        int $authorUserId, ?string $note = null
    ): int {
        $title = trim($title);
        if ($title === '') throw new \InvalidArgumentException('Title required.');
        $a = $this->find($articleId);
        if (!$a) throw new \InvalidArgumentException('Article not found.');

        $revId = $this->createRevision($articleId, $title, $summary, $body, $authorUserId, $note);

        // Mirror title/summary to the article row so lists don't need a
        // revisions join for basic display.
        $this->db->update('kb_articles', [
            'title'   => substr($title, 0, 191),
            'summary' => $summary !== null ? substr($summary, 0, 500) : null,
        ], 'id = ?', [$articleId]);

        return $revId;
    }

    /** Mark article published, pointing at the given revision. */
    public function publish(int $articleId, int $revisionId): void
    {
        $this->db->update('kb_articles', [
            'status'              => 'published',
            'current_revision_id' => $revisionId,
            'published_at'        => date('Y-m-d H:i:s'),
        ], 'id = ?', [$articleId]);
    }

    public function archive(int $articleId): void
    {
        $this->db->update('kb_articles', ['status' => 'archived'], 'id = ?', [$articleId]);
    }

    public function unarchive(int $articleId): void
    {
        $this->db->update('kb_articles', ['status' => 'draft'], 'id = ?', [$articleId]);
    }

    public function delete(int $articleId): void
    {
        // CASCADE wipes revisions.
        $this->db->delete('kb_articles', 'id = ?', [$articleId]);
    }

    /**
     * Restore a prior revision by creating a NEW revision whose body is a
     * copy of #$revisionId. Preserves history linearity (no pointer
     * rewrites) and makes "who restored what when" visible in the
     * revisions list.
     */
    public function restoreRevision(int $articleId, int $revisionId, int $authorUserId): int
    {
        $src = $this->findRevision($revisionId);
        if (!$src || (int) $src['article_id'] !== $articleId) {
            throw new \InvalidArgumentException('Revision not part of this article.');
        }
        return $this->saveRevision(
            $articleId,
            (string) $src['title'],
            $src['summary'] !== null ? (string) $src['summary'] : null,
            (string) $src['body'],
            $authorUserId,
            'restored from revision #' . (int) $revisionId
        );
    }

    // ── Internals ────────────────────────────────────────────────────────

    private function createRevision(
        int $articleId, string $title, ?string $summary, string $body,
        int $authorUserId, ?string $note
    ): int {
        return (int) $this->db->insert('kb_article_revisions', [
            'article_id'     => $articleId,
            'title'          => substr($title, 0, 191),
            'summary'        => $summary !== null ? substr($summary, 0, 500) : null,
            'body'           => $body,
            'author_user_id' => $authorUserId,
            'note'           => $note !== null ? substr($note, 0, 255) : null,
        ]);
    }

    public static function slugify(string $s): string
    {
        $s = strtolower(trim($s));
        $s = preg_replace('~[^a-z0-9]+~', '-', $s) ?? '';
        return trim($s, '-');
    }
}
