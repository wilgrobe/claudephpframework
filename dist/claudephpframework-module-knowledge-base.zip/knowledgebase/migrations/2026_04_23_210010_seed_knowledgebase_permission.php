<?php
// modules/knowledgebase/migrations/2026_04_23_210010_seed_knowledgebase_permission.php
use Core\Database\Migration;

return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage knowledge base',
            'knowledgebase.manage',
            'knowledgebase',
            'Create, edit, publish, and archive knowledge-base articles.',
        ]);
    }

    public function down(): void {}
};
