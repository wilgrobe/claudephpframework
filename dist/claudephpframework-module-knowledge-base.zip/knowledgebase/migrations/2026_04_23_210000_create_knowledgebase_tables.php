<?php
// modules/knowledgebase/migrations/2026_04_23_210000_create_knowledgebase_tables.php
use Core\Database\Migration;

/**
 * Schema for the knowledge-base module.
 *
 *   kb_articles          — the canonical article row. `current_revision_id`
 *                          points at the latest *published* revision;
 *                          readers always render through this pointer so
 *                          they never see a draft. `status` is
 *                          draft|published|archived — archived stays
 *                          queryable for admins but not public.
 *
 *   kb_article_revisions — immutable version history. One row per save.
 *                          `author_user_id` + `note` capture who and why.
 *                          When admins "restore" an old revision, a NEW
 *                          revision is created with the old body + a note
 *                          like "restored from #42" — the original
 *                          revision row is never altered.
 *
 *   Taxonomy integration  — use `attach_term('kb_article', $id, 'kb-categories', $slug)`
 *                          from the taxonomy module. No schema dependency
 *                          here; taxonomy_entity_terms handles it.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE kb_articles (
                id                   INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                slug                 VARCHAR(191) NOT NULL,
                title                VARCHAR(191) NOT NULL,
                summary              VARCHAR(500) NULL,
                current_revision_id  INT UNSIGNED NULL,
                status               ENUM('draft','published','archived') NOT NULL DEFAULT 'draft',
                owner_user_id        INT UNSIGNED NULL,
                owner_group_id       INT UNSIGNED NULL,
                published_at         DATETIME NULL,
                created_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at           DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_slug (slug),
                KEY idx_status (status, published_at),
                KEY idx_owner_user  (owner_user_id,  status),
                KEY idx_owner_group (owner_group_id, status)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE kb_article_revisions (
                id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                article_id       INT UNSIGNED NOT NULL,
                title            VARCHAR(191) NOT NULL,
                summary          VARCHAR(500) NULL,
                body             MEDIUMTEXT NOT NULL,
                author_user_id   INT UNSIGNED NULL,
                note             VARCHAR(255) NULL,
                created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

                KEY idx_article_created (article_id, created_at),
                CONSTRAINT fk_kbrev_article
                    FOREIGN KEY (article_id) REFERENCES kb_articles (id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS kb_article_revisions");
        $this->db->query("DROP TABLE IF EXISTS kb_articles");
    }
};
