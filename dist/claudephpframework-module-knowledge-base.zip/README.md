# Knowledge-base module

Article system with full immutable version history, draft/published/
archived lifecycle, and a LIKE-based search.

## Features

- **Immutable revisions** — every save creates a `kb_article_revisions`
  row. Never rewritten, only appended. Publishing points
  `articles.current_revision_id` at the chosen revision.
- **Restore old version** — copies the old revision's body into a new
  revision with note "restored from #N". Linear history preserved.
- **Status** — draft (never shown publicly), published, archived.
- **Naive search** — LIKE across current-revision title/summary/body,
  ranked by match position. Swap for SearchService when scale requires.
- **Admin editor** with revisions sidebar — view / publish / restore
  any past revision without leaving the editor.

## Routes

| Method | Path                                  | Purpose |
|--------|---------------------------------------|---------|
| GET    | `/kb`                                 | Index + search |
| GET    | `/kb/{slug}`                          | Read published article |
| GET    | `/admin/kb`                           | Admin list (all statuses) |
| GET/POST | `/admin/kb/create`                  | New article |
| GET/POST | `/admin/kb/{id}/edit`               | Edit + save revision |
| POST   | `/admin/kb/{id}/publish/{revId}`      | Publish a revision |
| POST   | `/admin/kb/{id}/archive`              | Archive |
| POST   | `/admin/kb/{id}/unarchive`            | Back to draft |
| POST   | `/admin/kb/{id}/delete`               | Hard delete |
| POST   | `/admin/kb/{id}/restore/{revId}`      | Restore old revision as new |
| GET    | `/admin/kb/{id}/revisions/{revId}`    | View specific revision |

Folder: `knowledgebase/`. View namespace: `knowledge_base`. Both
identifiers chosen to match the framework's conventions (flat
lowercase folder for the autoloader, underscored view namespace for
`View::addNamespace`'s `[a-zA-Z0-9_]+` regex).

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
