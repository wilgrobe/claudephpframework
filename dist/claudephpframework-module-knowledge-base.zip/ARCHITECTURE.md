# Architecture — Knowledge-base

## Files

```
knowledgebase/
├── module.php
├── routes.php                      # 11 routes
├── Controllers/
│   ├── KnowledgeBaseController.php          # Public
│   └── KnowledgeBaseAdminController.php     # Admin
├── Services/KnowledgeBaseService.php
├── Views/{public,admin}/…
└── migrations/{create_tables, seed_permission}.php
```

## Data model

```
kb_articles:
  id, slug (unique), title, summary,
  current_revision_id NULL, status ENUM,
  owner_user_id, owner_group_id, published_at, timestamps

kb_article_revisions:
  id, article_id CASCADE, title, summary, body,
  author_user_id, note, created_at
```

## Restore semantics

`restoreRevision($articleId, $revisionId)` doesn't rewrite pointers.
It calls `saveRevision` with the old revision's body + a synthetic
note. The result:

- History stays a strict append-only list ordered by id.
- The currently-published row is unchanged until an explicit publish.
- Admin can easily see "restored from #X" as the most recent activity.

This is the opposite of what some wiki engines do ("rollback" mutates
the pointer). The append-only flavour is more audit-friendly.

## Search

`search($q)` does a LIKE on current-revision fields ranked by match
position:

```sql
SELECT a.*, r.title AS rev_title, r.summary AS rev_summary,
       CASE
         WHEN r.title   LIKE ? THEN 3
         WHEN r.summary LIKE ? THEN 2
         WHEN r.body    LIKE ? THEN 1
       END AS match_rank
FROM kb_articles a JOIN kb_article_revisions r ON r.id = a.current_revision_id
WHERE a.status = 'published' AND (r.title LIKE ? OR r.summary LIKE ? OR r.body LIKE ?)
ORDER BY match_rank DESC, a.published_at DESC
```

The LIKE query escapes `%` and `_` in the user input. A single `%q%`
wraps the term; no fuzzy matching, no stopword handling. Fine for a
few thousand articles; scale via FULLTEXT or external index when
needed.
