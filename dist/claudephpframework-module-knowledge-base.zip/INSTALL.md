# Installation — Knowledge-base

## Steps

1. Unzip into `modules/` (folder inside: `knowledgebase/`).
2. `php artisan migrate` (creates 2 tables + seeds permission).
3. Grant `knowledgebase.manage` to a role at `/admin/roles`.

## First-use walkthrough

1. `/admin/kb/create` → new article titled "Getting started".
2. Edit saves a revision. Sidebar lists all revisions with the
   current one green-highlighted.
3. Edit again — new revision. Click "Publish this" on the new row.
4. Click "Restore" on revision #1 — a new revision is created with
   #1's body, note "restored from revision #1". Published revision
   stays where you left it until you click publish on the restore row.
5. `/kb` renders the public index; article lives at `/kb/{slug}`.

## Deferred features

- **Full-text search** — swap LIKE for a MySQL FULLTEXT index or the
  framework's SearchIndexer. The service's `search()` is the only
  touchpoint.
- **Diff view** — side-by-side diff between two revisions. The raw
  bodies are on the revision rows; a simple inline diff is ~30 lines.
- **Category tree** — taxonomy module handles this already via
  `attach_term('kb_article', $id, 'kb-categories', $slug)`. UI
  integration deferred.
- **Comments on articles** — drop `<?= comments('kb_article', $id) ?>`
  into `Views/public/show.php` once comments are installed.
