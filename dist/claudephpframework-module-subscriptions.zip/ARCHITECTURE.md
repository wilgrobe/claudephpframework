# Architecture — Subscriptions module

## Files

```
subscriptions/
├── module.php
├── routes.php                                             # 14 routes
├── Controllers/
│   ├── BillingController.php                              # User: /billing + subscribe/cancel/resume
│   ├── SubscriptionAdminController.php                    # Admin: plan CRUD + oversight
│   └── SubscriptionWebhookController.php                  # Stripe webhook receiver
├── Services/
│   ├── SubscriptionService.php                            # Domain logic + webhook dispatch
│   └── StripeSubscriptionDriver.php                       # Stripe-specific API calls
├── Jobs/
│   └── DunningJob.php                                     # Daily past-due email digest
├── Views/
│   ├── admin/plans/index.php                              # Plans list
│   ├── admin/plans/form.php                               # Plan create/edit
│   ├── admin/subscriptions.php                            # Subscriptions list w/ status tabs
│   └── billing/index.php                                  # User landing — status + catalog
└── migrations/
    ├── 2026_04_22_200000_create_subscriptions_tables.php  # 3 tables
    ├── 2026_04_22_200010_seed_subscriptions_permission.php
    └── 2026_04_22_200020_seed_dunning_scheduled_task.php
```

## Tables

**`subscription_plans`** — admin catalog
```
id, name, slug (unique), description, amount_cents, currency,
interval ENUM(day|week|month|year), interval_count, trial_days,
gateway, gateway_price_id, active, sort_order, created_at, updated_at
```

**`subscriptions`** — per-user state mirrored from Stripe
```
id, user_id, plan_id (nullable FK), gateway, gateway_customer_id,
gateway_subscription_id, status ENUM(incomplete|trial|active|past_due|canceled),
current_period_start, current_period_end, cancel_at_period_end,
trial_ends_at, canceled_at, last_payment_error, created_at, updated_at

UNIQUE (gateway, gateway_subscription_id) — one local row per Stripe sub
```

**`subscription_events`** — append-only webhook audit log
```
id, subscription_id (nullable FK), gateway, event_type, event_id,
payload_json, occurred_at

UNIQUE (gateway, event_id) — idempotent replay
```

## Lifecycle

```
             Stripe status     →      local status
   ─────────────────────────────────────────────────
   (checkout.session.completed → create row)
                                     incomplete
   trialing                       →  trial
   active                         →  active
   past_due, unpaid               →  past_due
   canceled, incomplete_expired   →  canceled
```

Webhooks drive all state transitions. The local row is never mutated
directly by the app in response to a successful Stripe call — we wait
for the corresponding event to arrive. Rationale: webhooks are the
source of truth; mutating locally risks divergence when Stripe's async
processing hasn't completed yet.

## Subscribe flow (happy path)

```
user clicks Subscribe on /billing
  → POST /billing/subscribe/{slug}
    → SubscriptionService::startCheckout
      → StripeSubscriptionDriver::createCheckoutSession
        → Stripe: POST /v1/checkout/sessions {mode=subscription, price=..., metadata={user_id, plan_id}}
      → returns session.url
    → 302 redirect to Stripe-hosted checkout
user enters card → Stripe charges → redirects back to /billing/success

  (meanwhile, asynchronously:)
Stripe → POST /webhooks/stripe/subscriptions
  → SubscriptionWebhookController::receive
    → verify signature (STRIPE_WEBHOOK_SECRET)
    → SubscriptionService::applyWebhookEvent
      → handleCheckoutCompleted (creates local subscriptions row)
      → handleSubscriptionUpsert on subsequent customer.subscription.updated
    → persist subscription_events row (idempotent)

user refreshes /billing → sees "active" status
```

## Why the two-service split

- **`SubscriptionService`** is gateway-agnostic in shape — reads and
  writes our local tables, dispatches webhook events, applies status
  logic. A future multi-gateway dispatcher lives here.
- **`StripeSubscriptionDriver`** is Stripe-specific — all `/v1/checkout/sessions`,
  `/v1/subscriptions/*`, `/v1/refunds` calls go through it. Wraps
  `StripeService::call()` so it doesn't re-implement HTTP or error handling.

Adding Square: write `SquareSubscriptionDriver` with the same public
surface (`isEnabled`, `createCheckoutSession`, `retrieveSubscription`,
`cancelSubscription`, `resumeSubscription`, `verifyWebhook`), then in
`SubscriptionService` branch on the plan's `gateway` column to pick the
driver at call time.

## Webhook dispatch

`SubscriptionService::applyWebhookEvent` routes by `$event['type']`:

| Stripe event                           | Handler                      | Effect                                           |
|----------------------------------------|------------------------------|--------------------------------------------------|
| `checkout.session.completed`           | `handleCheckoutCompleted`    | Fetches subscription, creates local row          |
| `customer.subscription.created`        | `handleSubscriptionUpsert`   | Upserts local row                                |
| `customer.subscription.updated`        | `handleSubscriptionUpsert`   | Upserts local row (status, period, cancel flag)  |
| `customer.subscription.deleted`        | `handleSubscriptionDeleted`  | Marks local row `canceled` with `canceled_at`    |
| `invoice.paid`                         | `handleInvoicePaid`          | Restores `active`, clears `last_payment_error`   |
| `invoice.payment_failed`               | `handleInvoiceFailed`        | Marks `past_due` with error message              |
| (anything else)                        | —                            | Logged into `subscription_events` with no effect |

Every event — handled or not — lands in `subscription_events` (unless it
duplicates a row by `event_id`, in which case dedupe wins). The full
payload is persisted for audit.

## Dunning

`DunningJob` runs daily at 09:00 via a seeded `scheduled_tasks` row.
For each subscription in `past_due` for > 24h:

1. Fetch the user's email from `users`
2. Skip if `last_payment_error` contains `[reminder sent]` (same-day idempotency marker)
3. Send an email pointing to `/billing`
4. Append `[reminder sent]` to `last_payment_error`

If Stripe's retries later succeed, `invoice.paid` arrives, the service
clears `last_payment_error` and sets status back to `active` — the
marker goes with it.

## Authorization

| Action                         | Who                                        |
|--------------------------------|--------------------------------------------|
| View /billing + subscribe      | Any authenticated user                     |
| Cancel / resume own            | Any authenticated user (own subscription)  |
| Plan CRUD                      | `subscriptions.manage` permission          |
| Subscription oversight + cancel | `subscriptions.manage` permission         |
| Webhook endpoint               | Stripe (verified by signature)             |

## Security

- **Webhook signature verification** — every incoming webhook is verified
  against `STRIPE_WEBHOOK_SECRET` via `StripeService::verifyWebhook` (HMAC
  SHA-256, timestamp tolerance 300s default). No auth middleware on the
  endpoint because Stripe posts from its own IP space; the signature is
  the boundary.
- **Idempotent webhook replay** — `UNIQUE (gateway, event_id)` on
  `subscription_events` means Stripe can redeliver without double-applying.
- **IDOR-safe cancel/resume** — billing actions always use
  `Auth::id()`-derived subscriptions, never a user-supplied id from the
  URL.
- **No card data in local DB** — subscription flow uses Stripe Checkout
  (hosted), so card details never hit our server. We only store the
  Stripe-side tokens (`customer`, `subscription`, `price` ids).

## Dependencies

- `claudephpframework-core` — Auth, Database, StripeService,
  MailService, NotificationService, Queue + Scheduler, SettingsService
- Core's `users` table (user_id FK on `subscriptions`)
- `scheduled_tasks` table (for dunning job)

## Known limitations / v2

- **Proration / plan upgrades** — not implemented. A `changePlan()` path
  in SubscriptionService would call Stripe's subscription update with
  proration_behavior; handling the resulting multi-line-item invoice
  needs care.
- **Billing portal link** — Stripe's hosted billing portal
  (customer-facing self-service for payment method updates) isn't
  wired yet. Add a `createBillingPortalSession` method to the driver
  and a `/billing/portal` redirect.
- **Multiple active subscriptions per user** — not modeled explicitly.
  The schema allows it (no UNIQUE on user_id), but the UI and
  `activeSubscriptionFor()` assume one.
- **Square + Braintree** — driver classes need implementing.
- **Invoices** — no local invoice table. Line-item history lives in
  `subscription_events` (invoice.paid / invoice.payment_failed payloads)
  but isn't rendered as a user-facing "receipts" page. The invoicing
  module (queued in the roadmap) would add that layer.
