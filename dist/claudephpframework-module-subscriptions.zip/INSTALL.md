# Installation — Subscriptions module

## Prerequisites

- `claudephpframework-core` installed.
- Stripe credentials configured in core's `.env`:
  - `STRIPE_SECRET_KEY` (`sk_test_*` or `sk_live_*`)
  - `STRIPE_PUBLIC_KEY` (`pk_test_*` or `pk_live_*`)
  - `STRIPE_WEBHOOK_SECRET` (`whsec_*` — created when you add the webhook
    endpoint in Stripe's dashboard)
- `subscriptions.manage` permission granted to at least one admin role
  (seeded by this module's migration; grant via `/admin/roles`).
- Cron running `php artisan schedule:run` every minute — drives the
  dunning job. (Should already be in place if the scheduler-based modules
  were set up.)

## Steps

1. Unzip into `modules/`:
   ```bash
   unzip claudephpframework-module-subscriptions.zip
   cp -r claudephpframework-module-subscriptions/subscriptions /path/to/project/modules/
   ```

2. Run the migrations (creates 3 tables + seeds permission + schedules dunning):
   ```bash
   php artisan migrate
   ```

3. Refresh the module manifest cache if you use production caching:
   ```bash
   php artisan module:cache
   ```

4. Grant the `subscriptions.manage` permission to your admin role via
   `/admin/roles`.

## Stripe setup

1. **Create products + prices** in the Stripe dashboard:
   - Products → Add product → set name + description
   - Under Pricing → set amount + recurring interval
   - Copy the `price_1AbCDef...` id

2. **Create a plan** in your app at `/admin/subscription-plans/create`:
   - Paste the Stripe price id into the "Stripe price id" field
   - Match the amount/currency/interval to what you set in Stripe (the
     app's copy is shown to users on the catalog; Stripe is the source of
     truth at charge time)

3. **Add the webhook endpoint** in Stripe:
   - Developers → Webhooks → Add endpoint
   - URL: `https://yourdomain.com/webhooks/stripe/subscriptions`
   - Events to send (at minimum):
     - `checkout.session.completed`
     - `customer.subscription.created`
     - `customer.subscription.updated`
     - `customer.subscription.deleted`
     - `invoice.paid`
     - `invoice.payment_failed`
   - Copy the signing secret (`whsec_*`) and paste into `.env` as
     `STRIPE_WEBHOOK_SECRET`.

## Test the full flow

1. Log in as a test user, visit `/billing`.
2. Click Subscribe on a plan → redirected to Stripe Checkout.
3. Use Stripe's test card `4242 4242 4242 4242`, any future expiry, any CVC.
4. After checkout, you're returned to `/billing` with a success flash.
5. Within a few seconds (webhook delivery), the page reloads showing
   status `active` / `trial`. Query `subscription_events` to confirm the
   webhook was received.
6. Test dunning: use Stripe's `4000 0000 0000 0341` (attaches OK but fails
   on recurring charge) to put a subscription into `past_due`.

## Environment variables

All Stripe creds live in core's `.env`. This module adds none of its own.

## Troubleshooting

- **Subscribe button does nothing** — plan is missing `gateway_price_id`.
  Open the plan in the admin edit view and paste the Stripe price id.
- **Local subscription stays `incomplete` after checkout** — webhook
  isn't reaching you. Check the Stripe dashboard's webhook logs, make
  sure the URL is reachable from the internet (use Stripe CLI's
  `stripe listen --forward-to localhost:8080/webhooks/stripe/subscriptions`
  in dev).
- **"Invalid signature" from webhook endpoint** — `STRIPE_WEBHOOK_SECRET`
  doesn't match Stripe's dashboard. Copy it fresh; the signing secret
  changes if you rotate or recreate the endpoint.
- **Dunning emails not going out** — `php artisan schedule:run` isn't
  running via cron, or `MAIL_DRIVER` is `none`. Check
  `scheduled_tasks.last_run_at` for the `subscriptions-dunning` row.
