# Subscriptions module

Recurring-billing primitives on top of the framework's Stripe integration.
Admin plan catalog, user-facing billing page, Stripe Checkout subscribe
flow, webhook-driven state sync, and daily dunning emails for past-due
subscribers.

## Features

- **Plan catalog** — admin CRUD under `/admin/subscription-plans`. Each
  plan maps to a Stripe `price_xxx` id (you create the Price in Stripe's
  dashboard; paste the id here).
- **User-facing billing** — `/billing` shows current status, plan details,
  renewal date, and lets users cancel or resume. Subscribe flow redirects
  to Stripe Checkout (hosted) — no card form in our app.
- **Lifecycle** — `incomplete` → `trial` → `active`, or directly to
  `active`. From `active` can transition to `past_due` (failed payment)
  or `canceled`. Webhook-driven; local state always reflects Stripe's.
- **Webhook handler** — `POST /webhooks/stripe/subscriptions` verifies
  signature and dispatches `checkout.session.completed`,
  `customer.subscription.{created,updated,deleted}`, `invoice.paid`,
  `invoice.payment_failed`. Idempotent on duplicate event ids.
- **Dunning** — `DunningJob` runs daily at 09:00; emails users whose
  subscription has been `past_due` for > 24h. Idempotent per day.
- **Audit log** — every processed webhook lands in `subscription_events`
  with the full payload, so a disputed charge can be reconstructed.
- **Stripe-first** — Square and Braintree support is queued; add a
  sibling `SquareSubscriptionDriver` / `BraintreeSubscriptionDriver`
  with the same surface as `StripeSubscriptionDriver` to extend.

## Routes

### User-facing

| Method | Path                                  | Middleware      | Purpose                 |
|--------|---------------------------------------|-----------------|-------------------------|
| GET    | `/billing`                            | Auth            | Current state + catalog |
| POST   | `/billing/subscribe/{slug}`           | Csrf + Auth     | Start Stripe Checkout   |
| GET    | `/billing/success`                    | Auth            | Return after checkout   |
| GET    | `/billing/cancel`                     | Auth            | Return on checkout abort|
| POST   | `/billing/cancel-subscription`        | Csrf + Auth     | Cancel at period end    |
| POST   | `/billing/resume`                     | Csrf + Auth     | Undo pending cancel     |

### Admin (`Auth + RequireAdmin`, `subscriptions.manage` permission)

| Method | Path                                         | Purpose            |
|--------|----------------------------------------------|--------------------|
| GET    | `/admin/subscription-plans`                  | Plans list         |
| GET/POST | `/admin/subscription-plans/create`         | Create plan        |
| GET/POST | `/admin/subscription-plans/{id}/edit`      | Edit plan          |
| POST   | `/admin/subscription-plans/{id}/delete`      | Delete plan        |
| GET    | `/admin/subscriptions`                       | Subscriptions list |
| POST   | `/admin/subscriptions/{id}/cancel`           | Admin cancel       |

### Webhook (no auth — signature-verified)

| Method | Path                                  | Purpose                             |
|--------|---------------------------------------|-------------------------------------|
| POST   | `/webhooks/stripe/subscriptions`      | Receive Stripe subscription events  |

See [`INSTALL.md`](./INSTALL.md) and [`ARCHITECTURE.md`](./ARCHITECTURE.md).
