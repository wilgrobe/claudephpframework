<?php
// modules/subscriptions/module.php
use Core\Module\ModuleProvider;

/**
 * Subscriptions module — recurring-billing primitives on top of the
 * framework's Stripe gateway. Plan catalog admin, user-facing /billing
 * page, Stripe Checkout subscribe flow, webhook-driven state sync, and
 * daily dunning emails for past-due subscribers.
 *
 * Stripe-first. Adding Square / Braintree support means a sibling
 * subscription driver class (SquareSubscriptionDriver) implementing the
 * same public surface as StripeSubscriptionDriver, plus a dispatcher in
 * SubscriptionService that picks the driver by the plan's `gateway` column.
 */
return new class extends ModuleProvider {
    public function name(): string            { return 'subscriptions'; }
    public function routesFile(): ?string     { return __DIR__ . '/routes.php'; }
    public function viewsPath(): ?string      { return __DIR__ . '/Views'; }
    public function migrationsPath(): ?string { return __DIR__ . '/migrations'; }
};
