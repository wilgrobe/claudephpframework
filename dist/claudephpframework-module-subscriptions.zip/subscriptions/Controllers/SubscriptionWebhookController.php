<?php
// modules/subscriptions/Controllers/SubscriptionWebhookController.php
namespace Modules\Subscriptions\Controllers;

use Core\Request;
use Core\Response;
use Core\Services\StripeService;
use Modules\Subscriptions\Services\SubscriptionService;

/**
 * Stripe webhook receiver for subscription-related events.
 *
 * Route: POST /webhooks/stripe/subscriptions — NO auth, NO CSRF.
 *   Stripe posts signed events from its own servers; we verify by
 *   computing HMAC over the raw body using STRIPE_WEBHOOK_SECRET. An
 *   unauthorized POST can't forge a valid signature so the verify step
 *   is the security boundary.
 *
 * On successful verify, delegates to SubscriptionService::applyWebhookEvent
 * which dispatches by event type and appends to the audit log.
 *
 * Stripe retries failed deliveries with exponential backoff for up to 3
 * days, so returning 500 on a transient error is safe — the event will
 * redeliver. Return 200 only after we've persisted the event (or
 * recognized it as a duplicate).
 */
class SubscriptionWebhookController
{
    public function receive(Request $request): Response
    {
        // Read the raw request body. Stripe signs the bytes exactly as
        // sent; parsed post data ($_POST) would be useless here.
        $payload   = (string) @file_get_contents('php://input');
        $signature = (string) ($_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '');

        // Verify — returns the decoded event or null if signature/timestamp
        // doesn't check out.
        $stripe = new StripeService();
        $event  = $stripe->verifyWebhook($payload, $signature);
        if (!$event) {
            return new Response('Invalid signature', 400);
        }

        try {
            (new SubscriptionService())->applyWebhookEvent($event);
        } catch (\Throwable $e) {
            // Let Stripe retry on our transient errors. The verified event
            // is logged by the service before handler dispatch, so audit
            // isn't lost even when processing fails.
            error_log('[subscriptions webhook] ' . $e->getMessage());
            return new Response('retry', 500);
        }
        return new Response('ok', 200);
    }
}
