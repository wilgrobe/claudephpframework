<?php
// modules/subscriptions/Controllers/SubscriptionAdminController.php
namespace Modules\Subscriptions\Controllers;

use Core\Auth\Auth;
use Core\Database\Database;
use Core\Request;
use Core\Response;
use Core\Session;
use Core\Validation\Validator;
use Modules\Subscriptions\Services\SubscriptionService;

/**
 * Admin surface for subscription plans and subscription oversight.
 * Gated by Auth + RequireAdmin at route registration; per-method
 * permission checks for defense in depth.
 */
class SubscriptionAdminController
{
    private Auth                $auth;
    private Database            $db;
    private SubscriptionService $subs;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->db   = Database::getInstance();
        $this->subs = new SubscriptionService();
    }

    // ── Plan CRUD ─────────────────────────────────────────────────────────

    public function plansIndex(Request $request): Response
    {
        if ($this->auth->cannot('subscriptions.manage')) return $this->denied();
        return Response::view('subscriptions::admin.plans.index', [
            'plans' => $this->subs->allPlans(),
            'user'  => $this->auth->user(),
        ]);
    }

    public function planCreate(Request $request): Response
    {
        if ($this->auth->cannot('subscriptions.manage')) return $this->denied();
        return Response::view('subscriptions::admin.plans.form', [
            'plan' => null,
            'user' => $this->auth->user(),
        ]);
    }

    public function planStore(Request $request): Response
    {
        if ($this->auth->cannot('subscriptions.manage')) return $this->denied();

        $v = new Validator($request->post());
        $v->validate([
            'name'         => 'required|min:2|max:191',
            'slug'         => 'required|min:2|max:120',
            'amount_cents' => 'required',
            'currency'     => 'required|min:2|max:8',
            'interval'     => 'required|in:day,week,month,year',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            Session::flash('old', $v->all());
            return Response::redirect('/admin/subscription-plans/create');
        }

        $slug = $this->sanitizeSlug((string) $v->get('slug'));
        if ($this->db->fetchOne("SELECT id FROM subscription_plans WHERE slug = ?", [$slug])) {
            Session::flash('errors', ['slug' => ['That slug is already in use.']]);
            Session::flash('old', $v->all());
            return Response::redirect('/admin/subscription-plans/create');
        }

        $id = $this->db->insert('subscription_plans', [
            'name'             => $v->get('name'),
            'slug'             => $slug,
            'description'      => $request->post('description'),
            'amount_cents'     => (int) $v->get('amount_cents'),
            'currency'         => strtoupper((string) $v->get('currency')),
            'interval'         => (string) $v->get('interval'),
            'interval_count'   => max(1, (int) $request->post('interval_count', 1)),
            'trial_days'       => max(0, (int) $request->post('trial_days', 0)),
            'gateway'          => 'stripe',
            'gateway_price_id' => $request->post('gateway_price_id') ?: null,
            'active'           => (int) $request->post('active', 1),
            'sort_order'       => (int) $request->post('sort_order', 0),
        ]);

        $this->auth->auditLog('plan.create', 'subscription_plans', $id);
        return Response::redirect('/admin/subscription-plans')
            ->withFlash('success', 'Plan created. Remember to paste the Stripe price_xxx id in the edit form if you haven\'t already.');
    }

    public function planEdit(Request $request): Response
    {
        if ($this->auth->cannot('subscriptions.manage')) return $this->denied();
        $plan = $this->subs->findPlan((int) $request->param(0));
        if (!$plan) return new Response('Plan not found', 404);
        return Response::view('subscriptions::admin.plans.form', [
            'plan' => $plan,
            'user' => $this->auth->user(),
        ]);
    }

    public function planUpdate(Request $request): Response
    {
        if ($this->auth->cannot('subscriptions.manage')) return $this->denied();
        $id   = (int) $request->param(0);
        $plan = $this->subs->findPlan($id);
        if (!$plan) return new Response('Plan not found', 404);

        $v = new Validator($request->post());
        $v->validate([
            'name'         => 'required|min:2|max:191',
            'slug'         => 'required|min:2|max:120',
            'amount_cents' => 'required',
            'currency'     => 'required|min:2|max:8',
            'interval'     => 'required|in:day,week,month,year',
        ]);
        if ($v->fails()) {
            Session::flash('errors', $v->errors());
            return Response::redirect("/admin/subscription-plans/$id/edit");
        }

        $slug  = $this->sanitizeSlug((string) $v->get('slug'));
        $clash = $this->db->fetchOne("SELECT id FROM subscription_plans WHERE slug = ? AND id <> ?", [$slug, $id]);
        if ($clash) {
            Session::flash('errors', ['slug' => ['That slug is already in use.']]);
            return Response::redirect("/admin/subscription-plans/$id/edit");
        }

        $this->db->update('subscription_plans', [
            'name'             => $v->get('name'),
            'slug'             => $slug,
            'description'      => $request->post('description'),
            'amount_cents'     => (int) $v->get('amount_cents'),
            'currency'         => strtoupper((string) $v->get('currency')),
            'interval'         => (string) $v->get('interval'),
            'interval_count'   => max(1, (int) $request->post('interval_count', 1)),
            'trial_days'       => max(0, (int) $request->post('trial_days', 0)),
            'gateway_price_id' => $request->post('gateway_price_id') ?: null,
            'active'           => (int) $request->post('active', 1),
            'sort_order'       => (int) $request->post('sort_order', 0),
        ], 'id = ?', [$id]);

        $this->auth->auditLog('plan.update', 'subscription_plans', $id);
        return Response::redirect("/admin/subscription-plans/$id/edit")
            ->withFlash('success', 'Plan saved.');
    }

    public function planDelete(Request $request): Response
    {
        if ($this->auth->cannot('subscriptions.manage')) return $this->denied();
        $id = (int) $request->param(0);
        if (!$this->subs->findPlan($id)) return new Response('Plan not found', 404);

        // plan_id on subscriptions is ON DELETE SET NULL — existing
        // subscriptions keep running, just lose the catalog reference.
        $this->db->delete('subscription_plans', 'id = ?', [$id]);
        $this->auth->auditLog('plan.delete', 'subscription_plans', $id);
        return Response::redirect('/admin/subscription-plans')
            ->withFlash('success', 'Plan deleted. Existing subscriptions unchanged.');
    }

    // ── Subscription oversight ────────────────────────────────────────────

    public function subscriptionsIndex(Request $request): Response
    {
        if ($this->auth->cannot('subscriptions.manage')) return $this->denied();

        $status = $request->query('status');
        $page   = max(1, (int) $request->query('page', 1));
        $data   = $this->subs->listSubscriptions($status ?: null, $page);

        // Counts per status — shown in the tab row above the table.
        $counts = [];
        foreach (SubscriptionService::STATUSES as $s) {
            $counts[$s] = $this->subs->listSubscriptions($s, 1, 1)['total'];
        }

        return Response::view('subscriptions::admin.subscriptions', [
            'items'   => $data['items'],
            'total'   => $data['total'],
            'status'  => $status,
            'page'    => $page,
            'counts'  => $counts,
            'user'    => $this->auth->user(),
        ]);
    }

    /** POST /admin/subscriptions/{id}/cancel — admin-initiated cancel-at-period-end. */
    public function subscriptionCancel(Request $request): Response
    {
        if ($this->auth->cannot('subscriptions.manage')) return $this->denied();
        $id = (int) $request->param(0);
        if ($this->subs->cancel($id, atPeriodEnd: true)) {
            $this->auth->auditLog('subscription.admin_cancel', 'subscriptions', $id);
            return Response::redirect('/admin/subscriptions')
                ->withFlash('success', "Subscription #$id set to cancel at period end.");
        }
        return Response::redirect('/admin/subscriptions')
            ->withFlash('error', "Could not cancel subscription #$id.");
    }

    // ── internals ─────────────────────────────────────────────────────────

    private function denied(): Response
    {
        return Response::redirect('/dashboard')
            ->withFlash('error', 'You do not have permission to manage subscriptions.');
    }

    private function sanitizeSlug(string $raw): string
    {
        $slug = strtolower(trim($raw));
        $slug = preg_replace('/[^a-z0-9]+/', '-', $slug);
        return trim((string) $slug, '-');
    }
}
