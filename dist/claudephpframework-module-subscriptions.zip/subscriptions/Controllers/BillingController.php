<?php
// modules/subscriptions/Controllers/BillingController.php
namespace Modules\Subscriptions\Controllers;

use Core\Auth\Auth;
use Core\Request;
use Core\Response;
use Core\Session;
use Modules\Subscriptions\Services\SubscriptionService;

/**
 * User-facing billing. Shows current plan + status, renders the plan
 * catalog for upgrade/subscribe, kicks off Stripe Checkout, and handles
 * the return redirects.
 *
 * Cancel / resume are user-initiated here; both go through
 * SubscriptionService which talks to Stripe and updates the local row.
 */
class BillingController
{
    private Auth                $auth;
    private SubscriptionService $subs;

    public function __construct()
    {
        $this->auth = Auth::getInstance();
        $this->subs = new SubscriptionService();
    }

    /** GET /billing — landing page: current state + plan catalog. */
    public function index(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $userId  = (int) $this->auth->id();
        $current = $this->subs->activeSubscriptionFor($userId);
        $plans   = $this->subs->activePlans();

        // Attach the current plan row for display convenience.
        $currentPlan = null;
        if ($current && !empty($current['plan_id'])) {
            $currentPlan = $this->subs->findPlan((int) $current['plan_id']);
        }

        return Response::view('subscriptions::billing.index', [
            'current'     => $current,
            'currentPlan' => $currentPlan,
            'plans'       => $plans,
            'user'        => $this->auth->user(),
        ]);
    }

    /** POST /billing/subscribe/{planSlug} — start Stripe Checkout. */
    public function subscribe(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $slug = (string) $request->param(0);
        $plan = $this->subs->findPlanBySlug($slug);
        if (!$plan || (int) $plan['active'] !== 1) {
            return Response::redirect('/billing')->withFlash('error', 'That plan is not available.');
        }

        $user       = $this->auth->user();
        $baseUrl    = rtrim((string) ($_ENV['APP_URL'] ?? ''), '/');
        $successUrl = $baseUrl . '/billing/success?session_id={CHECKOUT_SESSION_ID}';
        $cancelUrl  = $baseUrl . '/billing/cancel';

        $url = $this->subs->startCheckout($plan, $user, $successUrl, $cancelUrl);
        if (!$url) {
            return Response::redirect('/billing')
                ->withFlash('error', 'Could not start checkout. Verify Stripe configuration and plan setup.');
        }

        $this->auth->auditLog('billing.checkout_start', 'subscription_plans', (int) $plan['id']);
        return Response::redirect($url);
    }

    /**
     * GET /billing/success — user returned from Stripe after successful
     * checkout. The actual subscription activation happens asynchronously
     * via the webhook (checkout.session.completed), so this page is
     * optimistic — the local row might still be 'incomplete' briefly.
     */
    public function success(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        Session::flash('success', 'Thanks — your subscription is being activated.');
        return Response::redirect('/billing');
    }

    /** GET /billing/cancel — user bailed out of checkout. */
    public function cancel(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');
        return Response::redirect('/billing');
    }

    /** POST /billing/cancel-subscription — cancel at period end. */
    public function cancelSubscription(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $userId  = (int) $this->auth->id();
        $current = $this->subs->activeSubscriptionFor($userId);
        if (!$current) return Response::redirect('/billing')->withFlash('error', 'No active subscription to cancel.');

        if ($this->subs->cancel((int) $current['id'], atPeriodEnd: true)) {
            $this->auth->auditLog('billing.cancel_scheduled', 'subscriptions', (int) $current['id']);
            return Response::redirect('/billing')
                ->withFlash('success', 'Your subscription is set to cancel at the end of the current period.');
        }
        return Response::redirect('/billing')->withFlash('error', 'Could not cancel. Contact support.');
    }

    /** POST /billing/resume — undo a pending cancel. */
    public function resumeSubscription(Request $request): Response
    {
        if ($this->auth->guest()) return Response::redirect('/login');

        $userId  = (int) $this->auth->id();
        $current = $this->subs->activeSubscriptionFor($userId);
        if (!$current) return Response::redirect('/billing')->withFlash('error', 'No subscription to resume.');

        if ($this->subs->resume((int) $current['id'])) {
            $this->auth->auditLog('billing.cancel_undone', 'subscriptions', (int) $current['id']);
            return Response::redirect('/billing')->withFlash('success', 'Your subscription will continue to renew.');
        }
        return Response::redirect('/billing')->withFlash('error', 'Could not resume. Contact support.');
    }
}
