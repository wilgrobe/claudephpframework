<?php
// modules/subscriptions/routes.php
/** @var \Core\Router\Router $router */

use App\Middleware\AuthMiddleware;
use App\Middleware\CsrfMiddleware;
use App\Middleware\RequireAdmin;

$B = 'Modules\Subscriptions\Controllers\BillingController';
$A = 'Modules\Subscriptions\Controllers\SubscriptionAdminController';
$W = 'Modules\Subscriptions\Controllers\SubscriptionWebhookController';

// ── User-facing billing ───────────────────────────────────────────────────
$router->get ('/billing',                        "$B@index",              [AuthMiddleware::class]);
$router->post('/billing/subscribe/{slug}',       "$B@subscribe",          [CsrfMiddleware::class, AuthMiddleware::class]);
$router->get ('/billing/success',                "$B@success",            [AuthMiddleware::class]);
$router->get ('/billing/cancel',                 "$B@cancel",             [AuthMiddleware::class]);
$router->post('/billing/cancel-subscription',    "$B@cancelSubscription", [CsrfMiddleware::class, AuthMiddleware::class]);
$router->post('/billing/resume',                 "$B@resumeSubscription", [CsrfMiddleware::class, AuthMiddleware::class]);

// ── Admin: plans CRUD ─────────────────────────────────────────────────────
$router->get ('/admin/subscription-plans',               "$A@plansIndex",  [AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/subscription-plans/create',        "$A@planCreate",  [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/subscription-plans/create',        "$A@planStore",   [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->get ('/admin/subscription-plans/{id}/edit',     "$A@planEdit",    [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/subscription-plans/{id}/edit',     "$A@planUpdate",  [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/subscription-plans/{id}/delete',   "$A@planDelete",  [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);

// ── Admin: subscription oversight ─────────────────────────────────────────
$router->get ('/admin/subscriptions',                    "$A@subscriptionsIndex",  [AuthMiddleware::class, RequireAdmin::class]);
$router->post('/admin/subscriptions/{id}/cancel',        "$A@subscriptionCancel",  [CsrfMiddleware::class, AuthMiddleware::class, RequireAdmin::class]);

// ── Stripe webhook ────────────────────────────────────────────────────────
// NO auth, NO CSRF — Stripe posts from its own servers; the verifyWebhook
// signature check inside the controller is the security boundary.
$router->post('/webhooks/stripe/subscriptions', "$W@receive");
