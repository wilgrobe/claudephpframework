<?php
// modules/subscriptions/Services/StripeSubscriptionDriver.php
namespace Modules\Subscriptions\Services;

use Core\Services\StripeService;

/**
 * Stripe-specific subscription operations. Intentionally NOT part of the
 * PaymentGateway contract — subscriptions have enough provider-specific
 * shape (Stripe Checkout Sessions, Invoices, Subscription Schedules) that
 * a unified interface across Stripe/Square/Braintree would either leak
 * abstractions or be an LCD straitjacket.
 *
 * When Square + Braintree subscriptions land, add sibling driver classes
 * (SquareSubscriptionDriver, BraintreeSubscriptionDriver) with the same
 * public surface, and pick at runtime inside SubscriptionService based on
 * the plan's `gateway` column.
 *
 * Wraps StripeService::call() — doesn't re-implement HTTP, error handling,
 * or API versioning.
 */
class StripeSubscriptionDriver
{
    public function __construct(private StripeService $stripe) {}

    public function isEnabled(): bool
    {
        return $this->stripe->isEnabled();
    }

    /**
     * Create a Checkout Session in subscription mode. Returns the session
     * URL the user should be redirected to, or null on failure.
     *
     * @param string $priceId     Stripe price_xxx id (plan's gateway_price_id)
     * @param string $successUrl  where Stripe redirects on completion
     * @param string $cancelUrl   where Stripe redirects on back/cancel
     * @param string $customerId  existing Stripe customer id, or '' to create
     * @param int    $trialDays   days of trial (0 = no trial)
     * @param string $customerEmail  used when customerId is empty; Stripe
     *                               creates the customer with this email
     * @param array  $metadata    metadata[key]=value pairs persisted on the
     *                            resulting subscription (we stash our
     *                            user_id + plan_id here so the webhook
     *                            handler can wire back)
     */
    public function createCheckoutSession(
        string $priceId,
        string $successUrl,
        string $cancelUrl,
        string $customerId = '',
        int    $trialDays = 0,
        string $customerEmail = '',
        array  $metadata = []
    ): ?array {
        $body = [
            'mode'                  => 'subscription',
            'line_items[0][price]'  => $priceId,
            'line_items[0][quantity]' => 1,
            'success_url'           => $successUrl,
            'cancel_url'            => $cancelUrl,
        ];
        if ($customerId !== '') {
            $body['customer'] = $customerId;
        } elseif ($customerEmail !== '') {
            $body['customer_email'] = $customerEmail;
        }
        if ($trialDays > 0) {
            $body['subscription_data[trial_period_days]'] = $trialDays;
        }
        foreach ($metadata as $k => $v) {
            $body["subscription_data[metadata][$k]"] = (string) $v;
        }

        return $this->stripe->call('POST', '/v1/checkout/sessions', $body);
    }

    /** Fetch a subscription's current state. Used when reconciling. */
    public function retrieveSubscription(string $subId): ?array
    {
        return $this->stripe->call('GET', "/v1/subscriptions/$subId");
    }

    /**
     * Cancel a subscription. When $atPeriodEnd=true, Stripe keeps the
     * subscription active until the end of the current billing period and
     * then stops renewing (the user still has access they paid for).
     * Otherwise cancels immediately (no proration — that's v2).
     */
    public function cancelSubscription(string $subId, bool $atPeriodEnd = true): ?array
    {
        if ($atPeriodEnd) {
            return $this->stripe->call('POST', "/v1/subscriptions/$subId", [
                'cancel_at_period_end' => 'true',
            ]);
        }
        return $this->stripe->call('DELETE', "/v1/subscriptions/$subId");
    }

    /** Undo a cancel_at_period_end flag. Subscription continues renewing. */
    public function resumeSubscription(string $subId): ?array
    {
        return $this->stripe->call('POST', "/v1/subscriptions/$subId", [
            'cancel_at_period_end' => 'false',
        ]);
    }

    /**
     * Verify a webhook payload + signature. Delegates to StripeService —
     * we use the same webhook secret for Checkout / subscription events
     * and other Stripe webhooks the app might later add.
     */
    public function verifyWebhook(string $payload, string $signature): ?array
    {
        return $this->stripe->verifyWebhook($payload, $signature);
    }
}
