<?php
// modules/subscriptions/Services/SubscriptionService.php
namespace Modules\Subscriptions\Services;

use Core\Database\Database;
use Core\Services\StripeService;

/**
 * Subscription domain logic. Gateway-agnostic on paper, Stripe-only in
 * practice until sibling drivers land.
 *
 * Responsibilities:
 *   - Plans: fetch for admin list + user-facing catalog
 *   - Subscriptions: fetch by user, current active, status transitions
 *   - Webhook event dispatcher: each Stripe event type maps to a handler
 *     that updates our local `subscriptions` + appends to
 *     `subscription_events`
 *   - Dunning: find subscriptions in past_due and mark for notification
 *
 * Controllers use this service; webhook controller calls
 * applyWebhookEvent(). Direct Stripe API calls (other than signature
 * verification) go through StripeSubscriptionDriver.
 */
class SubscriptionService
{
    public const STATUSES = ['incomplete', 'trial', 'active', 'past_due', 'canceled'];

    private Database                 $db;
    private StripeSubscriptionDriver $stripe;

    public function __construct()
    {
        $this->db     = Database::getInstance();
        $this->stripe = new StripeSubscriptionDriver(new StripeService());
    }

    // ── Plan reads ────────────────────────────────────────────────────────

    /** @return array<int, array<string, mixed>> */
    public function activePlans(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM subscription_plans
              WHERE active = 1
           ORDER BY sort_order ASC, amount_cents ASC"
        );
    }

    /** @return array<int, array<string, mixed>> */
    public function allPlans(): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM subscription_plans ORDER BY sort_order ASC, name ASC"
        );
    }

    public function findPlan(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM subscription_plans WHERE id = ?", [$id]);
    }

    public function findPlanBySlug(string $slug): ?array
    {
        return $this->db->fetchOne("SELECT * FROM subscription_plans WHERE slug = ?", [$slug]);
    }

    // ── Subscription reads ────────────────────────────────────────────────

    /** Return the user's most recent active/trial subscription, or null. */
    public function activeSubscriptionFor(int $userId): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM subscriptions
              WHERE user_id = ?
                AND status IN ('trial','active','past_due')
           ORDER BY created_at DESC
              LIMIT 1",
            [$userId]
        );
    }

    /** All subscriptions for a user, newest first. Used by the admin view. */
    public function subscriptionsForUser(int $userId): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM subscriptions WHERE user_id = ? ORDER BY created_at DESC",
            [$userId]
        );
    }

    public function findSubscriptionByGatewayId(string $gateway, string $gatewaySubId): ?array
    {
        return $this->db->fetchOne(
            "SELECT * FROM subscriptions WHERE gateway = ? AND gateway_subscription_id = ?",
            [$gateway, $gatewaySubId]
        );
    }

    public function findSubscription(int $id): ?array
    {
        return $this->db->fetchOne("SELECT * FROM subscriptions WHERE id = ?", [$id]);
    }

    /**
     * Admin listing — paginated, filterable by status. Joins plan name +
     * user email for display.
     *
     * @return array{items: array<int, array<string, mixed>>, total: int}
     */
    public function listSubscriptions(?string $status = null, int $page = 1, int $perPage = 50): array
    {
        $offset = max(0, ($page - 1) * $perPage);
        if ($status && in_array($status, self::STATUSES, true)) {
            $where = "WHERE s.status = ?";
            $bind  = [$status];
        } else {
            $where = "";
            $bind  = [];
        }
        $items = $this->db->fetchAll(
            "SELECT s.*, p.name AS plan_name, u.email AS user_email, u.username
               FROM subscriptions s
          LEFT JOIN subscription_plans p ON p.id = s.plan_id
          LEFT JOIN users u              ON u.id = s.user_id
               $where
           ORDER BY s.created_at DESC
              LIMIT ? OFFSET ?",
            [...$bind, $perPage, $offset]
        );
        $total = (int) $this->db->fetchColumn(
            "SELECT COUNT(*) FROM subscriptions s $where",
            $bind
        );
        return ['items' => $items, 'total' => $total];
    }

    // ── Subscribe flow ────────────────────────────────────────────────────

    /**
     * Create a Stripe Checkout Session for $userId subscribing to $plan.
     * Returns the hosted checkout URL or null on failure.
     *
     * We pre-create a local subscriptions row in status=`incomplete` so we
     * have a handle to correlate the webhook back to when the user
     * completes payment. The webhook handler promotes that row to
     * active/trial and fills in gateway ids.
     *
     * Pragmatic alternative: stash our user_id + plan_id in the Stripe
     * subscription's metadata and look up the local row on webhook.
     * We do that too (belt + suspenders).
     */
    public function startCheckout(array $plan, array $user, string $successUrl, string $cancelUrl): ?string
    {
        if (!$this->stripe->isEnabled()) return null;
        if (empty($plan['gateway_price_id'])) {
            error_log('[subscriptions] plan #' . (int) $plan['id'] . ' has no gateway_price_id — cannot start checkout');
            return null;
        }

        $session = $this->stripe->createCheckoutSession(
            priceId:       (string) $plan['gateway_price_id'],
            successUrl:    $successUrl,
            cancelUrl:     $cancelUrl,
            trialDays:     (int) $plan['trial_days'],
            customerEmail: (string) ($user['email'] ?? ''),
            metadata: [
                'user_id' => (int) $user['id'],
                'plan_id' => (int) $plan['id'],
            ]
        );
        return $session['url'] ?? null;
    }

    // ── Cancel / resume ───────────────────────────────────────────────────

    /**
     * Cancel — by default at period end so the user keeps the access they
     * paid for. The user's local row reflects the pending cancel via
     * cancel_at_period_end=1. Stripe will fire customer.subscription.updated
     * which we also handle to keep state consistent.
     */
    public function cancel(int $subId, bool $atPeriodEnd = true): bool
    {
        $sub = $this->findSubscription($subId);
        if (!$sub || empty($sub['gateway_subscription_id'])) return false;

        $res = $this->stripe->cancelSubscription((string) $sub['gateway_subscription_id'], $atPeriodEnd);
        if (!$res) return false;

        if ($atPeriodEnd) {
            $this->db->update('subscriptions',
                ['cancel_at_period_end' => 1],
                'id = ?', [$subId]
            );
        } else {
            $this->db->update('subscriptions',
                ['status' => 'canceled', 'canceled_at' => date('Y-m-d H:i:s')],
                'id = ?', [$subId]
            );
        }
        return true;
    }

    public function resume(int $subId): bool
    {
        $sub = $this->findSubscription($subId);
        if (!$sub || empty($sub['gateway_subscription_id'])) return false;
        if ((int) $sub['cancel_at_period_end'] !== 1) return true; // nothing to resume

        $res = $this->stripe->resumeSubscription((string) $sub['gateway_subscription_id']);
        if (!$res) return false;

        $this->db->update('subscriptions',
            ['cancel_at_period_end' => 0],
            'id = ?', [$subId]
        );
        return true;
    }

    // ── Webhook dispatch ──────────────────────────────────────────────────

    /**
     * Dispatch a Stripe webhook event. Idempotent — dedupes by event id via
     * the unique key on subscription_events.gateway+event_id. Unknown event
     * types are logged as raw events (no state change) so we don't lose
     * them.
     */
    public function applyWebhookEvent(array $event): void
    {
        $type    = (string) ($event['type']   ?? '');
        $eventId = (string) ($event['id']     ?? '');
        $obj     = $event['data']['object']   ?? [];
        if (!is_array($obj)) $obj = [];

        // Idempotency — INSERT IGNORE on (gateway, event_id).
        $duplicate = $eventId !== '' && $this->db->fetchOne(
            "SELECT id FROM subscription_events WHERE gateway = ? AND event_id = ?",
            ['stripe', $eventId]
        );

        $subId = null;
        switch ($type) {
            case 'checkout.session.completed':
                $subId = $this->handleCheckoutCompleted($obj);
                break;
            case 'customer.subscription.created':
            case 'customer.subscription.updated':
                $subId = $this->handleSubscriptionUpsert($obj);
                break;
            case 'customer.subscription.deleted':
                $subId = $this->handleSubscriptionDeleted($obj);
                break;
            case 'invoice.paid':
                $subId = $this->handleInvoicePaid($obj);
                break;
            case 'invoice.payment_failed':
                $subId = $this->handleInvoiceFailed($obj);
                break;
            default:
                // Unknown / not relevant — still persist for audit.
                break;
        }

        if (!$duplicate) {
            $this->db->insert('subscription_events', [
                'subscription_id' => $subId,
                'gateway'         => 'stripe',
                'event_type'      => substr($type, 0, 100),
                'event_id'        => $eventId !== '' ? substr($eventId, 0, 191) : null,
                'payload_json'    => json_encode($event, JSON_UNESCAPED_SLASHES | JSON_PARTIAL_OUTPUT_ON_ERROR),
            ]);
        }
    }

    /**
     * Checkout session completed → a new subscription starts.
     * The session object carries subscription id, customer id, and our
     * metadata (user_id, plan_id). We create the local row here and
     * subsequent customer.subscription.* events keep it updated.
     */
    private function handleCheckoutCompleted(array $session): ?int
    {
        $gwSubId = (string) ($session['subscription'] ?? '');
        if ($gwSubId === '') return null;

        // Metadata lives on the subscription object, not the session —
        // fetch the subscription to get user_id/plan_id reliably.
        $sub = $this->stripe->retrieveSubscription($gwSubId);
        if (!$sub) return null;

        $userId = (int) ($sub['metadata']['user_id'] ?? 0);
        $planId = (int) ($sub['metadata']['plan_id'] ?? 0);
        if ($userId === 0) return null;

        return $this->upsertSubscription($sub, userId: $userId, planId: $planId);
    }

    /** Subscription created/updated — upsert local row from the payload. */
    private function handleSubscriptionUpsert(array $sub): ?int
    {
        $userId = (int) ($sub['metadata']['user_id'] ?? 0);
        $planId = (int) ($sub['metadata']['plan_id'] ?? 0);

        // If metadata is missing, try to find an existing local row by
        // gateway_subscription_id — covers cases where the user was created
        // outside our app but we're managing the subscription state.
        if ($userId === 0) {
            $existing = $this->findSubscriptionByGatewayId('stripe', (string) ($sub['id'] ?? ''));
            if (!$existing) return null;
            $userId = (int) $existing['user_id'];
            $planId = (int) ($existing['plan_id'] ?? 0);
        }

        return $this->upsertSubscription($sub, userId: $userId, planId: $planId ?: null);
    }

    /** Subscription deleted → mark canceled. */
    private function handleSubscriptionDeleted(array $sub): ?int
    {
        $existing = $this->findSubscriptionByGatewayId('stripe', (string) ($sub['id'] ?? ''));
        if (!$existing) return null;
        $this->db->update('subscriptions',
            [
                'status'      => 'canceled',
                'canceled_at' => date('Y-m-d H:i:s'),
            ],
            'id = ?', [(int) $existing['id']]
        );
        return (int) $existing['id'];
    }

    /** Invoice paid → subscription in good standing; clear any past_due marker. */
    private function handleInvoicePaid(array $invoice): ?int
    {
        $gwSubId = (string) ($invoice['subscription'] ?? '');
        if ($gwSubId === '') return null;
        $existing = $this->findSubscriptionByGatewayId('stripe', $gwSubId);
        if (!$existing) return null;
        $this->db->update('subscriptions',
            [
                'status'             => 'active',
                'last_payment_error' => null,
            ],
            'id = ? AND status <> ?', [(int) $existing['id'], 'canceled']
        );
        return (int) $existing['id'];
    }

    /** Invoice payment failed → past_due; captures the failure reason. */
    private function handleInvoiceFailed(array $invoice): ?int
    {
        $gwSubId = (string) ($invoice['subscription'] ?? '');
        if ($gwSubId === '') return null;
        $existing = $this->findSubscriptionByGatewayId('stripe', $gwSubId);
        if (!$existing) return null;

        $error = substr((string) ($invoice['last_payment_error']['message']
            ?? $invoice['last_finalization_error']['message']
            ?? 'payment failed'), 0, 500);

        $this->db->update('subscriptions',
            [
                'status'             => 'past_due',
                'last_payment_error' => $error,
            ],
            'id = ?', [(int) $existing['id']]
        );
        return (int) $existing['id'];
    }

    /**
     * Common upsert from a Stripe subscription payload. Used by
     * checkout.session.completed and customer.subscription.{created,updated}.
     *
     * Translates Stripe status strings to our local status enum:
     *   trialing → trial
     *   active   → active
     *   past_due → past_due
     *   canceled / incomplete_expired / unpaid → canceled
     *   incomplete → incomplete
     */
    private function upsertSubscription(array $sub, int $userId, ?int $planId): int
    {
        $gwSubId = (string) ($sub['id'] ?? '');
        $status  = $this->mapStatus((string) ($sub['status'] ?? ''));

        $data = [
            'user_id'                 => $userId,
            'plan_id'                 => $planId,
            'gateway'                 => 'stripe',
            'gateway_customer_id'     => (string) ($sub['customer'] ?? ''),
            'gateway_subscription_id' => $gwSubId,
            'status'                  => $status,
            'current_period_start'    => !empty($sub['current_period_start']) ? date('Y-m-d H:i:s', (int) $sub['current_period_start']) : null,
            'current_period_end'      => !empty($sub['current_period_end'])   ? date('Y-m-d H:i:s', (int) $sub['current_period_end'])   : null,
            'cancel_at_period_end'    => !empty($sub['cancel_at_period_end']) ? 1 : 0,
            'trial_ends_at'           => !empty($sub['trial_end'])            ? date('Y-m-d H:i:s', (int) $sub['trial_end'])            : null,
            'canceled_at'             => !empty($sub['canceled_at'])          ? date('Y-m-d H:i:s', (int) $sub['canceled_at'])          : null,
        ];

        $existing = $this->findSubscriptionByGatewayId('stripe', $gwSubId);
        if ($existing) {
            $this->db->update('subscriptions', $data, 'id = ?', [(int) $existing['id']]);
            return (int) $existing['id'];
        }
        return (int) $this->db->insert('subscriptions', $data);
    }

    /**
     * Map Stripe status strings to our narrower enum. Public so tests can
     * exercise the table without a subscription payload.
     */
    public function mapStatus(string $stripeStatus): string
    {
        return match ($stripeStatus) {
            'trialing'                          => 'trial',
            'active'                            => 'active',
            'past_due', 'unpaid'                => 'past_due',
            'canceled', 'incomplete_expired'    => 'canceled',
            default                             => 'incomplete',
        };
    }

    // ── Dunning ───────────────────────────────────────────────────────────

    /**
     * Subscriptions stuck in past_due for > $ageHours. The dunning job
     * uses this to decide which users to notify about a failed payment.
     * Threshold prevents us from spamming users whose payment just failed
     * a minute ago — Stripe's automatic retries should get them first.
     *
     * @return array<int, array<string, mixed>>
     */
    public function pastDueNeedingNotice(int $ageHours = 24): array
    {
        return $this->db->fetchAll(
            "SELECT * FROM subscriptions
              WHERE status = 'past_due'
                AND updated_at <= DATE_SUB(NOW(), INTERVAL ? HOUR)
           ORDER BY updated_at ASC
              LIMIT 100",
            [$ageHours]
        );
    }
}
