<?php
// modules/subscriptions/migrations/2026_04_22_200010_seed_subscriptions_permission.php
use Core\Database\Migration;

/**
 * Seed the `subscriptions.manage` permission so admin roles can be granted
 * the ability to edit plans and oversee subscriptions. Idempotent via
 * INSERT IGNORE on the slug unique key — safe to re-run.
 *
 * No Moderator-style auto-role for subscriptions. Grant this permission
 * to the existing Admin role (or a dedicated "Billing admin" role the
 * app creates) via /admin/roles.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO permissions (name, slug, module, description)
            VALUES (?, ?, ?, ?)
        ", [
            'Manage subscriptions',
            'subscriptions.manage',
            'subscriptions',
            'Create and edit subscription plans; view and cancel subscriptions.',
        ]);
    }

    public function down(): void
    {
        // Don't delete — other roles may reference this permission via
        // role_permissions and a cascade would silently strip their access.
        // If you really need to, clean manually after confirming no grants.
    }
};
