<?php
// modules/subscriptions/migrations/2026_04_22_200020_seed_dunning_scheduled_task.php
use Core\Database\Migration;

/**
 * Seed a scheduled_tasks row that runs DunningJob daily at 09:00.
 *
 * 09:00 local is generally a reasonable time for dunning emails — better
 * inbox visibility than overnight, not disruptive mid-workday. Override
 * the schedule later via `/admin/scheduled-tasks` or directly updating
 * the row if your audience is in a different timezone.
 *
 * Idempotent via INSERT IGNORE on the unique `name` column.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            INSERT IGNORE INTO scheduled_tasks
                (name, class, payload, schedule_expression, queue, enabled, next_run_at)
            VALUES
                (?, ?, ?, ?, ?, 1, NOW())
        ", [
            'subscriptions-dunning',
            \Modules\Subscriptions\Jobs\DunningJob::class,
            json_encode([]),
            '0 9 * * *',
            'default',
        ]);
    }

    public function down(): void
    {
        $this->db->query("DELETE FROM scheduled_tasks WHERE name = ?", ['subscriptions-dunning']);
    }
};
