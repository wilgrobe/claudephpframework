<?php
// modules/subscriptions/migrations/2026_04_22_200000_create_subscriptions_tables.php
use Core\Database\Migration;

/**
 * Schema for the subscriptions module. Three tables:
 *
 *   subscription_plans    — admin-managed catalog of purchasable plans.
 *                           Each row links our internal plan id to a
 *                           gateway-side price id (e.g. Stripe price_xxx).
 *
 *   subscriptions         — one row per user's subscription. Mirrors Stripe's
 *                           subscription object (current_period_*, status,
 *                           cancel_at_period_end) so we can render the user's
 *                           billing state without hitting the gateway API on
 *                           every page load.
 *
 *   subscription_events   — append-only audit trail of every webhook we
 *                           processed. Useful for debugging a customer's
 *                           dispute or reconstructing why a subscription
 *                           moved to past_due.
 *
 * Status enum:
 *   incomplete — checkout started, payment not yet confirmed
 *   trial      — active during a trial period, not yet billed
 *   active     — billed successfully, subscription in good standing
 *   past_due   — most recent invoice failed; retrying
 *   canceled   — subscription has ended (by user or gateway)
 *
 * Matches Stripe's lifecycle semantics closely, which makes webhook
 * mapping straightforward.
 */
return new class extends Migration {
    public function up(): void
    {
        $this->db->query("
            CREATE TABLE subscription_plans (
                id               INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                name             VARCHAR(191) NOT NULL,
                slug             VARCHAR(120) NOT NULL,
                description      TEXT         NULL,
                amount_cents     INT UNSIGNED NOT NULL,
                currency         VARCHAR(8)   NOT NULL DEFAULT 'USD',
                `interval`       ENUM('day','week','month','year') NOT NULL DEFAULT 'month',
                interval_count   INT UNSIGNED NOT NULL DEFAULT 1,
                trial_days       INT UNSIGNED NOT NULL DEFAULT 0,
                gateway          VARCHAR(32)  NOT NULL DEFAULT 'stripe',
                gateway_price_id VARCHAR(191) NULL,
                active           TINYINT(1)   NOT NULL DEFAULT 1,
                sort_order       INT          NOT NULL DEFAULT 0,
                created_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uq_slug (slug),
                KEY idx_active_sort (active, sort_order),
                KEY idx_gateway_price (gateway, gateway_price_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE subscriptions (
                id                      BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                user_id                 INT UNSIGNED NOT NULL,
                plan_id                 INT UNSIGNED NULL,
                gateway                 VARCHAR(32)  NOT NULL DEFAULT 'stripe',
                gateway_customer_id     VARCHAR(191) NULL,
                gateway_subscription_id VARCHAR(191) NULL,
                status                  ENUM('incomplete','trial','active','past_due','canceled') NOT NULL DEFAULT 'incomplete',
                current_period_start    DATETIME     NULL,
                current_period_end      DATETIME     NULL,
                cancel_at_period_end    TINYINT(1)   NOT NULL DEFAULT 0,
                trial_ends_at           DATETIME     NULL,
                canceled_at             DATETIME     NULL,
                last_payment_error      VARCHAR(500) NULL,
                created_at              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
                updated_at              DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

                UNIQUE KEY uq_gateway_sub_id (gateway, gateway_subscription_id),
                KEY idx_user          (user_id, status),
                KEY idx_status        (status),
                KEY idx_period_end    (current_period_end),
                KEY idx_plan          (plan_id),
                CONSTRAINT fk_sub_plan FOREIGN KEY (plan_id)
                    REFERENCES subscription_plans (id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");

        $this->db->query("
            CREATE TABLE subscription_events (
                id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                subscription_id BIGINT UNSIGNED NULL,
                gateway         VARCHAR(32)  NOT NULL DEFAULT 'stripe',
                event_type      VARCHAR(100) NOT NULL,
                event_id        VARCHAR(191) NULL,
                payload_json    JSON         NOT NULL,
                occurred_at     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,

                UNIQUE KEY uq_event_id (gateway, event_id),
                KEY idx_subscription (subscription_id, occurred_at),
                KEY idx_event_type   (event_type, occurred_at),
                CONSTRAINT fk_event_sub FOREIGN KEY (subscription_id)
                    REFERENCES subscriptions (id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    public function down(): void
    {
        $this->db->query("DROP TABLE IF EXISTS subscription_events");
        $this->db->query("DROP TABLE IF EXISTS subscriptions");
        $this->db->query("DROP TABLE IF EXISTS subscription_plans");
    }
};
