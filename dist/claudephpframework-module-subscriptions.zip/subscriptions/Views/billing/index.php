<?php $pageTitle = 'Billing'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="max-width:760px;margin:0 auto">
    <h1 style="margin-bottom:1.5rem">Billing</h1>

    <?php if ($current): ?>
    <!-- Current subscription block -->
    <div class="card" style="margin-bottom:1.5rem">
        <div class="card-header">
            <h2 style="font-size:1.125rem">Your subscription</h2>
            <?php
            $badgeMap = ['active' => 'success', 'trial' => 'info', 'past_due' => 'warning', 'canceled' => 'gray'];
            $class = 'badge-' . ($badgeMap[$current['status']] ?? 'gray');
            ?>
            <span class="badge <?= $class ?>"><?= e(str_replace('_', ' ', $current['status'])) ?></span>
        </div>
        <div class="card-body">
            <?php if ($currentPlan): ?>
            <div style="font-size:1.1rem"><strong><?= e($currentPlan['name']) ?></strong></div>
            <div style="color:#6b7280;font-size:14px">
                <?= number_format($currentPlan['amount_cents'] / 100, 2) ?> <?= e($currentPlan['currency']) ?>
                every <?= (int) $currentPlan['interval_count'] === 1 ? e($currentPlan['interval']) : (int) $currentPlan['interval_count'] . ' ' . e($currentPlan['interval']) . 's' ?>
            </div>
            <?php endif; ?>

            <?php if ($current['status'] === 'trial' && !empty($current['trial_ends_at'])): ?>
            <p style="margin-top:1rem;color:#0369a1;font-size:14px">
                Your trial ends <strong><?= e(date('M j, Y', strtotime($current['trial_ends_at']))) ?></strong>.
                Billing will begin then.
            </p>
            <?php endif; ?>

            <?php if ($current['status'] === 'past_due'): ?>
            <div style="margin-top:1rem;padding:.75rem;background:#fff7ed;border:1px solid #fed7aa;border-radius:6px;color:#9a3412;font-size:14px">
                <strong>Payment failed.</strong>
                Please update your payment method in your Stripe account to avoid service interruption.
                <?php if (!empty($current['last_payment_error'])): ?>
                <div style="font-size:12px;margin-top:.35rem;color:#7c2d12"><?= e((string) $current['last_payment_error']) ?></div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if (!empty($current['current_period_end'])): ?>
            <div style="margin-top:1rem;color:#6b7280;font-size:13px">
                <?php if ((int) $current['cancel_at_period_end'] === 1): ?>
                Ends on <?= e(date('M j, Y', strtotime($current['current_period_end']))) ?>. Won't renew.
                <?php elseif (in_array($current['status'], ['active', 'trial'], true)): ?>
                Next billed on <?= e(date('M j, Y', strtotime($current['current_period_end']))) ?>.
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div style="margin-top:1rem;display:flex;gap:.5rem">
                <?php if ((int) $current['cancel_at_period_end'] === 1): ?>
                <form method="POST" action="/billing/resume">
                    <?= csrf_field() ?><button class="btn btn-primary btn-sm">Resume subscription</button>
                </form>
                <?php elseif (in_array($current['status'], ['active', 'trial', 'past_due'], true)): ?>
                <form method="POST" action="/billing/cancel-subscription"
                      data-confirm="Cancel your subscription? It stays active until <?= $current['current_period_end'] ? e(date('M j, Y', strtotime($current['current_period_end']))) : 'the end of the current period' ?>.">
                    <?= csrf_field() ?><button class="btn btn-sm btn-secondary">Cancel subscription</button>
                </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if (empty($current) || !in_array($current['status'], ['active', 'trial'], true)): ?>
    <!-- Plan catalog for new or re-subscribing users -->
    <div class="card">
        <div class="card-header"><h2 style="font-size:1.125rem"><?= $current ? 'Re-subscribe' : 'Choose a plan' ?></h2></div>
        <div class="card-body">
            <?php if (empty($plans)): ?>
            <p style="color:#6b7280">No plans are available right now. Please check back later.</p>
            <?php else: ?>
            <div style="display:grid;gap:1rem;grid-template-columns:repeat(auto-fit, minmax(240px, 1fr))">
                <?php foreach ($plans as $p): ?>
                <div style="border:1px solid #e5e7eb;border-radius:8px;padding:1.25rem">
                    <h3 style="margin:0 0 .5rem 0;font-size:1.1rem"><?= e($p['name']) ?></h3>
                    <div style="margin-bottom:.75rem">
                        <span style="font-size:1.5rem;font-weight:600"><?= number_format($p['amount_cents'] / 100, 2) ?></span>
                        <span style="color:#6b7280;font-size:13px"><?= e($p['currency']) ?> / <?= e($p['interval']) ?></span>
                    </div>
                    <?php if (!empty($p['description'])): ?>
                    <p style="color:#4b5563;font-size:14px;margin:0 0 1rem 0"><?= nl2br(e($p['description'])) ?></p>
                    <?php endif; ?>
                    <?php if ((int) $p['trial_days'] > 0): ?>
                    <div style="color:#0369a1;font-size:12px;margin-bottom:.75rem"><?= (int) $p['trial_days'] ?>-day free trial</div>
                    <?php endif; ?>
                    <form method="POST" action="/billing/subscribe/<?= e($p['slug']) ?>">
                        <?= csrf_field() ?>
                        <button class="btn btn-primary" style="width:100%"<?= empty($p['gateway_price_id']) ? ' disabled title="Plan missing Stripe price id"' : '' ?>>
                            Subscribe
                        </button>
                    </form>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
