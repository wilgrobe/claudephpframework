<?php $pageTitle = 'Subscription Plans'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h2>Subscription Plans</h2>
        <div style="display:flex;gap:.35rem">
            <a href="/admin/subscriptions" class="btn btn-sm btn-secondary">View subscriptions</a>
            <a href="/admin/subscription-plans/create" class="btn btn-sm btn-primary">+ New plan</a>
        </div>
    </div>

    <?php if (empty($plans)): ?>
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">
        No plans yet. Create one and paste the matching Stripe <code>price_xxx</code> id to enable checkout.
    </div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead>
                <tr><th>Name</th><th>Price</th><th>Interval</th><th>Trial</th><th>Stripe ID</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
            <?php foreach ($plans as $p): ?>
            <tr>
                <td>
                    <strong><?= e($p['name']) ?></strong>
                    <div style="font-size:12px;color:#9ca3af"><code><?= e($p['slug']) ?></code></div>
                </td>
                <td style="white-space:nowrap">
                    <?= number_format($p['amount_cents'] / 100, 2) ?>
                    <span style="color:#6b7280;font-size:12px"><?= e($p['currency']) ?></span>
                </td>
                <td><?= (int) $p['interval_count'] ?> <?= e($p['interval']) ?><?= (int) $p['interval_count'] === 1 ? '' : 's' ?></td>
                <td><?= (int) $p['trial_days'] ?> days</td>
                <td>
                    <?php if (!empty($p['gateway_price_id'])): ?>
                    <code style="font-size:11px"><?= e($p['gateway_price_id']) ?></code>
                    <?php else: ?>
                    <span class="badge badge-warning" title="Plan cannot start checkout without a Stripe price id">⚠ missing</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?= (int) $p['active'] === 1
                        ? '<span class="badge badge-success">Active</span>'
                        : '<span class="badge badge-gray">Inactive</span>' ?>
                </td>
                <td>
                    <div style="display:flex;gap:.35rem">
                        <a href="/admin/subscription-plans/<?= (int) $p['id'] ?>/edit" class="btn btn-xs btn-secondary">Edit</a>
                        <form method="POST" action="/admin/subscription-plans/<?= (int) $p['id'] ?>/delete"
                              data-confirm="Delete plan '<?= e($p['name']) ?>'? Existing subscriptions will keep running but lose the catalog reference.">
                            <?= csrf_field() ?><button class="btn btn-xs btn-danger">Delete</button>
                        </form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
