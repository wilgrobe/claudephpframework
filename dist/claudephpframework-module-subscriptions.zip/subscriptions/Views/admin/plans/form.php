<?php
$isEdit    = !empty($plan);
$pageTitle = $isEdit ? 'Edit plan: ' . $plan['name'] : 'New plan';
$errors    = \Core\Session::get('errors', []);
$old       = \Core\Session::get('old', []);
$val       = fn(string $k, string $default = '') => e($old[$k] ?? ($plan[$k] ?? $default));
?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div style="display:flex;align-items:center;gap:1rem;margin-bottom:1rem">
    <a href="/admin/subscription-plans" class="btn btn-sm btn-secondary">← Back</a>
    <h1 style="margin:0;font-size:1.5rem"><?= $isEdit ? 'Edit plan' : 'New plan' ?></h1>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?= $isEdit ? '/admin/subscription-plans/' . (int) $plan['id'] . '/edit' : '/admin/subscription-plans/create' ?>">
            <?= csrf_field() ?>

            <div class="form-row">
                <label>Name *</label>
                <input type="text" name="name" value="<?= $val('name') ?>" required maxlength="191">
            </div>

            <div class="form-row">
                <label>Slug *</label>
                <input type="text" name="slug" value="<?= $val('slug') ?>" required maxlength="120" pattern="[a-z0-9-]+">
                <small>URL-safe identifier used by <code>/billing/subscribe/{slug}</code>.</small>
            </div>

            <div class="form-row">
                <label>Description</label>
                <textarea name="description" rows="3"><?= $val('description') ?></textarea>
            </div>

            <div style="display:flex;gap:1rem">
                <div class="form-row" style="flex:2">
                    <label>Amount (cents) *</label>
                    <input type="number" name="amount_cents" value="<?= $val('amount_cents', '0') ?>" required min="0">
                    <small>e.g. 999 = $9.99. Stripe uses smallest currency unit.</small>
                </div>
                <div class="form-row" style="flex:1">
                    <label>Currency *</label>
                    <input type="text" name="currency" value="<?= $val('currency', 'USD') ?>" required maxlength="8" style="text-transform:uppercase">
                </div>
            </div>

            <div style="display:flex;gap:1rem">
                <div class="form-row" style="flex:1">
                    <label>Interval *</label>
                    <select name="interval">
                        <?php foreach (['month', 'year', 'week', 'day'] as $iv): ?>
                        <option value="<?= $iv ?>" <?= ($old['interval'] ?? $plan['interval'] ?? 'month') === $iv ? 'selected' : '' ?>><?= ucfirst($iv) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-row" style="flex:1">
                    <label>Interval count</label>
                    <input type="number" name="interval_count" value="<?= $val('interval_count', '1') ?>" min="1">
                    <small>e.g. 3 + month = billed every 3 months.</small>
                </div>
                <div class="form-row" style="flex:1">
                    <label>Trial days</label>
                    <input type="number" name="trial_days" value="<?= $val('trial_days', '0') ?>" min="0">
                </div>
            </div>

            <div class="form-row">
                <label>Stripe price id</label>
                <input type="text" name="gateway_price_id" value="<?= $val('gateway_price_id') ?>" placeholder="price_1AbCDeFgHiJkLmN" maxlength="191">
                <small>
                    Create the matching Price in your Stripe dashboard (Products → Add price)
                    and paste the id here. Without it this plan can't start a checkout.
                </small>
            </div>

            <div style="display:flex;gap:1rem">
                <div class="form-row" style="flex:1">
                    <label>Sort order</label>
                    <input type="number" name="sort_order" value="<?= $val('sort_order', '0') ?>">
                </div>
                <div class="form-row" style="flex:1;display:flex;align-items:flex-end">
                    <label>
                        <input type="checkbox" name="active" value="1" <?= (!$isEdit || (int) ($plan['active'] ?? 1) === 1) ? 'checked' : '' ?>>
                        Active
                    </label>
                </div>
            </div>

            <div style="margin-top:1rem">
                <button class="btn btn-primary">Save</button>
            </div>
        </form>
    </div>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
