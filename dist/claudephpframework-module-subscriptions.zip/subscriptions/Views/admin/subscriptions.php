<?php $pageTitle = 'Subscriptions'; ?>
<?php include BASE_PATH . '/app/Views/layout/header.php'; ?>

<div class="card">
    <div class="card-header">
        <h2>Subscriptions</h2>
        <a href="/admin/subscription-plans" class="btn btn-sm btn-secondary">Plans →</a>
    </div>

    <div style="padding:.75rem 1.25rem;border-bottom:1px solid #e5e7eb;display:flex;gap:.5rem;flex-wrap:wrap">
        <a href="/admin/subscriptions" class="btn btn-sm <?= empty($status) ? 'btn-primary' : 'btn-secondary' ?>">All</a>
        <?php foreach (['active', 'trial', 'past_due', 'canceled', 'incomplete'] as $s): ?>
        <a href="?status=<?= e($s) ?>" class="btn btn-sm <?= $status === $s ? 'btn-primary' : 'btn-secondary' ?>">
            <?= ucfirst(str_replace('_', ' ', $s)) ?>
            <span style="opacity:.7;margin-left:.25rem">(<?= (int) ($counts[$s] ?? 0) ?>)</span>
        </a>
        <?php endforeach; ?>
    </div>

    <?php if (empty($items)): ?>
    <div class="card-body" style="text-align:center;padding:3rem 1rem;color:#6b7280">No subscriptions in this status.</div>
    <?php else: ?>
    <div class="table-responsive">
        <table class="table">
            <thead><tr><th>User</th><th>Plan</th><th>Status</th><th>Period end</th><th>Gateway</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($items as $s): ?>
            <tr>
                <td>
                    <?php if (!empty($s['username'])): ?>
                    <strong><?= e($s['username']) ?></strong>
                    <div style="font-size:12px;color:#9ca3af"><?= e((string) $s['user_email']) ?></div>
                    <?php else: ?>
                    <span style="color:#9ca3af">user #<?= (int) $s['user_id'] ?></span>
                    <?php endif; ?>
                </td>
                <td>
                    <?= e($s['plan_name'] ?? '(unlinked)') ?>
                </td>
                <td>
                    <?php
                    $badgeMap = ['active' => 'success', 'trial' => 'info', 'past_due' => 'warning', 'canceled' => 'gray', 'incomplete' => 'gray'];
                    $class = 'badge-' . ($badgeMap[$s['status']] ?? 'gray');
                    ?>
                    <span class="badge <?= $class ?>"><?= e(str_replace('_', ' ', $s['status'])) ?></span>
                    <?php if ((int) $s['cancel_at_period_end'] === 1): ?>
                    <div style="font-size:11px;color:#b45309;margin-top:.15rem">cancels at period end</div>
                    <?php endif; ?>
                </td>
                <td style="font-size:12px;color:#6b7280;white-space:nowrap">
                    <?= $s['current_period_end'] ? e(date('M j, Y', strtotime((string) $s['current_period_end']))) : '—' ?>
                </td>
                <td style="font-size:11px">
                    <?php if (!empty($s['gateway_subscription_id'])): ?>
                    <code><?= e($s['gateway_subscription_id']) ?></code>
                    <?php else: ?>
                    <span style="color:#9ca3af">—</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php if (in_array($s['status'], ['active', 'trial', 'past_due'], true)): ?>
                    <form method="POST" action="/admin/subscriptions/<?= (int) $s['id'] ?>/cancel"
                          data-confirm="Cancel subscription #<?= (int) $s['id'] ?> at period end?">
                        <?= csrf_field() ?><button class="btn btn-xs btn-warning">Cancel</button>
                    </form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php endif; ?>
</div>

<?php include BASE_PATH . '/app/Views/layout/footer.php'; ?>
