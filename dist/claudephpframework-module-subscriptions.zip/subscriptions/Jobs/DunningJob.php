<?php
// modules/subscriptions/Jobs/DunningJob.php
namespace Modules\Subscriptions\Jobs;

use Core\Database\Database;
use Core\Queue\Job;
use Core\Services\MailService;
use Modules\Subscriptions\Services\SubscriptionService;

/**
 * Dunning digest for past-due subscribers.
 *
 * Runs daily via a seeded scheduled_tasks row. For each subscription stuck
 * in past_due for > 24h (Stripe's own retry window), sends the user an
 * email nudging them to update their payment method.
 *
 * The email just links back to /billing — users click, see the "past due"
 * banner, click Update payment method, and Stripe's billing portal handles
 * the actual credential update. (Wiring the billing portal endpoint is a
 * v2 nicety; for now the link to /billing is where the banner appears.)
 *
 * Idempotent across reruns: we stamp `last_payment_error` with "[reminder sent]"
 * on the first run so a second run the same day doesn't re-notify. Stripe
 * webhook arriving with success (invoice.paid → status=active) clears the
 * marker.
 */
class DunningJob extends Job
{
    public function handle(): void
    {
        $svc  = new SubscriptionService();
        $db   = Database::getInstance();
        $mail = new MailService();

        $pastDue = $svc->pastDueNeedingNotice(ageHours: 24);

        foreach ($pastDue as $sub) {
            // Idempotency marker — skip if we've already notified today.
            $err = (string) ($sub['last_payment_error'] ?? '');
            if (str_contains($err, '[reminder sent]')) continue;

            $user = $db->fetchOne(
                "SELECT id, email, username, first_name FROM users WHERE id = ?",
                [(int) $sub['user_id']]
            );
            if (!$user || empty($user['email'])) continue;

            $name = $user['first_name'] ?: $user['username'] ?: 'there';
            $subject = 'Action needed: your subscription payment failed';
            $body    = "Hi $name,\n\n"
                     . "We couldn't process the most recent payment for your subscription. "
                     . "Your account is still active for now, but it will be suspended if "
                     . "we can't collect payment soon.\n\n"
                     . "Please update your payment method at:\n"
                     . (string) ($_ENV['APP_URL'] ?? '') . "/billing\n\n"
                     . "If you already updated it, you can ignore this message.";
            $html    = nl2br(htmlspecialchars($body, ENT_QUOTES));

            try {
                $mail->send((string) $user['email'], $subject, $html, $body);
            } catch (\Throwable $e) {
                error_log('[dunning] failed to mail user #' . $user['id'] . ': ' . $e->getMessage());
                continue;
            }

            // Mark so we don't re-notify the same subscription later today.
            // Truncate to fit column; append the marker to whatever reason
            // Stripe gave us.
            $newErr = substr($err ? "$err [reminder sent]" : '[reminder sent]', 0, 500);
            $db->update('subscriptions',
                ['last_payment_error' => $newErr],
                'id = ?', [(int) $sub['id']]
            );
        }
    }
}
